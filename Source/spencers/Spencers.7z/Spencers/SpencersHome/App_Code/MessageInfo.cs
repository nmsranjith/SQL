﻿
/// <summary>
/// Summary description for MessageInfo
/// </summary>
public enum MessageInfo
{
    Error,Information
}
