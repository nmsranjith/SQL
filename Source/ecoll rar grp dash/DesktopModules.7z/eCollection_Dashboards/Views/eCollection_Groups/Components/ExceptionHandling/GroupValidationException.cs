﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DotNetNuke.Modules.eCollection_Groups.Components.ExceptionHandling
{
    public class GroupValidationException:Exception
    {
        private string _message;
        private MyEnums.CrudState _errorState;

        public GroupValidationException(string message)
            : base(message)
        {
            this._message = message;
        }

        public GroupValidationException(string message, MyEnums.CrudState errorState)
            : base(message)
        {
            this._message = message;
            this._errorState = errorState;
        }
        
        public string getErrorMessage()
        {
            return this._message;
        }

        public MyEnums.CrudState getErrorState()
        {
            return _errorState;
        }
    }
}