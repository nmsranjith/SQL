﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DotNetNuke.Entities.Content;

namespace DotNetNuke.Modules.eCollection_Groups.Components.Modal
{
    public class Messages : ContentItem
    {
        private string _messagecode;
        private string _messagedesc;

        public string MessageCode
        {
            get
            {
                return _messagecode;
            }
            set { _messagecode = value; }
        }

        public string MessageDesc
        {
            get
            {
                return _messagedesc;
            }
            set { _messagedesc = value; }
        }

        public override void Fill(System.Data.IDataReader dr)
        {
            MessageCode = dr["MESSAGE_CODE"] as string;
            MessageDesc = dr["MESSAGE_DESCRIPTION"] as string;
        }
    }
}