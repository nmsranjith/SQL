﻿using System;
using DotNetNuke.Common;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DotNetNuke.Modules.eCollection_Dashboards.Components.Model;
using System.Data;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using DotNetNuke.Modules.eCollection_Dashboards.Components.Common;
using System.Configuration;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Instrumentation;

namespace DotNetNuke.Modules.eCollection_Dashboards.Views
{
    // --------------------------------------------------------------------------------------------------------------------
    // <copyright file="SubscriptionsList" company="CENGAGE LEARNING AUSTRALIA PTY LIMITED">
    //    Copyright (c) 2014 CENGAGE LEARNING AUSTRALIA PTY LIMITED
    // </copyright>
    // <summary>
    //    Displays all the personal and school subscriptions of current academic year and future inactive subscriptions.
    // </summary>
    // ---------------------------------------------------------------------------------------------------------------------
    public partial class SubscriptionsList : eCollection_DashboardsModuleBase
    {
        AdmAuthentication admAuthentication;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                FillSubscription();
            _dashboardController.ClearAllCache();
        }

        /// <summary>
        /// 
        /// </summary>
        protected void FillSubscription()
        {
            try
            {
                if (SubsList.Rows.Count == 1)
                    SubsHeadingid.Visible = false;
                else
                    SubsHeadingid.Visible = true;
                DataTable subList = _dashboardController.GetSubscriptionsList(new Users()
                                            {
                                                UserLoginName = Session["UserName"].ToString(),
                                                Active = 'Y'
                                            });
               
                var subst = (from subs in subList.AsEnumerable()
                             select subs.Field<string>("SubscriptionType")).ToList().Distinct();
             
                List<Subscription> subsHeaderList = new List<Subscription>();
                subst.ToList().ForEach(x => subsHeaderList.Add(new Subscription() { SubscriptionType = x }));
               

                //LogFileWrite(new Exception("rarExists" + rarExists.AsEnumerable().Count()));
                //if (rarExists.AsEnumerable().Count() > 0)
                //{
                //    //var AppLink = rarExists.AsEnumerable().Select(u => u.Field<string>("AppLink")).FirstOrDefault();
                //    //LogFileWrite(new Exception("AppLink" + AppLink));
                //    //AdmAuthentication.DatamarketAccessUri = ConfigurationManager.AppSettings["RARSERVICEURL"];
                //    //admAuthentication = new AdmAuthentication(LoginName, Password);
                //    //AdmAccessToken tokens = admAuthentication.GetAccessToken();
                //    //LogFileWrite(new Exception("access_token" + tokens.access_token));
                //    //LogFileWrite(new Exception("expires_in" + tokens.expires_in));
                //    //LogFileWrite(new Exception("refresh_token" + tokens.refresh_token));
                //    //LogFileWrite(new Exception("token_type" + tokens.token_type));
                //    //AppUrl.Value = "?token=" + tokens.access_token + "&rtoken=" + tokens.refresh_token;
                //    //Session["RARAppLink"] = AppLink + AppUrl.Value;
                //    //_dashboardController.UpdateToken(LoginName, tokens.access_token);
                //}
                if (subsHeaderList.Count == 0)
                {
                    SubstopDiv.Style.Add("Display", "none");
                    MessageOuterDiv.Style.Add("Display", "block");
                    Message1.Text = Constants.NOSUBSCRIPTIONSINFO;
                    CreateLink.NavigateUrl = (new Uri(Request.Url.AbsoluteUri)).Host;
                }
                else
                {
                    MessageOuterDiv.Style.Add("Display", "none");
                    SubscriptionTypeRptr.DataSource = subsHeaderList;
                    SubscriptionTypeRptr.DataBind();
                }


            }
            catch (Exception ex)
            {
                LogFileWrite(ex);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void UseButton_Click(object sender, EventArgs e)
        {
            try
            {
                string IsRAR = (sender as Button).CommandName;
                _dashboardController.ClearAllCache();
                if (IsRAR == "Y")
                {
                    DataTable subList = _dashboardController.GetSubscriptionsList(new Users()
                    {
                        UserLoginName = Session["UserName"].ToString(),
                        Active = 'Y'
                    });
                    var rarExists = subList.AsEnumerable().Where(u => u.Field<string>("ISRAR") == "Y");
                    var AppLink = rarExists.AsEnumerable().Select(u => u.Field<string>("AppLink")).FirstOrDefault();
                   
                    AdmAuthentication.DatamarketAccessUri = ConfigurationManager.AppSettings["RARSERVICEURL"];
                    admAuthentication = new AdmAuthentication(LoginName, Password);
                    AdmAccessToken tokens = admAuthentication.GetAccessToken();
                   
                    DateTime origin = new DateTime(1970, 1, 1, 0, 0, 0, 0);
                    
                    TimeSpan diff = Convert.ToDateTime(tokens.expires) - origin;
                 
                    _dashboardController.UpdateToken(LoginName, tokens.access_token, Null.SetNullInteger(Math.Floor(diff.TotalSeconds)), Null.SetNullInteger((sender as Button).CommandArgument));
                    string url = AppLink.Contains('?') ? string.Concat(AppLink, "&token=", tokens.access_token, "&rtoken=", tokens.refresh_token) : (AppLink.EndsWith("/")? string.Concat(AppLink, "?token=", tokens.access_token, "&rtoken=", tokens.refresh_token):string.Concat(AppLink, "/?token=", tokens.access_token, "&rtoken=", tokens.refresh_token));
                    Response.Redirect(url);

                }
                else
                {
                    Session["Subscription"] = (sender as Button).CommandArgument;
                    Session["AddedStudentList"] = null;
                    Session["AddedStudentCount"] = null;
                }

                Response.Redirect(Globals.NavigateURL(PortalSettings.ActiveTab.TabID) + "?pagename=" + DASHBOARD);
            }
            catch (Exception ex)
            {
                LogFileWrite(ex);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void SubscriptionTypeRptr_ItemDataBound(object sender, System.Web.UI.WebControls.RepeaterItemEventArgs e)
        {
            try
            {
                Repeater subsListRptr = e.Item.FindControl("SubsListRptr") as Repeater;
                HtmlGenericControl subsHeader = e.Item.FindControl("SubscriptionType") as HtmlGenericControl;
                EnumerableRowCollection<DataRow> query = _dashboardController.GetSubscriptionsList(new Users()
                                            {
                                                UserLoginName = Session["UserName"].ToString(),
                                                Active = 'Y'
                                            }).AsEnumerable().Where(x => x.Field<string>("SubscriptionType") == subsHeader.InnerText.Trim());
                subsListRptr.DataSource = query.AsDataView();
                subsListRptr.DataBind();
            }
            catch (Exception ex) { LogFileWrite(ex); }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void SubsListRptr_ItemDataBound(object sender, System.Web.UI.WebControls.RepeaterItemEventArgs e)
        {
            try
            {
                HiddenField isQtyless = e.Item.FindControl("IsQtyless") as HiddenField;
                HiddenField custsubsskhdn = e.Item.FindControl("custsubsskhdn") as HiddenField;
                Literal useBtnclass = e.Item.FindControl("UseBtnclass") as Literal;
                HtmlGenericControl raBtnContainer = e.Item.FindControl("Btncontainer") as HtmlGenericControl;
                HiddenField reActivate = e.Item.FindControl("ReActivateBtnClsName") as HiddenField;
                DnnLog.Error("useBtnclass: " + useBtnclass.Text);
                if (isQtyless.Value.Trim().Equals("Y"))
                {
                    //HtmlAnchor appLink = e.Item.FindControl("AppLink") as HtmlAnchor;
                    //string rarApp = appLink.HRef;

                    //Button ecollBtn = e.Item.FindControl("SubsUseButton") as Button;

                    //if (_dashboardController.GetAllrenewels(Null.SetNullInteger(ecollBtn.CommandArgument)).Count == 0)
                    //{

                    //    rarApp = rarApp + AppUrl.Value + "&subid=" + custsubsskhdn.Value;
                    //    appLink.HRef = rarApp;
                    //    appLink.Visible = true;
                    //    raBtnContainer.Attributes.Add("class", "SubsManageDiv "+ useBtnclass.Text +" RarBtncont");
                    //    ecollBtn.Visible = false;
                    //}
                    //else
                    //    raBtnContainer.Attributes["class"] = "SubsManageDiv " + useBtnclass.Text;
                    HtmlGenericControl qtyLsRenewContainer = e.Item.FindControl("QtyLsRenewContainer") as HtmlGenericControl;
                    if (reActivate.Value.ToLower() == "hideitems")
                    {

                        Literal isEligible = e.Item.FindControl("IsEligible") as Literal;

                        qtyLsRenewContainer.Visible = isEligible.Text.Trim().Equals("Y");
                        HtmlGenericControl expiryCont = e.Item.FindControl("ExpiryCont") as HtmlGenericControl;
                        Literal showExpiredDays = e.Item.FindControl("showExpiredDays") as Literal;
                        expiryCont.Visible = int.Parse(showExpiredDays.Text) <= int.Parse(ConfigurationManager.AppSettings["RAREXPIRYALERT"]) && int.Parse(showExpiredDays.Text) >= 0;

                        HtmlGenericControl renewContainer = e.Item.FindControl("renewContainer") as HtmlGenericControl;

                        renewContainer.Visible = false;
                    }
                    else
                        qtyLsRenewContainer.Visible = false;
                }

                    raBtnContainer.Attributes["class"] = "SubsManageDiv " + useBtnclass.Text;
            }
            catch (Exception ex) { LogFileWrite(ex); }
        }
        protected void SubsListRptr_ItemCommand(object sender, RepeaterCommandEventArgs e)
        {
            //if (e.CommandName == manageTag)
            //    NavigateToView(MANAGELICENSE_VIEW);

            //Repeater SubscriptionTypeRptr1 = (Repeater)e.Item.FindControl("SubscriptionTypeRptr");

            if (e.CommandName == "RENEW")
            {
                Repeater SubsListRptr1 = (Repeater)e.Item.FindControl("SubsListRptr");
                HiddenField custsubsskhdn1 = (HiddenField)e.Item.FindControl("custsubsskhdn");

                Session["eCollRenewSubsSk"] = custsubsskhdn1.Value;
                renewPanePlaceHolder.Controls.Add(Page.LoadControl("DesktopModules/Subscriptions/Views/eCollectionRenew.ascx"));
                ScriptManager.RegisterStartupScript(Page, typeof(Page), "popupNonTrialrenew", "ecollpopuprenewal(1);", true);
            }

            //if (e.CommandName == visitTag)
            //    NavigateToView(string.Empty);

        }
    }
}