﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DotNetNuke.Modules.eCollection_Dashboards.Components.Model
{
    public class APIClientProvider
    {
    }
}