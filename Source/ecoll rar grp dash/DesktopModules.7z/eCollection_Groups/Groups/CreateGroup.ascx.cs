﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DotNetNuke.Common;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Modules.eCollection_Groups.Components;
using DotNetNuke.Modules.eCollection_Groups.Components.Common;
using _IDCollection = DotNetNuke.Modules.eCollection_Groups.Components.Common.IDCollection;
using DotNetNuke.Modules.eCollection_Groups.Components.Modal;
using DotNetNuke.Modules.eCollection_Groups.Components.ExceptionHandling;
using DotNetNuke.Modules.eCollection_Students.Components.Controllers;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Instrumentation;

namespace DotNetNuke.Modules.eCollection_Groups.Groups
{
    // --------------------------------------------------------------------------------------------------------------------
    // <copyright file="CreateGroup" company="CENGAGE LEARNING AUSTRALIA PTY LIMITED">
    //    Copyright (c) 2014 CENGAGE LEARNING AUSTRALIA PTY LIMITED
    // </copyright>
    // <summary>
    //   This screen is used for creating Classes/Groups
    // </summary>
    // ------------------------------------------------------------------------------------------------------------------------------

    public partial class CreateGroup : eCollection_GroupsModuleBase
    {
        private SortDirection StudentSortDirection
        {
            get
            {
                if (Session["StudentSortDirection"] == null)
                    Session["StudentSortDirection"] = SortDirection.Ascending;
                return (SortDirection)Session["StudentSortDirection"];
            }
            set { Session["StudentSortDirection"] = value; }
        }
        /// -----------------------------------------------------------------------------
        /// <summary>
        /// Page_Load runs when the control is loaded
        /// </summary>
        /// -----------------------------------------------------------------------------
        protected void Page_Load(object sender, EventArgs e)
        {
            CustomPaging.OnbuttonClicked += new CustomPaging.ButtonClciked(SortAndBind);
            DnnLog.Error("SelectedId Post: " + selectedStudentIDText.Text);
            if (!IsPostBack)
            {
                try
                {
                    DnnLog.Error("SelectedId In Post: " + selectedStudentIDText.Text);
                    DataCache.RemoveCache(string.Format("GetStudentsBySubcription{0}", int.Parse(Session["Subscription"].ToString())));
                    DataCache.RemoveCache(string.Format("GetTeachersbySubscription{0}", int.Parse(Session["Subscription"].ToString())));
                    DataCache.RemoveCache(string.Format("GetStudentByGroup{0}", LoginName));
                    if (SelectedSubscription != null && SelectedSubscription != string.Empty)
                    {
                        string selectedIndex = "1";
                    }
                    if (MergeClassId == null)
                    {
                        if (Request.QueryString["classid"] != null)
                        {
                            DnnLog.Error("Edit group query string value: " + Request.QueryString["classid"]);
                            EditClassId = int.Parse(Request.QueryString["classid"].ToString());
                        }
                        else if (Request.QueryString["groupid"] != null)
                        {
                            DnnLog.Error("Edit group query string value: " + Request.QueryString["groupid"]);
                            EditGroupId = int.Parse(Request.QueryString["groupid"].ToString());
                        }
                    }

                    if (EditGroupId != -1 || EditClassId != -1)
                    {
                        if (StudentList == null || TeachersList == null)
                            EditGroup();
                        else
                            SortAndBind(10, 0, 0);
                        CreateGroupButton.Text = "SAVE GROUP";
                        CreateGroupButton.CssClass = "SaveBtnStyle ";
                    }
                    else
                    {
                        //GroupName = string.Empty;
                        EditClassId = null;
                        EditGroupId = null;
                        if (TeachersList == null)
                        {
                            DnnLog.Error("TeacherList Empty");
                            List<IDCollection> currentUserCollection = new List<IDCollection>();
                            IDCollection currentUser = new IDCollection() { Id = userID, Text = "You" };
                            currentUserCollection.Add(currentUser);
                            TeachersList = currentUserCollection;
                        }
                        DnnLog.Error("TeacherList " + TeachersList.AsEnumerable().Count());
                        StudentsContentDiv.Style.Add("display", "none");
                        if (MergeClassId != null && SelectedID == null)
                        {
                            // clicked from merge group
                            if (StudentList == null || TeachersList == null)
                                MergeGroups();
                            else
                                SortAndBind(10, 0, 0);
                        }
                        else
                        {
                            if (StudentList == null && TeachersList == null)
                                SortOpCont.Visible = SortDiv.Visible=  false;
                            SortAndBind(10, 0, 0);
                        }

                        CreateGroupButton.Text = "CREATE GROUP";
                    }
                    if (GroupName.ToLower().Equals("unallocated students"))
                    {
                        GroupNameTextBox.Enabled = false;
                        GroupNameTextDiv.Attributes["class"]=  "GroupNameTextDiv grpDisable";
                        AddStudentButton.CssClass = "grpDisable CreateGroupAddStudentBtn AddButtonBackground";
                        AddStudentButton.Enabled = true;
                        StudentDetailsDiv.Attributes["class"] = "grpDisable StudentDetailsDiv";
                        UserIsAdmin.Value = CheckUserIsAdmin.ToString();
                    }
                    GroupNameTextBox.Text = GroupName;
                    ChangeCheckBoxImg();

                    if (StudentList != null || TeachersList != null)
                    {
                        RisePopUp.Value = SelectedSubscription;
                    }
                }
                catch (Exception ex)
                {
                    this.Messages.ShowError(ex.Message);
                    LogFileWrite(ex);
                }
            }
            if (GroupName.ToLower().Equals("unallocated students"))
            {
                GroupNameTextBox.Enabled = false;
                GroupNameTextDiv.Attributes["class"] = "GroupNameTextDiv grpDisable";
                AddStudentButton.CssClass = "grpDisable CreateGroupAddStudentBtn AddButtonBackground";
                AddStudentButton.Enabled = true;
                StudentDetailsDiv.Attributes["class"] = "grpDisable StudentDetailsDiv";
                UserIsAdmin.Value = CheckUserIsAdmin.ToString();
            }
            if(CreateGroupButton.Text == "SAVE GROUP")
            CreateGroupButton.CssClass = "SaveBtnStyle";
            Messages.ClearMessages();

        }

        /// <summary>
        /// 
        /// </summary>
        private void ChangeCheckBoxImg()
        {
            if (!Type)
            {
                CheckBoxDiv.Attributes.Add("class", "groupuncheckboximg groupcheckboximg");
                ClassCheckHiddenField.Value = "false";
            }
            else
            {
                CheckBoxDiv.Attributes.Add("class", "groupcheckboximg");
                ClassCheckHiddenField.Value = "true";
            }
            ClassCheckBox.Checked = Type;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void TeacherDetailsRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            Label label = (Label)e.Item.FindControl("TeacherNameLabel");
            label.Text = label.Text.Length > 35 ? label.Text.Substring(0, 35) + "..." : label.Text;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void StudentDetailsRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            Label label = (Label)e.Item.FindControl("StudentNameLabel");
            label.Text = label.Text.Length > 35 ? label.Text.Substring(0, 35) + "..." : label.Text;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void CancelCreateGroup_Click(object sender, EventArgs e)
        {
            StudentList = null;
            TeachersList = null;
            EditClassId = null;
            EditGroupId = null;
            SelectedSubscription = null;
            GroupName = null;
            SelectedID = null;
            MergeClassId = null;
            Session["ClassType"] = null;
            Response.Redirect(Globals.NavigateURL(PortalSettings.Current.ActiveTab.TabID));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void AddStudentButton_Click(object sender, EventArgs e)
        {
            try
            {
                List<Students> SelectedstudentList = new List<Students>();
                RepeaterItemCollection myItemCollection;
                myItemCollection = StudentDetailsRepeater.Items;
                for (int Stindex = 0; Stindex < myItemCollection.Count; Stindex++)
                {
                    Students studentIDCollection = new Students();
                    studentIDCollection.UserID = (int.Parse((myItemCollection[Stindex].FindControl("studentid") as Label).Text));
                    studentIDCollection.ReadingLevel = (int.Parse((myItemCollection[Stindex].FindControl("ReadingLevel") as Literal).Text));
                    studentIDCollection.StudentNames = (myItemCollection[Stindex].FindControl("StudentNameLabel") as Label).Text;
                    SelectedstudentList.Add(studentIDCollection);
                }
                // StudentList = SelectedstudentList;
                if (SelectedstudentList.Count > 0)
                    RisePopUp.Value = SelectedSubscription;
                GroupName = GroupNameTextBox.Text;
                Type = ClassCheckBox.Checked;
                ChangeCheckBoxImg();

                if (EditGroupId != -1 || EditClassId != -1)
                {
                    Response.Redirect(Globals.NavigateURL(PortalSettings.Current.ActiveTab.TabID) + "?pagename=" + ADDSTUDENTTOEDITGROUP);
                }
                else
                {
                    Response.Redirect(Globals.NavigateURL(PortalSettings.Current.ActiveTab.TabID) + "?pagename=" + ADDSTUDENTTOCREATEGROUP);
                }

            }
            catch (Exception ex)
            {
                this.Messages.ShowError(ex.Message);
                LogFileWrite(ex);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void AddTeachersButton_Click(object sender, EventArgs e)
        {
            try
            {
                List<_IDCollection> SelectedTeacherID = new List<_IDCollection>();
                RepeaterItemCollection myItemCollection;
                myItemCollection = TeacherDetailsRepeater.Items;
                for (int Teindex = 0; Teindex < myItemCollection.Count; Teindex++)
                {
                    _IDCollection teacherIDCollection = new _IDCollection();
                    teacherIDCollection.Id = (int.Parse((myItemCollection[Teindex].FindControl("classid") as Label).Text));
                    teacherIDCollection.Text = (myItemCollection[Teindex].FindControl("TeacherNameLabel") as Label).Text;
                    SelectedTeacherID.Add(teacherIDCollection);
                }
                TeachersList = SelectedTeacherID;

                if (SelectedTeacherID.Count > 0)
                    RisePopUp.Value = SelectedSubscription;
                GroupName = GroupNameTextBox.Text;
                Type = ClassCheckBox.Checked;
                ChangeCheckBoxImg();
                if (EditGroupId != -1 || EditClassId != -1)
                {
                    Response.Redirect(Globals.NavigateURL(PortalSettings.Current.ActiveTab.TabID) + "?pagename=" + ADDTEACHERTOEDITGROUP);
                }
                else
                {
                    Response.Redirect(Globals.NavigateURL(PortalSettings.Current.ActiveTab.TabID) + "?pagename=" + ADDTEACHERTOCREATEGROUP);
                }
            }
            catch (Exception ex)
            {
                this.Messages.ShowError(ex.Message);
                LogFileWrite(ex);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ClickTeacherDelete(object sender, EventArgs e)
        {
            TeacherDelete.Text = "delete";
            TeacherDeleteImgButton__Click(Session["obj"] as object, e);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void TeacherDeleteImgButton__Click(object sender, EventArgs e)
        {
            try
            {
                Session["obj"] = sender;
                //Get the reference of the clicked button.
                Button button = (sender as Button);

                //Get the Repeater Item reference
                RepeaterItem item = button.NamingContainer as RepeaterItem;
                int teacherID = int.Parse((item.FindControl("teacherid") as Literal).Text);
                //if (teacherID != userID)
                //{
                List<_IDCollection> SelectedTeacherID = new List<_IDCollection>();
                RepeaterItemCollection myItemCollection;
                myItemCollection = TeacherDetailsRepeater.Items;

                for (int Teindex = 0; Teindex < myItemCollection.Count; Teindex++)
                {
                    if (CreateGroupButton.Text == "CREATE GROUP")
                    {
                        if (TeacherDelete.Text == string.Empty && (int.Parse((myItemCollection[Teindex].FindControl("teacherid") as Literal).Text)) == teacherID && ((myItemCollection[Teindex].FindControl("TeacherNameLabel") as Label).Text.ToLower()) == "you")
                        {
                            ScriptManager.RegisterStartupScript(Page, GetType(), "DeleteOwnerMessage", "<script>DeleteOwnerMessage()</script>", false);
                            return;
                        }
                    }
                    else
                    {
                        if (EditGroupId != -1)
                        {
                            if (TeacherDelete.Text == string.Empty && (int.Parse((myItemCollection[Teindex].FindControl("teacherid") as Literal).Text)) == teacherID && GroupController.Instance.GetGroupOwnerID(EditGroupId.Value) == teacherID)
                            {
                                ScriptManager.RegisterStartupScript(Page, GetType(), "DeleteOwnerMessage", "<script>DeleteOwnerMessage()</script>", false);
                                return;
                            }
                        }
                        if (EditClassId != -1)
                        {
                            if (TeacherDelete.Text == string.Empty && (int.Parse((myItemCollection[Teindex].FindControl("teacherid") as Literal).Text)) == teacherID && GroupController.Instance.GetGroupOwnerID(EditClassId.Value) == teacherID)
                            {
                                ScriptManager.RegisterStartupScript(Page, GetType(), "DeleteOwnerMessage", "<script>DeleteOwnerMessage()</script>", false);
                                return;
                            }
                        }
                    }
                    if ((int.Parse((myItemCollection[Teindex].FindControl("teacherid") as Literal).Text)) != teacherID)
                    {
                        _IDCollection teacherIDCollection = new _IDCollection();
                        teacherIDCollection.Id = (int.Parse((myItemCollection[Teindex].FindControl("teacherid") as Literal).Text));
                        teacherIDCollection.Text = (myItemCollection[Teindex].FindControl("TeacherNameLabel") as Label).Text;
                        SelectedTeacherID.Add(teacherIDCollection);
                    }

                }
                TeachersList = SelectedTeacherID;

                TeacherDetailsRepeater.DataSource = TeachersList;
                TeacherDetailsRepeater.DataBind();


                CreateGroupBtnHolder.Attributes.Add("class", "ActiveAddButtonsHolder CreateButtonGradient");
                CreateGroupButton.Enabled = true;
                CreateGroupButton.CssClass = "BtnStyle";

            }
            catch (Exception ex)
            {
                this.Messages.ShowError(ex.Message);
                LogFileWrite(ex);
            }

        }
        protected void RemoveUsergroupbtn_Click(object sender, EventArgs e)
        {
            string[] selectedStudentIDArray = selectedStudentIDText.Text.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).Select(sValue => sValue.Trim()).ToArray();
            DnnLog.Error("SelectedId: " + selectedStudentIDText.Text);
            if (selectedStudentIDArray.Length > 0)
            {
                StudentList = StudentList.Where(u => !selectedStudentIDArray.Contains(u.UserID.ToString())).ToList();
                DnnLog.Error("StudentList count: " + StudentList.Count);
            }
            string[] selectedTeacherIDArray = selectedTeacherIDText.Text.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).Select(sValue => sValue.Trim()).ToArray();
            DnnLog.Error("SelectedId: " + selectedTeacherIDText.Text);
            if (selectedTeacherIDArray.Length > 0)
            {
                TeachersList = TeachersList.Where(u => !selectedTeacherIDArray.Contains(u.Id.ToString())).ToList();
            }
            int pageno = CustomPaging.GetCurrentPageNo();
            FillStudentsList(StudentList, ConstRowCount, pageno);
            selectedStudentIDText.Text = string.Empty;
            selectedTeacherIDText.Text = string.Empty;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void StudentDeleteImgButton__Click(object sender, EventArgs e)
        {
            try
            {
                //Get the reference of the clicked button.
                Button button = (sender as Button);

                //Get the Repeater Item reference
                RepeaterItem item = button.NamingContainer as RepeaterItem;
                int studentID = int.Parse((item.FindControl("studentid") as Literal).Text);
                List<Students> SelectedstudentID = new List<Students>();
                RepeaterItemCollection myItemCollection;
                myItemCollection = StudentDetailsRepeater.Items;
                for (int Stindex = 0; Stindex < myItemCollection.Count; Stindex++)
                {
                    if ((int.Parse((myItemCollection[Stindex].FindControl("studentid") as Literal).Text)) != studentID)
                    {
                        Students studentIDCollection = new Students();
                        studentIDCollection.UserID = (int.Parse((myItemCollection[Stindex].FindControl("studentid") as Literal).Text));
                        studentIDCollection.StudentNames = (myItemCollection[Stindex].FindControl("StudentNameLabel") as Label).Text;
                        SelectedstudentID.Add(studentIDCollection);
                    }
                }
                StudentList = SelectedstudentID;
                StudentDetailsRepeater.DataSource = StudentList;
                StudentDetailsRepeater.DataBind();
                //StudentDetailsUpdatePanel.Update();
                //MessageUpdatePanel.Update();
                if (StudentList.Count == 0 && TeacherDetailsRepeater.Items.Count == 0)
                {
                    CreateGroupBtnHolder.Attributes.Add("class", "DisabledAddButtonHolder CreateButtonGradient");
                    CreateGroupButton.Enabled = false;
                    CreateGroupButton.CssClass = "BtnStyle DbldBtn";
                    StudentDetailsDiv.Style.Add("display", "none");
                }
                else
                {
                    CreateGroupBtnHolder.Attributes.Add("class", "ActiveAddButtonsHolder CreateButtonGradient");
                    CreateGroupButton.Enabled = true;
                    CreateGroupButton.CssClass = "BtnStyle";
                }

            }
            catch (Exception ex)
            {
                this.Messages.ShowError(ex.Message);
                LogFileWrite(ex);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void CreateGroupButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (GroupNameTextBox.Text.Trim() == string.Empty)
                {
                    Messages.ShowWarning(GetMessage(DotNetNuke.Modules.eCollection_Groups.Components.Common.Constants.MS_GRPNAMEVALIDATION));
                    return;
                }

                Components.Groups groups = new Components.Groups();
                groups.CustomerSubId = int.Parse(Session["Subscription"].ToString());
                groups.Name = GroupNameTextBox.Text;
                groups.LoginName = LoginName;
                if (ClassCheckBox.Checked)
                {
                    groups.GroupType = 'C';
                }
                else
                {
                    groups.GroupType = 'N';
                }
                groups.CreatedOnDate = DateTime.Now;
                groups.ActiveFlag = 'Y';
                groups.DateCreated = DateTime.Now;
                if (TeachersList != null && TeachersList.Count != 0)
                {
                    groups.TeachersList = TeachersList;
                }
                else if (TeacherDetailsRepeater.Items.Count > 0)
                {
                    List<IDCollection> newTeachersList = new List<_IDCollection>();
                    RepeaterItemCollection myItemCollection;
                    myItemCollection = TeacherDetailsRepeater.Items;
                    for (int Teindex = 0; Teindex < myItemCollection.Count; Teindex++)
                    {
                        _IDCollection teacherIDCollection = new _IDCollection();
                        teacherIDCollection.Id = (int.Parse((myItemCollection[Teindex].FindControl("classid") as Label).Text));
                        teacherIDCollection.Text = (myItemCollection[Teindex].FindControl("TeacherNameLabel") as Label).Text;
                        newTeachersList.Add(teacherIDCollection);
                    }
                    groups.TeachersList = newTeachersList;
                }

                if (StudentList != null && StudentList.Count != 0)
                {
                    groups.StudentList = StudentList;
                }
                else if (StudentDetailsRepeater.Items.Count > 0)
                {
                    List<Students> newStudentList = new List<Students>();

                    RepeaterItemCollection myItemCollection;
                    myItemCollection = StudentDetailsRepeater.Items;
                    for (int Stindex = 0; Stindex < myItemCollection.Count; Stindex++)
                    {
                        Students students = new Students();
                        if ((myItemCollection[Stindex].FindControl("studentid") as Literal) != null)
                            students.UserID = (int.Parse((myItemCollection[Stindex].FindControl("studentid") as Literal).Text));
                        if ((myItemCollection[Stindex].FindControl("StudentNameLabel") as Label) != null)
                            students.StudentNames = (myItemCollection[Stindex].FindControl("StudentNameLabel") as Label).Text;
                        //students.StudentLoginName = (myItemCollection[Stindex].Controls[2] as Label).Text.Replace("(", "").Replace(")", "");
                        newStudentList.Add(students);
                    }
                    groups.StudentList = newStudentList;
                }
                DnnLog.Error("EditGroupId: " + EditGroupId);
                DnnLog.Error("EditClassId: " + EditClassId);
                Components.GroupController Gc = GroupController.Instance;
                if (EditGroupId != -1 || EditClassId != -1)
                {
                    List<_IDCollection> TeacherListIDCollection = null;
                    List<Students> StudentListIDCollection = null;
                    List<Students> DeletedStudentIDCollection = null;
                    List<_IDCollection> DeletedTeacherIDCollection = null;


                    AllOther = true;
                    int customerSubSK = 0;
                    if (EditGroupId != -1)
                    {
                        TeacherListIDCollection = GroupController.Instance.GetMembersByGroup(Null.SetNullInteger(EditGroupId), "Teacher");
                        List<string> teacherIDCol = TeacherListIDCollection.Select(u => u.Id.ToString()).ToList<string>();
                        groups.TeachersList = TeachersList.Where(u => (!teacherIDCol.Contains(u.Id.ToString()))).ToList();
                        StudentListIDCollection = GroupController.Instance.GetStudentByGroup(Null.SetNullInteger(EditGroupId));
                        List<string> studentIDCol = StudentListIDCollection.Select(u => u.UserID.ToString()).ToList<string>();
                        groups.StudentList = StudentList.Where(u => (!studentIDCol.Contains(u.UserID.ToString()))).ToList();
                        customerSubSK = GroupLists.Where(u => u.GroupId == EditGroupId).FirstOrDefault().CustomerSubId.Value;
                        groups.GroupId = EditGroupId.Value;
                    }
                    if (EditClassId != -1)
                    {
                        TeacherListIDCollection = GroupController.Instance.GetMembersByGroup(Null.SetNullInteger(EditClassId), "Teacher");
                        List<string> teacherIDCol = TeacherListIDCollection.Select(u => u.Id.ToString()).ToList<string>();
                        groups.TeachersList = TeachersList.Where(u => (!teacherIDCol.Contains(u.Id.ToString()))).ToList();
                        StudentListIDCollection = GroupController.Instance.GetStudentByGroup(Null.SetNullInteger(EditClassId));
                        List<string> studentIDCol = StudentListIDCollection.Select(u => u.UserID.ToString()).ToList<string>();
                        groups.StudentList = StudentList.Where(u => (!studentIDCol.Contains(u.UserID.ToString()))).ToList();

                        customerSubSK = ClassList.Where(u => u.GroupId.Equals(EditClassId)).FirstOrDefault().CustomerSubId.Value;
                        groups.GroupId = EditClassId.Value;
                    }

                    if (StudentList != null)
                    {
                        DnnLog.Error("StudentListIDCollection.Count: " + StudentListIDCollection.Count);
                        DeletedStudentIDCollection = (from InactiveStudent in StudentListIDCollection
                                                      where !(from activeStudent in StudentList
                                                              select activeStudent.UserID).Contains(InactiveStudent.UserID)
                                                      select InactiveStudent).ToList();
                        DnnLog.Error("DeletedStudentIDCollection: " + DeletedStudentIDCollection.Count);
                    }
                    if (TeachersList != null)
                    {
                        DeletedTeacherIDCollection = (from InactiveTeacher in TeacherListIDCollection
                                                      where !(from activeTeacher in TeachersList
                                                              select activeTeacher.Id).Contains(InactiveTeacher.Id)
                                                      select InactiveTeacher).ToList();
                        DnnLog.Error("DeletedTeacherIDCollection: " + DeletedTeacherIDCollection.Count);
                    }
                    DnnLog.Error("TeacherDetailsRepeater.Items: " + TeacherDetailsRepeater.Items.Count);
                    if (TeacherDetailsRepeater.Items.Count == 0)
                    {

                        Messages.ShowWarning("A teacher is mandatory. Please enter a teacher, then click Create Group.");
                        return;
                    }
                    if (StudentDetailsRepeater.Items.Count == 0 && TeacherDetailsRepeater.Items.Count == 0)
                    {
                        Messages.ShowWarning(GetMessage(DotNetNuke.Modules.eCollection_Groups.Components.Common.Constants.MS_MEMBERVALIDATION));
                        return;
                    }
                    if (GroupName.ToLower() != GroupNameTextBox.Text.Trim().ToLower() && GroupNameTextBox.Text.Trim() != string.Empty)
                    {
                        if (GroupController.Instance.ValidateGroupName(GroupNameTextBox.Text.Trim(), groups.GroupType, int.Parse(Session["Subscription"].ToString())))
                        {
                            Messages.ShowWarning(GetMessage(DotNetNuke.Modules.eCollection_Groups.Components.Common.Constants.MS_GRPNAMEEXIST));
                            GroupNameTextBox.Text = string.Empty;
                            return;
                        }
                        else
                        {
                            GroupController.Instance.UpdateMembers(groups, DeletedTeacherIDCollection, DeletedStudentIDCollection, customerSubSK);
                            Messages.ClearMessages();
                        }
                    }
                    else
                    {
                        GroupController.Instance.UpdateMembers(groups, DeletedTeacherIDCollection, DeletedStudentIDCollection, customerSubSK);
                        Messages.ClearMessages();
                    }
                }
                else
                {
                    if (!GroupController.Instance.ValidateGroupName(GroupNameTextBox.Text.Trim(), groups.GroupType, int.Parse(Session["Subscription"].ToString())))
                    {

                        if (TeacherDetailsRepeater.Items.Count == 0)
                        {
                            Messages.ShowWarning("A teacher is mandatory. Please enter a teacher, then click Create Group.");
                            return;
                        }
                        else if (!(StudentDetailsRepeater.Items.Count == 0 && TeacherDetailsRepeater.Items.Count == 0))
                        {
                            int succesfull = int.Parse(Gc.Add(groups).ToString());
                        }
                        else
                        {
                            Messages.ShowWarning(GetMessage(DotNetNuke.Modules.eCollection_Groups.Components.Common.Constants.MS_MEMBERVALIDATION));
                            return;
                        }

                        StudentList = null;
                        TeachersList = null;
                    }
                    else
                    {
                        Messages.ShowWarning(GetMessage(DotNetNuke.Modules.eCollection_Groups.Components.Common.Constants.MS_GRPNAMEEXIST));
                        GroupNameTextBox.Text = string.Empty;
                        return;
                    }
                }
                eCollection_Dashboards.Components.Controller.DashboardController.Instance.ClearAllCache();
                StudentsController.Instance.ClearAllCache();
                DataCache.RemoveCache(string.Format("GetGroupOwnerID{0}", EditGroupId.Value));
                DataCache.RemoveCache(string.Format("GetGroupOwnerID{0}", EditClassId.Value));
                Response.Redirect(Globals.NavigateURL(PortalSettings.Current.ActiveTab.TabID));
            }
            catch (GroupValidationException exc)
            {
                if (exc.getErrorState() == MyEnums.CrudState.Insert)
                {
                    Messages.ShowWarning(exc.getErrorMessage());
                }

            }
            catch (Exception ex)
            {
                this.Messages.ShowError(ex.Message);
                LogFileWrite(ex);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void EditGroup()
        {
            try
            {
                GroupController groupcontroller = GroupController.Instance;
                int? selectedGroupId = null;
                if (TeachersList == null || StudentList == null)
                {
                    int? selectedSubs = 0;
                    string groupname = null;
                    char classorgroup = new char();
                    AllOther = true;
                    if (EditGroupId != -1)
                    {
                        selectedGroupId = EditGroupId;
                        TeachersList = groupcontroller.GetMembersByGroup(Null.SetNullInteger(EditGroupId), "Teacher");
                        StudentList = groupcontroller.GetStudentByGroup(Null.SetNullInteger(EditGroupId));
                        selectedSubs = GroupLists.Where(u => u.GroupId.Equals(EditGroupId)).FirstOrDefault().CustomerSubId;
                        groupname = GroupLists.Where(u => u.GroupId.Equals(EditGroupId)).FirstOrDefault().Name;
                        classorgroup = GroupType;
                    }
                    if (EditClassId != -1)
                    {
                        selectedGroupId = EditClassId;
                        TeachersList = groupcontroller.GetMembersByGroup(Null.SetNullInteger(EditClassId), "Teacher");
                        StudentList = groupcontroller.GetStudentByGroup(Null.SetNullInteger(EditClassId));
                        selectedSubs = ClassList.Where(u => u.GroupId.Equals(EditClassId)).FirstOrDefault().CustomerSubId;
                        groupname = ClassList.Where(u => u.GroupId.Equals(EditClassId)).FirstOrDefault().Name;
                        classorgroup = ClassType;
                    }
                    if (SelectedSubscription != null)
                    {
                        Session["StudentSortDirection"] = null;
                        CustomPaging.DisplayPropertyForPage("block");
                        SortAndBind(10, 0, 0);
                    }
                    GroupNameTextBox.Text = groupname;
                    GroupName = groupname;
                    if (classorgroup == 'C')
                    {
                        Type = true;
                    }
                    else
                    {
                        Type = false;
                    }
                    ChangeCheckBoxImg();
                    AllOther = false;
                }
            }
            catch (Exception ex)
            {
                this.Messages.ShowError(ex.Message);
                LogFileWrite(ex);
            }
        }
        private void SortAndBind(int take, int pageSize, int startCount)
        {
            try
            {
                DnnLog.Error("SortAndBind Teacher List: " + TeachersList.AsEnumerable().Count());
                List<Students> studentcollection = null;
                if (StudentList != null)
                {
                    ConstRowCount = StudentList.Count;
                    studentcollection = StudentList.OrderBy(o => o.StudentNames).Take(take).Skip(pageSize).ToList();
                    if (ConstRowCount == 0)
                    {
                        //   MessageOuterDiv.Style.Add("Display", "block");
                        StudentsContentDiv.Style.Add("display", "none");

                        //   Message1.Text = Constants.NOSTUDENTINFO;
                    }
                    else
                    {

                        //  MessageOuterDiv.Style.Add("Display", "none");
                        StudentsContentDiv.Style.Add("display", "block");
                    }
                    if (StudentSortDirection == SortDirection.Descending)
                    {
                        studentcollection.Reverse();
                        TeachersList.Reverse();
                    }

                }
                else
                    AllTeacherClassContainer.Style.Add("display", "none");
                FillStudentsList(studentcollection, ConstRowCount, startCount);
            }
            catch (Exception ex) { LogFileWrite(ex); }
        }
        private void FillStudentsList(List<Students> _studentList, int totalCount, int startCount)
        {
            try
            {

                DnnLog.Error("fill Teacher List: " + TeachersList.AsEnumerable().Count());
                if (TeachersList != null && TeachersList.Count != 0)
                {
                    CreateGroupContentDiv.Style.Add("display", "block");
                    TeachersList.ForEach(u => { if (u.Id.ToString() == userID.ToString()) { u.Text = "You"; } });
                    if (StudentSortDirection == SortDirection.Descending)
                    {
                        TeachersList.Reverse();
                    }
                    TeacherDetailsRepeater.DataSource = TeachersList;//.Where(u => u.Id != userID);
                    TeacherDetailsRepeater.DataBind();
                    CreateGroupBtnHolder.Attributes.Add("class", "ActiveAddButtonsHolder CreateButtonGradient");
                    CreateGroupButton.Enabled = true;
                    CreateGroupButton.CssClass = "BtnStyle";
                }
                else
                {
                    TeacherDetailsRepeater.DataSource = new List<_IDCollection>();
                    TeacherDetailsRepeater.DataBind();
                    TeacherDetailsDiv.Style.Add("display", "none");
                    ClassContainer.Style.Add("display", "none");
                }
                if (_studentList != null && _studentList.Count != 0)
                {
                    CustomPaging.CreatePagingControl(totalCount, startCount);
                    CustomPaging.PageButtonStyle(startCount);

                    if (!(ConstRowCount > 10))
                    {
                        CustomPaging.DisplayPropertyForPage("none");
                    }
                    CreateGroupBtnHolder.Attributes.Add("class", "DisabledAddButtonHolder CreateButtonGradient");
                    CreateGroupButton.Enabled = false;
                    CreateGroupButton.CssClass = "BtnStyle DbldBtn";
                }


                if (_studentList != null && _studentList.Count != 0)
                {
                    CreateGroupBtnHolder.Attributes.Add("class", "ActiveAddButtonsHolder CreateButtonGradient");
                    CreateGroupButton.Enabled = true;
                    CreateGroupButton.CssClass = "BtnStyle";
                    CreateGroupContentDiv.Style.Add("display", "block");
                    StudentDetailsRepeater.DataSource = _studentList;
                    StudentDetailsRepeater.DataBind();
                    StudentDetailsDiv.Style.Add("display", "block");
                }
                else
                {
                    StudentDetailsRepeater.DataSource = new List<Students>();
                    StudentDetailsRepeater.DataBind();
                    AllTeacherClassContainer.Style.Add("display", "none");
                    StudentDetailsDiv.Style.Add("display", "none");
                }

            }
            catch (Exception ex) { LogFileWrite(ex); }
        }

        protected void groupssortdpn_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<Students> studentcollection = new List<Students>();
            int pageno = CustomPaging.GetCurrentPageNo();
            RepeaterItemCollection myItemCollection;
            myItemCollection = StudentDetailsRepeater.Items;
            for (int Stindex = 0; Stindex < myItemCollection.Count; Stindex++)
            {
                Students students = new Students();
                if ((myItemCollection[Stindex].FindControl("studentid") as Literal) != null)
                    students.UserID = (int.Parse((myItemCollection[Stindex].FindControl("studentid") as Literal).Text));
                if ((myItemCollection[Stindex].FindControl("StudentNameLabel") as Label) != null)
                    students.StudentNames = (myItemCollection[Stindex].FindControl("StudentNameLabel") as Label).Text;
                //students.StudentLoginName = (myItemCollection[Stindex].Controls[2] as Label).Text.Replace("(", "").Replace(")", "");
                studentcollection.Add(students);
            }
            switch (groupssortdpn.SelectedIndex)
            {
                case 0:
                    StudentSortDirection = SortDirection.Ascending;
                    FillStudentsList(studentcollection.OrderBy(s => s.StudentNames).ToList(), ConstRowCount, pageno);
                    break;
                case 1:
                    StudentSortDirection = SortDirection.Descending;
                    FillStudentsList(studentcollection.OrderByDescending(s => s.StudentNames).ToList(), ConstRowCount, pageno);
                    break;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        private void MergeGroups()
        {
            try
            {
                // DnnLog.Error("Merge ecoll start");

                List<int> GroupsIds = new List<int>();
                foreach (string id in MergeClassId)
                {
                    GroupsIds.Add(int.Parse(id));
                }
                AllOther = true;
                GroupController _groupController = GroupController.Instance;
                List<Components.Groups> MergedGroups = new List<Components.Groups>();
                MergedGroups = _groupController.GetGroupList(GroupType, LoginName, AllOther, int.Parse(Session["Subscription"].ToString()));
                GroupType = 'C';
                List<Components.Groups> MergedGroupClass = new List<Components.Groups>();
                MergedGroupClass = MergedGroups.Concat(_groupController.GetClassList(GroupType, LoginName, AllOther, int.Parse(Session["Subscription"].ToString()))).ToList<Components.Groups>(); // do urself
                List<_IDCollection> TeacherListIDCollection = new List<_IDCollection>();
                List<Students> StudentListIDCollection = new List<Students>();
                int selectedSubs = 0;
                //DnnLog.Error("Merge ecoll Count"+ MergedGroupClass.Count);
                foreach (Components.Groups groups in MergedGroupClass)
                {
                    // DnnLog.Error("Merge " + groups.GroupId + "," + groups.MemberCount + "teacher group=" + groups.TeachersList.Count + "Student group=" + groups.StudentList.Count);
                    if (GroupsIds.Contains(groups.GroupId))
                    {
                        groups.TeachersList = _groupController.GetMembersByGroup(Null.SetNullInteger(groups.GroupId), "Teacher");
                        groups.StudentList = _groupController.GetStudentByGroup(Null.SetNullInteger(groups.GroupId));
                        foreach (_IDCollection idc in groups.TeachersList)
                        {
                            if (!TeacherListIDCollection.Contains(new _IDCollection(idc.Id, idc.Text)))
                            {
                                TeacherListIDCollection.Add(new _IDCollection(idc.Id, idc.Text));
                            }
                        }
                        foreach (Students idc in groups.StudentList)
                        {
                            if (!StudentListIDCollection.Contains(new Students(idc.UserID, idc.StudentNames)))
                            {
                                StudentListIDCollection.Add(new Students(idc.UserID, idc.StudentNames));
                            }
                        }
                        selectedSubs = groups.CustomerSubId.Value;
                    }
                }
                AllOther = false;
                // DnnLog.Error("TeacherListIDCollection=" + TeacherListIDCollection.Count);
                // DnnLog.Error("StudentListIDCollection=" + StudentListIDCollection.Count);
                TeachersList = TeacherListIDCollection;
                StudentList = StudentListIDCollection;
                SortAndBind(10, 0, 0);

            }
            catch (Exception ex)
            {
                this.Messages.ShowError(ex.Message);
                LogFileWrite(ex);
            }
        }

    }
}
