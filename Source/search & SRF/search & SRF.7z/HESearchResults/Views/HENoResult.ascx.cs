﻿using System;

namespace DotNetNuke.Modules.HESearchResults.Views
{ 
    // --------------------------------------------------------------------------------------------------------------------
    // <copyright file="NoResult" company="CENGAGE LEARNING AUSTRALIA PTY LIMITED">
    //    Copyright (c) 2014 CENGAGE LEARNING AUSTRALIA PTY LIMITED
    // </copyright>
    // <summary>
    //    Provides the No result page.
    // </summary>
    // ------------------------------------------------------------------------------------------------------------------------------
    
    public partial class NoResult : System.Web.UI.UserControl
    {
        /// -----------------------------------------------------------------------------
        /// <summary>
        /// Page_Load runs when the control is loaded
        /// </summary>
        /// -----------------------------------------------------------------------------
        protected void Page_Load(object sender, EventArgs e)
        {
           // DivisionLbl.Text = Request.QueryString["division"];
        }
    }
}