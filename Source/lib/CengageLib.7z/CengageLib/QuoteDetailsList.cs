﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cengage.eCommerce.CengageLib
{
    public class QuoteDetailsList
    {
        public int ProductSK { get; set; }
        public int Quantity { get; set; }
        public string ImagePath { get; set; }
        public string Title { get; set; }
        public string Authors { get; set; }
        public string ISBN { get; set; }
        public string RRP { get; set; }
        public string DiscountPrice { get; set; }
        public string Students { get; set; }
        public string Products { get; set; }

    }
}
