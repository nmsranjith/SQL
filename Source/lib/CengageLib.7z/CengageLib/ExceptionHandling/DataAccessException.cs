﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using DotNetNuke.Instrumentation;

namespace Cengage.eCommerce.ExceptionHandling
{
    public class DataAccessException : System.Exception, ISerializable
    {
        private static readonly DataAccessException instance = new DataAccessException();
        private string _message;

        public static DataAccessException Instance
        {
            get
            {
                return instance;
            }
        }

        public DataAccessException() : base()
        {
            // Add implementation (if required)
        }

        public DataAccessException(string message) : base(message)
        {
            this._message = message;
        }

        public DataAccessException(string message, System.Exception inner) : base(message, inner)
        {
            this._message = message;
        }

        protected DataAccessException(SerializationInfo info, StreamingContext context) : base(info, context)
        {

        }
        /// <summary>
        ///  Log the Exceptions.
        /// </summary>
        /// <param name="ex"></param>
        public void ExceptionMessage(Exception ex)
        {
            StringBuilder ExceptionMessage = new StringBuilder();
            ExceptionMessage.Append("Message" + ex.Message + "\t");
            if (ex.InnerException != null)
            {
                ExceptionMessage.Append("Inner Exception Message" + ex.InnerException.Message + "\t");
                ExceptionMessage.Append("Inner Exception Stacktrace" + ex.InnerException.StackTrace + "\t");
            }
            DnnLog.Error(ExceptionMessage);
        }

    }

}
