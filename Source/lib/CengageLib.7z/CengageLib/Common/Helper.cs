﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Reflection;

namespace Cengage.eCommerce.Common
{
    public static class Helper
    {
        public static DataTable ToDataTable<T>(this List<T> list)
        {
            DataTable dt = new DataTable();
            if (list.Count > 0)
            {
                Type listType = list.ElementAt(0).GetType();            //Get element properties and add datatable columns              
                PropertyInfo[] properties = listType.GetProperties();
                foreach (PropertyInfo property in properties)
                    dt.Columns.Add(new DataColumn() { ColumnName = property.Name });
                foreach (object item in list)
                {
                    DataRow dr = dt.NewRow();
                    foreach (DataColumn col in dt.Columns)
                        dr[col] = listType.GetProperty(col.ColumnName).GetValue(item, null);
                    dt.Rows.Add(dr);
                }
            }
            return dt;
        }


        public static void Sort<TSource, TValue>(this List<TSource> source,
        Func<TSource, TValue> selector)
        {
            var comparer = Comparer<TValue>.Default;
            source.Sort((x, y) => comparer.Compare(selector(x), selector(y)));
        }
        public static void SortDescending<TSource, TValue>(this List<TSource> source,
                Func<TSource, TValue> selector)
        {
            var comparer = Comparer<TValue>.Default;
            source.Sort((x, y) => comparer.Compare(selector(y), selector(x)));
        }

        public static void SortListByPropertyName<T>(this List<T> list, bool isAscending, string propertyName) where T : IComparable
        {
            var propInfo = typeof(T).GetProperty(propertyName);
            Comparison<T> asc = (t1, t2) => ((IComparable)propInfo.GetValue(t1, null)).CompareTo(propInfo.GetValue(t2, null));
            Comparison<T> desc = (t1, t2) => ((IComparable)propInfo.GetValue(t2, null)).CompareTo(propInfo.GetValue(t1, null));
            list.Sort(isAscending ? asc : desc);
        }

        private static Dictionary<Type, IList<PropertyInfo>> typeDictionary = new Dictionary<Type, IList<PropertyInfo>>();
        public static IList<PropertyInfo> GetPropertiesForType<T>()
        {
            var type = typeof(T);
            if (!typeDictionary.ContainsKey(typeof(T)))
            {
                typeDictionary.Add(type, type.GetProperties().ToList());
            }
            return typeDictionary[type];
        }

        public static IList<T> ToList<T>(this DataTable table) where T : new()
        {
            IList<PropertyInfo> properties = GetPropertiesForType<T>();
            IList<T> result = new List<T>();

            foreach (var row in table.Rows)
            {
                var item = CreateItemFromRow<T>((DataRow)row, properties);
                result.Add(item);
            }

            return result;
        }

        private static T CreateItemFromRow<T>(DataRow row, IList<PropertyInfo> properties) where T : new()
        {
            T item = new T();
            foreach (var property in properties)
            {
                    property.SetValue(item, row[property.Name], null);
            }
            return item;
        }


        public static bool DiffInMonths(DateTime oldDate, DateTime newDate)
        {
            if (oldDate != DateTime.MinValue && newDate != DateTime.MinValue)
            {

                TimeSpan ts = newDate - oldDate;

                int months = ts.Days / 31;

                if (months >= 1)
                {
                    return true;
                }

            }
            return false;
        }

    }
}
