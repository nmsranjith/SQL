﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cengage.eCommerce.Common
{
    public class Age
    {
        private int Years;
        private int Months;
        private int Days;
            
        public Age(int years, int months, int days)
        {
            Years = years;
            Months = months;
            Days = days;
        }
   
        public override string ToString()
        {
            if (Years == 0 && Months == 0 && Days != 0)
                return string.Format("{0} Days", Days);
            if (Years == 0 && Months != 0 && Days == 0)
                return string.Format("{0} Months", Months);
            if (Years == 0 && Months != 0 && Days != 0)
                return string.Format("{0} Months, {1} Days", Months, Days);
   
            if (Years != 0 && Months != 0 && Days != 0)
                return string.Format("{0} Years, {1} Months, {2} Days", Years, Months, Days);
   
            if (Years != 0 && Months == 0 && Days != 0)
                return string.Format("{0} Years, {1} Days",Years, Days);            
            if (Years != 0 && Months != 0 && Days == 0)
                return string.Format("{0} Years, {1} Months",Years, Months);
            return string.Format("{0} Years, {1} Months, {2} Days", Years, Months, Days);
        }
    }
}
