﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Cengage.eCommerce.Common
{
    public static class Validator
    {
         public static bool IsValidEmail(this string val)
           {
               if (string.IsNullOrEmpty(val)) return false;
   
               const string expresion = @"^(?:[a-zA-Z0-9_'^&/+-])+(?:\.(?:[a-zA-Z0-9_'^&/+-])+)*@(?:(?:\[?(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))\.){3}(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\]?)|(?:[a-zA-Z0-9-]+\.)+(?:[a-zA-Z]){2,}\.?)$";
               Regex regex = new Regex(expresion, RegexOptions.IgnoreCase);
               return regex.IsMatch(val);           
           }

         public static bool IsValidURI(this string val)
           {
               if (string.IsNullOrEmpty(val)) return false;
   
               return Uri.IsWellFormedUriString(val, UriKind.Absolute);
           }

    }
}
