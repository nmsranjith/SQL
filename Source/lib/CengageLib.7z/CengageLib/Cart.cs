﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cengage.eCommerce.Lib
{
    public class Cart
    {
        public List<CartDetail> cart = new List<CartDetail>();
        public int UserSk { get; set; }
        public int TradingAccountSk { get; set; }
        public int StoreID { get; set; }
        public int NoOfProductAvailable { get { return cart.Count; } }
        public decimal OrderTotal { get { return cart.Sum(x => x.LineTotal); } } 
        public List<CartDetail> GetCart()
        {
            return cart;
        }

        public void SetCart(List<CartDetail> products)
        {
            cart = new List<CartDetail>();
            cart.AddRange(products);
        }

        public CartDetail GetProductByISBN(string ISBN13)
        {
            CartDetail product = null;
            if (ISBN13 != string.Empty || ISBN13 != "")
            {
                product = (CartDetail)cart.Where(part => part.ISBN13 == ISBN13).FirstOrDefault();
            }
            return product;
        }

        public CartDetail GetProductBySk(int prductSK)
        {
            CartDetail product = null;
            if (prductSK != 0)
            {
                product = (CartDetail)cart.Where(part => part.ProductSk == prductSK).FirstOrDefault();
            }
            return product;
        }

        public CartDetail GetProductByIndex(int index)
        {
            return index < NoOfProductAvailable ? cart[index] : null;
        }

        public bool AddProduct(CartDetail product)
        {
            //product.Quantity = product.Quantity == 0 ? 1 : product.Quantity;
            if (product.ISBN13 != "" || product.ProductSk == 0)
            {
                int resultno = cart.Where(part => part.ISBN13 == product.ISBN13).Count();
                if (resultno > 0)
                {                    
                    CartDetail result = (CartDetail)cart.Where(part => part.ISBN13 == product.ISBN13).Single();
                    //if (result != null && product.Quantity != 1)
                    if (result != null)
                    {
                        cart.Remove(result);
                        result.Quantity += product.Quantity;
                        result.Quantity = result.Quantity > 999 ? 999 : result.Quantity;
                        cart.Add(result);
                        return true;
                    }
                    else
                        return false;
                }
                else
                    cart.Add(product);
                return true;
            }
            else
                return false;

        }

        public bool RemoveProductByISBN(string ISBN13)
        {

            if (ISBN13 != string.Empty || ISBN13 != "")
            {
                int resultno = cart.Where(part => part.ISBN13 == ISBN13).Count();
                if (resultno > 0)
                {
                    CartDetail product = (CartDetail)cart.Where(part => part.ISBN13 == ISBN13).Single();
                    cart.Remove(product);
                    return true;
                }
            }
            return false;
        }

        public bool RemoveProductBySk(int prductSK)
        {
            if (prductSK == 0)
            {
                int resultno = cart.Where(part => part.ProductSk == prductSK).Count();
                if (resultno > 0)
                {
                    CartDetail product = (CartDetail)cart.Where(part => part.ProductSk == prductSK).Single();
                    cart.Remove(product);
                    return true;
                }
            }
            return false;
        }  

        public Cart AddProducts(List<CartDetail> products,Cart cartobject)
        {
            foreach (CartDetail product in products)
            {

                cartobject.AddProduct(product);
            }
            return cartobject;

        }

        public bool UpdateProductByISBN(CartDetail product)
        {
            if (product.ISBN13 != string.Empty || product.ISBN13 != "")
            {
                int resultno = cart.Where(part => part.ISBN13 == product.ISBN13).Count();
                if (resultno > 0)
                {
                    CartDetail result = (CartDetail)cart.Where(part => part.ISBN13 == product.ISBN13).Single();
                    cart.Remove(result);
                    cart.Add(product);
                    return true;
                }
            }
            return false;
        }
    }
}
