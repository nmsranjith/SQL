﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Content;

namespace Cengage.eCommerce.Lib
{
    public class CengageFacetSearchResult : ContentItem
    {
        public string AttributeName { get; set; }
        public string AttributeTypeValue { get; set; }
        public int ProductCount { get; set; }
        public string IsMultiselect { get; set; }


        public override void Fill(IDataReader DataReader)
        {
            AttributeName = Null.SetNullString(DataReader["ATTRIBUTE_NAME"]);
            AttributeTypeValue = Null.SetNullString(DataReader["ATTRIBUTE_TYPE_VALUE"]);
            ProductCount = Null.SetNullInteger(DataReader["ProductCount"]);
            IsMultiselect = Null.SetNullString(DataReader["IS_MULTI_SELECT"]);
        }
    }
}
