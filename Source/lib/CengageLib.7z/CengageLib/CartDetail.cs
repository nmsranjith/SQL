﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cengage.eCommerce.Lib
{
    public class CartDetail : ProductDetail
    {
        public long CartLineSk { get; set; }
        public decimal LineRRP { get; set; }
        public decimal LineUnitPriceStd { get; set; }
        public int LineGST { get; set; }
        public decimal LineDiscountPercentage { get; set; }
        public decimal LineValue { get; set; }
        public int Quantity { get; set; }
        public decimal LineTotal { get; set; }
        public int TradingPartnerSk { get; set; }
        public int StoreID { get; set; }
        public decimal LineGst { get; set; }
        public string PriceStatus { get; set; }
        public decimal LineRrp { get; set; }
        public string Href { get; set; }
        public string Stockstatus { get; set; }
        public int Stockqty { get; set; }
        public string IsCachedPrice { get; set; }
    }
}
