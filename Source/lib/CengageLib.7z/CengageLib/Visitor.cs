﻿/// <summary>
/// Class which helps to keep track of user/visitor details
/// </summary>
using System;
using System.Web;


[Serializable]
public class Visitor
{
    #region property methods
    public int UserID { get; set; }
    public string UserName { get; set; }
    public string DomainOfUser { get; set; }
    public string CountryName { get; set; }
    public string CountryCode { get; set; }
    public string IPAddress { get; set; }
    public string StoreID { get; set; }
    public string ShippingCountry { get; set; }
    public int TradingAccountSK { get; set; }
    public string CurrencyCode { get; set; }
    public string GstApplicable { get; set; }
    public string UserCreated { get; set; }
    public string Currency { get; set; }
    public string UserEmail { get; set; }
    public int BranchCode { get; set; }
    public string User_IP_Country { get; set; }
    public string VerificationStatus { get; set; }
    public string StoreSK { get; set; }

    public string AppTragetSearchCode { get; set; }

    public int CengageUser { get; set; }
    public int DefaultAccountRoleSK { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }

    public string BusinessAccount { get; set; }
    public string PersonalAccount { get; set; }
    public string StaffAccount { get; set; }
    public string PartnerType { get; set; }

    public string FilterDivision { get; set; }

    public string RepID { get; set; }

    public string Filter { get; set; }

    #region HESEARCH
    public string ProductSK { get; set; }
    public string ActionType { get; set; }
    public string Division { get; set; }
    public HttpContext context { get; set; }
    #endregion
    #endregion

    public string AreaOfInterest { get; set; }

    public string UserType { get; set; }

    public string SecondaryEmail { get; set; }

    public string PrimaryPassword { get; set; }

    public string SecondaryPassword { get; set; }

    public string GUID { get; set; }
	
    public string ContactID { get; set; }

    public int SecondaryID { get; set; }
}