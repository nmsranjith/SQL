﻿
/*******************************
 * Project          :   Ecommerce
 * Module Name      :   Subscription Upgrade
 * Author           :   Srinivasan M
 * Creation date    :   12-06-2013
 * Description      :   will be provide
  
 Modification History
 * by                       Date                            Remarks
 
*****************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Cengage.Ecommerce
{
    [Serializable]
    public class SubscriptionInfo
    {
        public int CUSTOMER_SUB_SK { get; set; }
        public int SUBSCRIPTION_SK { get; set; }
        public int QUANTITY_LICENCES { get; set; }
        public int SUBSK { get; set; }
        public int BASE_QUANTITY_LICENCES { get; set; }
        public int REMAINING_MONTH { get; set; }
        public int UserSk { get; set; }
        public int TradingPartnerSK { get; set; }
        public int STORE_SK { get; set; }
        public int PRODUCT_SK { get; set; }        
        public double TotalAmt { get; set; }

        public string RenewType { get; set; }
        public string RenewBy { get; set; }
        public string Country { get; set; }
        public string PurchaseType { get; set; }
        public string CreatedBy { get; set; }
        public string Currency { get; set; }
        public string UserModified { get; set; }
        public string Flag { get; set; }
        public string SUBS_ID { get; set; }
        public string SUB_QTY { get; set; }
        public string ACTIVE { get; set; }
        public string SUB_QTY_ALL { get; set; }
        public string STORE_ID { get; set; }
        public string GST_APPLICABLE { get; set; }
        public string PRO_RATE_UOM { get; set; }
        public string PRO_RATE_RULE { get; set; }
        public string TIME_PERIOD { get; set; }
        public string TIME_PERIOD_UOM { get; set; }
        public string PERIOD_TYPE { get; set; }
        public string ISBN_13 { get; set; }
        public string TITLE { get; set; }
        public string Order_SK { get; set; }

        public DateTime START_DATE { get; set; }
        public DateTime END_DATE { get; set; }        
        
    }
}