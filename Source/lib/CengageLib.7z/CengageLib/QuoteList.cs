﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cengage.eCommerce.CengageLib
{
    public class QuoteList
    {

        public string AccountName { get; set; }
        public string AccountNumber { get; set; }
        public string QuoteName { get; set; }
        public string QuoteReferenceNo { get; set; }
        public int Quantity { get; set; }
        public string QuotePrice { get; set; }
        public string Status { get; set; }
        public string ExpiryDate { get; set; }
        public string IsFavorite { get; set; }
        public string QuoteSK { get; set; }
        public string CanDelete { get; set; }
        public string AssignedToUserSK { get; set; }
        
    }
}
