﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Cengage.Ecommerce.CheckOut
{
    [Serializable]
    public class ProductLists
    {
        public int QTY { get; set; }
        public string PRODUCT_TITLE { get; set; }
        public double RRP_PRICE { get; set; }
        public string DISCOUNT_PERCENTAGE { get; set; }
        public double LINE_TOTAL { get; set; }
        public string ISBN13 { get; set; }
        public string MEDIA_TYPE { get; set; }

        public string SUBS_NAME { get; set; }
        public DateTime START_DATE { get; set; }
        public DateTime END_DATE { get; set; }
        public string TIME_PERIOD { get; set; }
        public string TIME_PERIOD_UOM { get; set; }

        public int PRODUCTSK { get; set; }
        public double DISCOUNT_PRICE { get; set; }
        public double GST_PRICE { get; set; }
        public double ORDER_TOTAL_PRICE { get; set; }
        public double DISCOUNT_UNIT_PRICE { get; set; }
        public string STOCKSTATUS { get; set; }
        public int Stockqty { get; set; }


    }
    
}