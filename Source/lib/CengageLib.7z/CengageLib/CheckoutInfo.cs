﻿using System;
using System.Data;
namespace Cengage.Ecommerce.CheckOut.Components.Model
{
    [Serializable]
    public class CheckoutInfo
    {
        public string Flag { get; set; }


        public int QTY { get; set; }
        public int id { get; set; }
        public int USERSK { get; set; }
        public int TRADINGPARTNERSK { get; set; }
        public int USER_ROLE_SK { get; set; }
        public int SECURITY_QUESTION_SK { get; set; }
        public int ADDRESS_SK { get; set; }
        public int COUNTRY_SK { get; set; }
        public int SEQ_NUMBER { get; set; }
        public int RCODE { get; set; }

        public string Order_SK { get; set; }
        public int SECURITYQUESTIONSK { get; set; }  
        public string MEDIA_TYPE { get; set; }        
        public string StroreID { get; set; }
        public string REQUIRES_SHIPPING { get; set; }
        public string ACTIVE { get; set; }
        public string SECURITY_QUESTIONS { get; set; }
        public string ADDRESS_LINE1 { get; set; }
        public string ADDRESS_LINE { get; set; }
        public string ADDRESS_LINE2 { get; set; }
        public string ADDRESS_LINE3 { get; set; }
        public string PARTNER_TYPE { get; set; }
        public string SHIP_TO_RULE { get; set; }
        public string PURCHASE_FLAG { get; set; }
        public string IS_DEFAULT_PARTNER { get; set; }
        public string LOGIN_NAME { get; set; }
        public string POSTAL_CODE { get; set; }
        public string SUBURB_AND_STATE { get; set; }
        public string COUNTRY_NAME { get; set; }
        public string COUNTRY_CODE { get; set; }
        public string PHONE { get; set; }
        public string EMAIL { get; set; }
        public string ISBN13LIST { get; set; }
        public string ISBN13 { get; set; }
        public string REGISTERED_BUSINESS_NAME { get; set; }
        public string SUBS_NAME { get; set; }
        public string ROLE_NAME { get; set; }
        public string TIME_PERIOD { get; set; }
        public string TIME_PERIOD_UOM { get; set; }
        public string BM_PAYMENT_TERMS { get; set; }
        public string PAY_OPTION { get; set; }
        public string PAY_OPTION_UI_REF { get; set; }
        public string PAY_TERM_TYPE { get; set; }
        public string DIRECT_SUBMIT { get; set; }
        public string CURRENCY { get; set; }
        public string CCNUMBER { get; set; }
        public string CCVN { get; set; }
        public string GSTV { get; set; }
        public string CURRENCYCODE { get; set; }        
        public string ATTENTIONTO { get; set; }
        public string SHIPPINGNOTE { get; set; }
        public string PAGETYPE { get; set; }
        public string CCNAME { get; set; }        
        public string RCODEDESC { get; set; }
        public string CTYPE { get; set; }
        public string FIRSTNAME { get; set; }
        public string LASTNAME { get; set; }                
        public string PASSWORD { get; set; }        
        public string SECURITYQUESTION { get; set; }
        public string SECURITYQUESTANS { get; set; }
        public string USERCREATE { get; set; }
        public string USERTYPE   { get; set; }
        public string ROLEID { get; set; }
        public string PURCHASETYPE { get; set; }
        public string STOREID { get; set; }
        public string STORESK { get; set; }
        public string PAYMENTREFERENCENUMBER { get;set;}
        public string PRODUCT_TITLE { get; set; }
        public double GST { get; set; }        
        public double SHIPPINGCOST { get; set; }
        public double TOTALPRICE { get; set; }
        public double LINE_TOTAL { get; set; }
        public DataTable PrductIDList { get; set; }
        public DateTime START_DATE { get; set; }
        public DateTime END_DATE { get; set; }
        public void Dispose()
        {            
            throw new NotImplementedException();
        }
    }
}