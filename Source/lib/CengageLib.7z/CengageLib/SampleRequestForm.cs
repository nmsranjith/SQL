﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cengage.eCommerce.Lib
{
    class SampleRequestForm
    {
    }
    // --------------------------------------------------------------------------------------------------------------------
    // <copyright file="SRFSupplements" company="CENGAGE LEARNING AUSTRALIA PTY LIMITED">
    //    Copyright (c) 2014 CENGAGE LEARNING AUSTRALIA PTY LIMITED
    // </copyright>
    // <summary>
    //    DAO class for Sample Request Form Teacher Supplements
    // </summary>
    // ---------------------------------------------------------------------------------------------------------------------    
    public class SRFSupplements
    {
        public int ProductSk { get; set; }
        public string Title { get; set; }
        public string ISBN { get; set; }
        public string Description { get; set; }
        public string WatchDemo { get; set; }
        public string LearnMore { get; set; }
        public string MediaType { get; set; }
        public string Price { get; set; }
        public bool IsCore { get; set; }
    }

    // --------------------------------------------------------------------------------------------------------------------
    // <copyright file="SRFItems" company="CENGAGE LEARNING AUSTRALIA PTY LIMITED">
    //    Copyright (c) 2014 CENGAGE LEARNING AUSTRALIA PTY LIMITED
    // </copyright>
    // <summary>
    //    DAO class for Sample Request Form Formats 
    // </summary>
    // ---------------------------------------------------------------------------------------------------------------------    
    public class SRFItems
    {
        public int ProductSk { get; set; }
        public string ISBN { get; set; }
        public string ProductImageUrl { get; set; }
        public string FormatType { get; set; }
        public string Description { get; set; }
        public string Price { get; set; }
        public string FormatTypeText { get; set; }

        public string ProductName { get; set; }
        public string SecondLevelDiscipline { get; set; }
        public string SecondLevelUrl { get; set; }
        public string ThirdLevelDiscipline { get; set; }
        public string ThirdLevelUrl { get; set; }
    }
}
