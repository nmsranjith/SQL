﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DotNetNuke.Entities.Content;
using System.Data;
using DotNetNuke.Common.Utilities;

namespace Cengage.eCommerce.Lib
{
    public class Facets //: ContentItem
    {
        //public string AttributeName { get; set; }
        //public string AttributeTypeValue { get; set; }
        //public int ProductCount { get; set; }
        //public string IsMultiselect { get; set; }
        //public int AttributeTypeSK { get; set; }
        //public int AttributeTypeVaueSK { get; set; }


        //public override void Fill(IDataReader DataReader)
        //{
        //    AttributeName = Null.SetNullString(DataReader["ATTRIBUTE_NAME"]);
        //    AttributeTypeValue = Null.SetNullString(DataReader["ATTRIBUTE_TYPE_VALUE"]);
        //    ProductCount = Null.SetNullInteger(DataReader["ProductCount"]);
        //    IsMultiselect = Null.SetNullString(DataReader["IS_MULTI_SELECT"]);
        //    AttributeTypeSK = Null.SetNullInteger(DataReader["ATTRIBUTE_TYPE_SK"]);
        //    AttributeTypeVaueSK = Null.SetNullInteger(DataReader["ATTRIBUTE_TYPE_VALUE_SK"]);
        //}

        public string ATTRIBUTE_NAME { get; set; }
        public int ATTRIBUTE_TYPE_SK { get; set; }
        public string ATTRIBUTE_TYPE_VALUE { get; set; }
        public int ATTRIBUTE_TYPE_VALUE_SK { get; set; }
        public int PROD_COUNT { get; set; }
        public string IS_MULTI_SELECT { get; set; }
        public string IS_CURRENT { get; set; }
        public string IS_SELECTED { get; set; }
        public int SEQNUM { get; set; }		
        public string IS_PARENT { get; set; }

        public string ParentFacetTitle { get; set; }
        public string ChildFacetTitle { get; set; }
    }
}
