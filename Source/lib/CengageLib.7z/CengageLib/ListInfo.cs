﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Cengage.Ecommerce.List.Components.Model
{
    [Serializable]
    public class ListInfo : IDisposable
    {
        # region Constructor
        public ListInfo() { }
        #endregion

        # region Public Property
        public string Flag { get; set; }
        public int Productsk { get; set; }
        public string ImageFileName { get; set; }
        public int ProductID { get; set; }
        public string ISBN13 { get; set; }
        public string Title { get; set; }
        public int Quantity { get; set; }
        public string ISBNS { get; set; }
        public string ListProductSk { get; set; }
        public string GenericFlag { get; set; }
        public string UserListQuoteSK { get; set; }
        public int UserSK { get; set; }
        public string Name { get; set; }
        public string IS_FAVOURITE { get; set; }
        public string ListType { get; set; }
        public int ProductCount { get; set; }
        public string Status { get; set; }
        public string QUOTE_EXPIRES_ON { get; set; }
        public int QUOTE_REF_NUMBER { get; set; }
        public string AppTargetCode { get; set; }
        public string Email { get; set; }
        public string Suburb { get; set; }
        public string Subjects { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public string DIVISION { get; set; }
        public string ROLE_NAME { get; set; }
        
        public string SUBMIT_ORDER_DIRECTLY { get; set; }
        //*******WebService Property**********//        
        public double RRP{get;set;}
        public double DiscountPrice{get;set;}
        public string CurrencyCode{get;set;}
        public string IsGstIncluded{get;set;}
        public string AllowSale{get;set;}
        public double LineItemTotal { get; set; }
        public string PriceType {get;set;}
        public string PARTNER_TYPE { get; set; }
        public string PriceSourceType{get;set;}
        public double DisplayIndividualPrice { get; set; }
        //*******Attributes Property********//
        public string Authors { get; set; }
        public string Students { get; set; }
        public string Product { get; set; }
        
        
        #endregion

        public void Dispose()
        {
            GC.Collect();
        }
    }





}