﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DotNetNuke.Entities.Content;
using DotNetNuke.Common.Utilities;
using System.Data;
using System.Configuration;
using System.Text.RegularExpressions;

public class CengageSearchResult :ContentItem
{
    public string Isbn10 { get; set; }
    public string Isbn13 { get; set; }
    public string Author { get; set; }
    public string Title { get; set; }
    public string AttributeName { get; set; }
    public string AttributeTypeValue { get; set; }
    public string ImagePath { get; set; }
    public int ProductSK { get; set; }
    public string AppTargetCode { get; set; }
    public string ProductDescription { get; set; }
    //public string PubStatusCode { get; set; }
    public int Edition { get; set; }
    public int CopyRightYear { get; set; }
    public DateTime PublicationDate { get; set; }
    public string IsDisplayAttribute { get; set; }
    public string IsMultiSelect { get; set; }
    public string SearchText { get; set; }
    public bool Chkstatus { get; set; }
    public bool AddStatus { get; set; }
    public string PriceVal { get; set; }
    public string DiscountVal { get; set;}
    public int QtyVal { get; set; }
    public string AllowSale { get; set; }
    public bool DiscountFlag
    {
        get;
        set;
    }
    public bool RrpFlag{ get; set; }

    public string StockAvail { get; set; }
    public double RRPPrice { get; set; }
    public double DiscountPrice { get; set; }
    public List<string> AttributeTypeCollection { get; set; }
    public string Exacturl { get; set; }
    public string IsCachedPrice { get; set; }
    public int? Stockqty { get; set; }
    public string Stockavailable { get; set; }
    
    public override void Fill(IDataReader DataReader)
    {
       Isbn10 = Null.SetNullString(DataReader["ISBN_10"]);
       Isbn13 = Null.SetNullString(DataReader["ISBN_13"]);
       Author = Null.SetNullString(DataReader["PREFERRED_NAME"]);
       Title = Null.SetNullString(DataReader["TITLE"]);
       AttributeName = Null.SetNullString(DataReader["ATTRIBUTE_NAME"]);
       AttributeTypeValue = Null.SetNullString(DataReader["ATTRIBUTE_TYPE_VALUE"]);
       ImagePath = Null.SetNullString(DataReader["IMAGE_FILE_NAME"]);
       AppTargetCode = Null.SetNullString(DataReader["APP_TARGET_CODE"]);
       ProductDescription = Null.SetNullString(DataReader["DESCRIPTION"]);
       ProductSK =Null.SetNullInteger(DataReader["PRODUCT_SK"]);
       //PubStatusCode = Null.SetNullString(DataReader["PUB_STATUS_CODE"]);
       Edition = Null.SetNullInteger(DataReader["EDITION"]);
       CopyRightYear = Null.SetNullInteger(DataReader["COPYRIGHT_YEAR"]);
       PublicationDate = Null.SetNullDateTime(DataReader["PUBLICATION_DATE"]);
       IsDisplayAttribute = Null.SetNullString(DataReader["IS_DISPLAY_ATTRIBUTE"]);
       IsMultiSelect = Null.SetNullString(DataReader["IS_MULTI_SELECT"]);
       Chkstatus = false;
       AddStatus = false;
       DiscountFlag = false;
       RrpFlag = false;
       DiscountVal = string.Empty;
       StockAvail = "Available";
       QtyVal = 0;
       RRPPrice = 0;
       DiscountPrice = 0;
       AllowSale = "Y";
       Exacturl = string.Empty;
       IsCachedPrice = "Y";
       Stockqty = 0;
       Stockavailable = string.Empty;
    }

    /// <summary>
    /// Returns ProductDetail Url with ISBN for primary and secondary products
    /// </summary>
    /// <param name="isbnnum"></param>
    /// <param name="Title"></param>
    /// <returns></returns>
    public static string getProductURL(string isbnnum,string Title)
    {
        string Exacturl = GenerateSlug(Title);
        return string.Concat(AppRoot(),"/product","/title/",Exacturl,"/isbn/",isbnnum);

    }
	
    /// <summary>
    /// Returns ProductDetail Url with ISBN for HE and Gale products
    /// </summary>
    /// <param name="isbnnum"></param>
    /// <param name="title"></param>
    /// <param name="division"></param>
    /// <returns></returns>
	public static string getHEProductURL(string isbnnum, string title,string division)
    {
        string Exacturl = GenerateSlug(title);
        return string.Concat(AppRoot(), "/product", "/division/", division, "/title/", Exacturl, "/isbn/", isbnnum);

    }

    /// <summary>
    ///  Returns ProductDetail Url with TL Id for Gale products
    /// </summary>
    /// <param name="tlid"></param>
    /// <param name="title"></param>
    /// <param name="division"></param>
    /// <returns></returns>
    public static string getGaleProductURL(string tlid, string title, string division)
    {
        string Exacturl = GenerateSlug(title);
        return string.Concat(AppRoot(), "/product", "/division/", division, "/title/", Exacturl, "/tlid/", tlid);

    }
	
    public static string GenerateSlug(string phrase)
    {

        string str = RemoveAccent(phrase).ToLower();

        // invalid chars          

        str = Regex.Replace(str,@"[^a-z0-9\s-]","");

        // convert multiple spaces into one space  

        str = Regex.Replace(str,@"\s+"," ").Trim();

        // cut and trim

        str = str.Substring(0,str.Length <= 45 ? str.Length : 45).Trim();

        str = Regex.Replace(str,@"\s","-"); // hyphens  

        return str;

    }



    public static string RemoveAccent(string txt)
    {

        byte[] bytes = System.Text.Encoding.GetEncoding("Cyrillic").GetBytes(txt);

        return System.Text.Encoding.ASCII.GetString(bytes);

    }

    public static string AppRoot() 
    {
        return ConfigurationManager.AppSettings["ApplicationRoot"].Replace("%s%", System.Web.HttpContext.Current.Request.Url.Scheme + "://" + System.Web.HttpContext.Current.Request.Url.Authority);
    }

}
