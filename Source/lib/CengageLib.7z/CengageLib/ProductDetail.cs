﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cengage.eCommerce.Lib
{
    public class ProductDetail
    {
        public string PriceSourceType { get; set; }
        public string Curency { get; set; }
        public char AllowSale { get; set; }
        public string ImageFieName { get; set; }
        public decimal UnitPricestd { get; set; }
        public string Authors { get; set; }
        public string Students { get; set; }
        public string Products { get; set; }
        public string DiscountType { get; set; }   
        public string ProductTitle { get; set; }
        public decimal Rrp { get; set; }
        public decimal DiscountPercentage { get; set; }
        public decimal DiscountedPrice { get; set; }
        public decimal Discountvalue { get; set; }
        public string ISBN13 { get; set; }
        public bool IsGSTIncluded { get; set; }
        public int ProductSk { get; set; }
        public string MediaType { get; set; }
        public bool RequiredShipping { get; set; }
        public string SubProduct { get; set; }
        public string AccountFlag { get; set; }
        public string Substituteisbn { get; set; }
        public string Substitutetitle { get; set; }
    }
}
