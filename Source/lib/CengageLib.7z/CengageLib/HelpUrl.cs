﻿using System;
using System.Web;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Cengage.eCommerce.Lib
{
   public static class HelpUrl
   {
       public static string GetLink(string code)
       {
           
          
           XDocument document = XDocument.Load(HttpContext.Current.Server.MapPath("~/HelpUrl.config"));

           var helpurl = from r in document.Descendants("code").Where
                              (r => (string)r.Attribute("key") == code)
                         select
                            r.Element("link").Value;
           string t = helpurl.Select(u => u.ToString()).FirstOrDefault();
           return t;
       }

   }
}
