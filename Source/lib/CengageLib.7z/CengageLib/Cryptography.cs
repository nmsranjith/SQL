﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.IO;
using DotNetNuke.Instrumentation;

namespace Cengage.eCommerce.Lib
{
    public class Cryptography
    {
        public static string Decrypt(string stringToDecrypt, string sEncryptionKey)
        {
            byte[] key = { };
            byte[] IV = { 10, 20, 30, 40, 50, 60, 70, 80 };
            try
            {
                byte[] inputByteArray = new byte[stringToDecrypt.Length];

                key = Encoding.UTF8.GetBytes(sEncryptionKey.Substring(0, 8));
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                inputByteArray = Convert.FromBase64String(stringToDecrypt);
                MemoryStream ms = new MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(key, IV), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                Encoding encoding = Encoding.UTF8;
                return encoding.GetString(ms.ToArray());
            }
            catch (Exception)
            {
                return (string.Empty);
            }
        }
        public static string Encrypt(string stringToEncrypt, string sEncryptionKey)
        {
            byte[] key = { };
            byte[] IV = { 10, 20, 30, 40, 50, 60, 70, 80 };
            byte[] inputByteArray; //Convert.ToByte(stringToEncrypt.Length) 

            try
            {
                key = Encoding.UTF8.GetBytes(sEncryptionKey.Substring(0, 8));
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                inputByteArray = Encoding.UTF8.GetBytes(stringToEncrypt);
                MemoryStream ms = new MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(key, IV), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                return Convert.ToBase64String(ms.ToArray());
            }
            catch (System.Exception)
            {
                return (string.Empty);
            }
        }
		
		public static string AESEncrypt(string stringToEncrypt)
        {
            try
            {
                byte[] SECRET_KEY ={0x08, 0x88, 0xf5, 0x51, 0xc7, 0xf3, 0x65, 0x4b, 0xd0, 0x72, 0x4d, 
                                    0x78, 0x33, 0x73, 0x9c, 0xa2
                                    };
                // create and configure the encryption class
                RijndaelManaged rijndaelCipher = new RijndaelManaged();
                rijndaelCipher.Mode = CipherMode.CBC;
                rijndaelCipher.Padding = PaddingMode.PKCS7;
                rijndaelCipher.KeySize = 128;
                rijndaelCipher.BlockSize = 128;
                rijndaelCipher.Key = SECRET_KEY; // a byte array version of the secret key
                string salt = GetRandomSalt();
                rijndaelCipher.IV = GetRandomSalt(salt); // the generated salt
                // create the Encryptor
                ICryptoTransform transform = rijndaelCipher.CreateEncryptor();
                // convert the creditcard number string to a byte array
                byte[] creditCardNumberByteArray = Encoding.UTF8.GetBytes(stringToEncrypt);
                // encrypt the creditcard number
                byte[] encryptedCreditCardNumberByteArray = transform.TransformFinalBlock(
                    creditCardNumberByteArray,
                    0,
                    creditCardNumberByteArray.Length);

                // create the hexidecimal representation, prepend the salt
                string hexrep = salt
                                + BitConverter.ToString(encryptedCreditCardNumberByteArray)
                                    .ToLower()
                                    .Replace("-", string.Empty);
                return hexrep;
            }
            catch (Exception)
            {
                throw;
            }

        }



        private static string GetRandomSalt()
        {
            Random rnd = new Random();
            byte[] salt = new byte[16];
            rnd.NextBytes(salt);
            return BitConverter.ToString(salt).ToLower().Replace("-", string.Empty);
         }

        private static byte[] GetRandomSalt(string hex)
        {             
            try
            {                  
                hex = hex.ToUpper(); 
                if (hex.Length % 2 == 1)
                {                 
                    throw new Exception("String length must be MOD 2");
                }

                // RIGHT BIT SHIFT the input length 1 step. 
                // This is only similar to: byte[] arr = new byte[hex.length / 2].. it's just more efficient 
                byte[] arr = new byte[hex.Length >> 1];          

                for (int i = 0; i < hex.Length >> 1; ++i)
                {                    
                    // lots of LEFT BIT SHIFTING. try to compute it and will  give you the byte value 
                    arr[i] = (byte)((GetHexVal(hex[i << 1]) << 4) + GetHexVal(hex[(i << 1) + 1])); 
                }        
                return arr;   
            }              
            catch (Exception)
            {              
                throw;   
            }  
        }

        private static int GetHexVal(char hex)
        {   
            int val = (int)hex;   
            return val - (val < 58 ? 48 : 55); 
        }
		
        /// <summary>
        /// Decrypt the encrypted data
        /// </summary>
        /// <param name="invitee">string invitee</param>
        /// <returns>string decrypt data</returns>
        public static string UTFDecrypt(string invitee)
        {
            byte[] ToEncryptArray = Convert.FromBase64String(invitee);
            DnnLog.Fatal("decryption of invitee ..." + ToEncryptArray);
            return UTF8Encoding.UTF8.GetString(ToEncryptArray); 
        }
        /// <summary>
        /// encrypt the password with SHA1 cryptography
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        public static string EncryptPassword(string password)
        {
            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(password);
            return Convert.ToBase64String(toEncryptArray, 0, toEncryptArray.Length);
        }
    }
}
