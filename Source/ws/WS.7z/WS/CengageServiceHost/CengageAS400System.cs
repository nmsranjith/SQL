﻿/*

  *  Project Name        :   Cengage Ecommerce
  *  Module Name         :   WebService(WCF) - CengageServiceHost
  *  Developer Name      :   Sureshkumar Chandrasekar
  *  Date Created        :   26-06-2013
  *  Date Modified       :   26-07-2013

  */
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using cwbx;
using Cengage.Ecommerce.CengageServiceLibrary;


namespace Cengage.Ecommerce.CengageServiceHost
{
    /// <summary>
    /// This is the wrapper of Inetrop.cwbx dll. This dll has the interface to connect AS400 system
    /// This class defines the AS400 connection & Price calculation
    /// </summary>
    public class CengageAS400System :ISystem
    {
        AS400System as400;
        Program program;
        List<Product> productLst;
        /// <summary>
        /// Values - 1.Price 2.Price_AA
        /// </summary>
        public ProgramType ProgramName { get; set; }
        /// <summary>
        /// Constructor to maintain productlist locally
        /// </summary>
        /// <param name="productLst"></param>
        public CengageAS400System(List<Product> productLst)
        {
            this.productLst = productLst;
        }
        /// <summary>
        /// Connect the AS400 system
        /// </summary>
        /// <returns></returns>
        public bool ConnectSystem()
        {
            bool retval = false;
            try
            {
                as400 = new cwbx.AS400SystemClass();
                program = new cwbx.Program();

                //Defines the host address
                as400.Define(ConfigurationManager.AppSettings["AS400_SYSTEMNAME"].ToString());
                
                //Defines the program in the host
                program.system = as400;
                program.system.UserID = ConfigurationManager.AppSettings["AS400_USERID"].ToString();
                program.system.Password = ConfigurationManager.AppSettings["AS400_PWD"].ToString();
                program.system.PromptMode = cwbx.cwbcoPromptModeEnum.cwbcoPromptNever;
                program.system.DefaultUserMode = cwbx.cwbcoDefaultUserModeEnum.cwbcoDefaultUserIgnore;

                if (this.ProgramName == ProgramType.Price_AA)
                {
                    program.LibraryName = ConfigurationManager.AppSettings["AS400_AALIBRARY"].ToString();
                    program.ProgramName = ConfigurationManager.AppSettings["AS400_AAPGM"].ToString();
                }
                else 
                {
                    program.LibraryName = ConfigurationManager.AppSettings["AS400_PRICELIBRARY"].ToString();
                    program.ProgramName = ConfigurationManager.AppSettings["AS400_PRICEPGM"].ToString();
                }
                Logger.Log.Info("Trying to connect AS400");
                //Check the active connection status before try to connect
                if (as400.IsConnected(cwbx.cwbcoServiceEnum.cwbcoServiceRemoteCmd) == 0)
                {
                    try
                    {
                        // Lost connection with the AS400. Disconnect, then reconnect.
                        as400.Disconnect(cwbx.cwbcoServiceEnum.cwbcoServiceAll);
                        as400.Connect(cwbx.cwbcoServiceEnum.cwbcoServiceRemoteCmd);

                        if (as400.IsConnected(cwbx.cwbcoServiceEnum.cwbcoServiceRemoteCmd) == 0)
                        {
                            Logger.Log.Info("Not able to connect");
                            retval = false;
                        }
                        else
                        {
                            Logger.Log.Info("AS400 Connected");
                            retval = true;
                        }
                    }
                    catch (Exception e)
                    {
                        Logger.Log.Error("Error occured when connect AS400 system.Error:" + e.Message);
                        retval = false;
                        LogAS400Error();
                    }
                }
                else
                {
                    as400.Connect(cwbx.cwbcoServiceEnum.cwbcoServiceRemoteCmd);
                    if (as400.IsConnected(cwbx.cwbcoServiceEnum.cwbcoServiceRemoteCmd) == 0)
                    {
                        Logger.Log.Info("Not able to connect");
                        retval = false;
                    }
                    else
                    {
                        Logger.Log.Info("AS400 Connected");
                        retval = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log.Error("Error occured when connect AS400 system.Error:" + ex.Message);
                retval = false;
                LogAS400Error();
            }
            return retval;
        }
        /// <summary>
        /// Disconnect the AS400 system
        /// </summary>
        public void DisconnectSystem()
        {
            try
            {
                as400.Disconnect(cwbx.cwbcoServiceEnum.cwbcoServiceAll);
                Logger.Log.Info("AS400 disconnected");
            }
            catch (Exception)
            {
                Logger.Log.Error("Error occured when disconnect AS400 system");
                LogAS400Error();
            }
        }
        /// <summary>
        /// Checks the availablity of product
        /// </summary>
        public void CheckAvailablity()
        {
            try
            {
                foreach (Product ProductItem in productLst)
                {
                    Logger.Log.Info("Product isbn - " + ProductItem.ISBN + " , Account - " + ProductItem.TradingAccountNumber + ", Qty -" + ProductItem.Quantity.ToString());
                    ProductItem.ePriceSource = PriceSource.CENGAGE_AS400;

                    StringConverter stringConverter = new cwbx.StringConverterClass();
                    PackedConverter packedConverter = new cwbx.PackedConverterClass();
                    ProgramParameters parameters = new cwbx.ProgramParametersClass();

                    // set input parameters
                    CreateStringParameter(parameters, stringConverter, "Item", 20, ProductItem.ISBN, cwbx.cwbrcParameterTypeEnum.cwbrcInput);
                    CreateStringParameter(parameters, stringConverter, "Customer", 10, ProductItem.TradingAccountNumber, cwbx.cwbrcParameterTypeEnum.cwbrcInput);
                    CreateStringParameter(parameters, stringConverter, "StockRequired", 1, "Y", cwbx.cwbrcParameterTypeEnum.cwbrcInout);

                    //set output Parameters
                    CreateStringParameter(parameters, stringConverter, "Response", 4, string.Empty, cwbx.cwbrcParameterTypeEnum.cwbrcOutput);
                    CreateStringParameter(parameters, stringConverter, "CustomerAllowed", 1, string.Empty, cwbx.cwbrcParameterTypeEnum.cwbrcOutput);
                    CreatePackedParameter(parameters, packedConverter, "Stock", 13, 4, string.Empty, cwbx.cwbrcParameterTypeEnum.cwbrcOutput);
                    CreateStringParameter(parameters, stringConverter, "SOHA", 20, string.Empty, cwbx.cwbrcParameterTypeEnum.cwbrcOutput);

                    try
                    {
                        // Define the command
                        Command initCommand = new CommandClass();
                        initCommand.system = program.system;
                        // note "TNT" will need to be replace with the production environment, this new production code would be supplied by Cengage.
                        Logger.Log.Info("SET TMSBASE/SETUP with code " + ConfigurationManager.AppSettings["TMSBASE_SETUP_CODE"]);
                        initCommand.Run("TMSBASE/SETUP " + ConfigurationManager.AppSettings["TMSBASE_SETUP_CODE"]);

                        // call the program
                        Logger.Log.Info("Executing check availablity");
                        program.Call(parameters);

                        // get output parameters
                        ProductItem.StockSohaCode = GetStringParameterValue(parameters, stringConverter, "SOHA", 20);
                        ProductItem.StockAvailableQuantity =double.Parse(packedConverter.FromBytes(parameters["Stock"].Value));
                        if (ProductItem.StockAvailableQuantity > 0)
                        {
                            Logger.Log.Info("Product available");
                            ProductItem.StockStatus = "Available";
                        }
                        else
                        {
                            Logger.Log.Info("Product is not available");
                            ProductItem.StockStatus = "Out of stock";
                        }
                        ProductItem.AllowSale = char.Parse(GetStringParameterValue(parameters, stringConverter, "CustomerAllowed", 1));
                        ProductItem.Response = GetStringParameterValue(parameters, stringConverter, "Response", 4);
                        ProductItem.ePriceSource = PriceSource.CENGAGE_AS400;

                        Logger.Log.Info("Program output. 1.AllowSale-" + ProductItem.AllowSale + " 2.Response-" + ProductItem.Response);
                    }
                    catch (Exception)
                    {
                        Logger.Log.Error("Error occured when execute check availablity program");
                        LogAS400Error();
                        throw;
                    }         
                }
            }
            catch (Exception)
            {
                Logger.Log.Error("Error occured when execute check availablity program");
                throw;
            }
        }
        /// <summary>
        /// to calculate the price of product
        /// </summary>
        public void CalculatePrice()
        {
            try
            {
                foreach (Product ProductItem in productLst)
                {
                    ProductItem.ePriceSource = PriceSource.CENGAGE_AS400;

                    Logger.Log.Info("Calculting price. ISBN - " + ProductItem.ISBN + ", Account -" + ProductItem.TradingAccountNumber + ",GST - " + ProductItem.IsGSTIncluded.ToString()+",Quantity - "+ProductItem.Quantity.ToString());
                    StringConverter stringConverter = new cwbx.StringConverterClass();
                    PackedConverter packedConverter = new cwbx.PackedConverterClass();
                    ProgramParameters parameters = new cwbx.ProgramParametersClass();
                    ProductItem.Quantity = (ProductItem.Quantity == 0) ? 1 : ProductItem.Quantity;

                    // set input parameters
                    CreateStringParameter(parameters, stringConverter, "P$I", 20, ProductItem.ISBN, cwbx.cwbrcParameterTypeEnum.cwbrcInput);
                    CreateStringParameter(parameters, stringConverter, "P$CN", 10, ProductItem.TradingAccountNumber, cwbx.cwbrcParameterTypeEnum.cwbrcInput);
                    CreateStringParameter(parameters, stringConverter, "P$QTY", 3, ProductItem.Quantity.ToString(), cwbx.cwbrcParameterTypeEnum.cwbrcInput);
                    CreatePackedParameter(parameters, packedConverter, "P$RRP", 9, 2, string.Empty, cwbx.cwbrcParameterTypeEnum.cwbrcOutput);
                    CreatePackedParameter(parameters, packedConverter, "P$BTTB", 11, 2, string.Empty, cwbx.cwbrcParameterTypeEnum.cwbrcOutput);
                    CreatePackedParameter(parameters, packedConverter, "P$BTTX", 11, 2, string.Empty, cwbx.cwbrcParameterTypeEnum.cwbrcOutput);
                    CreatePackedParameter(parameters, packedConverter, "P$DCRA", 5, 2, string.Empty, cwbx.cwbrcParameterTypeEnum.cwbrcOutput);
                    CreatePackedParameter(parameters, packedConverter, "P$TXRA", 7, 4, string.Empty, cwbx.cwbrcParameterTypeEnum.cwbrcOutput);
                    CreateStringParameter(parameters, stringConverter, "C$RRP", 10, string.Empty, cwbx.cwbrcParameterTypeEnum.cwbrcOutput);
                    CreateStringParameter(parameters, stringConverter, "C$BTTB", 12, string.Empty, cwbx.cwbrcParameterTypeEnum.cwbrcOutput);
                    CreateStringParameter(parameters, stringConverter, "C$BTTX", 12, string.Empty, cwbx.cwbrcParameterTypeEnum.cwbrcOutput);
                    CreateStringParameter(parameters, stringConverter, "C$DCRA", 6, string.Empty, cwbx.cwbrcParameterTypeEnum.cwbrcOutput);
                    CreateStringParameter(parameters, stringConverter, "C$TXRA", 8, string.Empty, cwbx.cwbrcParameterTypeEnum.cwbrcOutput);
                    CreateStringParameter(parameters, stringConverter, "P$Response", 4, string.Empty, cwbx.cwbrcParameterTypeEnum.cwbrcOutput);

                    try
                    {
                        Command initCommand = new CommandClass();

                        initCommand.system = program.system;

                        // note "TNT" will need to be replace with the production environment, this new production code would be supplied by Cengage.
                        Logger.Log.Info("SET TMSBASE/SETUP with code " + ConfigurationManager.AppSettings["TMSBASE_SETUP_CODE"]);
                        initCommand.Run("TMSBASE/SETUP " + ConfigurationManager.AppSettings["TMSBASE_SETUP_CODE"]);

                        // call the program
                        Logger.Log.Info("Executing price calculate program");
                        program.Call(parameters);
                        ProductItem.Response = GetStringParameterValue(parameters, stringConverter, "P$Response", 4);
                        if (ProductItem.Response != null && string.Equals(ProductItem.Response.Trim(),"0000"))
                        {

                            StringBuilder outputLog = new StringBuilder();
                            // get Tax Amount 
                            try
                            {
                                ProductItem.BaseTaxAmount = double.Parse(GetStringParameterValue(parameters, stringConverter, "C$BTTX", 12).Trim());
                                ProductItem.GSTUnit = ProductItem.BaseTaxAmount;
                                outputLog.Append(" 1. C$BTTX , BaseTaxAmount , GSTUnit : " + ProductItem.BaseTaxAmount.ToString());
                            }
                            catch (Exception)
                            {
                                ProductItem.BaseTaxAmount = 0;
                                outputLog.Append(" 1. C$BTTX , BaseTaxAmount , GSTUnit : 0");
                            }

                            //get Tax Percentage
                            try
                            {
                                ProductItem.TaxRateActual = double.Parse(GetStringParameterValue(parameters, stringConverter, "C$TXRA", 8).Trim());
                                outputLog.Append(" 2. C$TXRA , TaxRateActual : " + ProductItem.TaxRateActual.ToString());
                            }
                            catch (Exception)
                            {
                                ProductItem.TaxRateActual = 0;
                                outputLog.Append(" 2. C$TXRA , TaxRateActual : 0");
                            }

                            // get RRP
                            try
                            {
                                ProductItem.RRP = double.Parse(GetStringParameterValue(parameters, stringConverter, "C$RRP", 10).Trim());
                                outputLog.Append(" 3. C$RRP, RRP : " + GetStringParameterValue(parameters, stringConverter, "C$RRP", 10).Trim());
                                if (!ProductItem.IsGSTIncluded && ProductItem.TaxRateActual != 0)
                                {
                                    ProductItem.RRP = double.Parse(GetStringParameterValue(parameters, stringConverter, "C$RRP", 10).Trim()) - (double.Parse(ProductItem.RRP.ToString()) / double.Parse(ProductItem.TaxRateActual.ToString()));
                                    outputLog.Append(" (RRP - (RRP/TaxRateActual)) as RRP : " + ProductItem.RRP);
                                }
                            }
                            catch (Exception)
                            {
                                ProductItem.RRP = 0;
                                outputLog.Append(" 3. C$RRP,RRP : 0");
                            }

                            // get Discount Percentage
                            try
                            {
                                ProductItem.DiscountrateActual = double.Parse(GetStringParameterValue(parameters, stringConverter, "C$DCRA", 6).Trim());
                                outputLog.Append(" 4. C$DCRA,DiscountrateActual : " + ProductItem.DiscountrateActual.ToString());
                            }
                            catch (Exception)
                            {
                                ProductItem.DiscountrateActual = 0;
                                outputLog.Append(" 4. C$DCRA,DiscountrateActual : 0");
                            }

                            // get Discounted Unit Price
                            try
                            {
                                if (ProductItem.DiscountrateActual == 0)
                                {
                                    ProductItem.UnitPriceActual = double.Parse((ProductItem.RRP * double.Parse(ProductItem.Quantity.ToString())).ToString());
                                    outputLog.Append(" 5. DiscountrateActual is 0, (UnitPriceActual = RRP*Qty) : " + ProductItem.UnitPriceActual.ToString());
                                }
                                else
                                {
                                    ProductItem.UnitPriceActual = double.Parse(GetStringParameterValue(parameters, stringConverter, "C$BTTB", 12).Trim());
                                    if (ProductItem.IsGSTIncluded)
                                    {
                                        ProductItem.UnitPriceActual += ProductItem.BaseTaxAmount;
                                        outputLog.Append(" 5. GSTIncluded(local) : N  (UnitPriceActual+BaseTaxAmount) as UnitPriceActual :" + ProductItem.UnitPriceActual.ToString());
                                    }
                                    ProductItem.DiscountedUnitPrice = ProductItem.UnitPriceActual / double.Parse(ProductItem.Quantity.ToString());
                                }
                            }
                            catch (Exception)
                            {
                                ProductItem.UnitPriceActual = 0;
                                outputLog.Append(" 5. C$BTTB,UnitPriceActual : 0");
                            }

                            //get LineItem Value
                            //ProductItem.LineItemValue = double.Parse(ProductItem.Quantity.ToString()) * ProductItem.UnitPriceActual;
                            ProductItem.LineItemValue = ProductItem.UnitPriceActual;
                            outputLog.Append(" 6. LineItemValue ,  UnitPriceActual : " + ProductItem.LineItemValue);
                            Logger.Log.Info("Program Output : " + outputLog.ToString());
                        }
                        else
                        {
                            throw new Exception("AS400 response code is :" + ProductItem.Response);
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Log.Error("Error occured when execute price calculation program");
                        throw ex;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        /// <summary>
        /// Log AS400 errors
        /// </summary>
        private void LogAS400Error()
        {
            StringBuilder as400Errors = new StringBuilder();
            if (as400 != null && as400.Errors != null && as400.Errors.Count > 0)
            {
                if (as400.Errors.Count > 0)
                {
                    foreach (Error error in as400.Errors)
                    {
                        as400Errors.Append(error.Text + Environment.NewLine);
                    }
                }
            }

            if (program != null && program.Errors != null && program.Errors.Count > 0)
            {
                if (program.Errors.Count > 0)
                {
                    foreach (Error error in program.Errors)
                    {
                        as400Errors.Append(error.Text + Environment.NewLine);
                    }
                }
            }
            if (as400Errors.ToString() != string.Empty)
            {
                Logger.Log.Error("CengageServiceHost - AS400 : " + as400Errors.ToString());
            }
        }
        /// <summary>
        ///  AS400 string parameter
        /// </summary>
        /// <param name="parameters"></param>
        /// <param name="stringConverter"></param>
        /// <param name="paramName"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        private string GetStringParameterValue(
           ProgramParameters parameters,
           StringConverter stringConverter,
           string paramName,
           int length)
        {
            try
            {
                stringConverter.Length = length;
                return stringConverter.FromBytes(parameters[paramName].Value);
            }
            catch (Exception)
            {
                throw;
            }
        }
        /// <summary>
        /// Construct AS400 String parameter
        /// </summary>
        /// <param name="parameters"></param>
        /// <param name="stringConverter"></param>
        /// <param name="paramName"></param>
        /// <param name="length"></param>
        /// <param name="value"></param>
        /// <param name="direction"></param>
        private void CreateStringParameter(
            ProgramParameters parameters,
            StringConverter stringConverter,
            string paramName,
            int length,
            string value,
            cwbrcParameterTypeEnum direction)
        {
            parameters.Append(paramName, direction, length);
            stringConverter.Length = length;
            parameters[paramName].Value = stringConverter.ToBytes(value.PadRight(length, ' '));
        }
        /// <summary>
        /// AS400 Packed parameter
        /// </summary>
        /// <param name="parameters"></param>
        /// <param name="packedConverter"></param>
        /// <param name="paramName"></param>
        /// <param name="length"></param>
        /// <param name="decimalPosition"></param>
        /// <param name="value"></param>
        /// <param name="direction"></param>
        private void CreatePackedParameter(
            ProgramParameters parameters,
            PackedConverter packedConverter,
            string paramName,
            int length,
            int decimalPosition,
            string value,
            cwbrcParameterTypeEnum direction)
        {
            parameters.Append(paramName, direction, length);
            packedConverter.Digits = length;
            packedConverter.DecimalPosition = decimalPosition;
            parameters[paramName].Value = packedConverter.ToBytes(value);
        }
    }
    /// <summary>
    /// Types - 1.Price Calculation 2.Price Availablity
    /// </summary>
    public enum ProgramType
    {
        Price,Price_AA
    }
}
    