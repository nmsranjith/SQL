﻿/*

  *  Project Name        :   Cengage Ecommerce
  *  Module Name         :   WebService(WCF) - CengageServiceHost
  *  Developer Name      :   Sureshkumar Chandrasekar
  *  Date Created        :   26-06-2013
  *  Date Modified       :   26-07-2013

  */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Text;
using Cengage.Ecommerce.CengageServiceLibrary;


namespace Cengage.Ecommerce.CengageServiceHost
{
    /// <summary>
    /// This is the wrapper of ECOM sysem. this is the interface to connect & Process ECOM operations 
    /// This class defines the ECOM connection & Price calculation
    /// </summary>
    public class CengageECOMSystem : ISystem
    {
        List<Product> products;
        SqlConnection sqlconnection = null;
        /// <summary>
        /// Constructor to maintain the product list 
        /// </summary>
        /// <param name="products"></param>
        public CengageECOMSystem(List<Product> products)
        {
            this.products = products;
        }
        /// <summary>
        /// Connect Ecom system
        /// </summary>
        /// <returns></returns>
        public bool ConnectSystem()
        {
            try
            {
                sqlconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ECOM_CONN"].ToString());
                Logger.Log.Info("Connecting ECom system");
                sqlconnection.Open();
                Logger.Log.Info("ECom system connected");
                return true;
            }
            catch (Exception)
            {
                Logger.Log.Error("Error occured when connect Ecom system");
                throw;
            }
        }
        /// <summary>
        /// Disconnect Ecom system
        /// </summary>
        public void DisconnectSystem()
        {
            try
            {
                Logger.Log.Info("Disconnecting ECom system");
                if (sqlconnection.State == ConnectionState.Open)
                {
                    sqlconnection.Close();
                    Logger.Log.Info("ECom system disconnected");
                    sqlconnection.Dispose();
                }
            }
            catch (Exception)
            {
                Logger.Log.Error("Error occured when disconnect ECom");
                throw;
            }
        }
        /// <summary>
        /// Calculate price for all products
        /// </summary>
        public void CalculatePrice()
        {
            SqlCommand command = null;
            SqlDataAdapter adapter = null;
            DataTable dt = null;
            try
            {
                foreach (Product ProductItem in products)
                {
                    //set price source as ECOM
                    ProductItem.ePriceSource = PriceSource.CENGAGE_AS400;
                    Logger.Log.Info("Calculating price for product ISBN - " + ProductItem.ISBN);
                    command = new SqlCommand("WS_GETPRODUCTPRICE", sqlconnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(new SqlParameter("@Isbn", ProductItem.ISBN));
                    command.Parameters.Add(new SqlParameter("@Currency", ProductItem.CurrencyCode));
                    command.Parameters.Add(new SqlParameter("@GST_Applicable", (ProductItem.IsGSTIncluded)?"Y":"N"));
                    using (adapter = new SqlDataAdapter(command))
                    {
                        dt = new DataTable();
                        adapter.Fill(dt);
                    }
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        Logger.Log.Info("Price calculated");
                        ProductItem.PriceType = dt.Rows[0]["PRICE_TYPE"].ToString();
                        ProductItem.CurrencyCode = dt.Rows[0]["CURRENCY"].ToString();
                        ProductItem.RRP = (ProductItem.IsGSTIncluded) ? double.Parse(dt.Rows[0]["GST_PRICE"].ToString()) : double.Parse(dt.Rows[0]["PRICE"].ToString());
                        ProductItem.UnitPriceActual = ProductItem.RRP;
                        ProductItem.StockAvailableQuantity = double.Parse(dt.Rows[0]["STOCK_QUANTITY"].ToString());
                        ProductItem.LineItemValue = double.Parse(ProductItem.Quantity.ToString()) * ProductItem.RRP;
                        if (ConfigurationManager.AppSettings["FORCE_DISCONNECTBM"] == "Y")
                        {
                            ProductItem.AllowSale = 'Y';
                        }
                        else
                        {
                            ProductItem.AllowSale = 'N';
                        }
                        ProductItem.ePriceSource = PriceSource.CENGAGE_AS400;
                        ProductItem.GSTUnit = double.Parse(dt.Rows[0]["GST_PRICE"].ToString()) - double.Parse(dt.Rows[0]["PRICE"].ToString());
                    }
                    else
                    {
                        Logger.Log.Info("Product not exists");
                    }
                }
            }
            catch (Exception)
            {
                Logger.Log.Error("Error occured when calculate price");
                throw;
            }
        }
        /// <summary>
        /// Set AllowSale and PriceSource. Allow sale is 'N'since it is not real time price 
        /// </summary>
        public void CheckAvailablity()
        {
            foreach (Product ProductItem in products)
            {
                ProductItem.ePriceSource = PriceSource.CENGAGE_AS400;
                if (ConfigurationManager.AppSettings["ISBN"] == "9780170134811")
                {
                    ProductItem.AllowSale = 'Y';
                }
                else
                {
                    ProductItem.AllowSale = 'N';
                }
                //if (ConfigurationManager.AppSettings["FORCE_DISCONNECTBM"] == "Y")
                //{
                //    ProductItem.AllowSale = 'Y';
                //}
                //else
                //{
                //    ProductItem.AllowSale = 'N';
                //}
                
                ProductItem.StockStatus = "Available";
            }
        }
        internal string GetAccountNo(string accountSk,string Countrycode)
        {
            try
            {
                using (SqlCommand command = new SqlCommand("ECOM_WS_GETACCOUNTNUMBER",sqlconnection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(new SqlParameter("@SK", accountSk));
                    command.Parameters.Add(new SqlParameter("@COUNTRYCODE", Countrycode));
                    object account = command.ExecuteScalar();
                    return account.ToString();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}