﻿/*

  *  Project Name        :   Cengage Ecommerce
  *  Module Name         :   WebService(WCF) - CengageServiceHost
  *  Developer Name      :   Sureshkumar Chandrasekar
  *  Date Created        :   26-06-2013
  *  Date Modified       :   26-07-2013

  */
using System;
using System.Data.SqlClient;
using Cengage.Ecommerce.CengageServiceLibrary;
namespace Cengage.Ecommerce.CengageServiceHost
{
    /// <summary>
    /// This engine will calculate the susbcription price for the processes 1.Renew 2.Purchase 3.Upgrade
    /// </summary>
    public class SubscriptionEngine
    {
        private SqlConnection sqlconnection;
        /// <summary>
        /// Constructor to keep sql connection locally
        /// </summary>
        /// <param name="sqlConnection"></param>
        public SubscriptionEngine(SqlConnection sqlConnection)
        {
            // TODO: Complete member initialization
            this.sqlconnection = sqlConnection;
        }
        /// <summary>
        /// Calculate price when renew susbscription
        /// </summary>
        /// <param name="orderedSubscription"></param>
        internal void Renew(ProductSubscription orderedSubscription)
        {
            SubscriptionBase subscriptionbase = null;
            try
            {
                Logger.Log.Info("CengageServiceHost :Renew subscription has started. ISBN:"+orderedSubscription.ISBN);
                Logger.Log.Info("CengageServiceHost :Get base values for subscription");
                //Get Subscription base values
                subscriptionbase = new SubscriptionBase(orderedSubscription,sqlconnection);
                
                //Today is the default start date of ordered susbscription
                orderedSubscription.OrderedStartDate = DateTime.Today;
                
                //Set ordered start date based on fixed period start date
                if (orderedSubscription.OrderedStartDate < subscriptionbase.FixedPeriodStartDt)
                {
                    orderedSubscription.OrderedStartDate = subscriptionbase.FixedPeriodStartDt;
                }

                //Apply Renew Formulae and get Price and GSTPrice
                orderedSubscription.OrderedSubscriptionPrice = subscriptionbase.BasedPrice *
                                                           (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionbase.BasedQuantity.ToString()));
                orderedSubscription.OrderedSubscriptionGSTPrice = subscriptionbase.BasedGSTPrice *
                                                           (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionbase.BasedQuantity.ToString()));
                
                //Apply the Discount calculations. This calculation will cater in phase-2. currently the values are hardcoded as 0
                orderedSubscription.IsDiscountApplicable = subscriptionbase.IsDiscountApplicable;
                if (orderedSubscription.IsDiscountApplicable)
                {
                    //Calculation will be added later
                    orderedSubscription.DiscountPercentage = 0;
                    orderedSubscription.OrderedSubscriptionDiscountPrice = 0;
                }
                else
                {
                    orderedSubscription.DiscountPercentage = 0;
                    orderedSubscription.OrderedSubscriptionDiscountPrice = 0;
                }
                
                //Apply next year renewal formulae. Days calculation are not required for next year renewal.
                if (orderedSubscription.IsNextYearIncluded)
                {
                    orderedSubscription.NextYearSubscriptionPrice = subscriptionbase.BasedPrice *
                                                          (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionbase.BasedQuantity.ToString()));
                    orderedSubscription.NextYearSubscriptionGSTPrice = subscriptionbase.BasedGSTPrice *
                                                          (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionbase.BasedQuantity.ToString()));
                    //For next year renewal ,apply the Discount calculations. This calculation will cater in phase-2. currently the values are hardcoded as 0
                    if (orderedSubscription.IsDiscountApplicable)
                    {
                        //Calculation will be added later
                        orderedSubscription.DiscountPercentage = 0;
                        orderedSubscription.NextYearSubscriptionDiscountPrice = 0;
                    }
                    else
                    {
                        orderedSubscription.DiscountPercentage = 0;
                        orderedSubscription.NextYearSubscriptionDiscountPrice = 0;
                    }
                }
                Logger.Log.Info("CengageServiceHost : Calculated the renew subscription for " + orderedSubscription.ISBN);
            }
            catch (Exception)
            {
                Logger.Log.Error("CengageServiceHost :Error occured when calculting renew subscription for " + orderedSubscription.ISBN);
                throw;
            }
        }
        /// <summary>
        /// calculate price when upgrade subscription
        /// </summary>
        /// <param name="orderedSubscription"></param>
        internal void Upgrade(ProductSubscription orderedSubscription)
        {
            SubscriptionBase prevSubsBase = null;
            ProductSubscription prevSubs=null;
            SubscriptionBase subscriptionBase = null;
            try
            {

                Logger.Log.Info("CengageServiceHost :Upgrade subscription has started. Current:" + orderedSubscription.ISBN + " Previous:" + orderedSubscription.Prev_ISBN);
                Logger.Log.Info("CengageServiceHost :Get base values for subscribed product");
                //Get existing subscription base details
                prevSubs=new ProductSubscription(){ISBN=orderedSubscription.Prev_ISBN,Store_Sk=orderedSubscription.Store_Sk,Country=orderedSubscription.Country};
                prevSubsBase = new SubscriptionBase(prevSubs,sqlconnection);

                //Claculate the balance price for the subscribed product. 
                //Step 1 : set the date for the subscribed product
                prevSubs.OrderedStartDate = DateTime.Today;
                if (prevSubs.OrderedStartDate < prevSubsBase.FixedPeriodStartDt)
                {
                    prevSubs.OrderedStartDate = prevSubsBase.FixedPeriodStartDt;
                }
                //Step 2 : Identify the ProRateUOM for the subscribed product. (ProRateUOM : 1.DAYs 2.MONTHS)
                switch (prevSubsBase.eProRateUOM)
                {
                    case ProRateUOM.Days:
                        //STEP 2.1 : Identify the ProRateRule (ProRateRule for Days ProRateUOM : 1.DAYS_365 2.DAYS_360)
                        switch (prevSubsBase.eProRateRule)
                        {
                            //365 days year calculation
                            case ProRateRule.DAYS_365:
                                //Calculate the remaining period of susbcribed product
                                Logger.Log.Info("CengageServiceHost :Calculate price ProRateUOM : DAYS ,ProRateRule : DAYS_365 ");
                                prevSubs.OrderedPeriodLength = (prevSubsBase.FixedPeriodEndDt - prevSubs.OrderedStartDate).Days;
                                //Calculate the remaining price & GSTPrice for susbcribed product
                                prevSubs.OrderedSubscriptionPrice = prevSubsBase.BasedPrice *
                                                           (double.Parse(orderedSubscription.Prev_LicenseCount.ToString()) / double.Parse(prevSubsBase.BasedQuantity.ToString())) * (double.Parse(prevSubs.OrderedPeriodLength.ToString()) / double.Parse((prevSubsBase.FixedPeriodEndDt - prevSubsBase.FixedPeriodStartDt).Days.ToString()));
                                prevSubs.OrderedSubscriptionGSTPrice = prevSubsBase.BasedGSTPrice *
                                                           (double.Parse(orderedSubscription.Prev_LicenseCount.ToString()) / double.Parse(prevSubsBase.BasedQuantity.ToString())) * (double.Parse(prevSubs.OrderedPeriodLength.ToString()) / double.Parse((prevSubsBase.FixedPeriodEndDt - prevSubsBase.FixedPeriodStartDt).Days.ToString()));
                                break;
                            //360 days year claculation (Avoid 31st date of every month)
                            case ProRateRule.DAYS_360:
                                Logger.Log.Info("CengageServiceHost :Calculate price ProRateUOM : DAYS ,ProRateRule : DAYS_360 ");
                                //Calculate the remaining period of susbcribed product
                                prevSubs.OrderedPeriodLength = prevSubs.OrderedStartDate.Days360(prevSubsBase.FixedPeriodEndDt);
                                //Calculate the remaining price & GSTPrice for susbcribed product
                                prevSubs.OrderedSubscriptionPrice = prevSubsBase.BasedPrice *
                                                            (double.Parse(orderedSubscription.Prev_LicenseCount.ToString()) / double.Parse(prevSubsBase.BasedQuantity.ToString())) * (double.Parse(prevSubs.OrderedPeriodLength.ToString()) /double.Parse(prevSubsBase.FixedPeriodStartDt.Days360(prevSubsBase.FixedPeriodEndDt).ToString()));
                                prevSubs.OrderedSubscriptionGSTPrice = prevSubsBase.BasedGSTPrice *
                                                           (double.Parse(orderedSubscription.Prev_LicenseCount.ToString()) / double.Parse(prevSubsBase.BasedQuantity.ToString())) * (double.Parse(prevSubs.OrderedPeriodLength.ToString()) / double.Parse(prevSubsBase.FixedPeriodStartDt.Days360(prevSubsBase.FixedPeriodEndDt).ToString()));
                                break;
                        }
                        break;
                    case ProRateUOM.Months:
                        //STEP 2.2 : Identify the ProRateRule (ProRateRule for Months ProRateUOM : 1.Exclude current month 2.Include current month)
                        switch (prevSubsBase.eProRateRule)
                        {
                            case ProRateRule.EXCL_CUR_MONTH:
                                Logger.Log.Info("CengageServiceHost :Calculate price ProRateUOM : MONTHS ,ProRateRule : EXCL_CUR_MONTH ");
                                //Calculate the remaining period of susbcribed product
                                prevSubs.OrderedPeriodLength = prevSubsBase.FixedPeriodEndDt.MonthDiff(prevSubs.OrderedStartDate, false);
                                break;
                            case ProRateRule.INCL_CUR_MONTH:
                                Logger.Log.Info("CengageServiceHost :Calculate price ProRateUOM : MONTHS ,ProRateRule : INCL_CUR_MONTH ");
                                //Calculate the remaining period of susbcribed product
                                prevSubs.OrderedPeriodLength = prevSubsBase.FixedPeriodEndDt.MonthDiff(prevSubs.OrderedStartDate, true);
                                break;
                        }
                        //Calculate the remaining price & GSTPrice for susbcribed product
                        prevSubs.OrderedSubscriptionPrice = prevSubsBase.BasedPrice *
                                                           (double.Parse(orderedSubscription.Prev_LicenseCount.ToString()) / double.Parse(prevSubsBase.BasedQuantity.ToString())) * (double.Parse(prevSubs.OrderedPeriodLength.ToString()) / double.Parse(prevSubsBase.TimePeriod.ToString()));
                        prevSubs.OrderedSubscriptionGSTPrice = prevSubsBase.BasedGSTPrice *
                                                           (double.Parse(orderedSubscription.Prev_LicenseCount.ToString()) / double.Parse(prevSubsBase.BasedQuantity.ToString())) * (double.Parse(prevSubs.OrderedPeriodLength.ToString()) / double.Parse(prevSubsBase.TimePeriod.ToString()));
                        break;
                }
                Logger.Log.Info("CengageServiceHost :Price calculation for subscribed product has completed");

                Logger.Log.Info("CengageServiceHost :Price calculation for current subscription started.ISBN : " + orderedSubscription.ISBN);
                //Calculate the price for current subscription. 

                Logger.Log.Info("CengageServiceHost :Get base values for current subscription");
                //Step 1 : Get the current susbscription base values
                subscriptionBase = new SubscriptionBase(orderedSubscription, sqlconnection);
                
                //Step 2 : Set the current susbscription start date
                orderedSubscription.OrderedStartDate = DateTime.Today;
                if (orderedSubscription.OrderedStartDate < subscriptionBase.FixedPeriodStartDt)
                {
                    orderedSubscription.OrderedStartDate = subscriptionBase.FixedPeriodStartDt;
                }
                
                //Step 3 : Identify the ProRateUOM for the cuurent subscription. (ProRateUOM : 1.DAYS 2.MONTHS)
                switch (subscriptionBase.eProRateUOM)
                {
                    case ProRateUOM.Days:
                        //STEP 3.1 : Identify the ProRateRule (ProRateRule for Days ProRateUOM : 1.DAYS_365 2.DAYS_360)
                        switch (subscriptionBase.eProRateRule)
                        {
                            //365 days year calculation
                            case ProRateRule.DAYS_365:
                                Logger.Log.Info("CengageServiceHost :Calculate price ProRateUOM : DAYS ,ProRateRule : DAYS_365 ");
                                //Calculate the ordered period
                                orderedSubscription.OrderedPeriodLength = (subscriptionBase.FixedPeriodEndDt - orderedSubscription.OrderedStartDate).Days;
                                //Apply the formulae to calculate price & GSTPrice for current subscription
                                orderedSubscription.OrderedSubscriptionPrice = subscriptionBase.BasedPrice *
                                                           (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionBase.BasedQuantity.ToString())) * (double.Parse(orderedSubscription.OrderedPeriodLength.ToString()) / double.Parse((subscriptionBase.FixedPeriodEndDt - subscriptionBase.FixedPeriodStartDt).Days.ToString()));
                                orderedSubscription.OrderedSubscriptionGSTPrice = subscriptionBase.BasedGSTPrice *
                                                          (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionBase.BasedQuantity.ToString())) * (double.Parse(orderedSubscription.OrderedPeriodLength.ToString()) / double.Parse((subscriptionBase.FixedPeriodEndDt - subscriptionBase.FixedPeriodStartDt).Days.ToString()));
                                break;
                            //360 days year claculation (Avoid 31st date of every month)
                            case ProRateRule.DAYS_360:
                                Logger.Log.Info("CengageServiceHost :Calculate price ProRateUOM : DAYS ,ProRateRule : DAYS_360 ");
                                //Calculate the ordered period
                                orderedSubscription.OrderedPeriodLength = orderedSubscription.OrderedStartDate.Days360(subscriptionBase.FixedPeriodEndDt);
                                //Apply the formulae to calculate price & GSTPrice for current subscription
                                orderedSubscription.OrderedSubscriptionPrice = subscriptionBase.BasedPrice *
                                                           (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionBase.BasedQuantity.ToString())) * (double.Parse(orderedSubscription.OrderedPeriodLength.ToString()) / double.Parse(subscriptionBase.FixedPeriodStartDt.Days360(subscriptionBase.FixedPeriodEndDt).ToString()));
                                orderedSubscription.OrderedSubscriptionGSTPrice = subscriptionBase.BasedGSTPrice *
                                                           (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionBase.BasedQuantity.ToString())) * (double.Parse(orderedSubscription.OrderedPeriodLength.ToString()) / double.Parse(subscriptionBase.FixedPeriodStartDt.Days360(subscriptionBase.FixedPeriodEndDt).ToString()));
                                break;
                        }
                        break;
                    case ProRateUOM.Months:
                        //STEP 3.2 : Identify the ProRateRule (ProRateRule for Months ProRateUOM : 1.Exclude current month 2.Include current month)
                        switch (subscriptionBase.eProRateRule)
                        {
                            case ProRateRule.EXCL_CUR_MONTH:
                                Logger.Log.Info("CengageServiceHost :Calculate price ProRateUOM : MONTHS ,ProRateRule : EXCL_CUR_MONTH ");
                                //Calculate the ordered period
                                orderedSubscription.OrderedPeriodLength = subscriptionBase.FixedPeriodEndDt.MonthDiff(orderedSubscription.OrderedStartDate, false);
                                break;
                            case ProRateRule.INCL_CUR_MONTH:
                                Logger.Log.Info("CengageServiceHost :Calculate price ProRateUOM : MONTHS ,ProRateRule : INCL_CUR_MONTH ");
                                //Calculate the ordered period
                                orderedSubscription.OrderedPeriodLength = subscriptionBase.FixedPeriodEndDt.MonthDiff(orderedSubscription.OrderedStartDate, true);
                                break;
                        }
                        //Apply the formulae to calculate price & GSTPrice for current subscription
                        orderedSubscription.OrderedSubscriptionPrice = subscriptionBase.BasedPrice *
                                                           (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionBase.BasedQuantity.ToString())) * (double.Parse(orderedSubscription.OrderedPeriodLength.ToString()) / double.Parse(subscriptionBase.TimePeriod.ToString()));
                        orderedSubscription.OrderedSubscriptionGSTPrice = subscriptionBase.BasedGSTPrice *
                                                           (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionBase.BasedQuantity.ToString())) * (double.Parse(orderedSubscription.OrderedPeriodLength.ToString()) / double.Parse(subscriptionBase.TimePeriod.ToString()));
                        break;
                }
                Logger.Log.Info("CengageServiceHost :Price calculation for current subscription has Completed");
                //Apply the formulae to calculate price & GSTPrice. (Current Subscription Price - Existing subscription price) 
                orderedSubscription.OrderedSubscriptionPrice = orderedSubscription.OrderedSubscriptionPrice - prevSubs.OrderedSubscriptionPrice;
                orderedSubscription.OrderedSubscriptionGSTPrice = orderedSubscription.OrderedSubscriptionGSTPrice - prevSubs.OrderedSubscriptionGSTPrice;
                Logger.Log.Info("CengageServiceHost :Calculated the price for upgrade subscription. Current:" + orderedSubscription.ISBN + " Previous:" + orderedSubscription.Prev_ISBN);
            }
            catch (Exception)
            {
                Logger.Log.Error("CengageServiceHost :Error occured when calculting upgrade subscription. Current:" + orderedSubscription.ISBN + " Previous:" + orderedSubscription.Prev_ISBN);
                throw;
            }
        }
        internal void Purchase(ProductSubscription orderedSubscription)
        {
            SubscriptionBase subscriptionbase = null;
            try
            {
                Logger.Log.Info("CengageServiceHost :Get base values for purchase subscription");
                //Step 1 : Get the susbscription base values
                subscriptionbase = new SubscriptionBase(orderedSubscription,sqlconnection);
                //Step 2 : Set the susbscription start date
                orderedSubscription.OrderedStartDate = DateTime.Today;
                if (orderedSubscription.OrderedStartDate < subscriptionbase.FixedPeriodStartDt)
                {
                    orderedSubscription.OrderedStartDate = subscriptionbase.FixedPeriodStartDt;
                }
                //Step 3 : Identify the ProRateUOM for  subscription. (ProRateUOM : 1.DAYS 2.MONTHS)
                switch (subscriptionbase.eProRateUOM)
	            {
		            case ProRateUOM.Days:
                        //STEP 3.1 : Identify the ProRateRule (ProRateRule for Days ProRateUOM : 1.DAYS_365 2.DAYS_360)
                        switch(subscriptionbase.eProRateRule)
                        {
                            //365 days year calculation
                            case ProRateRule.DAYS_365:
                                Logger.Log.Info("CengageServiceHost :Calculate price ProRateUOM : DAYS ,ProRateRule : DAYS_365 ");
                                //Calculate the ordered period
                                orderedSubscription.OrderedPeriodLength =(subscriptionbase.FixedPeriodEndDt-orderedSubscription.OrderedStartDate).Days;
                                //Apply the formulae to calculate price & GSTPrice subscription
                                orderedSubscription.OrderedSubscriptionPrice = subscriptionbase.BasedPrice *
                                                           (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionbase.BasedQuantity.ToString())) * (double.Parse(orderedSubscription.OrderedPeriodLength.ToString()) / double.Parse((subscriptionbase.FixedPeriodEndDt - subscriptionbase.FixedPeriodStartDt).Days.ToString()));
                                orderedSubscription.OrderedSubscriptionGSTPrice = subscriptionbase.BasedGSTPrice *
                                                           (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionbase.BasedQuantity.ToString())) * (double.Parse(orderedSubscription.OrderedPeriodLength.ToString()) / double.Parse((subscriptionbase.FixedPeriodEndDt - subscriptionbase.FixedPeriodStartDt).Days.ToString()));
                                break;
                            //360 days year calculation
                            case ProRateRule.DAYS_360:
                                Logger.Log.Info("CengageServiceHost :Calculate price ProRateUOM : DAYS ,ProRateRule : DAYS_360 ");
                                //Calculate the ordered period
                                orderedSubscription.OrderedPeriodLength = orderedSubscription.OrderedStartDate.Days360(subscriptionbase.FixedPeriodEndDt);
                                //Apply the formulae to calculate price & GSTPrice subscription
                                orderedSubscription.OrderedSubscriptionPrice = subscriptionbase.BasedPrice *
                                                          (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionbase.BasedQuantity.ToString())) * (double.Parse(orderedSubscription.OrderedPeriodLength.ToString()) / double.Parse(subscriptionbase.FixedPeriodStartDt.Days360(subscriptionbase.FixedPeriodEndDt).ToString()));
                                orderedSubscription.OrderedSubscriptionGSTPrice = subscriptionbase.BasedGSTPrice *
                                                           (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionbase.BasedQuantity.ToString())) * (double.Parse(orderedSubscription.OrderedPeriodLength.ToString()) / double.Parse(subscriptionbase.FixedPeriodStartDt.Days360(subscriptionbase.FixedPeriodEndDt).ToString()));
                                break;
                        }
                        break;
                    case ProRateUOM.Months:
                        //STEP 3.2 : Identify the ProRateRule (ProRateRule for Months ProRateUOM : 1.Exclude current month 2.Include current month)
                        switch(subscriptionbase.eProRateRule)
                        {
                            case ProRateRule.EXCL_CUR_MONTH:
                                Logger.Log.Info("CengageServiceHost :Calculate price ProRateUOM : MONTHS ,ProRateRule : EXCL_CUR_MONTH ");
                                //Calculate the ordered period
                                orderedSubscription.OrderedPeriodLength = subscriptionbase.FixedPeriodEndDt.MonthDiff(orderedSubscription.OrderedStartDate,false);
                                break;
                            case ProRateRule.INCL_CUR_MONTH:
                                Logger.Log.Info("CengageServiceHost :Calculate price ProRateUOM : MONTHS ,ProRateRule : INCL_CUR_MONTH ");
                                //Calculate the ordered period
                                orderedSubscription.OrderedPeriodLength = subscriptionbase.FixedPeriodEndDt.MonthDiff(orderedSubscription.OrderedStartDate, true);
                                break;
                        }
                        //Apply the formulae to calculate price & GSTPrice for subscription
                        orderedSubscription.OrderedSubscriptionPrice = subscriptionbase.BasedPrice *
                                                            (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionbase.BasedQuantity.ToString())) * (double.Parse(orderedSubscription.OrderedPeriodLength.ToString()) / double.Parse(subscriptionbase.TimePeriod.ToString()));
                        orderedSubscription.OrderedSubscriptionGSTPrice = subscriptionbase.BasedGSTPrice *
                                                            (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionbase.BasedQuantity.ToString())) * (double.Parse(orderedSubscription.OrderedPeriodLength.ToString()) / double.Parse(subscriptionbase.TimePeriod.ToString()));
                        break;
	            }
                //Apply the Discount calculations. This calculation will cater in phase-2. currently the values are hardcoded as 0
                orderedSubscription.IsDiscountApplicable = subscriptionbase.IsDiscountApplicable;
                if (orderedSubscription.IsDiscountApplicable)
                {
                    //Calculation will be added later
                    orderedSubscription.DiscountPercentage = 0;
                    orderedSubscription.OrderedSubscriptionDiscountPrice = 0;
                }
                else
                {
                    orderedSubscription.DiscountPercentage = 0;
                    orderedSubscription.OrderedSubscriptionDiscountPrice = 0;
                }
                //Apply next year purchase formulae. Days calculation are not required for next year renewal.
                if (orderedSubscription.IsNextYearIncluded)
                {
                    orderedSubscription.NextYearSubscriptionPrice = subscriptionbase.BasedPrice *
                                                           (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionbase.BasedQuantity.ToString()));
                    orderedSubscription.NextYearSubscriptionGSTPrice = subscriptionbase.BasedGSTPrice *
                                                           (double.Parse(orderedSubscription.OrderedQuantity.ToString()) / double.Parse(subscriptionbase.BasedQuantity.ToString()));
                    //For next year renewal ,apply the Discount calculations. This calculation will cater in phase-2. currently the values are hardcoded as 0
                    if (orderedSubscription.IsDiscountApplicable)
                    {
                        //Calculation will be added later
                        orderedSubscription.DiscountPercentage = 0;
                        orderedSubscription.NextYearSubscriptionDiscountPrice = 0;
                    }
                    else
                    {
                        orderedSubscription.DiscountPercentage = 0;
                        orderedSubscription.NextYearSubscriptionDiscountPrice = 0;
                    }
                }
                Logger.Log.Info("CengageServiceHost :Calculated the purchase subscription for " + orderedSubscription.ISBN);
            }
            catch (Exception)
            {
                Logger.Log.Error("CengageServiceHost :Error occured when calculte purchase subscription for " + orderedSubscription.ISBN);
                throw;
            }
        }
    }
}