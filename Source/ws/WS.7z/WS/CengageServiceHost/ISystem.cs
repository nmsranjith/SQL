﻿/*

  *  Project Name        :   Cengage Ecommerce
  *  Module Name         :   WebService(WCF) - CengageServiceHost
  *  Developer Name      :   Sureshkumar Chandrasekar
  *  Date Created        :   26-06-2013
  *  Date Modified       :   26-07-2013

  */
namespace Cengage.Ecommerce.CengageServiceHost
{
    /// <summary>
    /// All the price calculation systems has to implement this interface.
    /// Currently the Price calculation systems are AS400 and Ecom
    /// </summary>
    public interface ISystem
    {
        bool ConnectSystem();
        void DisconnectSystem();
        void CheckAvailablity();
        void CalculatePrice();
    }
}