﻿/*

  *  Project Name        :   Cengage Ecommerce
  *  Module Name         :   WebService(WCF) - CengageServiceHost
  *  Developer Name      :   Sureshkumar Chandrasekar
  *  Date Created        :   26-06-2013
  *  Date Modified       :   26-07-2013

  */
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Cengage.Ecommerce.CengageServiceLibrary;

namespace Cengage.Ecommerce.CengageServiceHost
{
    /// <summary>
    /// This is the wrapper of subscription sysem. this is the interface to connect & Process subscription operations 
    /// This class defines the subscription connection & Price calculation.
    /// Check availablity method is not requed to implement
    /// </summary>
    public class SubscriptionSystem : ISystem
    {
        List<ProductSubscription> subscriptions;
        SqlConnection sqlconnection = null;
        /// <summary>
        /// Constructor to maintain the subscription list locally
        /// </summary>
        /// <param name="products"></param>
        public SubscriptionSystem(List<ProductSubscription> subscriptions)
        {
           this.subscriptions = subscriptions;
        }
        /// <summary>
        /// Connect subscription system
        /// </summary>
        /// <returns></returns>
        public bool ConnectSystem()
        {
            try
            {
                sqlconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ECOM_CONN"].ToString());
                Logger.Log.Info("CengageServiceHost :Connecting subscription system");
                sqlconnection.Open();
                Logger.Log.Info("CengageServiceHost :subscription system connected");
                return true;
            }
            catch (Exception)
            {
                Logger.Log.Error("CengageServiceHost :Error occured when connect subscription system");
                throw;
            }
        }
        /// <summary>
        /// Disconnect Ecom system
        /// </summary>
        public void DisconnectSystem()
        {
            try
            {
                Logger.Log.Info("CengageServiceHost :Disconnecting subscription system");
                if (sqlconnection.State == ConnectionState.Open)
                {
                    sqlconnection.Close();
                    sqlconnection.Dispose();
                }
                Logger.Log.Info("CengageServiceHost :Disconnected subscription system");
            }
            catch (Exception)
            {
                Logger.Log.Error("CengageServiceHost :Error occured when disconnect subscription system");
                throw;
            }
        }
        /// <summary>
        /// Calculate price for all subscriptions.
        /// </summary>
        public void CalculatePrice()
        {
            try
            {
                Logger.Log.Info("CengageServiceHost :Subscription Price calulation has started");
                //Initialize the subscription engine
                SubscriptionEngine objEngine = new SubscriptionEngine(sqlconnection);
                //iterate subscription and claculate price
                foreach (ProductSubscription item in subscriptions)
                {
                    switch (item.eSubscriptionProcessType)
                    {
                        case SubscriptionProcessType.Purchase:
                            objEngine.Purchase(item);
                            break;
                        case SubscriptionProcessType.Renew:
                            objEngine.Renew(item);
                            break;
                        case SubscriptionProcessType.Upgrade:
                            objEngine.Upgrade(item);
                            break;
                    }    
                }
                Logger.Log.Info("CengageServiceHost :Subscription Price calulation has completed");
                
            }
            catch (Exception)
            {
                Logger.Log.Error("CengageServiceHost :Error occured when calculate price for subscription");
                throw;
            }
        }
        /// <summary>
        /// Not implemented as subscription process does not require to check availablity.
        /// All the subscription prices are calculated based on ECOM DB values. Not AS400
        /// </summary>
        public void CheckAvailablity()
        {
            throw new NotImplementedException();
        }
    }
}