﻿/*

  *  Project Name        :   Cengage Ecommerce
  *  Module Name         :   WebService(WCF) - CengageServiceHost
  *  Developer Name      :   Sureshkumar Chandrasekar
  *  Date Created        :   26-06-2013
  *  Date Modified       :   26-07-2013

  */
using log4net;
namespace Cengage.Ecommerce.CengageServiceHost
{
    public static class Logger
    {
       /* private static string logfile = ConfigurationSettings.AppSettings["LOGFILE"].ToString();
        public static void Log(string message)
        {
            // Create a writer and open the file:
            StreamWriter log;
            if (!File.Exists(logfile))
            {
                log = new StreamWriter(logfile);
            }
            else
            {
                log = File.AppendText(logfile);
            }

            // Write to the file:
            log.WriteLine(DateTime.Now);
            log.WriteLine(message);
            log.WriteLine();

            // Close the stream:
            log.Close();
        }*/
        private static readonly ILog log = LogManager.GetLogger(typeof(Logger));

        public static ILog Log
        {
            get { return Logger.log; }
        } 


    }
}
