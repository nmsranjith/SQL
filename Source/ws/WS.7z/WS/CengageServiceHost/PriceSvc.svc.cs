﻿/*

  *  Project Name        :   Cengage Ecommerce
  *  Module Name         :   WebService(WCF) - CengageServiceHost
  *  Developer Name      :   Sureshkumar Chandrasekar
  *  Date Created        :   26-06-2013
  *  Date Modified       :   26-07-2013

  */
using System;
using System.Collections.Generic;
using System.ServiceModel;
using Cengage.Ecommerce.CengageServiceLibrary;
using System.Configuration;

namespace Cengage.Ecommerce.CengageServiceHost
{
   /// <summary>
    /// Service implements methods available in the contract(interface) IPriceSvc
    ///Calculate Products and subscriptions price
   /// </summary>
    public class PriceSvc : IPriceSvc
    {
        /// <summary>
        /// to get the product price
        /// Each and every product should have value for Isbn,Account No,GST included and currency
        /// </summary>
        /// <param name="products"></param>
        /// <returns>ProductList</returns>
        public List<Product> GetProductPrice(List<Product> products)
        {
            ISystem objSystem = null;
            try
            {
                Logger.Log.Info("List of product received.List Count " + products.Count);
                objSystem = new CengageAS400System(products) { ProgramName = ProgramType.Price };
                //Try connect AS400 system. If can't then use Ecom system
                if (ConfigurationManager.AppSettings["FORCE_DISCONNECTBM"] =="N" && objSystem.ConnectSystem())
                {
                    try
                    {
                        Logger.Log.Info("AS400 system price calculation started");
                        //Calculate Price in AS400 system
                        setAccountNumber(products);
                        objSystem.CalculatePrice();
                        objSystem.DisconnectSystem();
                    }
                    catch (Exception e)
                    {
                        objSystem.DisconnectSystem();
                        Logger.Log.Error("Error : " + e.Message);
                        objSystem = new CengageECOMSystem(products);
                        if (objSystem.ConnectSystem())
                        {
                            Logger.Log.Info("Ecom system price calculation started");
                            //Calculate price in Ecom system
                            objSystem.CalculatePrice();
                            objSystem.DisconnectSystem();
                        }
                    }
                }
                else
                {
                    objSystem = new CengageECOMSystem(products);
                    if (objSystem.ConnectSystem())
                    {
                        Logger.Log.Info("Ecom system price calculation started");
                        //Calculate price in Ecom system
                        objSystem.CalculatePrice();
                        objSystem.DisconnectSystem();
                    }
                }
                return products;
            }
            catch (Exception Ex)
            {
                Logger.Log.Error("Error : " + Ex.Message);
                throw new FaultException(Ex.Message);
            }
        }
        /// <summary>
        /// to set the subscription price
        /// Each and every subscription object should have 
        /// </summary>
        /// <param name="subscriptions"></param>
        /// <returns>ProductSubscriptionList</returns>
        public List<ProductSubscription> GetSubscriptionPrice(List<ProductSubscription> subscriptions)
        {
            ISystem objSystem = null;
            try
            {
                Logger.Log.Info("CengageServiceHost - GetSubscriptionPrice : List of product received.List Count " + subscriptions.Count);
                objSystem = new SubscriptionSystem(subscriptions);
                //Connect Ecom system
                if (objSystem.ConnectSystem())
                {
                    Logger.Log.Info("CengageServiceHost - GetProductPrice : Subscription price calculation has started");
                    //Calculate subscription price in Ecom system
                    objSystem.CalculatePrice();
                    objSystem.DisconnectSystem();
                }
                return subscriptions;
            }
            catch (Exception Ex)
            {
                Logger.Log.Error("CengageServiceHost :Error : " + Ex.Message);
                throw new FaultException(Ex.Message);
            }
        }
        /// <summary>
        /// to check the product availablity
        /// </summary>
        /// <param name="products"></param>
        /// <returns>ProductList</returns>
        public List<Product> GetProductAvailablity(List<Product> products)
        {
            ISystem objSystem = null;
            try
            {
                Logger.Log.Info("List of product received.List Count " + products.Count);
                objSystem = new CengageAS400System(products) { ProgramName=ProgramType.Price_AA};
                //Connect AS400 system and checks the availablity
                if (ConfigurationManager.AppSettings["FORCE_DISCONNECTBM"] =="N" && objSystem.ConnectSystem())
                {
                    try
                    {
                        Logger.Log.Info("As400 check availablity started");
                        setAccountNumber(products);
                        objSystem.CheckAvailablity();
                        objSystem.DisconnectSystem();
                        Logger.Log.Info("As400 check availablity completed");
                    }
                    catch (Exception e)
                    {
                        Logger.Log.Error("Error : " + e.Message);
                        objSystem.DisconnectSystem();
                        objSystem = new CengageECOMSystem(products);
                        //Connect Ecom system and checks the availablity
                        if (objSystem.ConnectSystem())
                        {
                            Logger.Log.Info("Ecom system check availablity started");
                            objSystem.CheckAvailablity();
                            objSystem.DisconnectSystem();
                            Logger.Log.Info("Ecom system check availablity completed");
                        }
                    }
                }
                else
                {
                    objSystem = new CengageECOMSystem(products);
                    //Connect Ecom system and checks the availablity
                    if (objSystem.ConnectSystem())
                    {
                        Logger.Log.Info("Ecom system check availablity started");
                        objSystem.CheckAvailablity();
                        objSystem.DisconnectSystem();
                        Logger.Log.Info("Ecom system check availablity completed");
                    }
                }
                return products;
            }
            catch (Exception Ex)
            {
                Logger.Log.Error("Error : " + Ex.Message);
                throw new FaultException(Ex.Message);
            }
        }

        private void setAccountNumber(List<Product> products)
        {
            try
            {
                Logger.Log.Info("Setup the Account Number for SK :" + products[0].AccountNumber + ",Country : " + products[0].ToCountry);
                 CengageECOMSystem objSystem = new CengageECOMSystem(products);
                 if (objSystem.ConnectSystem())
                 {
                     string AccountNo = objSystem.GetAccountNo(products[0].AccountNumber,(string.IsNullOrEmpty(products[0].ToCountry)?"NIL":products[0].ToCountry));
                     Logger.Log.Info("SK :" + products[0].AccountNumber + " ,Account Number :"+AccountNo);
                     products.ForEach(prod => prod.TradingAccountNumber = AccountNo);
                     objSystem.DisconnectSystem();
                 }
            }
            catch (Exception Ex)
            {
                Logger.Log.Error("Error : " + Ex.Message);
                throw Ex;
            }
        }
    }
}
