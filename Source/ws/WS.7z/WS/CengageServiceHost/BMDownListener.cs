﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace Cengage.Ecommerce.CengageServiceHost
{
    public static class BMDownListener
    {
        private static bool isBmDown; 
        public static bool IsBmDown
        {
            get
            {
                try
                {
                    string intervals = ConfigurationManager.AppSettings["BMDOWN_DAY_" + DateTime.Now.DayOfWeek.ToString().ToUpper()].Trim();
                    if (intervals != "")
                    {
                        isBmDown = false;
                        intervals.Split('|').ToList().ForEach(interval =>
                        {
                            string[] starttime = interval.Split('-')[0].Split(':');
                            string[] endtime = interval.Split('-')[1].Split(':');
                            if (DateTime.Now.TimeOfDay > new TimeSpan(int.Parse(starttime[0]), int.Parse(starttime[1]), int.Parse(starttime[2]))
                                &&
                                DateTime.Now.TimeOfDay < new TimeSpan(int.Parse(endtime[0]), int.Parse(endtime[1]), int.Parse(endtime[2]))
                                )
                            {
                                isBmDown = true;
                            }
                        }
                        );
                    }
                    else
                    {
                        isBmDown = false;
                    }
                }
                catch (Exception)
                {
                    isBmDown = false;
                    Logger.Log.Info("Error occured when read BMDown intervals");
                }

                return isBmDown;
            }
         }
      }
   }
