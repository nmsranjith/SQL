﻿/*

  *  Project Name        :   Cengage Ecommerce
  *  Module Name         :   WebService(WCF) - CengageServiceHost
  *  Developer Name      :   Sureshkumar Chandrasekar
  *  Date Created        :   26-06-2013
  *  Date Modified       :   26-07-2013

  */
using System;
using System.Data;
using System.Data.SqlClient;
using Cengage.Ecommerce.CengageServiceLibrary;
namespace Cengage.Ecommerce.CengageServiceHost
{
    /// <summary>
    /// Construct base values for all subscription
    /// </summary>
    public class SubscriptionBase 
    {
        private ProductSubscription orderedsubscription;
        private SqlConnection sqlconnection;
        public SubscriptionBase(ProductSubscription orderedSubscription, System.Data.SqlClient.SqlConnection sqlConnection)
        {
            try
            {
                Logger.Log.Info("CengageServiceHost :Construct subscription base");
                // TODO: Complete member initialization
                this.orderedsubscription = orderedSubscription;
                this.sqlconnection = sqlConnection;
                setSubscriptionBase();
            }
            catch (Exception)
            {
                Logger.Log.Info("CengageServiceHost :Error occured when construct subscription base");
                throw;
            }
        }

        public string CategoryName { get; set; }
        public PeriodType ePeriodType { get; set; }

        public FixedPeriodType eFixedPeriodType { get; set; }
        public ProRateUOM eProRateUOM { get; set; }
        public ProRateRule eProRateRule { get; set; }
        public DateTime FixedPeriodStartDt { get; set; }
        public DateTime FixedPeriodEndDt { get; set; }

        
        public int BasedPeriodlength { get; set; }
        public int BasedQuantity { get; set; }
        public double BasedPrice { get; set; }
        public double BasedGSTPrice { get; set; }

        
        public bool IsDiscountApplicable { get; set; }
        public double DiscountPercentage { get; set; }

        //GST
        
        public bool IsGSTApplicable { get; set; }
        
        public double GSTPercentage { get; set; }

        public int TimePeriod { get; set; }

        private void setSubscriptionBase()
        {
            SqlCommand objCommand = null;
            SqlDataAdapter objAdapt = null;
            DataTable dt=null;
            try
            {
                objCommand = new SqlCommand("WS_GETSUBSCRIPTIONBASE", sqlconnection) { CommandType = CommandType.StoredProcedure };
                objCommand.Parameters.Add(new SqlParameter("@ISBN", this.orderedsubscription.ISBN));
                objCommand.Parameters.Add(new SqlParameter("@Country", this.orderedsubscription.Country));
                objCommand.Parameters.Add(new SqlParameter("@Store", this.orderedsubscription.Store_Sk));
                dt = new DataTable();
                objAdapt = new SqlDataAdapter(objCommand);
                dt = new DataTable();
                objAdapt.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    this.CategoryName = dt.Rows[0]["SUBS_CATEGORY_NAME"].ToString();
                    this.ePeriodType = (dt.Rows[0]["SUBS_PERIOD_TYPE"].ToString().ToUpper() == "FIXED") ? PeriodType.Fixed : PeriodType.Floating;
                    this.eFixedPeriodType = (dt.Rows[0]["FIX_PER_TYPE_ID"].ToString().ToUpper() == "ACADEMIC_YEAR") ? FixedPeriodType.AcademicYear : FixedPeriodType.CalendarYear;
                    this.eProRateUOM = (dt.Rows[0]["PRO_RATE_UOM"].ToString().ToUpper() == "DAYS") ? ProRateUOM.Days : ProRateUOM.Months;
                    this.IsDiscountApplicable = (dt.Rows[0]["DISCOUNT_APPLICABLE"].ToString() == "0") ? false : true;
                    if (IsDiscountApplicable)
                        this.DiscountPercentage = Double.Parse(dt.Rows[0]["DISCOUNT_PERCENTAGE"].ToString());
                    else
                        this.DiscountPercentage = 0;


                    if (this.eProRateUOM == ProRateUOM.Days)
                    {
                        switch (dt.Rows[0]["PRO_RATE_RULE"].ToString().ToUpper())
                        {
                            case "DAYS_365":
                                this.eProRateRule = ProRateRule.DAYS_365;
                                break;
                            case "DAYS_360":
                                this.eProRateRule = ProRateRule.DAYS_360;
                                break;
                        }
                    }
                    else
                    {
                        switch (dt.Rows[0]["PRO_RATE_RULE"].ToString().ToUpper())
                        {
                            case "EXCL_CUR_MONTH":
                                this.eProRateRule = ProRateRule.EXCL_CUR_MONTH;
                                break;
                            case "INCL_CUR_MONTH":
                                this.eProRateRule = ProRateRule.INCL_CUR_MONTH;
                                break;
                        }
                    }

                    this.FixedPeriodStartDt = DateTime.Parse(dt.Rows[0]["START_DATE"].ToString());
                    this.FixedPeriodEndDt = DateTime.Parse(dt.Rows[0]["END_DATE"].ToString());
                    this.BasedQuantity = int.Parse(dt.Rows[0]["QTY_LICENSES"].ToString());
                    this.BasedPrice = double.Parse(dt.Rows[0]["PRICE"].ToString());
                    this.BasedGSTPrice = double.Parse(dt.Rows[0]["GSTPRICE"].ToString());
                    this.GSTPercentage = double.Parse(dt.Rows[0]["GST_PERCENTAGE"].ToString());
                    this.IsGSTApplicable = (dt.Rows[0]["GST_APPLICABLE"].ToString() == "0") ? false : true;
                    this.TimePeriod = int.Parse(dt.Rows[0]["TIME_PERIOD"].ToString());
                }
                else
                {
                    throw new Exception("Subscription base is not able to set");
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
    public enum PeriodType
    {
        Fixed,Floating
    }
    public enum FixedPeriodType
    {
        CalendarYear,AcademicYear
    }
    public enum ProRateUOM
    {
        Months,Days
    }
    public enum ProRateRule
    {
        DAYS_365,DAYS_360,EXCL_CUR_MONTH,INCL_CUR_MONTH
    }
   
}