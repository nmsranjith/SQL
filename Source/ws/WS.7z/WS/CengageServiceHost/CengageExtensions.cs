﻿/*

  *  Project Name        :   Cengage Ecommerce
  *  Module Name         :   WebService(WCF) - CengageServiceHost
  *  Developer Name      :   Sureshkumar Chandrasekar
  *  Date Created        :   26-06-2013
  *  Date Modified       :   26-07-2013

  */
using System;

namespace Cengage.Ecommerce.CengageServiceHost
{
    /// <summary>
    /// This is extension method of DATETIME object
    /// It gives the duration between two dates in Days360 scheme
    /// Logic :
    /// There are two cases to consider:
    /// When the month and year of both dates are the same.
    /// When the month and year are different.
    /// For the first case, the calculation is simple, day of DT minus day of DF. 
    /// For the seconde case, we can divide the calculation in three sections, considering Date From (DF) and Date To (DT)
    /// From the day of DF to 30 of the same month (30 - Day(DF))
    /// Complete months of 30 days
    /// From 1 to the day of DT of the month of DT
    /// For example, for the dates 10/01/2012 and 08/12/2012 In this case, the math would be: 20 + (10 * 30) + 8 = 328
    ///
    /// There are special cases to consider when the day from the date from is 31 or the month is February.
    /// If both date A and B fall on the last day of February, then date B will be changed to the 30th.
    /// If date A falls on the 31st of a month or last day of February, then date A will be changed to the 30th.
    /// If date A falls on the 30th of a month after applying (2) above and date B falls on the 31st of a month, then date B will be changed to the 30th.
    /// </summary>
    /// <param name="pDateFrom"></param>
    /// <param name="pDateTo"></param>
    /// <returns></returns>
    public static class CengageExtensions
    {
        public static int Days360(this DateTime pDateFrom, DateTime pDateTo)
        {
            int mDayFrom, mDayTo;
            int iret;

            if (pDateTo < pDateFrom) return 0;

            mDayFrom = pDateFrom.Day;
            mDayTo = pDateTo.Day;

            CheckDays(pDateFrom, pDateTo, ref mDayFrom, ref mDayTo, true);

            if (IsSameMonth(pDateFrom, pDateTo))
            {
                iret = mDayTo - mDayFrom;
                if (iret < 0) iret = 0;

                return iret;
            }
            iret = (30 - mDayFrom) + DaysFullMonth(pDateFrom, pDateTo) + mDayTo;

            if (iret < 0) iret = 0;

            return iret;
        }
        private static int DaysFullMonth(DateTime pDateFrom, DateTime pDateTo)
        {
            int iret = (pDateTo.Month - pDateFrom.Month - 1) * 30 + (pDateTo.Year - pDateFrom.Year) * 360;
            if (iret < 0) iret = 0;

            return iret;
        }
        private static bool IsSameMonth(DateTime pDateFrom, DateTime pDateTo)
        {
            return (pDateFrom.Month == pDateTo.Month && pDateFrom.Year == pDateTo.Year);
        }
        private static void CheckDays(DateTime pDateFrom, DateTime pDateTo, ref int pDayFrom, ref int pDayTo, bool pNASD)
        {
            if (pNASD)
            {
                if (LastDayOfMonth(pDateFrom) && pDateFrom.Month == 2)
                    pDayFrom = 30;

                if (pDayTo == 31 && pDayFrom >= 30)
                    pDayTo = 30;

                if (pDayFrom == 31)
                    pDayFrom = 30;
            }
            else
            {
                if (pDayFrom == 31) pDayFrom = 30;
                if (pDayTo == 31) pDayTo = 30;
            }
        }
        private static bool LastDayOfMonth(DateTime pDate)
        {
            return (pDate.AddDays(1).Month == pDate.Month + 1);
        }
        public static int MonthDiff(this DateTime StartDate, DateTime EndDate,bool IncludeCurrentMonth)
        {
            if(IncludeCurrentMonth)
                return ((EndDate.Year - StartDate.Year) * 12) + EndDate.Month - StartDate.Month;
            else
                return (((EndDate.Year - StartDate.Year) * 12) + EndDate.Month - StartDate.Month)-1;
        }
    }
}