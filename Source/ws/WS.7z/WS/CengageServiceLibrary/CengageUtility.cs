﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace CengageServiceLibrary
{
    public class CengageUtility
    {
        protected FaultException<CengageServiceException> WrapException(Exception ex)
        {
            CengageServiceException myFex = new CengageServiceException();
            myFex.Type = ex.GetType().FullName;
            myFex.ErrorMessage = ex.Message;
            FaultException<CengageServiceException> ff = new FaultException<CengageServiceException>(myFex, new FaultReason(((ServiceException)ex).ErrorNo.ToString())); //new FaultReason("Reason"));
            throw ff;
        }

    }
}
