﻿/*

  *  Project Name        :   Cengage Ecommerce
  *  Module Name         :   WebService(WCF) - CengageServiceLibrary
  *  Developer Name      :   Sureshkumar Chandrasekar
  *  Date Created        :   26-06-2013
  *  Date Modified       :   26-07-2013

  */
using System.Collections.Generic;
using System.ServiceModel;

namespace Cengage.Ecommerce.CengageServiceLibrary
{
    /// <summary>
    /// This is the service contract which is used in Host and Client.
    /// The implementation will be in Host and can be called through client
    /// By Default the exception from service is FaultContract
    /// </summary>
    [ServiceContract]
    public interface IPriceSvc
    {
        [FaultContract(typeof(FaultException))]
        [OperationContract]
        List<Product> GetProductPrice(List<Product> products);

        [FaultContract(typeof(FaultException))]
        [OperationContract]
        List<ProductSubscription> GetSubscriptionPrice(List<ProductSubscription> subscriptions);

        [FaultContract(typeof(FaultException))]
        [OperationContract]
        List<Product> GetProductAvailablity(List<Product>  products);
    }
}
