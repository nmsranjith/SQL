﻿/*

  *  Project Name        :   Cengage Ecommerce
  *  Module Name         :   WebService(WCF) - CengageServiceLibrary
  *  Developer Name      :   Sureshkumar Chandrasekar
  *  Date Created        :   26-06-2013
  *  Date Modified       :   26-07-2013

  */
using System;
using System.Runtime.Serialization;

namespace Cengage.Ecommerce.CengageServiceLibrary
{
    /// <summary>
    /// Product Entity
    /// </summary>
    [DataContract]
    public class Product
    {
        //Common input Parameter for AA and PriceProgram
        [DataMember]
        public string ISBN { get; set; }
        [DataMember]
        public string AccountNumber { get; set; }
        [DataMember]
        public string TradingAccountNumber { get; set; }
       

        //Common output Parameter for AA and PriceProgram
        [DataMember]
        public PriceSource ePriceSource { get; set; }
        [DataMember]
        public string Response { get; set; }


        //Output from AA pgm
        [DataMember]
        public string StockSohaCode { get; set; }
        [DataMember]
        public double StockAvailableQuantity { get; set; }
        [DataMember]
        public string StockStatus { get; set; }
        [DataMember]
        public char AllowSale { get; set; }


        //Input Parameter for Price pgm
        [DataMember]
        public int Quantity { get; set; }
        [DataMember]
        public int QuantityforExtensionAmount { get; set; }
        [DataMember]
        public DateTime EffectiveDate { get; set; }
        [DataMember]
        public string CustomerPriceCode { get; set; }
        [DataMember]
        public char ExchangeCode { get; set; }
        [DataMember]
        public string TypeOfSaleCode { get; set; }
        [DataMember]
        public string OurReference { get; set; }
        [DataMember]
        public string SalesRepCode { get; set; }
        [DataMember]
        public string PromotionPackagecode { get; set; }
        [DataMember]
        public string PriceOverrideFlag { get; set; }
        [DataMember]
        public double InputUnitPrice { get; set; }
        [DataMember]
        public char DiscountOverrideFlag { get; set; }
        [DataMember]
        public double InputDiscountRate { get; set; }
        [DataMember]
        public string ProcessNo { get; set; }
        [DataMember]
        public int LineNo { get; set; }
        [DataMember]
        public int SubLineNo { get; set; }
        [DataMember]
        public string ToCountry { get; set; }
        [DataMember]
        public string ToPostCode { get; set; }
        [DataMember]
        public string ToState { get; set; }
        [DataMember]
        public string FromWareHouse { get; set; }
        [DataMember]
        public string TaxExemptNo { get; set; }
        [DataMember]
        public string ApplyTax { get; set; }
        [DataMember]
        public char TaxOverrideFlag { get; set; }
        [DataMember]
        public double InputTaxRate { get; set; }
        [DataMember]
        public char GenerationFlag { get; set; }
        [DataMember]
        public double ExchangeRate { get; set; }
        [DataMember]
        public char FirmSaleFlag { get; set; }
        [DataMember]
        public double RRP { get; set; }
        [DataMember]
        public double UnitPriceNormal { get; set; }
        [DataMember]
        public double UnitPriceActual { get; set; }
        [DataMember]
        public double UnitPriceTaxable { get; set; }
        [DataMember]
        public char FixedPriceFlag { get; set; }
        [DataMember]
        public string PriceFormulae { get; set; }
        [DataMember]
        public string PriceTaxInclusive { get; set; }
        [DataMember]
        public double DiscountRateNormal { get; set; }
        [DataMember]
        public double DiscountrateActual { get; set; }
        [DataMember]
        public char FixedDiscountFlag { get; set; }
        [DataMember]
        public double TaxRateNormal { get; set; }
        [DataMember]
        public double TaxRateActual { get; set; }
        [DataMember]
        public double TradeTaxableAmount { get; set; }
        [DataMember]
        public double TradeTaxAmount { get; set; }
        [DataMember]
        public double BaseTaxableAmount { get; set; }
        [DataMember]
        public double BaseTaxAmount { get; set; }
        [DataMember]
        public double OutputPrice { get; set; }
        [DataMember]
        public double OutputQuantity { get; set; }

        //Input\Output for Cached system
        [DataMember]
        public string CurrencyCode { get; set; }
        [DataMember]
        public bool IsGSTIncluded { get; set; }
        [DataMember]
        public string PriceType { get; set; }

        [DataMember]
        public double LineItemValue { get; set; }
        [DataMember]
        public double DiscountedUnitPrice { get; set; }

        [DataMember]
        public double GSTUnit { get; set; }

       /* 
        //Subscription Input
        [DataMember]
        public int s_ProductSK { get; set; }
        [DataMember]
        public double DiscountedUnitPrice { get; set; }
        [DataMember]
        public int DiscountPercentage { get; set; }
        [DataMember]
        public double LineItemValue { get; set; }
        [DataMember]
        public double GstUnit { get; set; }
        [DataMember]
        public double GstLineItem { get; set; }
        //[DataMember]
        //public string PriceStatus { get; set; }
        //[DataMember]
        //public char PriceSourceType { get; set; }
        // DSO936: Bookmaster Price and Discount Retrieval – API
        [DataMember]
        public string Item { get; set; }
        [DataMember]
        public string CustomerAccountCode { get; set; }
        // GET_PRICE_AA WS*/
        
    }
    /// <summary>
    /// Realtime and Cached system decaration 
    /// </summary>
    public enum PriceSource
    {
        CENGAGE_AS400, CENGAGE_ECOM
    }
}