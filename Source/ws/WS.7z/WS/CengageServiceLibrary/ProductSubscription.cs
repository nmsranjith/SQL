﻿/*

  *  Project Name        :   Cengage Ecommerce
  *  Module Name         :   WebService(WCF) - CengageServiceLibrary
  *  Developer Name      :   Sureshkumar Chandrasekar
  *  Date Created        :   26-06-2013
  *  Date Modified       :   26-07-2013

  */
using System;
using System.Runtime.Serialization;

namespace Cengage.Ecommerce.CengageServiceLibrary
{
    /// <summary>
    /// Subscription Entity
    /// </summary>
    [DataContract]
    public class ProductSubscription
    {
        [DataMember]
        public string ISBN { get; set; }
        [DataMember]
        public string TradingAccNo { get; set; }
        [DataMember]
        public int OrderedQuantity { get; set; }
        [DataMember]
        public DateTime OrderedStartDate { get; set; }
        

        [DataMember]
        public int OrderedPeriodLength { get; set; }
        [DataMember]
        public SubscriptionProcessType eSubscriptionProcessType { get; set; }

        [DataMember]
        public double OrderedSubscriptionPrice { get; set; }
        [DataMember]
        public double OrderedSubscriptionGSTPrice { get; set; }
        [DataMember]
        public double OrderedSubscriptionDiscountPrice { get; set; }

        [DataMember]
        public bool IsNextYearIncluded { get; set; }

        [DataMember]
        public double NextYearSubscriptionPrice { get; set; }
        [DataMember]
        public double NextYearSubscriptionGSTPrice { get; set; }
        [DataMember]
        public double NextYearSubscriptionDiscountPrice { get; set; }

        [DataMember]
        public string Country {get;set;}
        [DataMember]
        public int Store_Sk { get; set; }
        
        [DataMember]
        public bool IsDiscountApplicable { get; set; }
        [DataMember]
        public double DiscountPercentage { get; set; }

        //For Upgrade
        [DataMember]
        public string Prev_ISBN { get; set; }
        [DataMember]
        public int Prev_LicenseCount { get; set; }
       


        //GST
        [DataMember]
        public bool IsGSTApplicable { get; set; }
        [DataMember]
        public double GSTPercentage { get; set; }

    }
    public enum SubscriptionProcessType
    {
        Purchase, Renew, Upgrade
    }
}