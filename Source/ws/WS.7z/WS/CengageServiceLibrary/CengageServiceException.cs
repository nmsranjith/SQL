﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace CengageServiceLibrary
{
    [DataContract]
    public class CengageServiceException
    {
        private string _type;
        private string _message;
        private string _errorNo;

        public CengageServiceException()
        {
        }

        [DataMember]
        public string Type
        {
            get { return _type; }
            set { _type = value; }
        }

        [DataMember]
        public string ErrorMessage
        {
            get { return _message; }
            set { _message = value; }
        }

        [DataMember]
        public string ErrorNo
        {
            get { return _errorNo; }
            set { _errorNo = value; }
        }



    }
}
