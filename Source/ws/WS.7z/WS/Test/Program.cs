﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Cengage.Ecommerce.CengageServiceClient;
using Cengage.Ecommerce.CengageServiceLibrary;
namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
           /* using (PriceSvcClient objClient = new PriceSvcClient())
            {
                 List<Product> lst = new List<Product>();
                 lst.Add(new Product() {
                     ISBN = "031406317X"
                                    });
            lst = objClient.GetProductPrice(lst);
            Console.WriteLine(lst[0].UnitPriceNormal.ToString());
            }
            Console.ReadLine();*/

           try
            {
                using (PriceSvcClient objClient = new PriceSvcClient())
                {
                    /*List<ProductSubscription> lst = new List<ProductSubscription>();
                    lst.Add(new ProductSubscription()
                    {
                        OrderedStartDate = DateTime.Today,
                        Country = "AU",
                        ISBN ="031406317X", //"0170097641",
                        TradingAccNo = "12",
                        OrderedQuantity = 60,
                        eSubscriptionProcessType = SubscriptionProcessType.Purchase,
                        IsNextYearIncluded = false,
                        Store_Sk = 4,

                        /*Prev_ISBN = "031406317X",
                        Prev_LicenseCount=50
                    });

                    lst = objClient.GetSubscriptionPrice(lst);*/

                    List<Product> lst = new List<Product>();
                    lst.Add(new Product() { ISBN = "9781869556877", Quantity = 1, CurrencyCode = "AUD", IsGSTIncluded = true, AccountNumber = "ECOMAUS" });
                    lst = objClient.GetProductPrice(lst);
                    Console.WriteLine(lst[0].RRP.ToString());
                }
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.Message);
            }
            Console.ReadLine();
        }
    }
}
