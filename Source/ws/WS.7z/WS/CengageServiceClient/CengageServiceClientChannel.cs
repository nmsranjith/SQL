﻿/*

  *  Project Name        :   Cengage Ecommerce
  *  Module Name         :   WebService(WCF) - CengageServiceClient
  *  Developer Name      :   Sureshkumar Chandrasekar
  *  Date Created        :   26-06-2013
  *  Date Modified       :   26-07-2013

  */

using System.ServiceModel;

namespace Cengage.Ecommerce.CengageServiceClient
{
    /// <summary>
    /// Channel Provider
    /// This is the base class for all the clients to connect the host through channel 
    /// Here we used only basicHttpBinding
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class CengageServiceClientChannel<T> where T : class
    {
        protected string endPointAddress = null;
        protected EndpointAddress basicEndPoint = null;
        protected BasicHttpBinding basicBinding = null;
        protected ChannelFactory<T> factory = null;
        protected T channel = null;
        /// <summary>
        /// constructor to create binding
        /// </summary>
        public CengageServiceClientChannel()
        {
            //Access the host through Http protocol with out any security. This can be replaced with WSBinding & https in future if client needed.
            //if the host placed in Intranet network then NetTcpBinding will be used for best performace
            basicBinding = new BasicHttpBinding();
            //set maximum size can be received from the channel
            basicBinding.MaxReceivedMessageSize = 2147483647;
            basicBinding.MaxBufferSize = 2147483647;
            basicBinding.MaxBufferPoolSize = 2147483647;
            basicBinding.ReaderQuotas.MaxDepth = 2147483647;
            basicBinding.ReaderQuotas.MaxStringContentLength = 2147483647;
            basicBinding.ReaderQuotas.MaxArrayLength = 2147483647;
            basicBinding.ReaderQuotas.MaxBytesPerRead = 2147483647;
            basicBinding.ReaderQuotas.MaxNameTableCharCount = 2147483647;
        }
        /// <summary>
        /// Read only - creating channel to the end point with the binding mode BasicHttpBinding
        /// </summary>
        public T Channel
        {
            get
            {
                factory = new ChannelFactory<T>(basicBinding, basicEndPoint);
                channel = factory.CreateChannel();

                return channel;
            }
        }
        /// <summary>
        /// to close the host connection
        /// clients need to call this method in their own dispose method.
        /// </summary>
        public void CloseConnection()
        {
            if (channel != null)
            {
                ((IClientChannel)channel).Close();
                ((IClientChannel)channel).Dispose();
                channel = null;
            }
            if (factory != null)
            {
                factory.Close();
                factory = null;
            }
        }
    }
}
