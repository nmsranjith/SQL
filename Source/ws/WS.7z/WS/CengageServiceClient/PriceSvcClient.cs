﻿/*

  *  Project Name        :   Cengage Ecommerce
  *  Module Name         :   WebService(WCF) - CengageServiceClient
  *  Developer Name      :   Sureshkumar Chandrasekar
  *  Date Created        :   26-06-2013
  *  Date Modified       :   26-07-2013

  */
using System;
using System.Collections.Generic;
using System.Configuration;
using System.ServiceModel;
using Cengage.Ecommerce.CengageServiceLibrary;

namespace Cengage.Ecommerce.CengageServiceClient
{
    /// <summary>
    /// This is the proxy class for PriceSvc.svc service
    /// </summary>
    public partial class PriceSvcClient : CengageServiceClientChannel<IPriceSvc>,IDisposable
    {
        /// <summary>
        /// Constructor to set endpoint address for client
        /// As it is the proxy for WCF , So we need to captue the exception as FaultException
        /// </summary>
        public PriceSvcClient()
        {
            this.endPointAddress = ConfigurationManager.AppSettings["CENGAGE_SERVICE_URL"];
            this.basicEndPoint = new EndpointAddress(this.endPointAddress);
        }
        /// <summary>
        /// to call the Host's method GetProductPrice
        /// </summary>
        /// <param name="ProductList"></param>
        /// <returns>ProductList</returns>
        public List<Product> GetProductPrice(List<Product> ProductList)
        {
            try
            {
                return base.Channel.GetProductPrice(ProductList);    
            }
            catch (FaultException Ex)
            {
                throw new Exception(Ex.Message);
            }
        }
        /// <summary>
        /// to call the Host's method GetSubscriptionPrice
        /// </summary>
        /// <param name="ProductSubscriptionList"></param>
        /// <returns>List of Product Subscription</returns>
        public List<ProductSubscription> GetSubscriptionPrice(List<ProductSubscription> ProductSubscriptionList)
        {
            try
            {
                return base.Channel.GetSubscriptionPrice(ProductSubscriptionList);
            }
            catch (FaultException Ex)
            {
                throw new Exception(Ex.Message);
            }
            
        }
        /// <summary>
        /// to call the host's method GetProductAvailablity
        /// </summary>
        /// <param name="ProductList"></param>
        /// <returns>ProductList</returns>
        public List<Product> GetProductAvailablity(List<Product> ProductList)
        {
            try
            {
                return base.Channel.GetProductAvailablity(ProductList);
            }
            catch (FaultException Ex)
            {
                throw new Exception(Ex.Message);
            }
        }
        /// <summary>
        /// To dispose the host connection
        /// This method will be invoked automatically when close the Using class
        /// </summary>
        public void Dispose()
        {
            try
            {
                base.CloseConnection();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
