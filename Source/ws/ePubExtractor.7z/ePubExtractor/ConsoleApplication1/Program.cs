﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Cengage.Ecommerce.ePubExtractor;


namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            ePubExtractorRepository obj = new ePubExtractorRepository();

        }
    }
}
