﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Cengage.Ecommerce.ePubExtractor;
using Cengage.Ecommerce.IntegratedServiceManagerHelper;


namespace Cengage.Ecommerce.ePubExtractor
{
    public class ePubExtractorService:IRunnable
    {
        public void Run(IDictionary<string, string> lstAttribute)
        {
            try
            {
                Logger.Log.Info("VarianceReport : VarianceReport started");
                //get all the config values from repository
                ePubExtractorRepository er = new ePubExtractorRepository(lstAttribute);
                //Call Deferred Job
                if (er.DoePubExtractorJob())
                {
                  
                }
                Logger.Log.Info("VarianceReport : VarianceReport Completed");
            }
            catch (Exception e)
            {
                Logger.Log.Error("VarianceReport : Error Message :" + e.Message);
            }
        }
    }
}
