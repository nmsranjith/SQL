﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Web;
using System.Web.Services;
using System.Xml;

namespace v1
{
    /// <summary>
    /// Summary description for api
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class api : System.Web.Services.WebService
    {
        string ls_success = "SUCCESS";
        string ls_failure = "FAILURE";
        string ls_teacher = "TEACHER";
        string ls_subs_admin = "SUBS ADMIN";
        string ls_cen_admin = "CEN ADMIN";
        string ls_cen_staff = "CEN STAFF";
        string ATTRIBUTE_TYPE_SK = System.Configuration.ConfigurationManager.AppSettings["ATTRIBUTE_TYPE_SK"];
        string MEDIA_TYPE_SK = System.Configuration.ConfigurationManager.AppSettings["MEDIA_TYPE_SK"];

        string ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];

        private void Log(string MethodName, string comment)
        {
            try
            {

                string isLogEnabled = ConfigurationManager.AppSettings["EnableLog"].ToString();
                if (isLogEnabled.ToUpper() == "YES")
                {
                    string fileName = ConfigurationManager.AppSettings["LogPath"].ToString() + @"\" + "NewLogfile" + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                    if (!File.Exists(fileName))
                    {
                        // Create a file to write to.
                        string[] createText = { DateTime.Now.ToString() + ':' + MethodName + ':' + comment + "\r\n" };
                        File.WriteAllLines(fileName, createText);
                    }

                    //LogFileWrite(new Exception(ConfigurationManager.AppSettings["LogPath"].ToString() + ConfigurationManager.AppSettings["EnableLog"].ToString()));
                    //TODO Format file to YYYYMMDD.txt
                    else
                    {
                        File.AppendAllText(fileName, DateTime.Now.ToString() + ":" + MethodName + ":" + comment + "\r\n");
                    }
                }
            }
            catch (Exception ex) { LogFileWrite(ex); }
        }
        private void SendMail(string as_subject, string as_body, string as_to_address, string as_cc_address)
        {
            MailMessage m = new MailMessage();
            m.From = new MailAddress("noreply@cengagelearning.com", "eCollectionAdmin");
            m.Subject = as_subject;
            m.Body = as_body;
            m.To.Add(as_to_address);
            m.IsBodyHtml = true;
            if (as_cc_address.Length > 0)
                m.To.Add(as_cc_address);

            SmtpClient smtp = new SmtpClient("mailhost.cengagelearning.com");

            smtp.Credentials = new System.Net.NetworkCredential("", "");
            smtp.Send(m);
        }

        private String EscapeXMLCharacters(String as_value)
        {
            as_value = as_value.Replace('&'.ToString(), "&amp;");
            //as_value = as_value.Replace('\''.ToString(), "&apos;");
            as_value = as_value.Replace('<'.ToString(), "&lt;");
            as_value = as_value.Replace('>'.ToString(), "&gt;");
            as_value = as_value.Replace("\"", "&quot;");

            return as_value;
        }

        private String EscapeForXMLNodeName(String as_value)
        {
            as_value = as_value.Replace('\''.ToString(), System.Configuration.ConfigurationManager.AppSettings["ApostropheEscape"]);
            as_value = as_value.Replace('’'.ToString(), System.Configuration.ConfigurationManager.AppSettings["ApostropheEscape"]);
            as_value = as_value.Replace('!'.ToString(), System.Configuration.ConfigurationManager.AppSettings["ExclamationEscape"]);
            as_value = as_value.Replace(' '.ToString(), System.Configuration.ConfigurationManager.AppSettings["SpaceEscape"]);
            as_value = as_value.Replace('0'.ToString(), System.Configuration.ConfigurationManager.AppSettings["NUM0"]);
            as_value = as_value.Replace('1'.ToString(), System.Configuration.ConfigurationManager.AppSettings["NUM1"]);
            as_value = as_value.Replace('2'.ToString(), System.Configuration.ConfigurationManager.AppSettings["NUM2"]);
            as_value = as_value.Replace('3'.ToString(), System.Configuration.ConfigurationManager.AppSettings["NUM3"]);
            as_value = as_value.Replace('4'.ToString(), System.Configuration.ConfigurationManager.AppSettings["NUM4"]);
            as_value = as_value.Replace('5'.ToString(), System.Configuration.ConfigurationManager.AppSettings["NUM5"]);
            as_value = as_value.Replace('6'.ToString(), System.Configuration.ConfigurationManager.AppSettings["NUM6"]);
            as_value = as_value.Replace('7'.ToString(), System.Configuration.ConfigurationManager.AppSettings["NUM7"]);
            as_value = as_value.Replace('8'.ToString(), System.Configuration.ConfigurationManager.AppSettings["NUM8"]);
            as_value = as_value.Replace('9'.ToString(), System.Configuration.ConfigurationManager.AppSettings["NUM9"]);

            return as_value;
        }

        private String EscapeSQLCharacters(String as_value)
        {
            as_value = as_value.Replace("\\u201c", "\"").Replace("\\u201d", "\"");
            as_value = as_value.Replace("“", "");
            as_value = as_value.Replace("'", "''");
            as_value = as_value.Replace(System.Configuration.ConfigurationManager.AppSettings["ApostropheEscape"], "’".ToString());
            as_value = as_value.Replace(System.Configuration.ConfigurationManager.AppSettings["ExclamationEscape"], "!".ToString());

            return as_value;
        }

        [WebMethod]
        public XmlDocument TestRest(string as_input_value, string information)
        {
            LogArguments("TestRest", as_input_value + ";", information);

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "TestRest");
            XmlElement ls_InputValue = ls_dom.CreateElement("InputValue");
            ls_Method.AppendChild(ls_InputValue);
            XmlText ls_InputValue_text = ls_dom.CreateTextNode(as_input_value);
            ls_InputValue.AppendChild(ls_InputValue_text);
            XmlElement ls_Error = ls_dom.CreateElement("Error");
            ls_Method.AppendChild(ls_Error);
            XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
            ls_Error.AppendChild(ls_ErrorCode);
            XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
            ls_ErrorCode.AppendChild(ls_ErrorCode_text);
            XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
            ls_Error.AppendChild(ls_ErrorDescription);
            XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
            ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
            XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
            ls_Method.AppendChild(ls_DisplayCustomMessage);
            XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
            ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
            XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
            ls_Method.AppendChild(ls_MessageCode);
            XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
            ls_MessageCode.AppendChild(ls_MessageCode_text);

            return ls_dom;
        }

        [WebMethod]
        public XmlDocument GetStartupAttributes(string as_ipad_udid, string information)
        {
            LogArguments("GetStartupAttributes", as_ipad_udid + ";", information);
            //Connection string to connect with database 

            ////string ls_ConnectionString = "";
            string ls_query;
            string ls_query1;
            string ls_item_value;

            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "GetStartupAttributes");

            try
            {

                //Open connection with database
                SQLConn.Open();

                // your code comes here 
                ls_query = "SELECT ";
                ls_query = ls_query + "IAC.IPAD_LINK_FLAG,IAC.SPLASH_DISPLAY_FLAG ";
                ls_query = ls_query + "FROM ";
                ls_query = ls_query + "CEN_IPAD_APP_CONTROL IAC";
                ls_query = ls_query + " WHERE ";
                ls_query = ls_query + "( IAC.IPAD_UDID = '" + as_ipad_udid + "')";

                DataSet lds_DataStore = new DataSet();
                System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                SQLAdapter.Fill(lds_DataStore);

                ls_query1 = "SELECT ";
                ls_query1 = ls_query1 + "IAC.IPAD_LINK_FLAG,IAC.SPLASH_DISPLAY_FLAG,TP.REGISTERED_BUSINESS_NAME ";
                ls_query1 = ls_query1 + "FROM ";
                ls_query1 = ls_query1 + "CEN_IPAD_APP_CONTROL IAC,CEN_TRADING_PARTNER_ACCOUNTS TP ";
                ls_query1 = ls_query1 + "WHERE ";
                ls_query1 = ls_query1 + "( TP.TRADING_PARTNER_ACCOUNT_SK = IAC.TRADING_PARTNER_ACCOUNT_SK ) AND ";
                ls_query1 = ls_query1 + "( IAC.IPAD_UDID = '" + as_ipad_udid + "')";

                //ls_return_value += "<WebResponse>";
                //ls_return_value += "<Method RequestName='GetStartupAttributes'>";

                //XmlElement ls_q = ls_dom.CreateElement("Query");
                //ls_Method.AppendChild(ls_q);
                //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query1);
                //ls_q.AppendChild(ls_Query_text);

                if (lds_DataStore.Tables[0].Rows.Count == 1)
                {

                    ls_item_value = lds_DataStore.Tables[0].Rows[0]["SPLASH_DISPLAY_FLAG"].ToString();
                    ls_item_value = EscapeXMLCharacters(ls_item_value);
                    if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                    //ls_return_value += "<item name='SPLASH_DISPLAY_FLAG'>" + ls_item_value + "</item>";
                    XmlElement ls_SPLASH_DISPLAY_FLAG = ls_dom.CreateElement("SPLASH_DISPLAY_FLAG");
                    ls_Method.AppendChild(ls_SPLASH_DISPLAY_FLAG);
                    XmlText ls_SPLASH_DISPLAY_FLAG_text = ls_dom.CreateTextNode(ls_item_value);
                    ls_SPLASH_DISPLAY_FLAG.AppendChild(ls_SPLASH_DISPLAY_FLAG_text);

                    ls_item_value = lds_DataStore.Tables[0].Rows[0]["IPAD_LINK_FLAG"].ToString();
                    ls_item_value = EscapeXMLCharacters(ls_item_value);
                    if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                    if (ls_item_value.Equals("1"))
                    {
                        DataSet lds_DataStore1 = new DataSet();
                        System.Data.SqlClient.SqlDataAdapter SQLAdapter1 = new System.Data.SqlClient.SqlDataAdapter(ls_query1, SQLConn);
                        SQLAdapter1.Fill(lds_DataStore1);
                        //ls_return_value += "<item name='IPAD_LINK_FLAG'>" + ls_item_value + "</item>";

                        if (lds_DataStore1.Tables[0].Rows.Count == 1)
                        {
                            XmlElement ls_IPAD_LINK_FLAG = ls_dom.CreateElement("IPAD_LINK_FLAG");
                            ls_Method.AppendChild(ls_IPAD_LINK_FLAG);
                            XmlText ls_IPAD_LINK_FLAG_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_IPAD_LINK_FLAG.AppendChild(ls_IPAD_LINK_FLAG_text);

                            ls_item_value = lds_DataStore1.Tables[0].Rows[0]["REGISTERED_BUSINESS_NAME"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            //ls_return_value += "<item name='PARTNER_NAME'>" + ls_item_value + "</item>";
                            XmlElement ls_PARTNER_NAME = ls_dom.CreateElement("REGISTERED_BUSINESS_NAME");
                            ls_Method.AppendChild(ls_PARTNER_NAME);
                            XmlText ls_PARTNER_NAME_text = ls_dom.CreateTextNode(ConvertToTitleCase(ls_item_value.ToLower()));
                            ls_PARTNER_NAME.AppendChild(ls_PARTNER_NAME_text);
                        }
                    }
                    else if (ls_item_value.Equals("0"))
                    {
                        //ls_return_value += "<item name='IPAD_LINK_FLAG'>" + "N" + "</item>";
                        XmlElement ls_IPAD_LINK_FLAG = ls_dom.CreateElement("IPAD_LINK_FLAG");
                        ls_Method.AppendChild(ls_IPAD_LINK_FLAG);
                        XmlText ls_IPAD_LINK_FLAG_text = ls_dom.CreateTextNode("0");
                        ls_IPAD_LINK_FLAG.AppendChild(ls_IPAD_LINK_FLAG_text);
                    }

                    //XmlElement ls_Error = ls_dom.CreateElement("Error");
                    //ls_Method.AppendChild(ls_Error);
                    //XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    //ls_Error.AppendChild(ls_ErrorCode);
                    //XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                    //ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    //XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    //ls_Error.AppendChild(ls_ErrorDescription);
                    //XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                    //ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                    //XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    //ls_Method.AppendChild(ls_DisplayCustomMessage);
                    //XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    //ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                    //XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    //ls_Method.AppendChild(ls_MessageCode);
                    //XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    //ls_MessageCode.AppendChild(ls_MessageCode_text);

                }
                else
                {
                    XmlElement ls_IPAD_LINK_FLAG = ls_dom.CreateElement("IPAD_LINK_FLAG");
                    ls_Method.AppendChild(ls_IPAD_LINK_FLAG);
                    XmlText ls_IPAD_LINK_FLAG_text = ls_dom.CreateTextNode("0");
                    ls_IPAD_LINK_FLAG.AppendChild(ls_IPAD_LINK_FLAG_text);

                    XmlElement ls_SPLASH_DISPLAY_FLAG = ls_dom.CreateElement("SPLASH_DISPLAY_FLAG");
                    ls_Method.AppendChild(ls_SPLASH_DISPLAY_FLAG);
                    XmlText ls_SPLASH_DISPLAY_FLAG_text = ls_dom.CreateTextNode("1");
                    ls_SPLASH_DISPLAY_FLAG.AppendChild(ls_SPLASH_DISPLAY_FLAG_text);

                    //Insert into IPAD_APP_CONTROL
                    ls_query = "INSERT INTO CEN_IPAD_APP_CONTROL (IPAD_UDID, IPAD_LINK_FLAG, SPLASH_DISPLAY_FLAG) VALUES (@txt1, @txt2, @txt3)";

                    SqlParameter ls_param1 = new SqlParameter();
                    ls_param1.ParameterName = "@txt1";
                    ls_param1.Value = as_ipad_udid;

                    SqlParameter ls_param2 = new SqlParameter();
                    ls_param2.ParameterName = "@txt2";
                    ls_param2.Value = "0";

                    SqlParameter ls_param3 = new SqlParameter();
                    ls_param3.ParameterName = "@txt3";
                    ls_param3.Value = "1";

                    using (SqlConnection connection = new SqlConnection(ls_ConnectionString))
                    {
                        SqlCommand command = new SqlCommand(ls_query, connection);
                        command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                        command.Parameters.Add(ls_param1);
                        command.Parameters.Add(ls_param2);
                        command.Parameters.Add(ls_param3);

                        command.Connection.Open();

                        try
                        {
                            command.ExecuteNonQuery();
                            command.Connection.Close();

                        }

                        catch (Exception exp)
                        {
                            XmlElement ls_Error = ls_dom.CreateElement("Error");
                            ls_Method.AppendChild(ls_Error);
                            XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                            ls_Error.AppendChild(ls_ErrorCode);
                            XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                            ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                            XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                            ls_Error.AppendChild(ls_ErrorDescription);
                            XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.StackTrace);
                            ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                            XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                            ls_Method.AppendChild(ls_DisplayCustomMessage);
                            XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                            ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                            XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                            ls_Method.AppendChild(ls_MessageCode);
                            XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                            ls_MessageCode.AppendChild(ls_MessageCode_text);

                            SendMail("Exception in iPad Web Services", exp.Source + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                            return ls_dom;
                        }

                    }

                }

                // Code for loading the messages
                ls_query = "SELECT ";
                ls_query = ls_query + "IAM.MESSAGE_CODE,IAM.MESSAGE_CUS_DESC ";
                ls_query = ls_query + "FROM ";
                ls_query = ls_query + "CEN_IPAD_APP_MESSAGES IAM";

                DataSet lds_DataStore2 = new DataSet();
                System.Data.SqlClient.SqlDataAdapter SQLAdapter2 = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                SQLAdapter2.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                SQLAdapter2.Fill(lds_DataStore2);

                //{
                //    ls_item_value = "M0000";
                //    XmlElement ls_MESSAGE_CODE = ls_dom.CreateElement(ls_item_value);
                //    ls_Method.AppendChild(ls_MESSAGE_CODE);

                //    ls_item_value = System.Configuration.ConfigurationManager.AppSettings["DbErrorDesc"];
                //    XmlText ls_MESSAGE_CODE_text = ls_dom.CreateTextNode(ls_item_value);
                //    ls_MESSAGE_CODE.AppendChild(ls_MESSAGE_CODE_text);
                //}

                if (lds_DataStore2.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= lds_DataStore2.Tables[0].Rows.Count - 1; i++)
                    {
                        ls_item_value = lds_DataStore2.Tables[0].Rows[i]["MESSAGE_CODE"].ToString();
                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                        XmlElement ls_MESSAGE_CODE = ls_dom.CreateElement(ls_item_value);
                        ls_Method.AppendChild(ls_MESSAGE_CODE);

                        ls_item_value = lds_DataStore2.Tables[0].Rows[i]["MESSAGE_CUS_DESC"].ToString();
                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                        XmlText ls_MESSAGE_CODE_text = ls_dom.CreateTextNode(ls_item_value);
                        ls_MESSAGE_CODE.AppendChild(ls_MESSAGE_CODE_text);

                    }
                }
                else
                {

                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode("Database Not Connected");
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0000");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    SendMail("Exception in iPad Web Services - GetStartupAttributes", "Database Not Connected", System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                    return ls_dom;
                }

                {
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);
                }

                XmlElement ls_LaunchScreenAnimationImages = ls_dom.CreateElement("LaunchScreenAnimationImages");
                ls_Method.AppendChild(ls_LaunchScreenAnimationImages);
                XmlElement ls_LaunchScreenAnimationImage1 = ls_dom.CreateElement("LaunchScreenAnimationImage1");
                ls_LaunchScreenAnimationImages.AppendChild(ls_LaunchScreenAnimationImage1);
                XmlText ls_LaunchScreenAnimationImage1_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["LAUNCHSCREEN_ANIMATION_FILE_1"]);
                ls_LaunchScreenAnimationImage1.AppendChild(ls_LaunchScreenAnimationImage1_text);
                XmlElement ls_LaunchScreenAnimationImage2 = ls_dom.CreateElement("LaunchScreenAnimationImage2");
                ls_LaunchScreenAnimationImages.AppendChild(ls_LaunchScreenAnimationImage2);
                XmlText ls_LaunchScreenAnimationImage2_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["LAUNCHSCREEN_ANIMATION_FILE_2"]);
                ls_LaunchScreenAnimationImage2.AppendChild(ls_LaunchScreenAnimationImage2_text);
                XmlElement ls_LaunchScreenAnimationImage3 = ls_dom.CreateElement("LaunchScreenAnimationImage3");
                ls_LaunchScreenAnimationImages.AppendChild(ls_LaunchScreenAnimationImage3);
                XmlText ls_LaunchScreenAnimationImage3_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["LAUNCHSCREEN_ANIMATION_FILE_3"]);
                ls_LaunchScreenAnimationImage3.AppendChild(ls_LaunchScreenAnimationImage3_text);
                XmlElement ls_LaunchScreenAnimationImage4 = ls_dom.CreateElement("LaunchScreenAnimationImage4");
                ls_LaunchScreenAnimationImages.AppendChild(ls_LaunchScreenAnimationImage4);
                XmlText ls_LaunchScreenAnimationImage4_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["LAUNCHSCREEN_ANIMATION_FILE_4"]);
                ls_LaunchScreenAnimationImage4.AppendChild(ls_LaunchScreenAnimationImage4_text);

                XmlElement ls_PrintCard = ls_dom.CreateElement("PrintCard");
                ls_Method.AppendChild(ls_PrintCard);
                XmlElement ls_PrintCardURL = ls_dom.CreateElement("PrintCardURL");
                ls_PrintCard.AppendChild(ls_PrintCardURL);
                XmlText ls_PrintCard_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["PrintCardURL"]);
                ls_PrintCardURL.AppendChild(ls_PrintCard_text);

                XmlElement ls_Cache = ls_dom.CreateElement("Cache");
                ls_Method.AppendChild(ls_Cache);
                XmlElement ls_ePubFileCache = ls_dom.CreateElement("ePubCache");
                ls_Cache.AppendChild(ls_ePubFileCache);
                XmlText ls_ePubFileCache_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["ePubCache"]);
                ls_ePubFileCache.AppendChild(ls_ePubFileCache_text);

                XmlElement ls_ClearCacheOnLogin = ls_dom.CreateElement("ClearCache");
                ls_Cache.AppendChild(ls_ClearCacheOnLogin);
                XmlText ls_ClearCacheOnLogin_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["ClearCache"]);
                ls_ClearCacheOnLogin.AppendChild(ls_ClearCacheOnLogin_text);

                XmlElement ls_try_ecollection = ls_dom.CreateElement("TryeCollection");
                ls_Method.AppendChild(ls_try_ecollection);
                XmlElement ls_GuestUserLoginName = ls_dom.CreateElement("GuestUserLoginName");
                ls_try_ecollection.AppendChild(ls_GuestUserLoginName);
                XmlText ls_try_ecollection_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["GuestUserLoginName"]);
                ls_GuestUserLoginName.AppendChild(ls_try_ecollection_text);
                XmlElement ls_GuestUserSk = ls_dom.CreateElement("GuestUserSk");
                ls_try_ecollection.AppendChild(ls_GuestUserSk);
                XmlText ls_GuestUserSk_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["GuestUserSk"]);
                ls_GuestUserSk.AppendChild(ls_GuestUserSk_text);
                XmlElement ls_GuestCustSubsSk = ls_dom.CreateElement("GuestCustSubsSk");
                ls_try_ecollection.AppendChild(ls_GuestCustSubsSk);
                XmlText ls_GuestCustSubsSk_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["GuestCustSubsSk"]);
                ls_GuestCustSubsSk.AppendChild(ls_GuestCustSubsSk_text);
                XmlElement ls_Try_ISBNS = ls_dom.CreateElement("ISBNS");
                ls_try_ecollection.AppendChild(ls_Try_ISBNS);
                XmlText ls_Try_ISBNS_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["ISBNS"]);
                ls_Try_ISBNS.AppendChild(ls_Try_ISBNS_text);

                XmlElement ls_WebAppURL = ls_dom.CreateElement("WebAppURL");
                ls_Method.AppendChild(ls_WebAppURL);
                XmlText ls_WebAppURL_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["WEB_APP_URL"]);
                ls_WebAppURL.AppendChild(ls_WebAppURL_text);

                XmlElement ls_AutoRefreshTime = ls_dom.CreateElement("AutoRefreshTime");
                ls_Method.AppendChild(ls_AutoRefreshTime);
                XmlText ls_AutoRefreshTime_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["AutoRefreshTime"]);
                ls_AutoRefreshTime.AppendChild(ls_AutoRefreshTime_text);

                XmlElement ls_ApostropheEscape = ls_dom.CreateElement("ApostropheEscape");
                ls_Method.AppendChild(ls_ApostropheEscape);
                XmlText ls_ApostropheEscape_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["ApostropheEscape"]);
                ls_ApostropheEscape.AppendChild(ls_ApostropheEscape_text);

                XmlElement ls_ExclamationEscape = ls_dom.CreateElement("ExclamationEscape");
                ls_Method.AppendChild(ls_ExclamationEscape);
                XmlText ls_ExclamationEscape_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["ExclamationEscape"]);
                ls_ExclamationEscape.AppendChild(ls_ExclamationEscape_text);

                XmlElement ls_MyWordsSpecialCharactersFilter = ls_dom.CreateElement("MyWordsSpecialCharactersFilter");
                ls_Method.AppendChild(ls_MyWordsSpecialCharactersFilter);
                XmlText ls_MyWordsSpecialCharactersFilter_text = ls_dom.CreateTextNode("”?“,.’ !… —:• ");
                ls_MyWordsSpecialCharactersFilter.AppendChild(ls_MyWordsSpecialCharactersFilter_text);

                XmlElement ls_ShowDebugMessages = ls_dom.CreateElement("ShowDebugMessages");
                ls_Method.AppendChild(ls_ShowDebugMessages);
                XmlText ls_ShowDebugMessages_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["ShowDebugMessages"]);
                ls_ShowDebugMessages.AppendChild(ls_ShowDebugMessages_text);

                XmlElement ls_APP_URL = ls_dom.CreateElement("APP_URL");
                ls_Method.AppendChild(ls_APP_URL);
                XmlText ls_APP_URL_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["APP_URL"]);
                ls_APP_URL.AppendChild(ls_APP_URL_text);

                SQLConn.Close();
                return ls_dom;

            }

            catch (Exception exp)
            {
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.StackTrace);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                ls_MessageCode.AppendChild(ls_MessageCode_text);

                SendMail("Exception in iPad Web Services - GetStartupAttributes", exp.Source + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                return ls_dom;
            }

        }

        [WebMethod]
        public XmlDocument LinkiPadToSchool(string as_teacher_email, string as_teacher_password, string as_ipad_udid, string information)
        {
            LogArguments("LinkiPadToSchool", as_teacher_email + ";" + as_teacher_password + ";" + as_ipad_udid, information);
            //Connection string to connect with database 

            //string ls_ConnectionString = "";
            string ls_update_statement;
            string ls_query;
            string ls_item_value;

            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "LinkiPadToSchool");

            try
            {

                //Open connection with database
                SQLConn.Open();

                // your code comes here 
                ls_query = "SELECT ";
                ls_query = ls_query + "U.PASSWORD,TP.TRADING_PARTNER_ACCOUNT_SK,TP.REGISTERED_BUSINESS_NAME,R.ROLE_ID ";
                ls_query = ls_query + "FROM ";
                ls_query = ls_query + "CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_TRADING_PARTNER_ACCOUNTS TP,CEN_USER_ROLES UR,CEN_ROLES R ";
                ls_query = ls_query + "WHERE ";
                ls_query = ls_query + "( TPU.TRADING_PARTNER_ACCOUNT_SK = TP.TRADING_PARTNER_ACCOUNT_SK ) AND ";
                ls_query = ls_query + "( R.ROLE_SK = UR.ROLE_SK ) AND ";
                ls_query = ls_query + "( UR.USER_SK = U.USER_SK ) AND ";
                ls_query = ls_query + "( TPU.USER_ROLE_SK = UR.USER_ROLE_SK ) AND ";
                ls_query = ls_query + "R.ROLE_ID IN ('TEACHER','SUBS ADMIN','CEN ADMIN','CEN STAFF') AND ";
                ls_query = ls_query + "( U.USER_LOGIN_NAME = '" + as_teacher_email + "') AND UR.ACTIVE='Y' AND TPU.ACTIVE='Y' AND TP.ACTIVE='Y' AND R.ACTIVE='Y'";

                DataSet lds_DataStore = new DataSet();
                System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                SQLAdapter.Fill(lds_DataStore);

                using (SqlConnection conn = new SqlConnection(ls_ConnectionString))
                {
                    ls_query = string.Empty;
                    ls_query = "INSERT INTO CEN_IPAD_LINKED_SCHOOL_UDIDs(IPAD_UDID,TRADING_PARTNER_ACCOUNT_SK,USER_LOGIN_NAME,ACTIVE,USER_CREATED,DATE_CREATED) ";
                    ls_query = ls_query + "SELECT DISTINCT '" + as_ipad_udid + "',TP.TRADING_PARTNER_ACCOUNT_SK,'" + as_teacher_email + "','Y','" + as_teacher_email + "','" + DateTime.Now.ToString() + "' FROM CEN_USERS AS U ";
                    ls_query = ls_query + "JOIN CEN_USER_ROLES AS UR ON UR.USER_SK=U.USER_SK ";
                    ls_query = ls_query + "JOIN CEN_TRADING_PARTNER_USERS AS TP ON TP.USER_ROLE_SK=UR.USER_ROLE_SK ";
                    ls_query = ls_query + "JOIN CEN_TRADING_PARTNER_ACCOUNTS AS TA ON TP.TRADING_PARTNER_ACCOUNT_SK=TA.TRADING_PARTNER_ACCOUNT_SK ";
                    ls_query = ls_query + "JOIN CEN_ROLES AS R ON UR.ROLE_SK=R.ROLE_SK ";
                    ls_query = ls_query + "WHERE R.ROLE_ID IN ('TEACHER','SUBS ADMIN') AND  ";
                    ls_query = ls_query + "U.USER_LOGIN_NAME = '" + as_teacher_email + "' AND UR.ACTIVE='Y' AND TP.ACTIVE='Y' AND TA.ACTIVE='Y' AND R.ACTIVE='Y'  ";
                    SqlCommand command = new SqlCommand(ls_query, conn);
                    try
                    {
                        command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                        command.Connection.Open();
                        command.ExecuteNonQuery();
                        command.Connection.Close();
                    }
                    catch (Exception ex) { LogFileWrite(ex); }

                }

                if (lds_DataStore.Tables[0].Rows.Count > 0)
                {

                    ls_item_value = lds_DataStore.Tables[0].Rows[0]["ROLE_ID"].ToString();
                    ls_item_value = EscapeXMLCharacters(ls_item_value);
                    if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                    if (ls_item_value.Equals(ls_teacher) || ls_item_value.Equals(ls_subs_admin) || ls_item_value.Equals(ls_cen_admin) || ls_item_value.Equals(ls_cen_staff))
                    {

                        ls_item_value = lds_DataStore.Tables[0].Rows[0]["PASSWORD"].ToString();
                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                        if (Encrypt(as_teacher_password).Equals(ls_item_value))
                        {
                            ls_item_value = lds_DataStore.Tables[0].Rows[0]["TRADING_PARTNER_ACCOUNT_SK"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                            ls_update_statement = "UPDATE CEN_IPAD_APP_CONTROL " + "SET IPAD_LINK_FLAG = @IPAD_LINK_FLAG, TRADING_PARTNER_ACCOUNT_SK = @TRADING_PARTNER_SK" + " WHERE IPAD_UDID = @IPAD_UDID";

                            SqlParameter ls_param1 = new SqlParameter();
                            ls_param1.ParameterName = "@IPAD_LINK_FLAG";
                            ls_param1.Value = "1";

                            SqlParameter ls_param2 = new SqlParameter();
                            ls_param2.ParameterName = "@IPAD_UDID";
                            ls_param2.Value = as_ipad_udid;

                            SqlParameter ls_param3 = new SqlParameter();
                            ls_param3.ParameterName = "@TRADING_PARTNER_SK";
                            ls_param3.Value = ls_item_value;

                            using (SqlConnection connection = new SqlConnection(ls_ConnectionString))
                            {
                                SqlCommand command = new SqlCommand(ls_update_statement, connection);
                                command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                                command.Parameters.Add(ls_param1);
                                command.Parameters.Add(ls_param2);
                                command.Parameters.Add(ls_param3);

                                command.Connection.Open();

                                try
                                {
                                    command.ExecuteNonQuery();
                                    command.Connection.Close();

                                    ls_item_value = lds_DataStore.Tables[0].Rows[0]["REGISTERED_BUSINESS_NAME"].ToString();
                                    ls_item_value = EscapeXMLCharacters(ls_item_value);
                                    if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                                    XmlElement ls_PartnerName = ls_dom.CreateElement("REGISTERED_BUSINESS_NAME");
                                    ls_Method.AppendChild(ls_PartnerName);

                                    XmlText ls_PartnerName_text = ls_dom.CreateTextNode(ConvertToTitleCase(ls_item_value.ToLower()));
                                    ls_PartnerName.AppendChild(ls_PartnerName_text);
                                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                                    ls_Method.AppendChild(ls_Error);
                                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                                    ls_Error.AppendChild(ls_ErrorCode);
                                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                                    ls_Error.AppendChild(ls_ErrorDescription);
                                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                                    ls_Method.AppendChild(ls_MessageCode);
                                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                                }
                                catch (Exception exp)
                                {
                                    command.Connection.Close();
                                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                                    ls_Method.AppendChild(ls_Error);
                                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                                    ls_Error.AppendChild(ls_ErrorCode);
                                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                                    ls_Error.AppendChild(ls_ErrorDescription);
                                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.StackTrace);
                                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                                    ls_Method.AppendChild(ls_MessageCode);
                                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                                    SendMail("Exception in iPad Web Services", exp.Source + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                                    SQLConn.Close();

                                    return ls_dom;
                                }
                            }
                        }
                        else
                        {
                            XmlElement ls_Error = ls_dom.CreateElement("Error");
                            ls_Method.AppendChild(ls_Error);
                            XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                            ls_Error.AppendChild(ls_ErrorCode);
                            XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                            ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                            XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                            ls_Error.AppendChild(ls_ErrorDescription);
                            XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                            ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                            XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                            ls_Method.AppendChild(ls_DisplayCustomMessage);
                            XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                            ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                            XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                            ls_Method.AppendChild(ls_MessageCode);
                            XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0006");
                            ls_MessageCode.AppendChild(ls_MessageCode_text);

                        }
                    }
                    else
                    {
                        XmlElement ls_Error = ls_dom.CreateElement("Error");
                        ls_Method.AppendChild(ls_Error);
                        XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                        ls_Error.AppendChild(ls_ErrorCode);
                        XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                        ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                        XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                        ls_Error.AppendChild(ls_ErrorDescription);
                        XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                        ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                        XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                        ls_Method.AppendChild(ls_DisplayCustomMessage);
                        XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                        ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                        XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                        ls_Method.AppendChild(ls_MessageCode);
                        XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0016");
                        ls_MessageCode.AppendChild(ls_MessageCode_text);
                    }
                }
                else
                {
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0016");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);
                }

                SQLConn.Close();

                return ls_dom;

            }
            catch (Exception exp)
            {
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.StackTrace);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                ls_MessageCode.AppendChild(ls_MessageCode_text);

                SendMail("Exception in iPad Web Services", exp.Source + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                SQLConn.Close();

                return ls_dom;
            }

        }

        [WebMethod]
        public XmlDocument TurnOffSplashScreen(string as_ipad_udid, string information)
        {
            LogArguments("TurnOffSplashScreen", as_ipad_udid, information);
            //Connection string to connect with database 

            //string ls_ConnectionString = "";
            string ls_update_statement;

            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            ls_update_statement = "UPDATE CEN_IPAD_APP_CONTROL " + "SET SPLASH_DISPLAY_FLAG = @SPLASH_DISPLAY_FLAG " + " WHERE IPAD_UDID = @IPAD_UDID";

            SqlParameter ls_param1 = new SqlParameter();
            ls_param1.ParameterName = "@SPLASH_DISPLAY_FLAG";
            ls_param1.Value = "0";

            SqlParameter ls_param2 = new SqlParameter();
            ls_param2.ParameterName = "@IPAD_UDID";
            ls_param2.Value = as_ipad_udid;

            XmlDocument ls_dom = new XmlDocument();

            using (SqlConnection connection = new SqlConnection(ls_ConnectionString))
            {
                SqlCommand command = new SqlCommand(ls_update_statement, connection);
                command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                command.Parameters.Add(ls_param1);
                command.Parameters.Add(ls_param2);

                command.Connection.Open();

                try
                {
                    command.ExecuteNonQuery();

                    XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
                    ls_dom.AppendChild(ls_WebResponse);
                    XmlElement ls_Method = ls_dom.CreateElement("Method");
                    ls_WebResponse.AppendChild(ls_Method);
                    ls_Method.SetAttribute("RequestName", "TurnOffSplashScreen");
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    command.Connection.Close();
                }

                catch (Exception exp)
                {
                    XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
                    ls_dom.AppendChild(ls_WebResponse);
                    XmlElement ls_Method = ls_dom.CreateElement("Method");
                    ls_WebResponse.AppendChild(ls_Method);
                    ls_Method.SetAttribute("RequestName", "TurnOffSplashScreen");
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.StackTrace);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    SendMail("Exception in iPad Web Services", exp.Source + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                    command.Connection.Close();

                    return ls_dom;
                }
            }

            return ls_dom;
        }

        [WebMethod]
        public XmlDocument UnlinkiPadFromSchoolAccount(string as_teacher_email, string as_teacher_password, string as_ipad_udid, string information)
        {
            LogArguments("UnlinkiPadFromSchoolAccount", as_teacher_email + ";" + as_teacher_password + ";" + as_ipad_udid, information);
            //string ls_ConnectionString = "";
            string ls_update_statement;
            string ls_query;
            string ls_item_value;

            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "UnlinkiPadFromSchoolAccount");
            try
            {
                try
                {

                    //Open connection with database
                    SQLConn.Open();

                    //ls_query = "SELECT ";
                    //ls_query = ls_query + "U.PASSWORD,TP.TRADING_PARTNER_ACCOUNT_SK,TP.REGISTERED_BUSINESS_NAME,R.ROLE_ID ";
                    //ls_query = ls_query + "FROM ";
                    //ls_query = ls_query + "CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_TRADING_PARTNER_ACCOUNTS TP,CEN_USER_ROLES UR,CEN_ROLES R ";
                    //ls_query = ls_query + "WHERE ";
                    //ls_query = ls_query + "( TPU.TRADING_PARTNER_ACCOUNT_SK = TP.TRADING_PARTNER_ACCOUNT_SK ) AND ";
                    //ls_query = ls_query + "( R.ROLE_SK = UR.ROLE_SK ) AND ";
                    //ls_query = ls_query + "( UR.USER_SK = U.USER_SK ) AND ";
                    //ls_query = ls_query + "( U.USER_LOGIN_NAME = '" + as_teacher_email + "')";

                    ls_query = "SELECT ";
                    ls_query = ls_query + "U.PASSWORD,TP.TRADING_PARTNER_ACCOUNT_SK,TP.REGISTERED_BUSINESS_NAME,R.ROLE_ID ";
                    ls_query = ls_query + "FROM ";
                    ls_query = ls_query + "CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_TRADING_PARTNER_ACCOUNTS TP,CEN_USER_ROLES UR,CEN_ROLES R ";
                    ls_query = ls_query + "WHERE ";
                    ls_query = ls_query + "( TPU.TRADING_PARTNER_ACCOUNT_SK = TP.TRADING_PARTNER_ACCOUNT_SK ) AND ";
                    ls_query = ls_query + "( R.ROLE_SK = UR.ROLE_SK ) AND ";
                    ls_query = ls_query + "( UR.USER_SK = U.USER_SK ) AND ";
                    ls_query = ls_query + "( TPU.USER_ROLE_SK = UR.USER_ROLE_SK ) AND ";
                    ls_query = ls_query + "R.ROLE_ID IN ('TEACHER','SUBS ADMIN','CEN ADMIN','CEN STAFF') AND ";
                    ls_query = ls_query + "( U.USER_LOGIN_NAME = '" + as_teacher_email + "')";

                    DataSet lds_DataStore = new DataSet();
                    System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                    SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                    SQLAdapter.Fill(lds_DataStore);

                    using (SqlConnection conn = new SqlConnection(ls_ConnectionString))
                    {
                        ls_query = string.Empty;
                        ls_query = "UPDATE CEN_IPAD_LINKED_SCHOOL_UDIDs ";
                        ls_query = ls_query + "SET ACTIVE='N',DATE_MODIFIED='" + DateTime.Now.ToString() + "',USER_MODIFIED='" + as_teacher_email + "' ";
                        ls_query = ls_query + "WHERE IPAD_UDID='" + as_ipad_udid + "'  ";
                        SqlCommand command = new SqlCommand(ls_query, conn);
                        try
                        {
                            command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                            command.Connection.Open();
                            command.ExecuteNonQuery();
                            command.Connection.Close();
                        }
                        catch (Exception ex) { LogFileWrite(ex); }
                    }

                    if (lds_DataStore.Tables[0].Rows.Count > 0)
                    {

                        ls_item_value = lds_DataStore.Tables[0].Rows[0]["ROLE_ID"].ToString();
                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                        if (ls_item_value.Equals(ls_teacher) || ls_item_value.Equals(ls_subs_admin) || ls_item_value.Equals(ls_cen_admin) || ls_item_value.Equals(ls_cen_staff))
                        {

                            ls_item_value = lds_DataStore.Tables[0].Rows[0]["PASSWORD"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                            if (Encrypt(as_teacher_password).Equals(ls_item_value))
                            {

                                ls_update_statement = "UPDATE CEN_IPAD_APP_CONTROL " + "SET IPAD_LINK_FLAG = @IPAD_LINK_FLAG, USER_MODIFIED='" + as_teacher_email + "', DATE_MODIFIED='" + DateTime.Now.ToString() + "'" + " WHERE IPAD_UDID = @IPAD_UDID";

                                SqlParameter ls_param1 = new SqlParameter();
                                ls_param1.ParameterName = "@IPAD_LINK_FLAG";
                                ls_param1.Value = "0";

                                SqlParameter ls_param2 = new SqlParameter();
                                ls_param2.ParameterName = "@IPAD_UDID";
                                ls_param2.Value = as_ipad_udid;

                                using (SqlConnection connection = new SqlConnection(ls_ConnectionString))
                                {
                                    SqlCommand command = new SqlCommand(ls_update_statement, connection);
                                    command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                                    command.Parameters.Add(ls_param1);
                                    command.Parameters.Add(ls_param2);

                                    command.Connection.Open();

                                    try
                                    {
                                        command.ExecuteNonQuery();

                                        XmlElement ls_Error = ls_dom.CreateElement("Error");
                                        ls_Method.AppendChild(ls_Error);
                                        XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                                        ls_Error.AppendChild(ls_ErrorCode);
                                        XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                                        ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                                        XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                                        ls_Error.AppendChild(ls_ErrorDescription);
                                        XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                                        ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                                        XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                                        ls_Method.AppendChild(ls_DisplayCustomMessage);
                                        XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                                        ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                                        XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                                        ls_Method.AppendChild(ls_MessageCode);
                                        XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0002");
                                        ls_MessageCode.AppendChild(ls_MessageCode_text);

                                        command.Connection.Close();
                                    }

                                    catch (Exception exp)
                                    {

                                        XmlElement ls_Error = ls_dom.CreateElement("Error");
                                        ls_Method.AppendChild(ls_Error);
                                        XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                                        ls_Error.AppendChild(ls_ErrorCode);
                                        XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                                        ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                                        XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                                        ls_Error.AppendChild(ls_ErrorDescription);
                                        XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.StackTrace);
                                        ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                                        XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                                        ls_Method.AppendChild(ls_DisplayCustomMessage);
                                        XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                                        ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                                        XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                                        ls_Method.AppendChild(ls_MessageCode);
                                        XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                                        ls_MessageCode.AppendChild(ls_MessageCode_text);

                                        SendMail("Exception in iPad Web Services", exp.Source + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                                        command.Connection.Close();

                                        return ls_dom;
                                    }
                                }
                            }
                            else
                            {
                                XmlElement ls_Error = ls_dom.CreateElement("Error");
                                ls_Method.AppendChild(ls_Error);
                                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                                ls_Error.AppendChild(ls_ErrorCode);
                                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                                ls_Error.AppendChild(ls_ErrorDescription);
                                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode("Failure");
                                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                                ls_Method.AppendChild(ls_DisplayCustomMessage);
                                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                                ls_Method.AppendChild(ls_MessageCode);
                                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0006");
                                ls_MessageCode.AppendChild(ls_MessageCode_text);
                            }
                        }
                        else
                        {
                            XmlElement ls_Error = ls_dom.CreateElement("Error");
                            ls_Method.AppendChild(ls_Error);
                            XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                            ls_Error.AppendChild(ls_ErrorCode);
                            XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                            ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                            XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                            ls_Error.AppendChild(ls_ErrorDescription);
                            XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode("Failure");
                            ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                            XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                            ls_Method.AppendChild(ls_DisplayCustomMessage);
                            XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                            ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                            XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                            ls_Method.AppendChild(ls_MessageCode);
                            XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0015");
                            ls_MessageCode.AppendChild(ls_MessageCode_text);
                        }
                    }
                    else
                    {
                        XmlElement ls_Error = ls_dom.CreateElement("Error");
                        ls_Method.AppendChild(ls_Error);
                        XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                        ls_Error.AppendChild(ls_ErrorCode);
                        XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                        ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                        XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                        ls_Error.AppendChild(ls_ErrorDescription);
                        XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode("Failure");
                        ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                        XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                        ls_Method.AppendChild(ls_DisplayCustomMessage);
                        XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                        ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                        XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                        ls_Method.AppendChild(ls_MessageCode);
                        XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0006");
                        ls_MessageCode.AppendChild(ls_MessageCode_text);
                    }

                    SQLConn.Close();

                    return ls_dom;

                }
                catch (Exception exp)
                {
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.StackTrace);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    SendMail("Exception in iPad Web Services", exp.Source + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);
                    SQLConn.Close();
                    LogFileWrite(exp);
                    return ls_dom;
                }
            }
            catch (Exception ex)
            {
                LogFileWrite(ex);
                return ls_dom;
            }
        }

        [WebMethod]
        public XmlDocument GetAllStudentsUserLoginName(string as_ipad_udid, string information)
        {
            LogArguments("GetAllStudentsUserLoginName", as_ipad_udid, information);
            //string ls_ConnectionString = "";
            string ls_query;
            string ls_item_value;

            //Connection string to connect with database 
            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "GetAllStudentsUserLoginName");
            try
            {
                try
                {

                    //Open connection with database
                    //SQLConn.Open();

                    //ls_query = "SELECT DISTINCT ";
                    //ls_query = ls_query + "U.USER_LOGIN_NAME ";
                    //ls_query = ls_query + "FROM ";
                    //ls_query = ls_query + "CEN_IPAD_APP_CONTROL IAC,CEN_TRADING_PARTNER_USERS TPU,CEN_USERS U,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_CUSTOMER_SUBS_USERS CSU ";
                    //ls_query = ls_query + "WHERE ";
                    //ls_query = ls_query + "( CSU.CUST_SUBS_SK = CS.CUST_SUBS_SK ) AND ";
                    //ls_query = ls_query + "( CSU.TRAD_PART_USER_SK = TPU.TRAD_PART_USER_SK ) AND ";
                    //ls_query = ls_query + "( IAC.TRADING_PARTNER_ACCOUNT_SK = CS.TRADING_PARTNER_ACCOUNT_SK ) AND ";                   
                    //ls_query = ls_query + "( TPU.USER_ROLE_SK = UR.USER_ROLE_SK ) AND ";
                    //ls_query = ls_query + "( U.USER_SK = UR.USER_SK ) AND ";
                    //ls_query = ls_query + "( IAC.IPAD_UDID = '" + as_ipad_udid + "' AND CS.STATUS NOT IN('BLOCKED','CLOSED') AND CS.ACTIVE='Y') Order By USER_LOGIN_NAME";

                    //XmlElement ls_q = ls_dom.CreateElement("Query");
                    //ls_Method.AppendChild(ls_q);
                    //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query);
                    //ls_q.AppendChild(ls_Query_text);

                    //DataSet lds_DataStore = new DataSet();
                    //System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                    //SQLAdapter.Fill(lds_DataStore);
                    SqlConnection conn = new SqlConnection(ls_ConnectionString);
                    DataSet lds_DataStore = new DataSet();

                    SqlCommand command = new SqlCommand("IPAD_APP_LINKED_SCHOOL_USERS", conn);
                    try
                    {
                        command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@iPadUDID", as_ipad_udid));
                        command.Connection.Open();
                        System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(command);
                        SQLAdapter.Fill(lds_DataStore);
                        command.Connection.Close();
                    }
                    catch (Exception ex) { LogFileWrite(ex); }

                    if (lds_DataStore.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i <= lds_DataStore.Tables[0].Rows.Count - 1; i++)
                        {
                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["USER_LOGIN_NAME"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_USER_LOGIN_NAME = ls_dom.CreateElement("USER_LOGIN_NAME");
                            ls_Method.AppendChild(ls_USER_LOGIN_NAME);
                            XmlText ls_USER_LOGIN_NAME_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_USER_LOGIN_NAME.AppendChild(ls_USER_LOGIN_NAME_text);
                        }

                    }

                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    SQLConn.Close();

                    return ls_dom;
                }

                catch (Exception exp)
                {
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.StackTrace);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    SendMail("Exception in iPad Web Services", exp.Source + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                    SQLConn.Close();

                    return ls_dom;
                }
            }
            catch (Exception ex)
            {
                LogFileWrite(ex);
                return ls_dom;
            }
        }

        [WebMethod]
        public XmlDocument ValidateLogin(string as_user_name, string as_password, string information)
        {
            var watch = Stopwatch.StartNew();
            Log("ValidateLogin", "Starting" + as_user_name + "," + as_password + "," + information);

            LogArguments("ValidateLogin", as_user_name + ";" + as_password + ";", information);

            //Connection string to connect with database

            //string ls_ConnectionString = "";
            string ls_query, ls_update_statement;
            string ls_item_value, ls_user_sk, ls_CUST_SUBS_SK;
            string ls_item_Qty, ls_lic_Qty, ls_End_Date, ls_Subs_Name, ls_LAST_NAME, ls_FIRST_NAME, ls_ROLES;

            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "ValidateLogin");
            try
            {
                try
                {

                    //Open connection with database
                    SQLConn.Open();

                    // your code comes here
                    ls_query = "SELECT ";
                    ls_query = ls_query + "U.PASSWORD,U.USER_SK,U.IPAD_LOGGED_IN_TIMES ";
                    ls_query = ls_query + "FROM ";
                    ls_query = ls_query + "CEN_USERS U ";
                    ls_query = ls_query + "WHERE ";
                    ls_query = ls_query + "( U.USER_LOGIN_NAME = '" + as_user_name + "')";

                    //XmlElement ls_q = ls_dom.CreateElement("Query");
                    //ls_Method.AppendChild(ls_q);
                    //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query);
                    //ls_q.AppendChild(ls_Query_text);

                    DataSet lds_DataStore = new DataSet();
                    System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                    SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                    SQLAdapter.Fill(lds_DataStore);

                    if (lds_DataStore.Tables[0].Rows.Count > 0)
                    {

                        ls_user_sk = lds_DataStore.Tables[0].Rows[0]["USER_SK"].ToString();
                        ls_user_sk = EscapeXMLCharacters(ls_user_sk);
                        if ((ls_user_sk.Equals(System.DBNull.Value)) || (ls_user_sk.Length == 0)) ls_user_sk = "-";

                        ls_item_value = lds_DataStore.Tables[0].Rows[0]["PASSWORD"].ToString();
                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                        if (Encrypt(as_password).Equals(ls_item_value))
                        {

                            // your code comes here
                            //ls_query = "SELECT DISTINCT CS.CUST_SUBS_SK as CUST_SUBS_SK FROM  CEN_CUSTOMER_SUBS_USERS AS SU JOIN CEN_CUSTOMER_SUBSCRIPTIONS AS CS ON SU.CUST_SUBS_SK = CS.CUST_SUBS_SK JOIN CEN_SUBSCRIPTIONS AS S ON CS.SUBS_SK = S.SUBS_SK JOIN CEN_TRADING_PARTNER_USERS ON CEN_TRADING_PARTNER_USERS.TRAD_PART_USER_SK = SU.TRAD_PART_USER_SK JOIN CEN_USER_ROLES ON CEN_USER_ROLES.USER_ROLE_SK = CEN_TRADING_PARTNER_USERS.USER_ROLE_SK JOIN CEN_USERS AS U ON CEN_USER_ROLES.USER_SK = U.USER_SK WHERE CS.ACTIVE='Y' AND SU.ACTIVE='Y' AND S.ACTIVE='Y' AND U.USER_LOGIN_NAME='" + as_user_name + "' AND DATEDIFF(day,'" + DateTime.Today + "',CS.END_DATE) > 0";
                            //ls_query = "SELECT CSU.CUST_SUBS_SK as CUST_SUBS_SK FROM CEN_USERS AS U JOIN CEN_USER_ROLES AS UR ON UR.USER_SK=U.USER_SK JOIN CEN_TRADING_PARTNER_USERS AS TRP ON TRP.USER_ROLE_SK=UR.USER_ROLE_SK JOIN CEN_CUSTOMER_SUBS_USERS AS CSU ON CSU.TRAD_PART_USER_SK=TRP.TRAD_PART_USER_SK JOIN CEN_CUSTOMER_SUBSCRIPTIONS AS CS ON CSU.CUST_SUBS_SK=CS.CUST_SUBS_SK JOIN CEN_ROLES AS R ON UR.ROLE_SK=R.ROLE_SK WHERE U.ACTIVE='Y' AND UR.ACTIVE='Y' AND TRP.ACTIVE='Y' AND CSU.ACTIVE='Y'AND CS.ACTIVE='Y' AND U.USER_LOGIN_NAME='" + as_user_name + "' AND DATEDIFF(day,'" + DateTime.Today + "',CS.END_DATE) > 0 AND CS.STATUS NOT IN('BLOCKED','CLOSED')";
                            ls_query = "SELECT DISTINCT CSU.CUST_SUBS_SK as CUST_SUBS_SK,U.FIRST_NAME,U.LAST_NAME,CASE WHEN R.ROLE_ID='STUDENT' THEN R.ROLE_ID ELSE 'TEACHER' end AS ROLE_ID, ";
                            ls_query += " CASE WHEN CS.SUBS_NAME IS NULL THEN S.SUBS_NAME WHEN CS.SUBS_NAME='' THEN S.SUBS_NAME  ELSE CS.SUBS_NAME  end  AS SUBS_NAME, CS.QTY_LICENSES, S.QTY_ITEMS,";
                            ls_query += "convert(varchar(15),convert(DATETIME,CS.END_DATE),103)+' '+substring(convert(varchar(50),convert(DATETIME,CS.END_DATE),131),12,8)+' '+substring(convert(varchar(50),convert(DATETIME,CS.END_DATE),131),24,2) END_DATE  FROM CEN_USERS AS U JOIN CEN_USER_ROLES AS UR ON UR.USER_SK=U.USER_SK JOIN CEN_TRADING_PARTNER_USERS AS TRP ON TRP.USER_ROLE_SK=UR.USER_ROLE_SK JOIN CEN_CUSTOMER_SUBS_USERS AS CSU ON CSU.TRAD_PART_USER_SK=TRP.TRAD_PART_USER_SK JOIN CEN_CUSTOMER_SUBSCRIPTIONS AS CS ON CSU.CUST_SUBS_SK=CS.CUST_SUBS_SK JOIN CEN_SUBSCRIPTIONS AS S ON CS.SUBS_SK=S.SUBS_SK JOIN CEN_ROLES AS R ON UR.ROLE_SK=R.ROLE_SK WHERE U.ACTIVE='Y' AND UR.ACTIVE='Y' AND TRP.ACTIVE='Y' AND CSU.ACTIVE='Y'AND CS.ACTIVE='Y' AND U.USER_LOGIN_NAME='" + as_user_name + "'";
                            ls_query += " AND DATEDIFF(day,CONVERT(Datetime,'" + DateTime.Today.Month + "-" + DateTime.Today.Day + "-" + DateTime.Today.Year + "', 120),CS.END_DATE) > 0";
                            ls_query += " AND CS.STATUS NOT IN('BLOCKED','CLOSED')";

                            //XmlElement ls_q1 = ls_dom.CreateElement("Query");
                            //ls_Method.AppendChild(ls_q1);
                            //XmlText ls_Query_text1 = ls_dom.CreateTextNode(ls_query);
                            //ls_q1.AppendChild(ls_Query_text1);

                            DataSet lds_DataStore1 = new DataSet();
                            System.Data.SqlClient.SqlDataAdapter SQLAdapter1 = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                            SQLAdapter1.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                            SQLAdapter1.Fill(lds_DataStore1);

                            if (lds_DataStore1.Tables[0].Rows.Count > 0)
                            {

                                ls_FIRST_NAME = lds_DataStore1.Tables[0].Rows[0]["FIRST_NAME"].ToString();
                                ls_FIRST_NAME = EscapeXMLCharacters(ls_FIRST_NAME);
                                if ((ls_user_sk.Equals(System.DBNull.Value)) || (ls_FIRST_NAME.Length == 0)) ls_FIRST_NAME = "-";

                                ls_LAST_NAME = lds_DataStore1.Tables[0].Rows[0]["LAST_NAME"].ToString();
                                ls_LAST_NAME = EscapeXMLCharacters(ls_LAST_NAME);
                                if ((ls_user_sk.Equals(System.DBNull.Value)) || (ls_LAST_NAME.Length == 0)) ls_LAST_NAME = "-";

                                ls_ROLES = lds_DataStore1.Tables[0].Rows[0]["ROLE_ID"].ToString();
                                ls_ROLES = EscapeXMLCharacters(ls_ROLES);
                                if ((ls_user_sk.Equals(System.DBNull.Value)) || (ls_ROLES.Length == 0)) ls_ROLES = "-";


                                XmlElement ls_UserLoginName = ls_dom.CreateElement("USER_LOGIN_NAME");
                                ls_Method.AppendChild(ls_UserLoginName);
                                XmlText ls_UserLoginName_text = ls_dom.CreateTextNode(as_user_name);
                                ls_UserLoginName.AppendChild(ls_UserLoginName_text);

                                XmlElement ls_FIRST_NAME_node = ls_dom.CreateElement("FIRST_NAME");
                                //ls_Method.AppendChild(ls_End_Date_node);
                                ls_Method.AppendChild(ls_FIRST_NAME_node);
                                XmlText ls_FIRST_NAME_text = ls_dom.CreateTextNode(ls_FIRST_NAME);
                                ls_FIRST_NAME_node.AppendChild(ls_FIRST_NAME_text);

                                XmlElement ls_LAST_NAME_node = ls_dom.CreateElement("LAST_NAME");
                                //ls_Method.AppendChild(ls_End_Date_node);
                                ls_Method.AppendChild(ls_LAST_NAME_node);
                                XmlText ls_LAST_NAME_text = ls_dom.CreateTextNode(ls_LAST_NAME);
                                ls_LAST_NAME_node.AppendChild(ls_LAST_NAME_text);

                                XmlElement ls_ROLE_ID_node = ls_dom.CreateElement("ROLE_ID");
                                //ls_Method.AppendChild(ls_End_Date_node);
                                ls_Method.AppendChild(ls_ROLE_ID_node);
                                XmlText ls_ROLE_ID_text = ls_dom.CreateTextNode(ls_ROLES);
                                ls_ROLE_ID_node.AppendChild(ls_ROLE_ID_text);


                                XmlElement lsSubscription = ls_dom.CreateElement("SUBSCRIPTIONS");
                                ls_Method.AppendChild(lsSubscription);

                                foreach (DataRow drs in lds_DataStore1.Tables[0].Rows)
                                {
                                    ls_CUST_SUBS_SK = drs["CUST_SUBS_SK"].ToString();
                                    ls_CUST_SUBS_SK = EscapeXMLCharacters(ls_CUST_SUBS_SK);
                                    if ((ls_CUST_SUBS_SK.Equals(System.DBNull.Value)) || (ls_CUST_SUBS_SK.Length == 0)) ls_CUST_SUBS_SK = "-";

                                    //Code adde for EC-915
                                    ls_item_Qty = drs["QTY_ITEMS"].ToString();
                                    ls_item_Qty = EscapeXMLCharacters(ls_item_Qty);
                                    if ((ls_user_sk.Equals(System.DBNull.Value)) || (ls_item_Qty.Length == 0)) ls_user_sk = "-";

                                    ls_Subs_Name = drs["SUBS_NAME"].ToString();
                                    ls_Subs_Name = EscapeXMLCharacters(ls_Subs_Name);
                                    if ((ls_user_sk.Equals(System.DBNull.Value)) || (ls_Subs_Name.Length == 0)) ls_user_sk = "-";

                                    ls_lic_Qty = drs["QTY_LICENSES"].ToString();
                                    ls_lic_Qty = EscapeXMLCharacters(ls_lic_Qty);
                                    if ((ls_user_sk.Equals(System.DBNull.Value)) || (ls_lic_Qty.Length == 0)) ls_user_sk = "-";

                                    ls_End_Date = drs["END_DATE"].ToString();
                                    ls_End_Date = EscapeXMLCharacters(ls_End_Date);
                                    if ((ls_user_sk.Equals(System.DBNull.Value)) || (ls_End_Date.Length == 0)) ls_user_sk = "-";


                                    //Code adde for EC-915
                                    XmlElement ls_CUST_SUBS_SK_node = ls_dom.CreateElement("CUST_SUBS_SK");
                                    lsSubscription.AppendChild(ls_CUST_SUBS_SK_node);

                                    XmlElement ls_CUST_SUBS_ID_node = ls_dom.CreateElement("ID");
                                    ls_CUST_SUBS_SK_node.AppendChild(ls_CUST_SUBS_ID_node);
                                    XmlText ls_CUST_SUBS_ID_text = ls_dom.CreateTextNode(ls_CUST_SUBS_SK);
                                    ls_CUST_SUBS_ID_node.AppendChild(ls_CUST_SUBS_ID_text);

                                    XmlElement ls_item_Qty_node = ls_dom.CreateElement("QTY_ITEMS");
                                    //ls_Method.AppendChild(ls_item_Qty_node);
                                    ls_CUST_SUBS_SK_node.AppendChild(ls_item_Qty_node);
                                    XmlText ls_item_Qty_text = ls_dom.CreateTextNode(ls_item_Qty);
                                    ls_item_Qty_node.AppendChild(ls_item_Qty_text);

                                    XmlElement ls_Subs_Name_node = ls_dom.CreateElement("SUBS_NAME");
                                    //ls_Method.AppendChild(ls_Subs_Name_node);
                                    ls_CUST_SUBS_SK_node.AppendChild(ls_Subs_Name_node);
                                    XmlText ls_Subs_Name_text = ls_dom.CreateTextNode(ls_Subs_Name);
                                    ls_Subs_Name_node.AppendChild(ls_Subs_Name_text);

                                    XmlElement ls_lic_Qty_node = ls_dom.CreateElement("QTY_LICENSES");
                                    //ls_Method.AppendChild(ls_lic_Qty_node);
                                    ls_CUST_SUBS_SK_node.AppendChild(ls_lic_Qty_node);
                                    XmlText ls_lic_Qty_text = ls_dom.CreateTextNode(ls_lic_Qty);
                                    ls_lic_Qty_node.AppendChild(ls_lic_Qty_text);

                                    XmlElement ls_End_Date_node = ls_dom.CreateElement("END_DATE");
                                    //ls_Method.AppendChild(ls_End_Date_node);
                                    ls_CUST_SUBS_SK_node.AppendChild(ls_End_Date_node);
                                    XmlText ls_End_Date_text = ls_dom.CreateTextNode(ls_End_Date);
                                    ls_End_Date_node.AppendChild(ls_End_Date_text);



                                }
                                ls_item_value = lds_DataStore.Tables[0].Rows[0]["IPAD_LOGGED_IN_TIMES"].ToString();
                                ls_item_value = EscapeXMLCharacters(ls_item_value);
                                if ((ls_item_value.Equals(System.DBNull.Value))) ls_item_value = "0";

                                ls_item_value = (Convert.ToInt32(ls_item_value) + 1).ToString();

                                ls_update_statement = "UPDATE CEN_USERS SET IPAD_LOGGED_IN_TIMES = " + ls_item_value + " WHERE USER_LOGIN_NAME = '" + as_user_name + "'";

                                //XmlElement ls_us = ls_dom.CreateElement("UpdateStatement");
                                //ls_Method.AppendChild(ls_us);
                                //XmlText ls_us_text = ls_dom.CreateTextNode(ls_update_statement);
                                //ls_us.AppendChild(ls_us_text);

                                using (SQLConn)
                                {
                                    SqlCommand command = new SqlCommand(ls_update_statement, SQLConn);

                                    try
                                    {
                                        command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                                        command.ExecuteNonQuery();
                                        command.Connection.Close();
                                    }
                                    catch (Exception exp)
                                    {

                                    }

                                }

                                XmlElement ls_USER_SK_node = ls_dom.CreateElement("USER_SK");
                                ls_Method.AppendChild(ls_USER_SK_node);
                                XmlText ls_USER_SK_text = ls_dom.CreateTextNode(ls_user_sk);
                                ls_USER_SK_node.AppendChild(ls_USER_SK_text);

                                XmlElement ls_Error = ls_dom.CreateElement("Error");
                                ls_Method.AppendChild(ls_Error);
                                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                                ls_Error.AppendChild(ls_ErrorCode);
                                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                                ls_Error.AppendChild(ls_ErrorDescription);
                                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                                ls_Method.AppendChild(ls_DisplayCustomMessage);
                                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                                ls_Method.AppendChild(ls_MessageCode);
                                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                                ls_MessageCode.AppendChild(ls_MessageCode_text);

                                DeleteMyDraws(as_user_name, information);
                            }
                            else
                            {
                                XmlElement ls_Error = ls_dom.CreateElement("Error");
                                ls_Method.AppendChild(ls_Error);
                                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                                ls_Error.AppendChild(ls_ErrorCode);
                                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                                ls_Error.AppendChild(ls_ErrorDescription);
                                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                                ls_Method.AppendChild(ls_DisplayCustomMessage);
                                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                                ls_Method.AppendChild(ls_MessageCode);
                                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0011");
                                ls_MessageCode.AppendChild(ls_MessageCode_text);
                            }
                        }
                        else
                        {
                            XmlElement ls_Error = ls_dom.CreateElement("Error");
                            ls_Method.AppendChild(ls_Error);
                            XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                            ls_Error.AppendChild(ls_ErrorCode);
                            XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                            ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                            XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                            ls_Error.AppendChild(ls_ErrorDescription);
                            XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                            ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                            XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                            ls_Method.AppendChild(ls_DisplayCustomMessage);
                            XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                            ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                            XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                            ls_Method.AppendChild(ls_MessageCode);
                            XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0011");
                            ls_MessageCode.AppendChild(ls_MessageCode_text);
                        }

                    }
                    else
                    {
                        XmlElement ls_Error = ls_dom.CreateElement("Error");
                        ls_Method.AppendChild(ls_Error);
                        XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                        ls_Error.AppendChild(ls_ErrorCode);
                        XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                        ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                        XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                        ls_Error.AppendChild(ls_ErrorDescription);
                        XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                        ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                        XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                        ls_Method.AppendChild(ls_DisplayCustomMessage);
                        XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                        ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                        XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                        ls_Method.AppendChild(ls_MessageCode);
                        XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0011");
                        ls_MessageCode.AppendChild(ls_MessageCode_text);
                    }

                    SQLConn.Close();
                    watch.Stop();
                    var elapsedMs = watch.ElapsedMilliseconds;
                    Log("ValidateLogin", "Ended Successfully : " + elapsedMs.ToString());
                    return ls_dom;

                }

                catch (Exception exp)
                {
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.StackTrace);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);
                    SendMail("Exception in iPad Web Services", exp.Source + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);
                    SQLConn.Close();
                    LogFileWrite(exp);
                    watch.Stop();
                    var elapsedMs = watch.ElapsedMilliseconds;
                    Log("ValidateLogin", "Ended with Exception : " + elapsedMs.ToString());
                    return ls_dom;
                }
            }
            catch (Exception ex)
            {
                LogFileWrite(ex);
                watch.Stop();
                var elapsedMs = watch.ElapsedMilliseconds;
                Log("ValidateLogin", "Ended with Exception : " + elapsedMs.ToString());
                return ls_dom;
            }

        }



        [WebMethod]
        public XmlDocument ShowStudentPassword(string as_user_login_name, string as_teacher_email, string as_password, string information)
        {

            LogArguments("ShowStudentPassword", as_user_login_name + ";" + as_teacher_email + ";" + as_password, information);
            //Connection string to connect with database 

            //string ls_ConnectionString = "";
            string ls_query;
            string ls_item_value;

            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "ShowStudentPassword");

            try
            {

                //Open connection with database
                SQLConn.Open();

                // your code comes here 
                ls_query = "SELECT ";
                ls_query = ls_query + "U.PASSWORD,TP.TRADING_PARTNER_ACCOUNT_SK,TP.REGISTERED_BUSINESS_NAME,R.ROLE_ID ";
                ls_query = ls_query + "FROM ";
                ls_query = ls_query + "CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_TRADING_PARTNER_ACCOUNTS TP,CEN_USER_ROLES UR,CEN_ROLES R ";
                ls_query = ls_query + "WHERE ";
                ls_query = ls_query + "( TPU.TRADING_PARTNER_ACCOUNT_SK = TP.TRADING_PARTNER_ACCOUNT_SK ) AND ";
                ls_query = ls_query + "( R.ROLE_SK = UR.ROLE_SK ) AND ";
                ls_query = ls_query + "( UR.USER_SK = U.USER_SK ) AND ";
                ls_query = ls_query + "( TPU.USER_ROLE_SK = UR.USER_ROLE_SK ) AND ";
                ls_query = ls_query + "R.ROLE_ID IN ('TEACHER','SUBS ADMIN') AND ";
                ls_query = ls_query + "( U.USER_LOGIN_NAME = '" + as_teacher_email + "')";

                //XmlElement ls_q = ls_dom.CreateElement("Query");
                //ls_Method.AppendChild(ls_q);
                //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query);
                //ls_q.AppendChild(ls_Query_text);

                DataSet lds_DataStore = new DataSet();
                System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                SQLAdapter.Fill(lds_DataStore);

                if (lds_DataStore.Tables[0].Rows.Count > 0)
                {

                    ls_item_value = lds_DataStore.Tables[0].Rows[0]["ROLE_ID"].ToString();
                    ls_item_value = EscapeXMLCharacters(ls_item_value);
                    if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                    if (ls_item_value.Equals(ls_teacher) || ls_item_value.Equals(ls_subs_admin) || ls_item_value.Equals(ls_cen_admin) || ls_item_value.Equals(ls_cen_staff))
                    {

                        ls_item_value = lds_DataStore.Tables[0].Rows[0]["PASSWORD"].ToString();
                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                        if (Encrypt(as_password).Equals(ls_item_value))
                        {
                            List<string> tradPtrAccs = new List<string>();
                            foreach (DataRow row in lds_DataStore.Tables[0].Rows)
                            {
                                ls_item_value = row["TRADING_PARTNER_ACCOUNT_SK"].ToString();
                                ls_item_value = EscapeXMLCharacters(ls_item_value);
                                if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                                if (!tradPtrAccs.Contains(ls_item_value))
                                    tradPtrAccs.Add(ls_item_value);
                            }

                            //ls_query = "SELECT ";
                            //ls_query = ls_query + "U.PASSWORD,U.FIRST_NAME,U.DATE_CREATED,U.EMAIL ";
                            //ls_query = ls_query + "FROM ";
                            //ls_query = ls_query + "CEN_USERS U ";
                            //ls_query = ls_query + "WHERE ";
                            //ls_query = ls_query + "( U.USER_LOGIN_NAME = '" + as_user_login_name + "')";

                            ls_query = "SELECT ";
                            ls_query = ls_query + "U.PASSWORD,U.FIRST_NAME,U.DATE_CREATED,U.EMAIL,TP.TRADING_PARTNER_ACCOUNT_SK,TP.REGISTERED_BUSINESS_NAME,R.ROLE_ID ";
                            ls_query = ls_query + "FROM ";
                            ls_query = ls_query + "CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_TRADING_PARTNER_ACCOUNTS TP,CEN_USER_ROLES UR,CEN_ROLES R ";
                            ls_query = ls_query + "WHERE ";
                            ls_query = ls_query + "( TPU.TRADING_PARTNER_ACCOUNT_SK = TP.TRADING_PARTNER_ACCOUNT_SK ) AND ";
                            ls_query = ls_query + "( R.ROLE_SK = UR.ROLE_SK ) AND ";
                            ls_query = ls_query + "( UR.USER_SK = U.USER_SK ) AND ";
                            ls_query = ls_query + "( TPU.USER_ROLE_SK = UR.USER_ROLE_SK ) AND ";
                            ls_query = ls_query + "( U.USER_LOGIN_NAME = '" + as_user_login_name + "' )"; // AND ";
                            //ls_query = ls_query + "( TP.TRADING_PARTNER_ACCOUNT_SK = " + ls_item_value + " )";

                            //XmlElement ls_q1 = ls_dom.CreateElement("Query1");
                            //ls_Method.AppendChild(ls_q1);
                            //XmlText ls_Query1_text = ls_dom.CreateTextNode(ls_query);
                            //ls_q1.AppendChild(ls_Query1_text);

                            DataSet lds_DataStore1 = new DataSet();
                            System.Data.SqlClient.SqlDataAdapter SQLAdapter1 = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                            SQLAdapter1.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                            SQLAdapter1.Fill(lds_DataStore1);

                            if (lds_DataStore1.Tables[0].Rows.Count == 1)
                            {
                                string ls_user_trading_partner_sk = lds_DataStore1.Tables[0].Rows[0]["TRADING_PARTNER_ACCOUNT_SK"].ToString();
                                if ((ls_user_trading_partner_sk.Equals(System.DBNull.Value)) || (ls_user_trading_partner_sk.Length == 0)) ls_user_trading_partner_sk = "-";
                                if (tradPtrAccs.Contains(ls_user_trading_partner_sk))
                                // if (ls_user_trading_partner_sk.Equals(ls_item_value))
                                {
                                    try
                                    {
                                        ls_item_value = lds_DataStore1.Tables[0].Rows[0]["PASSWORD"].ToString();
                                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                                        XmlElement ls_UserLoginName = ls_dom.CreateElement("USER_LOGIN_NAME");
                                        ls_Method.AppendChild(ls_UserLoginName);
                                        XmlText ls_UserLoginName_text = ls_dom.CreateTextNode(as_user_login_name);
                                        ls_UserLoginName.AppendChild(ls_UserLoginName_text);

                                        XmlElement ls_Password = ls_dom.CreateElement("PASSWORD");
                                        ls_Method.AppendChild(ls_Password);
                                        XmlText ls_Password_text = ls_dom.CreateTextNode(Decrypt(ls_item_value));
                                        ls_Password.AppendChild(ls_Password_text);

                                        ls_item_value = lds_DataStore1.Tables[0].Rows[0]["FIRST_NAME"].ToString();
                                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                                        XmlElement ls_FirstName = ls_dom.CreateElement("FIRST_NAME");
                                        ls_Method.AppendChild(ls_FirstName);
                                        XmlText ls_FirstName_text = ls_dom.CreateTextNode(ls_item_value);
                                        ls_FirstName.AppendChild(ls_FirstName_text);

                                        ls_item_value = lds_DataStore1.Tables[0].Rows[0]["EMAIL"].ToString();
                                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                                        XmlElement ls_Email = ls_dom.CreateElement("EMAIL");
                                        ls_Method.AppendChild(ls_Email);
                                        XmlText ls_Email_text = ls_dom.CreateTextNode(ls_item_value);
                                        ls_Email.AppendChild(ls_Email_text);

                                        ls_item_value = lds_DataStore1.Tables[0].Rows[0]["DATE_CREATED"].ToString();
                                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                                        XmlElement ls_DateCreated = ls_dom.CreateElement("DATE_CREATED");
                                        ls_Method.AppendChild(ls_DateCreated);
                                        XmlText ls_DateCreated_text = ls_dom.CreateTextNode(ls_item_value);
                                        ls_DateCreated.AppendChild(ls_DateCreated_text);

                                        XmlElement ls_Error = ls_dom.CreateElement("Error");
                                        ls_Method.AppendChild(ls_Error);
                                        XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                                        ls_Error.AppendChild(ls_ErrorCode);
                                        XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                                        ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                                        XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                                        ls_Error.AppendChild(ls_ErrorDescription);
                                        XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                                        ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                                        XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                                        ls_Method.AppendChild(ls_DisplayCustomMessage);
                                        XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                                        ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                                        XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                                        ls_Method.AppendChild(ls_MessageCode);
                                        XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                                        ls_MessageCode.AppendChild(ls_MessageCode_text);

                                    }
                                    catch (Exception ex) { LogFileWrite(ex); }
                                }
                                else
                                {
                                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                                    ls_Method.AppendChild(ls_Error);
                                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                                    ls_Error.AppendChild(ls_ErrorCode);
                                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                                    ls_Error.AppendChild(ls_ErrorDescription);
                                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                                    ls_Method.AppendChild(ls_MessageCode);
                                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0021");
                                    ls_MessageCode.AppendChild(ls_MessageCode_text);
                                }
                            }
                            else
                            {
                                XmlElement ls_Error = ls_dom.CreateElement("Error");
                                ls_Method.AppendChild(ls_Error);
                                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                                ls_Error.AppendChild(ls_ErrorCode);
                                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                                ls_Error.AppendChild(ls_ErrorDescription);
                                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                                ls_Method.AppendChild(ls_DisplayCustomMessage);
                                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                                ls_Method.AppendChild(ls_MessageCode);
                                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0013");
                                ls_MessageCode.AppendChild(ls_MessageCode_text);
                            }
                        }
                        else
                        {
                            XmlElement ls_Error = ls_dom.CreateElement("Error");
                            ls_Method.AppendChild(ls_Error);
                            XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                            ls_Error.AppendChild(ls_ErrorCode);
                            XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                            ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                            XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                            ls_Error.AppendChild(ls_ErrorDescription);
                            XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                            ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                            XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                            ls_Method.AppendChild(ls_DisplayCustomMessage);
                            XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                            ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                            XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                            ls_Method.AppendChild(ls_MessageCode);
                            XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0006");
                            ls_MessageCode.AppendChild(ls_MessageCode_text);
                        }
                    }
                    else
                    {
                        XmlElement ls_Error = ls_dom.CreateElement("Error");
                        ls_Method.AppendChild(ls_Error);
                        XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                        ls_Error.AppendChild(ls_ErrorCode);
                        XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                        ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                        XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                        ls_Error.AppendChild(ls_ErrorDescription);
                        XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                        ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                        XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                        ls_Method.AppendChild(ls_DisplayCustomMessage);
                        XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                        ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                        XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                        ls_Method.AppendChild(ls_MessageCode);
                        XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0017");
                        ls_MessageCode.AppendChild(ls_MessageCode_text);
                    }
                }
                else
                {
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0006");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);
                }

                SQLConn.Close();

                return ls_dom;
            }

            catch (Exception exp)
            {
                LogFileWrite(exp);
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.StackTrace);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                ls_MessageCode.AppendChild(ls_MessageCode_text);

                SQLConn.Close();

                return ls_dom;
            }
        }

        [WebMethod]
        public XmlDocument ResetPassword(string as_teacher_email, string as_teacher_dob, string information)
        {
            LogArguments("ResetPassword", as_teacher_email + ";" + as_teacher_dob, information);
            //Connection string to connect with database 

            //string ls_ConnectionString = "";
            string ls_query;
            string ls_item_value;

            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "ResetPassword");

            string[] as_teacher_dob1 = as_teacher_dob.Split('/');

            for (int p = 0; p < as_teacher_dob1.Length; p++)
            {
                if (as_teacher_dob1[p].Length == 1)
                    as_teacher_dob1[p] = '0' + as_teacher_dob1[p];
            }

            as_teacher_dob = "";

            for (int p = 0; p < as_teacher_dob1.Length; p++)
            {
                as_teacher_dob = as_teacher_dob + as_teacher_dob1[p];
                if (p != as_teacher_dob1.Length - 1)
                    as_teacher_dob = as_teacher_dob + "/";
            }

            try
            {

                //Open connection with database
                SQLConn.Open();

                // your code comes here 
                ls_query = "SELECT ";
                ls_query = ls_query + "U.PASSWORD, U.DATE_OF_BIRTH ";
                ls_query = ls_query + "FROM ";
                ls_query = ls_query + "CEN_USERS U ";
                ls_query = ls_query + "WHERE ";
                ls_query = ls_query + "( U.USER_LOGIN_NAME = '" + as_teacher_email + "')";

                //XmlElement ls_q = ls_dom.CreateElement("Query");
                //ls_Method.AppendChild(ls_q);
                //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query);
                //ls_q.AppendChild(ls_Query_text);

                string link = string.Concat(System.Configuration.ConfigurationManager.AppSettings["webappurl"], "/forgot-password?ResetPwd=", HttpUtility.UrlEncode(Encrypt(as_teacher_email)));
                //SendMail("PM eCollection : Update your login details(old)", "Update your Cengage Learning login details by clicking <a href='" + link + "'>here</a>. Please note that the link is only active for 24 hours. After this time all requests will need to be resubmitted.", as_teacher_email, "");
                //SendMail("PM eCollection Reset Password", "Please use this URL to reset your password", as_teacher_email, "");



                DataSet lds_DataStore = new DataSet();
                System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                SQLAdapter.Fill(lds_DataStore);

                if (lds_DataStore.Tables[0].Rows.Count > 0)
                {

                    ls_item_value = lds_DataStore.Tables[0].Rows[0]["DATE_OF_BIRTH"].ToString();
                    ls_item_value = EscapeXMLCharacters(ls_item_value);
                    if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                    string ls_dob = Convert.ToDateTime(ls_item_value).ToString("dd/MM/yy");

                    if (ls_dob.Equals(as_teacher_dob))
                    {
                        //string link = string.Concat(System.Configuration.ConfigurationManager.AppSettings["webappurl"], "/forgot-password?ResetPwd=", HttpUtility.UrlEncode(Encrypt(as_teacher_email)));
                        //SendMail("PM eCollection : Update your login details(old)", "Update your Cengage Learning login details by clicking <a href='" + link + "'>here</a>. Please note that the link is only active for 24 hours. After this time all requests will need to be resubmitted.", as_teacher_email, "");
                        ////SendMail("PM eCollection Reset Password", "Please use this URL to reset your password", as_teacher_email, "");

                        //string ls_query1 = "INSERT INTO UTIL_EMAILQUEUE(TEMPLATE_NAME,FROM_ADDRESS,FROM_NAME,TO_ADDRESS,SENT_FLAG,MAIL_SUBJECT,MAIL_BODY,DATE_CREATED,USER_CREATED,ACTIVE)";
                        //ls_query1 = ls_query1 + "VALUES('ForgotPassword','noreply@pmecollection.com','noreply@pmecollection.com',@txt1,0,'PM eCollection : Update your login details','Update your Cengage Learning login details by clicking <a href='" + link + "'>here</a>. Please note that the link is only active for 24 hours. After this time all requests will need to be resubmitted.',"+DateTime.Now+",@txt1,1)";

                        //SqlParameter ls_param1 = new SqlParameter();
                        //ls_param1.ParameterName = "@txt1";
                        //ls_param1.Value = as_teacher_email;

                        ////SqlParameter ls_param2 = new SqlParameter();
                        ////ls_param2.ParameterName = "@txt2";
                        ////ls_param2.Value = "0";

                        ////SqlParameter ls_param3 = new SqlParameter();
                        ////ls_param3.ParameterName = "@txt3";
                        ////ls_param3.Value = "1";

                        //using (SqlConnection connection = new SqlConnection(ls_ConnectionString))
                        //{
                        //    SqlCommand command = new SqlCommand(ls_query1, connection);
                        //    command.Parameters.Add(ls_param1);
                        //    //command.Parameters.Add(ls_param2);
                        //    //command.Parameters.Add(ls_param3);

                        //    command.Connection.Open();
                        //    command.ExecuteNonQuery();
                        //    command.Connection.Close();

                        //}

                        XmlElement ls_Error = ls_dom.CreateElement("Error");
                        ls_Method.AppendChild(ls_Error);
                        XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                        ls_Error.AppendChild(ls_ErrorCode);
                        XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                        ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                        XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                        ls_Error.AppendChild(ls_ErrorDescription);
                        XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                        ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                        XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                        ls_Method.AppendChild(ls_DisplayCustomMessage);
                        XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                        ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                        XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                        ls_Method.AppendChild(ls_MessageCode);
                        XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                        ls_MessageCode.AppendChild(ls_MessageCode_text);


                        string ls_query1 = "INSERT INTO UTIL_EMAILQUEUE(FROM_ADDRESS,FROM_NAME,TO_ADDRESS,SENT_FLAG,MAIL_SUBJECT,MAIL_BODY,DATE_CREATED,USER_CREATED,ACTIVE)";
                        ls_query1 = ls_query1 + " VALUES('noreply@cengagelearning.com','PM eCollection Admin','" + as_teacher_email + "','0','PM eCollection : Update your login details','<html><head>      <title>Cengage Learning</title>       </head>";
                        ls_query1 = ls_query1 + " <body style=\"color: #000; font-family: Arial;\">  <table align=\"center\" width=\"700\" cellspacing=\"0\" cellpadding=\"0\" style=\"border:2px solid #4AC8F0\">  ";
                        ls_query1 = ls_query1 + "<tbody><tr>  <td> <table width=\"700\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"> <tbody><tr>              <td>    ";
                        ls_query1 = ls_query1 + "<img src=\"{HEADER_IMG}\" width=\"780\" height=\"200\">          ";
                        ls_query1 = ls_query1 + "</td>             </tr> </tbody></table>              <table align=\"center\" cellspacing=\"0\" cellpadding=\"40\" style=\"font-family: Arial;\"> ";
                        ls_query1 = ls_query1 + "  <tbody><tr>  <td> <table style=\"font-family: Arial; border-bottom:2px solid #4AC8F0;\" width=\"700\" border=\"0\" cellpadding=\"0\" align=\"center\">    ";
                        ls_query1 = ls_query1 + "       <tbody><tr> <td>          ";
                        ls_query1 = ls_query1 + "<h1>Hello Customer,</h1> </td>       </tr>     ";
                        ls_query1 = ls_query1 + "</tbody></table> <br><br>       <br><br><table style=\"font-family: Arial;\" width=\"700\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\"> ";
                        ls_query1 = ls_query1 + "<tbody><tr>         <td> <p style=\"color:#7c7c7c\"> Update your Cengage Learning login details by clicking <a href=\"" + link + "\">here</a>. Please note that the link is only active for 24 hours. After this time all requests will need to be resubmitted.  </p>   </td>     </tr>        </tbody></table> ";
                        ls_query1 = ls_query1 + "<br><table width=\"700\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\" style=\"font-family: Arial;\">  <tbody><tr>  <td>       <p style=\"color:#7c7c7c\">Regards,<br>      Cengage Learning.</p>    </td>  ";
                        ls_query1 = ls_query1 + "</tr>    </tbody></table> </td>  </tr>    </tbody></table>  </td>  </tr>    </tbody></table>  ";
                        ls_query1 = ls_query1 + "</body></html>',@txt3,'" + as_teacher_email + "','Y')";

                        SqlParameter ls_param3 = new SqlParameter();
                        ls_param3.ParameterName = "@txt3";
                        ls_param3.DbType = DbType.DateTime;
                        ls_param3.Value = DateTime.Now;

                        using (SqlConnection connection = new SqlConnection(ls_ConnectionString))
                        {
                            try
                            {
                                SqlCommand command = new SqlCommand(ls_query1, connection);
                                command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                                // command.Parameters.Add(ls_param1);
                                //command.Parameters.Add(ls_param2);
                                command.Parameters.Add(ls_param3);

                                command.Connection.Open();
                                command.ExecuteNonQuery();
                                command.Connection.Close();
                            }
                            catch (Exception e)
                            {
                                LogFileWrite(e);
                            }

                        }

                    }
                    else
                    {
                        XmlElement ls_Error = ls_dom.CreateElement("Error");
                        ls_Method.AppendChild(ls_Error);
                        XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                        ls_Error.AppendChild(ls_ErrorCode);
                        XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                        ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                        XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                        ls_Error.AppendChild(ls_ErrorDescription);
                        XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                        ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                        XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                        ls_Method.AppendChild(ls_DisplayCustomMessage);
                        XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                        ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                        XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                        ls_Method.AppendChild(ls_MessageCode);
                        XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0014");
                        ls_MessageCode.AppendChild(ls_MessageCode_text);

                    }
                }
                else
                {
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0014");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                }

                SQLConn.Close();

                return ls_dom;

            }
            catch (Exception exp)
            {
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.StackTrace);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                ls_MessageCode.AppendChild(ls_MessageCode_text);

                SQLConn.Close();

                return ls_dom;

            }

        }

        [WebMethod]
        public XmlDocument GetPromotionalSplashScreenValues(string information)
        {
            LogArguments("GetPromotionalSplashScreenValues", "", information);

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "GetPromotionalSplashScreenValues");

            XmlElement ls_PromotionalWebsiteAddress = ls_dom.CreateElement("PROMOTIONAL_WEBSITE_ADDRESS");
            ls_Method.AppendChild(ls_PromotionalWebsiteAddress);
            XmlText ls_PromotionalWebsiteAddress_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["PROMOTIONAL_WEBSITE_ADDRESS"]);
            ls_PromotionalWebsiteAddress.AppendChild(ls_PromotionalWebsiteAddress_text);

            XmlElement ls_PromotionalVideoFile = ls_dom.CreateElement("PROMOTIONAL_VIDEO_FILE");
            ls_Method.AppendChild(ls_PromotionalVideoFile);
            XmlText ls_PromotionalVideoFile_text = ls_dom.CreateTextNode(System.Configuration.ConfigurationManager.AppSettings["PROMOTIONAL_VIDEO_FILE"]);
            ls_PromotionalVideoFile.AppendChild(ls_PromotionalVideoFile_text);

            XmlElement ls_Error = ls_dom.CreateElement("Error");
            ls_Method.AppendChild(ls_Error);
            XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
            ls_Error.AppendChild(ls_ErrorCode);
            XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
            ls_ErrorCode.AppendChild(ls_ErrorCode_text);
            XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
            ls_Error.AppendChild(ls_ErrorDescription);
            XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
            ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
            XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
            ls_Method.AppendChild(ls_DisplayCustomMessage);
            XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
            ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
            XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
            ls_Method.AppendChild(ls_MessageCode);
            XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
            ls_MessageCode.AppendChild(ls_MessageCode_text);

            return ls_dom;

        }

        /* [WebMethod]
         public XmlDocument GetReadingSessionInfoForCurrentLoggedUser(string as_user_login_name, string as_demo_mode, string as_cust_subs_sk, string information)
         {
             LogArguments("GetReadingSessionInfoForCurrentLoggedUser", as_user_login_name + ";" + as_demo_mode + ";" + as_cust_subs_sk, information);
             //Connection string to connect with database 

             //string ls_ConnectionString = "";
             string ls_query, ls_query1, ls_query10;
             string ls_item_value,ls_session_sk;

             //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
             SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

             if(as_user_login_name.Equals(System.Configuration.ConfigurationManager.AppSettings["GuestUserLoginName"]))
             {
                 as_cust_subs_sk = System.Configuration.ConfigurationManager.AppSettings["GuestCustSubsSk"];
             }

             XmlDocument ls_dom = new XmlDocument();
             XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
             ls_dom.AppendChild(ls_WebResponse);
             XmlElement ls_Method = ls_dom.CreateElement("Method");
             ls_WebResponse.AppendChild(ls_Method);
             ls_Method.SetAttribute("RequestName", "GetReadingSessionInfoForCurrentLoggedUser");

             try
             {

                 //Open connection with database
                 SQLConn.Open();

                 //ls_query = "SELECT ";
                 //ls_query = ls_query + "SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ";
                 //ls_query = ls_query + "FROM ";
                 //ls_query = ls_query + "CEN_USERS U,CEN_CUSTOMER_SUBS_USERS CSU,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_SESSION_MEMBERS SM ,CEN_SESSION_HISTORY SHIS,CEN_SESSIONS SES ";
                 //ls_query = ls_query + "WHERE ";
                 //ls_query = ls_query + "CSU.TRAD_PART_USER_SK=TPU.TRAD_PART_USER_SK AND ";
                 //ls_query = ls_query + "TPU.USER_ROLE_SK=UR.USER_ROLE_SK AND ";
                 //ls_query = ls_query + "UR.USER_SK=U.USER_SK AND ";
                 //ls_query = ls_query + "CSU.CUST_SUBS_USER_SK=SM.CUST_SUBS_USER_SK AND ";
                 //ls_query = ls_query + "SM.SESSION_MEMBER_SK =SHIS.SESSION_MEMBER_SK AND ";
                 //ls_query = ls_query + "SES.SESSION_SK=SM.SESSION_SK AND ";
                 //ls_query = ls_query + "SES.CUST_SUBS_SK=CS.CUST_SUBS_SK AND ";
                 //ls_query = ls_query + "CSU.CUST_SUBS_SK=CS.CUST_SUBS_SK AND ";
                 //ls_query = ls_query + "SES.WORK_TYPE='SESS' AND ";
                 //ls_query = ls_query + "SES.ACTIVE='Y' AND ";
                 //ls_query = ls_query + "U.USER_LOGIN_NAME='" + as_user_login_name + "'";

                 //ls_query = ls_query + "UNION ";

                 //ls_query = ls_query + "SELECT ";
                 //ls_query = ls_query + "SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ";
                 //ls_query = ls_query + "FROM ";
                 //ls_query = ls_query + "CEN_USERS U,CEN_CUSTOMER_SUBS_USERS CSU,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_SESSION_members Sm ,CEN_SESSION_HISTORY SHIS,CEN_GROUP_MEMBERS GM,CEN_SESSIONS SES ";
                 //ls_query = ls_query + "WHERE ";
                 //ls_query = ls_query + "CSU.TRAD_PART_USER_SK=TPU.TRAD_PART_USER_SK AND ";
                 //ls_query = ls_query + "TPU.USER_ROLE_SK=UR.USER_ROLE_SK AND ";
                 //ls_query = ls_query + "UR.USER_SK=U.USER_SK AND ";
                 //ls_query = ls_query + "Sm.GRP_MEM_SK=GM.GRP_MEM_SK AND ";
                 //ls_query = ls_query + "GM.CUST_SUBS_USER_SK=CSU.CUST_SUBS_USER_SK AND ";
                 //ls_query = ls_query + "SM.SESSION_MEMBER_SK=SHIS.SESSION_MEMBER_SK AND ";
                 //ls_query = ls_query + "SES.SESSION_SK=SM.SESSION_SK AND SES.CUST_SUBS_SK=CS.CUST_SUBS_SK AND ";
                 //ls_query = ls_query + "CSU.CUST_SUBS_SK=CS.CUST_SUBS_SK AND ";
                 //ls_query = ls_query + "SES.WORK_TYPE='SESS' AND ";
                 //ls_query = ls_query + "SES.ACTIVE='Y' AND ";
                 //ls_query = ls_query + "U.USER_LOGIN_NAME='" + as_user_login_name + "'";

                 //ls_query = "SELECT ";
                 //ls_query = ls_query + "DISTINCT SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ";
                 //ls_query = ls_query + "FROM ";
                 //ls_query = ls_query + "CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM,CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU ";
                 //ls_query = ls_query + "WHERE ";
                 //ls_query = ls_query + "SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and ";       
                 //ls_query = ls_query + "SES.SESSION_SK=sm.SESSION_SK and ";        
                 //ls_query = ls_query + "SES.ACTIVE='Y' and ";
                 //ls_query = ls_query + "SES.WORK_TYPE='sess' and ";      
                 //ls_query = ls_query + "SM.ACTIVE = 'Y' and ";    
                 //ls_query = ls_query + "U.USER_SK=ur.USER_SK and ";        
                 //ls_query = ls_query + "UR.USER_ROLE_SK=tpu.USER_ROLE_SK and ";        
                 //ls_query = ls_query + "TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and ";
                 //ls_query = ls_query + "CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND ";       
                 //ls_query = ls_query + "CS.ACTIVE='y' and ";
                 //ls_query = ls_query + "U.USER_LOGIN_NAME='"+ as_user_login_name + "' AND ";
                 //ls_query = ls_query + "CSU.ACTIVE= 'Y' AND ";
                 //ls_query = ls_query + "SES.SESSION_STATUS = 'Active' AND ";
                 //ls_query = ls_query + "datediff(DAY,'" + DateTime.Today + "', SES.SESSION_EXPIRY_DATE ) > 0 AND ";
                 //ls_query = ls_query + "ses.CREATED_BY_CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK";
                 //ls_query = ls_query + " UNION  SELECT DISTINCT SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM,CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y' and SES.WORK_TYPE='sess' and SM.ACTIVE = 'Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND datediff(DAY,'" + DateTime.Today + "', SES.SESSION_EXPIRY_DATE ) > 0 AND sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK";

                 //ls_query = "SELECT DISTINCT SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE, SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM,CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y'and SES.WORK_TYPE='sess' and SM.ACTIVE = 'Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND datediff(DAY,'" + DateTime.Today + "', SES.SESSION_EXPIRY_DATE ) > 0 AND sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK Order By SESSION_EXPIRY_DATE DESC";

                 //ls_query = "SELECT DISTINCT TOP 1 SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ,ses.DATE_CREATED FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM,CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y'and SES.WORK_TYPE='sess' and SM.ACTIVE = 'Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND datediff(DAY, SES.SESSION_CREATED_DATE,'" + DateTime.Today + "' ) > 0 AND sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK Order By ses.DATE_CREATED DESC";

                 ls_query = "SELECT DISTINCT TOP 1 SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ,ses.DATE_CREATED FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM,CEN_USERS U, CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y'and SES.WORK_TYPE='sess' and SM.ACTIVE = 'Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND datediff(DAY,SES.SESSION_CREATED_DATE,'" + DateTime.Today + "') < 0 AND sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK Order By ses.DATE_CREATED DESC";

                 XmlElement ls_q = ls_dom.CreateElement("Query");
                 ls_Method.AppendChild(ls_q);
                 XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query);
                 ls_q.AppendChild(ls_Query_text);

                 DataSet lds_DataStore = new DataSet();
                 System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                 SQLAdapter.Fill(lds_DataStore);

                 string ls_top1_session_sk = "";

                 if (lds_DataStore.Tables[0].Rows.Count > 0)
                 {
                     ls_top1_session_sk = lds_DataStore.Tables[0].Rows[0]["SESSION_SK"].ToString();
                     if ((ls_top1_session_sk.Equals(System.DBNull.Value)) || (ls_top1_session_sk.Length == 0)) ls_top1_session_sk = "-";
                 }


                 //ls_query10 = "SELECT distinct SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ,ses.DATE_CREATED FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM,CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y'and SES.WORK_TYPE='sess' and SM.ACTIVE = 'Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND datediff(DAY, SES.SESSION_EXPIRY_DATE,'" + DateTime.Today + "' ) < 0 AND sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK ORDER BY SES.SESSION_EXPIRY_DATE";
                 ls_query10 = "SELECT distinct SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ,ses.DATE_CREATED FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM, CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y' and SES.WORK_TYPE='sess' and SM.ACTIVE = 'Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND datediff(DAY, SES.SESSION_EXPIRY_DATE,'" + DateTime.Today + "') < 0 AND sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK ORDER BY SES.SESSION_EXPIRY_DATE";
                
                 if (ls_top1_session_sk.Length > 0)
                 {
                     //ls_query10 = "SELECT distinct SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ,ses.DATE_CREATED FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM,CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y'and SES.WORK_TYPE='sess' and SM.ACTIVE = 'Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND datediff(DAY, SES.SESSION_EXPIRY_DATE,'" + DateTime.Today + "' ) < 0 AND sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK AND SES.SESSION_SK <> " + ls_top1_session_sk + " ORDER BY SES.SESSION_EXPIRY_DATE";
                     ls_query10 = "SELECT distinct SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ,ses.DATE_CREATED FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM, CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y' and SES.WORK_TYPE='sess' and SM.ACTIVE = 'Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND datediff(DAY, SES.SESSION_EXPIRY_DATE,'" + DateTime.Today + "') < 0 AND SES.SESSION_SK != " + ls_top1_session_sk  + " AND sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK ORDER BY SES.SESSION_EXPIRY_DATE";

                 }

                 XmlElement ls_q2 = ls_dom.CreateElement("Query1");
                 ls_Method.AppendChild(ls_q2);
                 XmlText ls_Query1_text = ls_dom.CreateTextNode(ls_query10);
                 ls_q2.AppendChild(ls_Query1_text);

                 DataSet lds_DataStore10 = new DataSet();
                 System.Data.SqlClient.SqlDataAdapter SQLAdapter10 = new System.Data.SqlClient.SqlDataAdapter(ls_query10, SQLConn);
                 SQLAdapter10.Fill(lds_DataStore10);

                 lds_DataStore.Merge(lds_DataStore10);

                 if (lds_DataStore.Tables[0].Rows.Count > 0)
                 {

                     XmlElement ls_Sessions = ls_dom.CreateElement("SESSIONS");
                     ls_Method.AppendChild(ls_Sessions);

                     for (int i = 0; i <= lds_DataStore.Tables[0].Rows.Count - 1; i++)
                     {

                         XmlElement ls_Session = ls_dom.CreateElement("SESSION");
                         ls_Sessions.AppendChild(ls_Session);

                         //ls_item_value = lds_DataStore.Tables[0].Rows[i]["SESS_HIST_SK"].ToString();
                         //ls_item_value = EscapeXMLCharacters(ls_item_value);
                         //if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                         //XmlElement ls_SessionHistorySk = ls_dom.CreateElement("SHIS.SESS_HIST_SK");
                         //ls_Session.AppendChild(ls_SessionHistorySk);
                         //XmlText ls_SessionHistorySk_text = ls_dom.CreateTextNode(ls_item_value);
                         //ls_SessionHistorySk.AppendChild(ls_SessionHistorySk_text);

                         ls_item_value = lds_DataStore.Tables[0].Rows[i]["SESSION_NAME"].ToString();
                         ls_item_value = EscapeXMLCharacters(ls_item_value);
                         if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                         XmlElement ls_SessionName = ls_dom.CreateElement("SESSION_NAME");
                         ls_Session.AppendChild(ls_SessionName);
                         XmlText ls_SessionName_text = ls_dom.CreateTextNode(ls_item_value);
                         ls_SessionName.AppendChild(ls_SessionName_text);

                         ls_item_value = lds_DataStore.Tables[0].Rows[i]["SESSION_CREATED_DATE"].ToString();
                         ls_item_value = EscapeXMLCharacters(ls_item_value);
                         if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                         XmlElement ls_SessionCreatedDate = ls_dom.CreateElement("SESSION_CREATED_DATE");
                         ls_Session.AppendChild(ls_SessionCreatedDate);
                         XmlText ls_SessionCreatedDate_text = ls_dom.CreateTextNode(ls_item_value);
                         ls_SessionCreatedDate.AppendChild(ls_SessionCreatedDate_text);

                         ls_item_value = lds_DataStore.Tables[0].Rows[i]["SESSION_EXPIRY_DATE"].ToString();
                         ls_item_value = EscapeXMLCharacters(ls_item_value);
                         if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                         XmlElement ls_SessionExpiryDate = ls_dom.CreateElement("SESSION_EXPIRY_DATE");
                         ls_Session.AppendChild(ls_SessionExpiryDate);
                         XmlText ls_SessionExpiryDate_text = ls_dom.CreateTextNode(ls_item_value);
                         ls_SessionExpiryDate.AppendChild(ls_SessionExpiryDate_text);

                         ls_item_value = lds_DataStore.Tables[0].Rows[i]["SESSION_NOTE"].ToString();
                         ls_item_value = EscapeXMLCharacters(ls_item_value);
                         if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                         XmlElement ls_SessionNote = ls_dom.CreateElement("SESSION_NOTE");
                         ls_Session.AppendChild(ls_SessionNote);
                         XmlText ls_SessionNote_text = ls_dom.CreateTextNode(ls_item_value);
                         ls_SessionNote.AppendChild(ls_SessionNote_text);

                         ls_item_value = lds_DataStore.Tables[0].Rows[i]["SESSION_TYPE"].ToString();
                         ls_item_value = EscapeXMLCharacters(ls_item_value);
                         if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                         XmlElement ls_SessionType = ls_dom.CreateElement("SESSION_TYPE");
                         ls_Session.AppendChild(ls_SessionType);
                         XmlText ls_SessionType_text = ls_dom.CreateTextNode(ls_item_value);
                         ls_SessionType.AppendChild(ls_SessionType_text);

                         ls_item_value = lds_DataStore.Tables[0].Rows[i]["SESSION_SK"].ToString();
                         ls_item_value = EscapeXMLCharacters(ls_item_value);
                         if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                         ls_session_sk = ls_item_value;

                         ls_query = "SELECT distinct sm.SESSION_MEMBER_SK FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM,CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND SES.SESSION_SK = " + ls_item_value + " and sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK"; //+ "' AND csu.CUST_SUBS_SK = " + as_cust_subs_sk;
                        
                         DataSet lds_DataStore2 = new DataSet();
                         System.Data.SqlClient.SqlDataAdapter SQLAdapter2 = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                         SQLAdapter2.Fill(lds_DataStore2);
                        
                         XmlElement ls_q1 = ls_dom.CreateElement("Query1");
                         ls_Method.AppendChild(ls_q1);
                         XmlText ls_Query_text1 = ls_dom.CreateTextNode(ls_query);
                         ls_q1.AppendChild(ls_Query_text1);

                         if (lds_DataStore2.Tables[0].Rows.Count > 0)
                         {
                             ls_item_value = lds_DataStore2.Tables[0].Rows[0]["SESSION_MEMBER_SK"].ToString();
                             ls_item_value = EscapeXMLCharacters(ls_item_value);
                             if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                             XmlElement ls_SESSION_MEMBER_SK = ls_dom.CreateElement("SESSION_MEMBER_SK");
                             ls_Session.AppendChild(ls_SESSION_MEMBER_SK);
                             XmlText ls_SESSION_MEMBER_SK_text = ls_dom.CreateTextNode(ls_item_value);
                             ls_SESSION_MEMBER_SK.AppendChild(ls_SESSION_MEMBER_SK_text);

                             ls_query1 = "SELECT DISTINCT ";
                             ls_query1 = ls_query1 + "PI.PRODUCT_SK,IMAGE_FILE_NAME,PRODUCT_ID,ISBN_13,SP.SESSION_PRODUCT_SK ";
                             ls_query1 = ls_query1 + "FROM ";
                             ls_query1 = ls_query1 + "CEN_PRODUCT_IMAGES PI,CEN_SESSION_PRODUCTS SP,CEN_CUSTOMER_SUBS_ITEMS CSI,CEN_PRODUCTS P ";
                             ls_query1 = ls_query1 + "WHERE ";
                             ls_query1 = ls_query1 + "SP.CUST_SUBS_ITEM_SK=CSI.CUST_SUBS_ITEM_SK AND ";
                             ls_query1 = ls_query1 + "PI.PRODUCT_SK=CSI.PRODUCT_SK AND ";
                             ls_query1 = ls_query1 + "CSI.PRODUCT_SK=P.PRODUCT_SK AND ";
                             ls_query1 = ls_query1 + "SP.ACTIVE = 'Y' AND PI.IMAGE_TYPE ='FTCOV' AND ";
                             ls_query1 = ls_query1 + "SP.SESSION_SK = " + ls_session_sk;

                             XmlElement ls_query12 = ls_dom.CreateElement("Query12");
                             ls_Method.AppendChild(ls_query12);
                             XmlText ls_Query12_text = ls_dom.CreateTextNode(ls_query1);
                             ls_query12.AppendChild(ls_Query12_text);

                             DataSet lds_DataStore1 = new DataSet();
                             System.Data.SqlClient.SqlDataAdapter SQLAdapter1 = new System.Data.SqlClient.SqlDataAdapter(ls_query1, SQLConn);
                             SQLAdapter1.Fill(lds_DataStore1);

                            if (lds_DataStore1.Tables[0].Rows.Count > 0)
                             {

                                 XmlElement ls_SessionProducts = ls_dom.CreateElement("SESSION_PRODUCTS");
                                 ls_Session.AppendChild(ls_SessionProducts);

                                 string ls_WEBSERVICEURL = System.Configuration.ConfigurationManager.AppSettings["WEBSERVICE_URL"];

                                 for (int ii = 0; ii <= lds_DataStore1.Tables[0].Rows.Count - 1; ii++)
                                 {
                                     ls_item_value = lds_DataStore1.Tables[0].Rows[ii]["IMAGE_FILE_NAME"].ToString();
                                     ls_item_value = EscapeXMLCharacters(ls_item_value);
                                     if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                                     XmlElement ls_ImageFileName = ls_dom.CreateElement("IMAGE_FILE_NAME");
                                     ls_SessionProducts.AppendChild(ls_ImageFileName);
                                     XmlText ls_FileName_text = ls_dom.CreateTextNode(ls_WEBSERVICEURL + "Thumbnails/" + ls_item_value.Substring(1));
                                     ls_ImageFileName.AppendChild(ls_FileName_text);

                                     ls_item_value = lds_DataStore1.Tables[0].Rows[ii]["ISBN_13"].ToString();
                                     ls_item_value = EscapeXMLCharacters(ls_item_value);
                                     if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                                     XmlElement ls_ISBN_13 = ls_dom.CreateElement("ISBN_13");
                                     ls_SessionProducts.AppendChild(ls_ISBN_13);
                                     XmlText ls_ISBN_13_text = ls_dom.CreateTextNode(ls_item_value);
                                     ls_ISBN_13.AppendChild(ls_ISBN_13_text);

                                     ls_item_value = lds_DataStore1.Tables[0].Rows[ii]["SESSION_PRODUCT_SK"].ToString();
                                     ls_item_value = EscapeXMLCharacters(ls_item_value);
                                     if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                                     XmlElement ls_SESSION_PRODUCT_SK = ls_dom.CreateElement("SESSION_PRODUCT_SK");
                                     ls_SessionProducts.AppendChild(ls_SESSION_PRODUCT_SK);
                                     XmlText ls_SESSION_PRODUCT_SK_text = ls_dom.CreateTextNode(ls_item_value);
                                     ls_SESSION_PRODUCT_SK.AppendChild(ls_SESSION_PRODUCT_SK_text);

                                     ls_item_value = lds_DataStore1.Tables[0].Rows[ii]["PRODUCT_SK"].ToString();
                                     ls_item_value = EscapeXMLCharacters(ls_item_value);
                                     if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                                     XmlElement ls_PRODUCT_SK = ls_dom.CreateElement("PRODUCT_SK");
                                     ls_SessionProducts.AppendChild(ls_PRODUCT_SK);
                                     XmlText ls_PRODUCT_SK_text = ls_dom.CreateTextNode(ls_item_value);
                                     ls_PRODUCT_SK.AppendChild(ls_PRODUCT_SK_text);

                                 }
                             }

                         }
                         else
                         {
                             //XmlElement ls_Error = ls_dom.CreateElement("Error");
                             //ls_Method.AppendChild(ls_Error);
                             //XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                             //ls_Error.AppendChild(ls_ErrorCode);
                             //XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                             //ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                             //XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                             //ls_Error.AppendChild(ls_ErrorDescription);
                             //XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                             //ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                             //XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                             //ls_Method.AppendChild(ls_DisplayCustomMessage);
                             //XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                             //ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                             //XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                             //ls_Method.AppendChild(ls_MessageCode);
                             //XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                             //ls_MessageCode.AppendChild(ls_MessageCode_text);
                         }
                     }

                     XmlElement ls_Error = ls_dom.CreateElement("Error");
                     ls_Method.AppendChild(ls_Error);
                     XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                     ls_Error.AppendChild(ls_ErrorCode);
                     XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                     ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                     XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                     ls_Error.AppendChild(ls_ErrorDescription);
                     XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                     ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                     XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                     ls_Method.AppendChild(ls_DisplayCustomMessage);
                     XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                     ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                     XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                     ls_Method.AppendChild(ls_MessageCode);
                     XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                     ls_MessageCode.AppendChild(ls_MessageCode_text);

                 }
                 else
                 {
                     XmlElement ls_Error = ls_dom.CreateElement("Error");
                     ls_Method.AppendChild(ls_Error);
                     XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                     ls_Error.AppendChild(ls_ErrorCode);
                     XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                     ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                     XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                     ls_Error.AppendChild(ls_ErrorDescription);
                     XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                     ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                     XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                     ls_Method.AppendChild(ls_DisplayCustomMessage);
                     XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                     ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                     XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                     ls_Method.AppendChild(ls_MessageCode);
                     XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                     ls_MessageCode.AppendChild(ls_MessageCode_text);
                 }

                 SQLConn.Close();

                 return ls_dom;
             }
             catch (Exception exp)
             {
                 XmlElement ls_Error = ls_dom.CreateElement("Error");
                 ls_Method.AppendChild(ls_Error);
                 XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                 ls_Error.AppendChild(ls_ErrorCode);
                 XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                 ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                 XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                 ls_Error.AppendChild(ls_ErrorDescription);
                 XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.StackTrace);
                 ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                 XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                 ls_Method.AppendChild(ls_DisplayCustomMessage);
                 XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                 ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                 XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                 ls_Method.AppendChild(ls_MessageCode);
                 XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                 ls_MessageCode.AppendChild(ls_MessageCode_text);

                 SQLConn.Close();

                 return ls_dom;

             }
         }
         */

        [WebMethod]
        public XmlDocument GetReadingSessionInfoForCurrentLoggedUser(string as_user_login_name, string as_demo_mode, string as_cust_subs_sk, string information)
        {
            try
            {
                LogArguments("GetReadingSessionInfoForCurrentLoggedUser", as_user_login_name + ";" + as_demo_mode + ";" + as_cust_subs_sk, information);
                //Connection string to connect with database

                //string ls_ConnectionString = "";
                string ls_query, ls_query1, ls_query10;
                string ls_item_value, ls_session_sk;

                //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
                SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

                if (as_user_login_name.Equals(System.Configuration.ConfigurationManager.AppSettings["GuestUserLoginName"]))
                {
                    as_cust_subs_sk = System.Configuration.ConfigurationManager.AppSettings["GuestCustSubsSk"];
                }

                XmlDocument ls_dom = new XmlDocument();
                XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
                ls_dom.AppendChild(ls_WebResponse);
                XmlElement ls_Method = ls_dom.CreateElement("Method");
                ls_WebResponse.AppendChild(ls_Method);
                ls_Method.SetAttribute("RequestName", "GetReadingSessionInfoForCurrentLoggedUser");

                try
                {

                    //Open connection with database
                    SQLConn.Open();

                    //ls_query = "SELECT ";
                    //ls_query = ls_query + "SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ";
                    //ls_query = ls_query + "FROM ";
                    //ls_query = ls_query + "CEN_USERS U,CEN_CUSTOMER_SUBS_USERS CSU,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_SESSION_MEMBERS SM ,CEN_SESSION_HISTORY SHIS,CEN_SESSIONS SES ";
                    //ls_query = ls_query + "WHERE ";
                    //ls_query = ls_query + "CSU.TRAD_PART_USER_SK=TPU.TRAD_PART_USER_SK AND ";
                    //ls_query = ls_query + "TPU.USER_ROLE_SK=UR.USER_ROLE_SK AND ";
                    //ls_query = ls_query + "UR.USER_SK=U.USER_SK AND ";
                    //ls_query = ls_query + "CSU.CUST_SUBS_USER_SK=SM.CUST_SUBS_USER_SK AND ";
                    //ls_query = ls_query + "SM.SESSION_MEMBER_SK =SHIS.SESSION_MEMBER_SK AND ";
                    //ls_query = ls_query + "SES.SESSION_SK=SM.SESSION_SK AND ";
                    //ls_query = ls_query + "SES.CUST_SUBS_SK=CS.CUST_SUBS_SK AND ";
                    //ls_query = ls_query + "CSU.CUST_SUBS_SK=CS.CUST_SUBS_SK AND ";
                    //ls_query = ls_query + "SES.WORK_TYPE='SESS' AND ";
                    //ls_query = ls_query + "SES.ACTIVE='Y' AND ";
                    //ls_query = ls_query + "U.USER_LOGIN_NAME='" + as_user_login_name + "'";

                    //ls_query = ls_query + "UNION ";

                    //ls_query = ls_query + "SELECT ";
                    //ls_query = ls_query + "SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ";
                    //ls_query = ls_query + "FROM ";
                    //ls_query = ls_query + "CEN_USERS U,CEN_CUSTOMER_SUBS_USERS CSU,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_SESSION_members Sm ,CEN_SESSION_HISTORY SHIS,CEN_GROUP_MEMBERS GM,CEN_SESSIONS SES ";
                    //ls_query = ls_query + "WHERE ";
                    //ls_query = ls_query + "CSU.TRAD_PART_USER_SK=TPU.TRAD_PART_USER_SK AND ";
                    //ls_query = ls_query + "TPU.USER_ROLE_SK=UR.USER_ROLE_SK AND ";
                    //ls_query = ls_query + "UR.USER_SK=U.USER_SK AND ";
                    //ls_query = ls_query + "Sm.GRP_MEM_SK=GM.GRP_MEM_SK AND ";
                    //ls_query = ls_query + "GM.CUST_SUBS_USER_SK=CSU.CUST_SUBS_USER_SK AND ";
                    //ls_query = ls_query + "SM.SESSION_MEMBER_SK=SHIS.SESSION_MEMBER_SK AND ";
                    //ls_query = ls_query + "SES.SESSION_SK=SM.SESSION_SK AND SES.CUST_SUBS_SK=CS.CUST_SUBS_SK AND ";
                    //ls_query = ls_query + "CSU.CUST_SUBS_SK=CS.CUST_SUBS_SK AND ";
                    //ls_query = ls_query + "SES.WORK_TYPE='SESS' AND ";
                    //ls_query = ls_query + "SES.ACTIVE='Y' AND ";
                    //ls_query = ls_query + "U.USER_LOGIN_NAME='" + as_user_login_name + "'";

                    //ls_query = "SELECT ";
                    //ls_query = ls_query + "DISTINCT SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ";
                    //ls_query = ls_query + "FROM ";
                    //ls_query = ls_query + "CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM,CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU ";
                    //ls_query = ls_query + "WHERE ";
                    //ls_query = ls_query + "SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and ";      
                    //ls_query = ls_query + "SES.SESSION_SK=sm.SESSION_SK and ";       
                    //ls_query = ls_query + "SES.ACTIVE='Y' and ";
                    //ls_query = ls_query + "SES.WORK_TYPE='sess' and ";     
                    //ls_query = ls_query + "SM.ACTIVE = 'Y' and ";   
                    //ls_query = ls_query + "U.USER_SK=ur.USER_SK and ";       
                    //ls_query = ls_query + "UR.USER_ROLE_SK=tpu.USER_ROLE_SK and ";       
                    //ls_query = ls_query + "TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and ";
                    //ls_query = ls_query + "CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND ";      
                    //ls_query = ls_query + "CS.ACTIVE='y' and ";
                    //ls_query = ls_query + "U.USER_LOGIN_NAME='"+ as_user_login_name + "' AND ";
                    //ls_query = ls_query + "CSU.ACTIVE= 'Y' AND ";
                    //ls_query = ls_query + "SES.SESSION_STATUS = 'Active' AND ";
                    //ls_query = ls_query + "datediff(DAY,'" + DateTime.Today + "', SES.SESSION_EXPIRY_DATE ) > 0 AND ";
                    //ls_query = ls_query + "ses.CREATED_BY_CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK";
                    //ls_query = ls_query + " UNION  SELECT DISTINCT SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM,CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y' and SES.WORK_TYPE='sess' and SM.ACTIVE = 'Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND datediff(DAY,'" + DateTime.Today + "', SES.SESSION_EXPIRY_DATE ) > 0 AND sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK";

                    //ls_query = "SELECT DISTINCT SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE, SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM,CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y'and SES.WORK_TYPE='sess' and SM.ACTIVE = 'Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND datediff(DAY,'" + DateTime.Today + "', SES.SESSION_EXPIRY_DATE ) > 0 AND sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK Order By SESSION_EXPIRY_DATE DESC";

                    //ls_query = "SELECT DISTINCT TOP 1 SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ,ses.DATE_CREATED FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM,CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y'and SES.WORK_TYPE='sess' and SM.ACTIVE = 'Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND datediff(DAY, SES.SESSION_CREATED_DATE,'" + DateTime.Today + "' ) > 0 AND sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK Order By ses.DATE_CREATED DESC";

                    ls_query = "SELECT DISTINCT TOP 1 SES.SESSION_NAME,convert(varchar(15),SES.SESSION_CREATED_DATE,103)+' '+substring(convert(varchar(50),SES.SESSION_CREATED_DATE,131),12,8)+' '+substring(convert(varchar(50),SES.SESSION_CREATED_DATE,131),24,2) SESSION_CREATED_DATE,";
                    ls_query += "convert(varchar(15),SES.SESSION_EXPIRY_DATE,103)+' '+substring(convert(varchar(50),SES.SESSION_EXPIRY_DATE,131),12,8)+' '+substring(convert(varchar(50),SES.SESSION_EXPIRY_DATE,131),24,2) SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ,";
                    ls_query += "convert(varchar(15),SES.DATE_CREATED,103)+' '+substring(convert(varchar(50),SES.DATE_CREATED,131),12,8)+' '+substring(convert(varchar(50),SES.DATE_CREATED,131),24,2) DATE_CREATED ,SES.DATE_CREATED AS DC FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM,CEN_USERS U, CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y'and SES.WORK_TYPE='sess' and SM.ACTIVE = 'Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND datediff(DAY,SES.SESSION_CREATED_DATE,'" + DateTime.Today + "') < 0 AND sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK and ses.cust_subs_sk=" + as_cust_subs_sk + " Order By DC DESC";



                    LogFileWrite(new Exception("Query 1 \r\n " + ls_query));
                    //  LogFileWrite(new Exception("Before call 1"));

                    //XmlElement ls_q = ls_dom.CreateElement("Query");
                    //ls_Method.AppendChild(ls_q);
                    //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query);
                    //ls_q.AppendChild(ls_Query_text);

                    DataSet lds_DataStore = new DataSet();
                    System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                    SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                    SQLAdapter.Fill(lds_DataStore);
                    // LogFileWrite(new Exception("After call 1--> Count=" + lds_DataStore.Tables[0].Rows.Count.ToString()));
                    string ls_top1_session_sk = "";

                    if (lds_DataStore.Tables[0].Rows.Count > 0)
                    {
                        ls_top1_session_sk = lds_DataStore.Tables[0].Rows[0]["SESSION_SK"].ToString();
                        if ((ls_top1_session_sk.Equals(System.DBNull.Value)) || (ls_top1_session_sk.Length == 0)) ls_top1_session_sk = "-";
                    }


                    //ls_query10 = "SELECT distinct SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ,ses.DATE_CREATED FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM,CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y'and SES.WORK_TYPE='sess' and SM.ACTIVE = 'Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND datediff(DAY, SES.SESSION_EXPIRY_DATE,'" + DateTime.Today + "' ) < 0 AND sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK ORDER BY SES.SESSION_EXPIRY_DATE";
                    ls_query10 = "SELECT distinct SES.SESSION_NAME,convert(varchar(15),SES.SESSION_CREATED_DATE,103)+' '+substring(convert(varchar(50),SES.SESSION_CREATED_DATE,131),12,8)+' '+substring(convert(varchar(50),SES.SESSION_CREATED_DATE,131),24,2) SESSION_CREATED_DATE,convert(varchar(15),SES.SESSION_EXPIRY_DATE,103)+' '+substring(convert(varchar(50),SES.SESSION_EXPIRY_DATE,131),12,8)+' '+substring(convert(varchar(50),SES.SESSION_EXPIRY_DATE,131),24,2) SESSION_EXPIRY_DATE,SESSION_EXPIRY_DATE as se,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ,convert(varchar(15),SES.DATE_CREATED,103)+' '+substring(convert(varchar(50),SES.DATE_CREATED,131),12,8)+' '+substring(convert(varchar(50),SES.DATE_CREATED,131),24,2) DATE_CREATED  FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM, CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y' and SES.WORK_TYPE='sess' and SM.ACTIVE = 'Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND datediff(DAY, SES.SESSION_EXPIRY_DATE,GETDATE()) < 0 AND sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK and ses.cust_subs_sk=" + as_cust_subs_sk + " ORDER BY se";
                    LogFileWrite(new Exception("Query 2 \r\n " + ls_query10));
                    //LogFileWrite(new Exception("Before call 2"));
                    if (ls_top1_session_sk.Length > 0)
                    {
                        //ls_query10 = "SELECT distinct SES.SESSION_NAME,SES.SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ,ses.DATE_CREATED FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM,CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y'and SES.WORK_TYPE='sess' and SM.ACTIVE = 'Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND datediff(DAY, SES.SESSION_EXPIRY_DATE,'" + DateTime.Today + "' ) < 0 AND sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK AND SES.SESSION_SK <> " + ls_top1_session_sk + " ORDER BY SES.SESSION_EXPIRY_DATE";
                        ls_query10 = "SELECT distinct SES.SESSION_NAME,convert(varchar(15),SES.SESSION_CREATED_DATE,103)+' '+substring(convert(varchar(50),SES.SESSION_CREATED_DATE,131),12,8)+' '+substring(convert(varchar(50),SES.SESSION_CREATED_DATE,131),24,2) SESSION_CREATED_DATE,convert(varchar(15),SES.SESSION_EXPIRY_DATE,103)+' '+substring(convert(varchar(50),SES.SESSION_EXPIRY_DATE,131),12,8)+' '+substring(convert(varchar(50),SES.SESSION_EXPIRY_DATE,131),24,2) SESSION_EXPIRY_DATE,SESSION_EXPIRY_DATE as se,SESSION_TYPE,SESSION_NOTE,SES.SESSION_SK ,convert(varchar(15),SES.DATE_CREATED,103)+' '+substring(convert(varchar(50),SES.DATE_CREATED,131),12,8)+' '+substring(convert(varchar(50),SES.DATE_CREATED,131),24,2) DATE_CREATED FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM, CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y' and SES.WORK_TYPE='sess' and SM.ACTIVE = 'Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND datediff(DAY, SES.SESSION_EXPIRY_DATE,GETDATE()) < 0 AND SES.SESSION_SK != " + ls_top1_session_sk + " AND sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK and ses.cust_subs_sk=" + as_cust_subs_sk + " ORDER BY se";
                        LogFileWrite(new Exception("Query 3 \r\n " + ls_query10));
                    }

                    //XmlElement ls_q2 = ls_dom.CreateElement("Query1");
                    //ls_Method.AppendChild(ls_q2);
                    //XmlText ls_Query1_text = ls_dom.CreateTextNode(ls_query10);
                    //ls_q2.AppendChild(ls_Query1_text);

                    DataSet lds_DataStore10 = new DataSet();
                    System.Data.SqlClient.SqlDataAdapter SQLAdapter10 = new System.Data.SqlClient.SqlDataAdapter(ls_query10, SQLConn);
                    SQLAdapter10.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                    SQLAdapter10.Fill(lds_DataStore10);
                    // LogFileWrite(new Exception("After call 2--> Count=" + lds_DataStore10.Tables[0].Rows.Count.ToString()));
                    lds_DataStore.Merge(lds_DataStore10);
                    //LogFileWrite(new Exception("After Merge"));
                    if (lds_DataStore.Tables[0].Rows.Count > 0)
                    {
                        // LogFileWrite(new Exception("HAS ROWS"));
                        XmlElement ls_Sessions = ls_dom.CreateElement("SESSIONS");
                        ls_Method.AppendChild(ls_Sessions);

                        for (int i = 0; i <= lds_DataStore.Tables[0].Rows.Count - 1; i++)
                        {

                            XmlElement ls_Session = ls_dom.CreateElement("SESSION");
                            ls_Sessions.AppendChild(ls_Session);

                            //ls_item_value = lds_DataStore.Tables[0].Rows[i]["SESS_HIST_SK"].ToString();
                            //ls_item_value = EscapeXMLCharacters(ls_item_value);
                            //if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            //XmlElement ls_SessionHistorySk = ls_dom.CreateElement("SHIS.SESS_HIST_SK");
                            //ls_Session.AppendChild(ls_SessionHistorySk);
                            //XmlText ls_SessionHistorySk_text = ls_dom.CreateTextNode(ls_item_value);
                            //ls_SessionHistorySk.AppendChild(ls_SessionHistorySk_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["SESSION_NAME"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_SessionName = ls_dom.CreateElement("SESSION_NAME");
                            ls_Session.AppendChild(ls_SessionName);
                            XmlText ls_SessionName_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_SessionName.AppendChild(ls_SessionName_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["SESSION_CREATED_DATE"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_SessionCreatedDate = ls_dom.CreateElement("SESSION_CREATED_DATE");
                            ls_Session.AppendChild(ls_SessionCreatedDate);
                            XmlText ls_SessionCreatedDate_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_SessionCreatedDate.AppendChild(ls_SessionCreatedDate_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["SESSION_EXPIRY_DATE"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_SessionExpiryDate = ls_dom.CreateElement("SESSION_EXPIRY_DATE");
                            ls_Session.AppendChild(ls_SessionExpiryDate);
                            XmlText ls_SessionExpiryDate_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_SessionExpiryDate.AppendChild(ls_SessionExpiryDate_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["SESSION_NOTE"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_SessionNote = ls_dom.CreateElement("SESSION_NOTE");
                            ls_Session.AppendChild(ls_SessionNote);
                            XmlText ls_SessionNote_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_SessionNote.AppendChild(ls_SessionNote_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["SESSION_TYPE"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_SessionType = ls_dom.CreateElement("SESSION_TYPE");
                            ls_Session.AppendChild(ls_SessionType);
                            XmlText ls_SessionType_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_SessionType.AppendChild(ls_SessionType_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["SESSION_SK"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                            ls_session_sk = ls_item_value;

                            ls_query = "SELECT distinct sm.SESSION_MEMBER_SK FROM CEN_SESSIONS SES,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_SESSION_MEMBERS SM,CEN_USERS U,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_CUSTOMER_SUBS_USERS CSU WHERE SES.CUST_SUBS_SK=cs.CUST_SUBS_SK and SES.SESSION_SK=sm.SESSION_SK and SES.ACTIVE='Y' and U.USER_SK=ur.USER_SK and UR.USER_ROLE_SK=tpu.USER_ROLE_SK and TPU.TRAD_PART_USER_SK=csu.TRAD_PART_USER_SK and CSU.CUST_SUBS_SK=cs.CUST_SUBS_SK AND CS.ACTIVE='y' and U.USER_LOGIN_NAME='" + as_user_login_name + "' AND CSU.ACTIVE= 'Y' AND SES.SESSION_STATUS = 'Active' AND SES.SESSION_SK = " + ls_item_value + " and sm.CUST_SUBS_USER_SK = csu.CUST_SUBS_USER_SK"; //+ "' AND csu.CUST_SUBS_SK = " + as_cust_subs_sk;
                            LogFileWrite(new Exception("Query 4 \r\n " + ls_query));
                            DataSet lds_DataStore2 = new DataSet();
                            System.Data.SqlClient.SqlDataAdapter SQLAdapter2 = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                            SQLAdapter2.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                            SQLAdapter2.Fill(lds_DataStore2);

                            //XmlElement ls_q1 = ls_dom.CreateElement("Query1");
                            //ls_Method.AppendChild(ls_q1);
                            //XmlText ls_Query_text1 = ls_dom.CreateTextNode(ls_query);
                            //ls_q1.AppendChild(ls_Query_text1);

                            if (lds_DataStore2.Tables[0].Rows.Count > 0)
                            {
                                ls_item_value = lds_DataStore2.Tables[0].Rows[0]["SESSION_MEMBER_SK"].ToString();
                                ls_item_value = EscapeXMLCharacters(ls_item_value);
                                if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                                XmlElement ls_SESSION_MEMBER_SK = ls_dom.CreateElement("SESSION_MEMBER_SK");
                                ls_Session.AppendChild(ls_SESSION_MEMBER_SK);
                                XmlText ls_SESSION_MEMBER_SK_text = ls_dom.CreateTextNode(ls_item_value);
                                ls_SESSION_MEMBER_SK.AppendChild(ls_SESSION_MEMBER_SK_text);

                                ls_query1 = "SELECT DISTINCT ";
                                ls_query1 = ls_query1 + "PI.PRODUCT_SK,IMAGE_FILE_NAME,PRODUCT_ID,ISBN_13,SP.SESSION_PRODUCT_SK ";
                                ls_query1 = ls_query1 + "FROM ";
                                ls_query1 = ls_query1 + "CEN_PRODUCT_IMAGES PI,CEN_SESSION_PRODUCTS SP,CEN_CUSTOMER_SUBS_ITEMS CSI,CEN_PRODUCTS P ";
                                ls_query1 = ls_query1 + "WHERE ";
                                ls_query1 = ls_query1 + "SP.CUST_SUBS_ITEM_SK=CSI.CUST_SUBS_ITEM_SK AND ";
                                ls_query1 = ls_query1 + "PI.PRODUCT_SK=CSI.PRODUCT_SK AND ";
                                ls_query1 = ls_query1 + "CSI.PRODUCT_SK=P.PRODUCT_SK AND ";
                                ls_query1 = ls_query1 + "SP.ACTIVE = 'Y' AND PI.IMAGE_TYPE ='FTCOV' AND ";
                                ls_query1 = ls_query1 + "SP.SESSION_SK = " + ls_session_sk;
                                LogFileWrite(new Exception("Query 5 \r\n " + ls_query1));
                                //XmlElement ls_query12 = ls_dom.CreateElement("Query12");
                                //ls_Method.AppendChild(ls_query12);
                                //XmlText ls_Query12_text = ls_dom.CreateTextNode(ls_query1);
                                //ls_query12.AppendChild(ls_Query12_text);

                                DataSet lds_DataStore1 = new DataSet();
                                System.Data.SqlClient.SqlDataAdapter SQLAdapter1 = new System.Data.SqlClient.SqlDataAdapter(ls_query1, SQLConn);
                                SQLAdapter1.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                                SQLAdapter1.Fill(lds_DataStore1);

                                if (lds_DataStore1.Tables[0].Rows.Count > 0)
                                {

                                    XmlElement ls_SessionProducts = ls_dom.CreateElement("SESSION_PRODUCTS");
                                    ls_Session.AppendChild(ls_SessionProducts);

                                    string ls_WEBSERVICEURL = System.Configuration.ConfigurationManager.AppSettings["WEBSERVICE_URL"];

                                    for (int ii = 0; ii <= lds_DataStore1.Tables[0].Rows.Count - 1; ii++)
                                    {
                                        ls_item_value = lds_DataStore1.Tables[0].Rows[ii]["IMAGE_FILE_NAME"].ToString();
                                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                                        XmlElement ls_ImageFileName = ls_dom.CreateElement("IMAGE_FILE_NAME");
                                        ls_SessionProducts.AppendChild(ls_ImageFileName);
                                        XmlText ls_FileName_text = ls_dom.CreateTextNode(ls_WEBSERVICEURL + "Thumbnails/" + ls_item_value.Substring(1));
                                        ls_ImageFileName.AppendChild(ls_FileName_text);

                                        ls_item_value = lds_DataStore1.Tables[0].Rows[ii]["ISBN_13"].ToString();
                                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                                        XmlElement ls_ISBN_13 = ls_dom.CreateElement("ISBN_13");
                                        ls_SessionProducts.AppendChild(ls_ISBN_13);
                                        XmlText ls_ISBN_13_text = ls_dom.CreateTextNode(ls_item_value);
                                        ls_ISBN_13.AppendChild(ls_ISBN_13_text);

                                        ls_item_value = lds_DataStore1.Tables[0].Rows[ii]["SESSION_PRODUCT_SK"].ToString();
                                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                                        XmlElement ls_SESSION_PRODUCT_SK = ls_dom.CreateElement("SESSION_PRODUCT_SK");
                                        ls_SessionProducts.AppendChild(ls_SESSION_PRODUCT_SK);
                                        XmlText ls_SESSION_PRODUCT_SK_text = ls_dom.CreateTextNode(ls_item_value);
                                        ls_SESSION_PRODUCT_SK.AppendChild(ls_SESSION_PRODUCT_SK_text);

                                        ls_item_value = lds_DataStore1.Tables[0].Rows[ii]["PRODUCT_SK"].ToString();
                                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                                        XmlElement ls_PRODUCT_SK = ls_dom.CreateElement("PRODUCT_SK");
                                        ls_SessionProducts.AppendChild(ls_PRODUCT_SK);
                                        XmlText ls_PRODUCT_SK_text = ls_dom.CreateTextNode(ls_item_value);
                                        ls_PRODUCT_SK.AppendChild(ls_PRODUCT_SK_text);

                                    }
                                }

                            }
                            else
                            {
                                //XmlElement ls_Error = ls_dom.CreateElement("Error");
                                //ls_Method.AppendChild(ls_Error);
                                //XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                                //ls_Error.AppendChild(ls_ErrorCode);
                                //XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                                //ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                                //XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                                //ls_Error.AppendChild(ls_ErrorDescription);
                                //XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                                //ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                                //XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                                //ls_Method.AppendChild(ls_DisplayCustomMessage);
                                //XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                                //ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                                //XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                                //ls_Method.AppendChild(ls_MessageCode);
                                //XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                                //ls_MessageCode.AppendChild(ls_MessageCode_text);
                            }
                        }

                        XmlElement ls_Error = ls_dom.CreateElement("Error");
                        ls_Method.AppendChild(ls_Error);
                        XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                        ls_Error.AppendChild(ls_ErrorCode);
                        XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                        ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                        XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                        ls_Error.AppendChild(ls_ErrorDescription);
                        XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                        ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                        XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                        ls_Method.AppendChild(ls_DisplayCustomMessage);
                        XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                        ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                        XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                        ls_Method.AppendChild(ls_MessageCode);
                        XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                        ls_MessageCode.AppendChild(ls_MessageCode_text);

                    }
                    else
                    {
                        //LogFileWrite(new Exception("NO ROWS"));
                        XmlElement ls_Error = ls_dom.CreateElement("Error");
                        ls_Method.AppendChild(ls_Error);
                        XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                        ls_Error.AppendChild(ls_ErrorCode);
                        XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                        ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                        XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                        ls_Error.AppendChild(ls_ErrorDescription);
                        XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                        ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                        XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                        ls_Method.AppendChild(ls_DisplayCustomMessage);
                        XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                        ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                        XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                        ls_Method.AppendChild(ls_MessageCode);
                        XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                        ls_MessageCode.AppendChild(ls_MessageCode_text);
                    }

                    SQLConn.Close();

                    return ls_dom;
                }
                catch (Exception exp)
                {
                    LogFileWrite(exp);
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.StackTrace);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    SQLConn.Close();

                    return ls_dom;

                }
            }
            catch (Exception ex) { LogFileWrite(ex); return null; }
        }

        [WebMethod]
        public XmlDocument GetMyWordsForCurrentLoggedUser(string as_user_login_name, string as_demo_mode, string information)
        {
            var watch = Stopwatch.StartNew();
            Log("GetMyWordsForCurrentLoggedUser", "Starting" + as_user_login_name + "," + as_demo_mode + "," + information);
            LogArguments("GetMyWordsForCurrentLoggedUser", as_user_login_name + ";" + as_demo_mode + ";", information);
            //Connection string to connect with database 

            //string ls_ConnectionString = "";
            string ls_query;
            string ls_item_value;
            string ls_WORD_GROUP_NAME, ls_WORD;

            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "GetMyWordsForCurrentLoggedUser ");

            try
            {

                //Open connection with database
                SQLConn.Open();

                //ls_query = "SELECT ";
                //ls_query = ls_query + "SESS_HIST_MY_WORDS_SK,WORD, BOOK_OPENED_AT,IS_CLEARED_FROM_IPAD, PRODUCT_ID,ISBN_13,WORD_AUDIO_FILE_NAME,WORD_CONTEXT_FILE_NAME ";
                //ls_query = ls_query + "FROM ";
                //ls_query = ls_query + "CEN_USERS U,CEN_CUSTOMER_SUBS_USERS CSU,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_SESSION_MEMBERS SM,CEN_SESSION_HISTORY SHIS,CEN_SESS_HIST_MY_WORDS SHW,CEN_CUSTOMER_SUBS_ITEMS CSI, CEN_SESSION_PRODUCTS SP, CEN_PRODUCTS P,CEN_IPAD_APP_WORD_AUDIO IAWA,CEN_IPAD_APP_WORD_CONTEXT_AUDIO IAWCA ";
                //ls_query = ls_query + "WHERE ";
                //ls_query = ls_query + "CSU.TRAD_PART_USER_SK=TPU.TRAD_PART_USER_SK AND ";
                //ls_query = ls_query + "TPU.USER_ROLE_SK=UR.USER_ROLE_SK AND ";
                //ls_query = ls_query + "UR.USER_SK=U.USER_SK AND ";
                //ls_query = ls_query + "CSU.CUST_SUBS_USER_SK=SM.CUST_SUBS_USER_SK AND ";
                //ls_query = ls_query + "SM.SESSION_MEMBER_SK =SHIS.SESSION_MEMBER_SK AND ";
                //ls_query = ls_query + "SHIS.SESS_HIST_SK=SHW.SESS_HIST_SK AND ";
                //ls_query = ls_query + "SP.SESSION_PRODUCT_SK = SHIS.SESSION_PRODUCT_SK AND ";
                //ls_query = ls_query + "SP.CUST_SUBS_ITEM_SK = CSI.CUST_SUBS_ITEM_SK AND ";
                //ls_query = ls_query + "p.PRODUCT_SK = csi.PRODUCT_SK AND ";
                //ls_query = ls_query + "CSU.CUST_SUBS_SK=CS.CUST_SUBS_SK AND ";
                //ls_query = ls_query + "p.PRODUCT_SK = IAWA.PRODUCT_SK AND ";
                //ls_query = ls_query + "SHW.WORD = IAWA.WORD_NAME and ";
                //ls_query = ls_query + "P.PRODUCT_SK = IAWCA.PRODUCT_SK AND ";
                //ls_query = ls_query + "WORD in (IAWCA.WORD_GROUP_NAME) AND ";
                //ls_query = ls_query + "CS.ACTIVE='Y' AND ";
                //ls_query = ls_query + "SHW.ACTIVE='Y' AND ";
                //ls_query = ls_query + "U.USER_LOGIN_NAME='SAMR'";

                //ls_query = ls_query + " UNION ";

                //ls_query = ls_query + "SELECT ";
                //ls_query = ls_query + "SESS_HIST_MY_WORDS_SK,WORD,BOOK_OPENED_AT,IS_CLEARED_FROM_IPAD,PRODUCT_ID,ISBN_13,WORD_AUDIO_FILE_NAME,WORD_CONTEXT_FILE_NAME ";
                //ls_query = ls_query + "FROM ";
                //ls_query = ls_query + "CEN_USERS U,CEN_CUSTOMER_SUBS_USERS CSU,CEN_CUSTOMER_SUBSCRIPTIONS CS,CEN_TRADING_PARTNER_USERS TPU,CEN_USER_ROLES UR,CEN_SESSION_MEMBERS SM ,CEN_SESSION_HISTORY SHIS,CEN_SESS_HIST_MY_WORDS SHW,CEN_GROUP_MEMBERS GM,CEN_SESSION_PRODUCTS SP,CEN_CUSTOMER_SUBS_ITEMS CSI,CEN_PRODUCTS P,CEN_IPAD_APP_WORD_AUDIO IAWA,CEN_IPAD_APP_WORD_CONTEXT_AUDIO IAWCA ";
                //ls_query = ls_query + "WHERE ";
                //ls_query = ls_query + "CSU.TRAD_PART_USER_SK=TPU.TRAD_PART_USER_SK AND ";
                //ls_query = ls_query + "TPU.USER_ROLE_SK=UR.USER_ROLE_SK AND ";
                //ls_query = ls_query + "UR.USER_SK=U.USER_SK AND ";
                //ls_query = ls_query + "Sm.GRP_MEM_SK=GM.GRP_MEM_SK AND ";
                //ls_query = ls_query + "GM.CUST_SUBS_USER_SK=CSU.CUST_SUBS_USER_SK AND ";
                //ls_query = ls_query + "SM.SESSION_MEMBER_SK =SHIS.SESSION_MEMBER_SK AND ";
                //ls_query = ls_query + "SHIS.SESS_HIST_SK=SHW.SESS_HIST_SK AND ";
                //ls_query = ls_query + "SP.SESSION_PRODUCT_SK = SHIS.SESSION_PRODUCT_SK AND ";
                //ls_query = ls_query + "SP.CUST_SUBS_ITEM_SK = CSI.CUST_SUBS_ITEM_SK AND ";
                //ls_query = ls_query + "p.PRODUCT_SK = csi.PRODUCT_SK AND ";
                //ls_query = ls_query + "CSU.CUST_SUBS_SK=CS.CUST_SUBS_SK AND ";
                //ls_query = ls_query + "p.PRODUCT_SK = IAWA.PRODUCT_SK AND ";
                //ls_query = ls_query + "SHW.WORD = IAWA.WORD_NAME and ";
                //ls_query = ls_query + "P.PRODUCT_SK = IAWCA.PRODUCT_SK AND ";
                //ls_query = ls_query + "WORD in (IAWCA.WORD_GROUP_NAME) AND ";
                //ls_query = ls_query + "CS.ACTIVE='Y' AND ";
                //ls_query = ls_query + "SHW.ACTIVE='Y' AND ";
                //ls_query = ls_query + "U.USER_LOGIN_NAME='SAMR'";

                //ls_query = "SELECT ";
                //ls_query = ls_query + "DISTINCT (SELECT TOP 1 SESS_HIST_MY_WORDS_SK from CEN_SESS_HIST_MY_WORDS CSHMY WHERE CSHMY.PRODUCT_SK = p.product_sk AND WORD = SHW.WORD AND USER_CREATED = '" + as_user_login_name + "' AND ACTIVE = 'Y' AND IS_CLEARED_FROM_IPAD = 'N'  ) SESS_HIST_MY_WORDS_SK,WORD,WORD_AUDIO_FILE_NAME,WORD_GROUP_NAME,WORD_CONTEXT_FILE_NAME,P.ISBN_13 ";
                //ls_query = ls_query + "FROM ";
                //ls_query = ls_query + "CEN_SESS_HIST_MY_WORDS SHW,CEN_IPAD_APP_WORD_AUDIO IAWA,CEN_IPAD_APP_WORD_CONTEXT_AUDIO IAWCA,CEN_PRODUCTS P ";
                //ls_query = ls_query + "WHERE ";
                //ls_query = ls_query + "SHW.PRODUCT_SK = P.PRODUCT_SK AND ";
                //ls_query = ls_query + "SHW.PRODUCT_SK = IAWA.PRODUCT_SK AND ";
                //ls_query = ls_query + "SHW.WORD = IAWA.WORD_NAME and ";
                //ls_query = ls_query + "SHW.PRODUCT_SK = IAWCA.PRODUCT_SK AND ";
                //ls_query = ls_query + "IAWCA.WORD_GROUP_NAME LIKE '%'+ SHW.WORD  +'%' AND ";
                //ls_query = ls_query + "SHW.ACTIVE='Y' AND ";
                //ls_query = ls_query + "SHW.IS_CLEARED_FROM_IPAD = 'N' AND ";
                //ls_query = ls_query + "SHW.USER_CREATED ='" + as_user_login_name + "' Order By Word";

                ls_query = "SELECT ";
                ls_query = ls_query + "DISTINCT (SELECT TOP 1 SESS_HIST_MY_WORDS_SK from CEN_SESS_HIST_MY_WORDS CSHMY WHERE CSHMY.PRODUCT_SK = p.product_sk AND WORD = SHW.WORD AND USER_CREATED = '" + as_user_login_name + "' AND ACTIVE = 'Y' AND IS_CLEARED_FROM_IPAD = 'N'  ) SESS_HIST_MY_WORDS_SK,WORD,WORD_AUDIO_FILE_NAME,WORD_GROUP_NAME,WORD_CONTEXT_FILE_NAME,P.ISBN_13 ";
                ls_query = ls_query + "FROM ";
                ls_query = ls_query + "CEN_SESS_HIST_MY_WORDS SHW,CEN_IPAD_APP_WORD_AUDIO IAWA,CEN_IPAD_APP_WORD_CONTEXT_AUDIO IAWCA,CEN_PRODUCTS P ";
                ls_query = ls_query + "WHERE ";
                ls_query = ls_query + "SHW.ISBN_13 = P.ISBN_13 AND ";
                ls_query = ls_query + "SHW.ISBN_13 = IAWA.ISBN_13 AND ";
                ls_query = ls_query + "SHW.WORD = IAWA.WORD_NAME and ";
                ls_query = ls_query + "SHW.ISBN_13 = IAWCA.ISBN_13 AND ";
                ls_query = ls_query + "IAWCA.WORD_GROUP_NAME LIKE '%'+ SHW.WORD  +'%' AND ";
                ls_query = ls_query + "SHW.ACTIVE='Y' AND ";
                ls_query = ls_query + "SHW.IS_CLEARED_FROM_IPAD = 'N' AND ";
                ls_query = ls_query + "SHW.USER_CREATED ='" + as_user_login_name + "' Order By Word";

                //XmlElement ls_q = ls_dom.CreateElement("Query");
                //ls_Method.AppendChild(ls_q);
                //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query);
                //ls_q.AppendChild(ls_Query_text);

                DataSet lds_DataStore = new DataSet();
                System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                SQLAdapter.Fill(lds_DataStore);

                if (lds_DataStore.Tables[0].Rows.Count > 0)
                {
                    XmlElement ls_Words = ls_dom.CreateElement("WORDS");
                    ls_Method.AppendChild(ls_Words);

                    for (int i = 0; i < lds_DataStore.Tables[0].Rows.Count; i++)
                    {

                        ls_WORD_GROUP_NAME = lds_DataStore.Tables[0].Rows[i]["WORD_GROUP_NAME"].ToString();
                        ls_WORD = lds_DataStore.Tables[0].Rows[i]["WORD"].ToString();

                        Boolean lb_match = false;
                        string[] ls_context_words;
                        ls_context_words = ls_WORD_GROUP_NAME.Split(',');

                        for (int z = 0; z < ls_context_words.Length; z++)
                        {
                            if (ls_context_words[z].Trim().ToLower().Equals(ls_WORD.ToLower()))
                            {
                                lb_match = true;
                                break;
                            }
                        }

                        if (lb_match)
                        {
                            XmlElement ls_WordH = ls_dom.CreateElement("WORD");
                            ls_Words.AppendChild(ls_WordH);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["SESS_HIST_MY_WORDS_SK"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_SESS_HIST_MY_WORDS_SK = ls_dom.CreateElement("SESS_HIST_MY_WORDS_SK");
                            ls_WordH.AppendChild(ls_SESS_HIST_MY_WORDS_SK);
                            XmlText ls_SESS_HIST_MY_WORDS_SK_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_SESS_HIST_MY_WORDS_SK.AppendChild(ls_SESS_HIST_MY_WORDS_SK_text);

                            XmlElement ls_Word = ls_dom.CreateElement("WORD");
                            ls_WordH.AppendChild(ls_Word);
                            XmlText ls_Word_text = ls_dom.CreateTextNode(ls_WORD.ToLower());
                            ls_Word.AppendChild(ls_Word_text);

                            string ls_WEBSERVICEURL = System.Configuration.ConfigurationManager.AppSettings["WEBSERVICE_URL"];

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["WORD_AUDIO_FILE_NAME"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            string ls_item_value1 = lds_DataStore.Tables[0].Rows[i]["ISBN_13"].ToString();
                            ls_item_value1 = EscapeXMLCharacters(ls_item_value1);
                            if ((ls_item_value1.Equals(System.DBNull.Value)) || (ls_item_value1.Length == 0)) ls_item_value1 = "-";
                            XmlElement ls_WordAudioFilePath = ls_dom.CreateElement("WORD_AUDIO_FILE_PATH");
                            ls_WordH.AppendChild(ls_WordAudioFilePath);
                            XmlText ls_WordAudioFilePath_text = ls_dom.CreateTextNode(ls_WEBSERVICEURL + ls_item_value1 + "/OEBPS/audio/word/" + ls_item_value);
                            ls_WordAudioFilePath.AppendChild(ls_WordAudioFilePath_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["WORD_CONTEXT_FILE_NAME"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_SentenceAudioFilePath = ls_dom.CreateElement("CONTEXT_AUDIO_FILE_PATH");
                            ls_WordH.AppendChild(ls_SentenceAudioFilePath);
                            XmlText ls_SentenceAudioFilePath_text = ls_dom.CreateTextNode(ls_WEBSERVICEURL + ls_item_value1 + "/OEBPS/audio/context/" + ls_item_value);
                            ls_SentenceAudioFilePath.AppendChild(ls_SentenceAudioFilePath_text);
                        }
                    }

                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                }
                else
                {
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                }

                SQLConn.Close();
                watch.Stop();
                var elapsedMs = watch.ElapsedMilliseconds;
                Log("GetMyWordsForCurrentLoggedUser", "Ended Successfully : " + elapsedMs.ToString());

                return ls_dom;

            }
            catch (Exception exp)
            {
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                ls_MessageCode.AppendChild(ls_MessageCode_text);

                SQLConn.Close();

                return ls_dom;

            }

        }

        String[] sizeArry = new String[] { "Byes", "KB", "MB", "GB" };
        String Get_Size_in_KB_MB_GB(ulong sizebytes, int index)
        {

            if (sizebytes < 1000) return sizebytes + sizeArry[index];

            else return Get_Size_in_KB_MB_GB(sizebytes / 1024, ++index);

        }



        static double DirectorySize(DirectoryInfo dInfo, bool includeSubDir)
        {

            // Enumerate all the files
            long totalSize = dInfo.GetFiles("*", SearchOption.AllDirectories).Sum(file => file.Length);

            // //If Subdirectories are to be included
            //if (includeSubDir)
            //{
            //    // Enumerate all sub-directories
            //    totalSize += dInfo.GetFiles()
            //             .Sum(dir => DirectorySize(dir, true));
            //}
            return (totalSize / 1024f) / 1024f;
        }

        /* [WebMethod]
         public XmlDocument GetBookShelfInfo(string as_user_login_name, string as_demo_mode, string information)//(string as_user_login_name,string as_cust_subs_sk,string as_demo_mode)
         {
             LogArguments("GetBookShelfInfo", as_user_login_name + ";" + as_demo_mode + ";",information);

             //Connection string to connect with database 

             //string ls_ConnectionString = "";
             string ls_query = "";
             string ls_item_value;
             string ls_product_id;
             string ls_PHYSICAL_FILE_PATH = System.Configuration.ConfigurationManager.AppSettings["PHYSICAL_FILE_PATH"];
             //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
             SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

             XmlDocument ls_dom = new XmlDocument();
             XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
             ls_dom.AppendChild(ls_WebResponse);
             XmlElement ls_Method = ls_dom.CreateElement("Method");
             ls_WebResponse.AppendChild(ls_Method);
             ls_Method.SetAttribute("RequestName", "GetBookShelfInfo");

             try
             {

                 //Open connection with database
                 SQLConn.Open();

                 //ls_query = "SELECT DISTINCT ";
                 //ls_query = ls_query + "p.PRODUCT_ID,p.TITLE,atv.ATTRIBUTE_TYPE_VALUE,at.ATTRIBUTE_TYPE_ID,pim.IMAGE_FILE_NAME,p.ISBN_13,p.PRODUCT_SK ";
                 //ls_query = ls_query + "FROM ";
                 //ls_query = ls_query + "CEN_USERS u,CEN_USER_ROLES ur,CEN_TRADING_PARTNER_USERS tpu,CEN_CUSTOMER_SUBS_USERS csu,CEN_CUSTOMER_SUBSCRIPTIONS cs,CEN_CUSTOMER_SUBS_ITEMS csi,CEN_PRODUCTS p,CEN_PRODUCT_ATTRIBUTE_TYPE_DETAILS patd,CEN_ATTRIBUTE_TYPE_values atv,CEN_ATTRIBUTE_TYPES at,CEN_PRODUCT_IMAGES pim ";
                 //ls_query = ls_query + "WHERE ";
                 //ls_query = ls_query + "u.USER_SK = ur.USER_SK AND ";
                 //ls_query = ls_query + "ur.USER_ROLE_SK = tpu.USER_ROLE_SK AND ";
                 //ls_query = ls_query + "tpu.TRAD_PART_USER_SK = csu.TRAD_PART_USER_SK AND ";
                 //ls_query = ls_query + "csu.CUST_SUBS_SK = cs.CUST_SUBS_SK AND ";
                 //ls_query = ls_query + "csi.ACTIVE ='Y' AND ";
                 //ls_query = ls_query + "csu.ACTIVE = 'y' AND ";
                 //ls_query = ls_query + "csi.CUST_SUBS_SK = cs.CUST_SUBS_SK AND ";
                 //ls_query = ls_query + "csi.PRODUCT_SK = p.PRODUCT_SK AND ";
                 //ls_query = ls_query + "p.PRODUCT_SK = patd.PRODUCT_SK AND ";
                 //ls_query = ls_query + "patd.ATTRIBUTE_TYPE_value_SK = atv.ATTRIBUTE_TYPE_value_SK AND ";
                 //ls_query = ls_query + "atv.ATTRIBUTE_TYPE_SK = at.ATTRIBUTE_TYPE_SK AND ";
                 //ls_query = ls_query + "p.PRODUCT_SK = pim.PRODUCT_SK AND ";
                 //ls_query = ls_query + "pim.IMAGE_TYPE = 'FTCOV' AND ";
                 //ls_query = ls_query + "at.ATTRIBUTE_TYPE_ID in ('GUIDED READING LEVEL','COLOUR') AND ";
                 //ls_query = ls_query + "p.ACTIVE ='Y' AND MEDIA_TYPE_SK = 59 AND ";
                 //ls_query = ls_query + "u.USER_LOGIN_NAME='" + as_user_login_name + "' ";
                 //ls_query = ls_query + "ORDER BY ATTRIBUTE_TYPE_ID ASC, ATTRIBUTE_TYPE_VALUE DESC,PRODUCT_ID DESC";

                 //ls_query = "SELECT DISTINCT p.PRODUCT_ID,p.TITLE,atv.ATTRIBUTE_TYPE_VALUE,at.ATTRIBUTE_TYPE_ID,pim.IMAGE_FILE_NAME,p.ISBN_13,p.PRODUCT_SK FROM CEN_USERS u,CEN_USER_ROLES ur,CEN_TRADING_PARTNER_USERS tpu,CEN_CUSTOMER_SUBS_USERS csu,CEN_CUSTOMER_SUBSCRIPTIONS cs,CEN_CUSTOMER_SUBS_ITEMS csi,CEN_PRODUCTS p,CEN_PRODUCT_ATTRIBUTE_TYPE_DETAILS patd,CEN_ATTRIBUTE_TYPE_values atv,CEN_ATTRIBUTE_TYPES at,CEN_PRODUCT_IMAGES pim,CEN_STUDENT_DETAILS sd1 WHERE u.USER_SK = ur.USER_SK AND ur.USER_ROLE_SK = tpu.USER_ROLE_SK AND tpu.TRAD_PART_USER_SK = csu.TRAD_PART_USER_SK AND csu.CUST_SUBS_SK = cs.CUST_SUBS_SK AND csi.ACTIVE ='Y' AND csu.ACTIVE = 'y' AND csi.CUST_SUBS_SK = cs.CUST_SUBS_SK AND csi.PRODUCT_SK = p.PRODUCT_SK AND p.PRODUCT_SK = patd.PRODUCT_SK AND patd.ATTRIBUTE_TYPE_value_SK = atv.ATTRIBUTE_TYPE_value_SK AND atv.ATTRIBUTE_TYPE_SK = at.ATTRIBUTE_TYPE_SK AND ATV.ATTRIBUTE_TYPE_SK=11 AND p.PRODUCT_SK = pim.PRODUCT_SK AND pim.IMAGE_TYPE = 'FTCOV' AND p.ACTIVE ='Y' AND MEDIA_TYPE_SK = 59 AND u.USER_LOGIN_NAME='" + as_user_login_name + "' AND u.user_SK = sd1.user_sk AND CONVERT(Int,RTRIM(SUBSTRING(ATV.ATTRIBUTE_TYPE_VALUE,CHARINDEX(' ',ATV.ATTRIBUTE_TYPE_VALUE,1) +1,2))) between sd1.STARTING_BOOK_READ_LEVEL_FROM and sd1.STARTING_BOOK_READ_LEVEL_UPTO ";   
                 //ls_query = ls_query + " UNION ";
                 //ls_query = ls_query + "SELECT DISTINCT p.PRODUCT_ID,p.TITLE,atv.ATTRIBUTE_TYPE_VALUE,at.ATTRIBUTE_TYPE_ID,pim.IMAGE_FILE_NAME,p.ISBN_13,p.PRODUCT_SK FROM CEN_USERS u,CEN_USER_ROLES ur,CEN_TRADING_PARTNER_USERS tpu,CEN_CUSTOMER_SUBS_USERS csu,CEN_CUSTOMER_SUBSCRIPTIONS cs,CEN_CUSTOMER_SUBS_ITEMS csi,CEN_PRODUCTS p,CEN_PRODUCT_ATTRIBUTE_TYPE_DETAILS patd,CEN_ATTRIBUTE_TYPE_values atv,CEN_ATTRIBUTE_TYPES at,CEN_PRODUCT_IMAGES pim,CEN_TEACHER_DETAILS sd1 WHERE u.USER_SK = ur.USER_SK AND ur.USER_ROLE_SK = tpu.USER_ROLE_SK AND tpu.TRAD_PART_USER_SK = csu.TRAD_PART_USER_SK AND csu.CUST_SUBS_SK = cs.CUST_SUBS_SK AND csi.ACTIVE ='Y' AND csu.ACTIVE = 'y' AND csi.CUST_SUBS_SK = cs.CUST_SUBS_SK AND csi.PRODUCT_SK = p.PRODUCT_SK AND p.PRODUCT_SK = patd.PRODUCT_SK AND patd.ATTRIBUTE_TYPE_value_SK = atv.ATTRIBUTE_TYPE_value_SK AND atv.ATTRIBUTE_TYPE_SK = at.ATTRIBUTE_TYPE_SK AND ATV.ATTRIBUTE_TYPE_SK=11 AND p.PRODUCT_SK = pim.PRODUCT_SK AND pim.IMAGE_TYPE = 'FTCOV' AND p.ACTIVE ='Y' AND MEDIA_TYPE_SK = 59 AND u.USER_LOGIN_NAME='" + as_user_login_name + "' AND u.user_SK = sd1.user_sk AND CONVERT(Int,RTRIM(SUBSTRING(ATV.ATTRIBUTE_TYPE_VALUE,CHARINDEX(' ',ATV.ATTRIBUTE_TYPE_VALUE,1) +1,2))) between sd1.BOOK_LEVEL_AVAILABLE_FROM and sd1.BOOK_LEVEL_AVAILABLE_UPTO  "; //ATTRIBUTE_TYPE_ID ASC, ATTRIBUTE_TYPE_VALUE DESC,PRODUCT_ID DESC";

                 //ls_query = ls_query + "SELECT DISTINCT p.PRODUCT_ID,p.TITLE,atv.ATTRIBUTE_TYPE_VALUE,at.ATTRIBUTE_TYPE_ID,pim.IMAGE_FILE_NAME,p.ISBN_13,p.PRODUCT_SK FROM CEN_USERS u,CEN_USER_ROLES ur,CEN_TRADING_PARTNER_USERS tpu,CEN_CUSTOMER_SUBS_USERS csu,CEN_CUSTOMER_SUBSCRIPTIONS cs,CEN_CUSTOMER_SUBS_ITEMS csi,CEN_PRODUCTS p,CEN_PRODUCT_ATTRIBUTE_TYPE_DETAILS patd,CEN_ATTRIBUTE_TYPE_values atv,CEN_ATTRIBUTE_TYPES at,CEN_PRODUCT_IMAGES pim,CEN_STUDENT_DETAILS sd1 WHERE u.USER_SK = ur.USER_SK AND ur.USER_ROLE_SK = tpu.USER_ROLE_SK AND tpu.TRAD_PART_USER_SK = csu.TRAD_PART_USER_SK AND csu.CUST_SUBS_SK = cs.CUST_SUBS_SK AND csi.ACTIVE ='Y' AND csu.ACTIVE = 'y' AND csi.CUST_SUBS_SK = cs.CUST_SUBS_SK AND csi.PRODUCT_SK = p.PRODUCT_SK AND p.PRODUCT_SK = patd.PRODUCT_SK AND patd.ATTRIBUTE_TYPE_value_SK = atv.ATTRIBUTE_TYPE_value_SK AND atv.ATTRIBUTE_TYPE_SK = at.ATTRIBUTE_TYPE_SK AND ATV.ATTRIBUTE_TYPE_SK= " + ATTRIBUTE_TYPE_SK + " AND p.PRODUCT_SK = pim.PRODUCT_SK AND pim.IMAGE_TYPE = 'FTCOV' AND p.ACTIVE ='Y' AND MEDIA_TYPE_SK = " + MEDIA_TYPE_SK + " AND u.USER_LOGIN_NAME='"+ as_user_login_name + "' AND u.user_SK = sd1.user_sk AND CONVERT(Int,RTRIM(SUBSTRING(ATV.ATTRIBUTE_TYPE_VALUE,CHARINDEX(' ',ATV.ATTRIBUTE_TYPE_VALUE,1) +1,2))) between sd1.CURRENT_BOOK_READ_LEVEL_FROM and sd1.CURRENT_BOOK_READ_LEVEL_UPTO ";
                 //ls_query = ls_query + "UNION ";
                 //ls_query = ls_query + "SELECT DISTINCT p.PRODUCT_ID,p.TITLE,atv.ATTRIBUTE_TYPE_VALUE,at.ATTRIBUTE_TYPE_ID,pim.IMAGE_FILE_NAME,p.ISBN_13,p.PRODUCT_SK FROM CEN_USERS u,CEN_USER_ROLES ur,CEN_TRADING_PARTNER_USERS tpu,CEN_CUSTOMER_SUBS_USERS csu,CEN_CUSTOMER_SUBSCRIPTIONS cs,CEN_CUSTOMER_SUBS_ITEMS csi,CEN_PRODUCTS p,CEN_PRODUCT_ATTRIBUTE_TYPE_DETAILS patd,CEN_ATTRIBUTE_TYPE_values atv,CEN_ATTRIBUTE_TYPES at,CEN_PRODUCT_IMAGES pim,CEN_TEACHER_DETAILS sd1 WHERE u.USER_SK = ur.USER_SK AND ur.USER_ROLE_SK = tpu.USER_ROLE_SK AND tpu.TRAD_PART_USER_SK = csu.TRAD_PART_USER_SK AND csu.CUST_SUBS_SK = cs.CUST_SUBS_SK AND csi.ACTIVE ='Y' AND csu.ACTIVE = 'y' AND csi.CUST_SUBS_SK = cs.CUST_SUBS_SK AND csi.PRODUCT_SK = p.PRODUCT_SK AND p.PRODUCT_SK = patd.PRODUCT_SK AND patd.ATTRIBUTE_TYPE_value_SK = atv.ATTRIBUTE_TYPE_value_SK AND atv.ATTRIBUTE_TYPE_SK = at.ATTRIBUTE_TYPE_SK AND ATV.ATTRIBUTE_TYPE_SK= " + ATTRIBUTE_TYPE_SK + " AND p.PRODUCT_SK = pim.PRODUCT_SK AND pim.IMAGE_TYPE = 'FTCOV' AND p.ACTIVE ='Y' AND MEDIA_TYPE_SK = " + MEDIA_TYPE_SK + " AND u.USER_LOGIN_NAME='" + as_user_login_name + "' AND u.user_SK = sd1.user_sk AND CONVERT(Int,RTRIM(SUBSTRING(ATV.ATTRIBUTE_TYPE_VALUE,CHARINDEX(' ',ATV.ATTRIBUTE_TYPE_VALUE,1) +1,2))) between sd1.BOOK_LEVEL_AVAILABLE_FROM and sd1.BOOK_LEVEL_AVAILABLE_UPTO ORDER BY ATTRIBUTE_TYPE_VALUE ASC"; //ATTRIBUTE_TYPE_VALUE DESC,PRODUCT_ID DESC";


                 ls_query = ls_query + "SELECT PRODUCT_SK,(SELECT * FROM  eComm_Authors_Select(PRODUCT_SK)) AUTHOR_NAME ";
 ls_query = ls_query + "INTO #tmp FROM CEN_PRODUCTS AS P JOIN CEN_MEDIA_TYPES AS MT ";
 ls_query = ls_query + "ON P.MEDIA_TYPE_SK=MT.MEDIA_TYPE_SK ";
 ls_query = ls_query + "WHERE MT.MEDIA_TYPE='ECO' AND P.ACTIVE='Y';  SELECT DISTINCT p.PRODUCT_ID,p.TITLE,atv.ATTRIBUTE_TYPE_VALUE,at.ATTRIBUTE_TYPE_ID,pim.IMAGE_FILE_NAME,";
                 ls_query = ls_query + "p.ISBN_13,p.PRODUCT_SK,T.AUTHOR_NAME ";
                 ls_query = ls_query + "FROM CEN_USERS u,";
                 ls_query = ls_query + "CEN_USER_ROLES ur, CEN_TRADING_PARTNER_USERS tpu,";
                 ls_query = ls_query + "CEN_CUSTOMER_SUBS_USERS csu, CEN_CUSTOMER_SUBSCRIPTIONS cs,";
                 ls_query = ls_query + "CEN_CUSTOMER_SUBS_ITEMS csi, CEN_PRODUCTS p,";
                 ls_query = ls_query + "CEN_PRODUCT_ATTRIBUTE_TYPE_DETAILS patd, CEN_ATTRIBUTE_TYPE_values atv,";
                 ls_query = ls_query + "CEN_ATTRIBUTE_TYPES at, CEN_PRODUCT_IMAGES pim, CEN_STUDENT_DETAILS sd1,";
                 ls_query = ls_query + "CEN_MEDIA_TYPES MT,#tmp AS T ";
                 ls_query = ls_query + "WHERE u.USER_SK = ur.USER_SK  AND ur.USER_ROLE_SK = tpu.USER_ROLE_SK ";
                 ls_query = ls_query + "AND tpu.TRAD_PART_USER_SK = csu.TRAD_PART_USER_SK ";
                 ls_query = ls_query + "AND csu.CUST_SUBS_SK = cs.CUST_SUBS_SK  AND csi.ACTIVE ='Y'  AND csu.ACTIVE = 'y' ";
                 ls_query = ls_query + "AND csi.CUST_SUBS_SK = cs.CUST_SUBS_SK  AND csi.PRODUCT_SK = p.PRODUCT_SK ";
                 ls_query = ls_query + "AND p.MEDIA_TYPE_SK=mt.MEDIA_TYPE_SK ";
                 ls_query = ls_query + "AND p.PRODUCT_SK = patd.PRODUCT_SK  AND patd.ATTRIBUTE_TYPE_value_SK = atv.ATTRIBUTE_TYPE_value_SK ";
                 ls_query = ls_query + "AND atv.ATTRIBUTE_TYPE_SK = at.ATTRIBUTE_TYPE_SK ";
                 ls_query = ls_query + "AND AT.ATTRIBUTE_TYPE_ID='GUIDED READING LEVEL' ";
                 ls_query = ls_query + "AND p.PRODUCT_SK = pim.PRODUCT_SK  AND pim.IMAGE_TYPE = 'FTCOV' AND T.PRODUCT_SK=P.PRODUCT_SK ";
                 ls_query = ls_query + "AND p.ACTIVE ='Y'  AND MT.MEDIA_TYPE = 'ECO' AND CSi.CUST_SUBS_SK in (" + GetAllUserSubscriptions(as_user_login_name) +") ";
                 ls_query = ls_query + " AND u.USER_LOGIN_NAME='" + as_user_login_name + "'  AND u.user_SK = sd1.user_sk AND  ISNUMERIC(ATV.ATTRIBUTE_TYPE_VALUE)=1 ";  
                 ls_query = ls_query + "AND CONVERT(float,RTRIM(SUBSTRING(ATV.ATTRIBUTE_TYPE_VALUE,CHARINDEX(' ',ATV.ATTRIBUTE_TYPE_VALUE,1) +1,2))) ";
                 ls_query = ls_query + "between sd1.CURRENT_BOOK_READ_LEVEL_FROM and sd1.CURRENT_BOOK_READ_LEVEL_UPTO ";
                 ls_query = ls_query + "UNION ";
                 ls_query = ls_query + "SELECT DISTINCT  p.PRODUCT_ID, p.TITLE, atv.ATTRIBUTE_TYPE_VALUE, at.ATTRIBUTE_TYPE_ID, pim.IMAGE_FILE_NAME,p.ISBN_13, p.PRODUCT_SK,T.AUTHOR_NAME "; 
                 ls_query = ls_query + "FROM CEN_USERS u, CEN_USER_ROLES ur,";
                 ls_query = ls_query + "CEN_TRADING_PARTNER_USERS tpu, CEN_CUSTOMER_SUBS_USERS csu,";
                 ls_query = ls_query + "CEN_CUSTOMER_SUBSCRIPTIONS cs, CEN_CUSTOMER_SUBS_ITEMS csi,";
                 ls_query = ls_query + "CEN_PRODUCTS p, CEN_PRODUCT_ATTRIBUTE_TYPE_DETAILS patd,";
                 ls_query = ls_query + "CEN_ATTRIBUTE_TYPE_values atv, CEN_ATTRIBUTE_TYPES at,";
                 ls_query = ls_query + "CEN_PRODUCT_IMAGES pim, CEN_TEACHER_DETAILS sd1,CEN_MEDIA_TYPES MT,#tmp AS T ";
                 ls_query = ls_query + "WHERE u.USER_SK = ur.USER_SK  AND ur.USER_ROLE_SK = tpu.USER_ROLE_SK ";
                 ls_query = ls_query + "AND tpu.TRAD_PART_USER_SK = csu.TRAD_PART_USER_SK ";
                 ls_query = ls_query + "AND p.MEDIA_TYPE_SK=mt.MEDIA_TYPE_SK ";
                 ls_query = ls_query + "AND csu.CUST_SUBS_SK = cs.CUST_SUBS_SK  AND csi.ACTIVE ='Y' ";
                 ls_query = ls_query + "AND csu.ACTIVE = 'y'  AND csi.CUST_SUBS_SK = cs.CUST_SUBS_SK ";
                 ls_query = ls_query + "AND csi.PRODUCT_SK = p.PRODUCT_SK  AND p.PRODUCT_SK = patd.PRODUCT_SK ";
                 ls_query = ls_query + "AND patd.ATTRIBUTE_TYPE_value_SK = atv.ATTRIBUTE_TYPE_value_SK  AND atv.ATTRIBUTE_TYPE_SK = at.ATTRIBUTE_TYPE_SK ";
                 ls_query = ls_query + "AND AT.ATTRIBUTE_TYPE_ID='GUIDED READING LEVEL' ";
                 ls_query = ls_query + "AND p.PRODUCT_SK = pim.PRODUCT_SK  AND pim.IMAGE_TYPE = 'FTCOV' AND T.PRODUCT_SK=P.PRODUCT_SK ";
                 ls_query = ls_query + "AND p.ACTIVE ='Y'  AND MT.MEDIA_TYPE = 'ECO' AND CSi.CUST_SUBS_SK in (" + GetAllUserSubscriptions(as_user_login_name) +") ";
                 ls_query = ls_query + " AND u.USER_LOGIN_NAME='" + as_user_login_name+ "'  AND u.user_SK = sd1.user_sk AND  ISNUMERIC(ATV.ATTRIBUTE_TYPE_VALUE)=1  ";
                 ls_query = ls_query + "AND CONVERT(float,RTRIM(SUBSTRING(ATV.ATTRIBUTE_TYPE_VALUE,CHARINDEX(' ',ATV.ATTRIBUTE_TYPE_VALUE,1) +1,2))) ";
                 ls_query = ls_query + "between sd1.BOOK_LEVEL_AVAILABLE_FROM and sd1.BOOK_LEVEL_AVAILABLE_UPTO ORDER BY ATTRIBUTE_TYPE_VALUE ASC; DROP TABLE #tmp;";
                               
                 XmlElement ls_q = ls_dom.CreateElement("Query");
                 ls_Method.AppendChild(ls_q);
                 XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query);
                 ls_q.AppendChild(ls_Query_text);

                 DataSet lds_DataStore = new DataSet();
                 System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                 SQLAdapter.Fill(lds_DataStore);

                 XmlElement ls_rowcount = ls_dom.CreateElement("RowCount");
                 ls_Method.AppendChild(ls_rowcount);
                 XmlText ls_rowcount_text = ls_dom.CreateTextNode(lds_DataStore.Tables[0].Rows.Count.ToString());
                 ls_rowcount.AppendChild(ls_rowcount_text);

                 if (lds_DataStore.Tables[0].Rows.Count > 0)
                 {
                     XmlElement ls_Products = ls_dom.CreateElement("PRODUCTS");
                     ls_Method.AppendChild(ls_Products);

                     for (int i = 0; i <= lds_DataStore.Tables[0].Rows.Count - 1; i++)
                     {

                         ls_item_value = lds_DataStore.Tables[0].Rows[i]["ATTRIBUTE_TYPE_ID"].ToString();
                         ls_item_value = EscapeXMLCharacters(ls_item_value);
                         if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                         if (ls_item_value.Equals("GUIDED READING LEVEL") || ls_item_value.Equals("Guided Reading Level"))
                         {

                             XmlElement ls_ProductH = ls_dom.CreateElement("PRODUCT");
                             ls_Products.AppendChild(ls_ProductH);

                             //XmlElement ls_AttributeTypeId = ls_dom.CreateElement("ATTRIBUTE_TYPE_ID");
                             //ls_ProductH.AppendChild(ls_AttributeTypeId);
                             //XmlText ls_AttributeTypeId_text = ls_dom.CreateTextNode(ls_item_value);
                             //ls_AttributeTypeId.AppendChild(ls_AttributeTypeId_text);

                             ls_item_value = lds_DataStore.Tables[0].Rows[i]["PRODUCT_ID"].ToString();
                             ls_item_value = EscapeXMLCharacters(ls_item_value);
                             if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                             ls_product_id = ls_item_value;
                             XmlElement ls_Product = ls_dom.CreateElement("PRODUCT_ID");
                             ls_ProductH.AppendChild(ls_Product);
                             XmlText ls_Product_text = ls_dom.CreateTextNode(ls_item_value);
                             ls_Product.AppendChild(ls_Product_text);

                             ls_item_value = lds_DataStore.Tables[0].Rows[i]["TITLE"].ToString();
                             ls_item_value = EscapeXMLCharacters(ls_item_value);
                             if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                             XmlElement ls_Title = ls_dom.CreateElement("TITLE");
                             ls_ProductH.AppendChild(ls_Title);
                             XmlText ls_Title_text = ls_dom.CreateTextNode(ls_item_value);
                             ls_Title.AppendChild(ls_Title_text);

                             ls_item_value = lds_DataStore.Tables[0].Rows[i]["ATTRIBUTE_TYPE_VALUE"].ToString();
                             ls_item_value = EscapeXMLCharacters(ls_item_value);
                             if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                             XmlElement ls_AttributeTypeValue = ls_dom.CreateElement("PM_READING_LEVEL");
                             ls_ProductH.AppendChild(ls_AttributeTypeValue);
                             ls_item_value = ls_item_value.Replace("LEVEL ", "");
                             ls_item_value = ls_item_value.Replace("Level ", "");
                             XmlText ls_AttributeTypeValue_text = ls_dom.CreateTextNode(ls_item_value);
                             ls_AttributeTypeValue.AppendChild(ls_AttributeTypeValue_text);

                             ls_item_value = lds_DataStore.Tables[0].Rows[i]["ISBN_13"].ToString();
                             ls_item_value = EscapeXMLCharacters(ls_item_value);
                             if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                             XmlElement ls_ISBN_13 = ls_dom.CreateElement("ISBN_13");
                             ls_ProductH.AppendChild(ls_ISBN_13);
                             XmlText ls_ISBN_13_text = ls_dom.CreateTextNode(ls_item_value);
                             ls_ISBN_13.AppendChild(ls_ISBN_13_text);

                             ls_item_value = lds_DataStore.Tables[0].Rows[i]["ISBN_13"].ToString();
                             ls_item_value = EscapeXMLCharacters(ls_item_value);
                             if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                             string flag = "0", flag1 = "0";
                             if (ls_item_value != "-")
                             {
                                 DirectoryInfo di = new DirectoryInfo(ls_PHYSICAL_FILE_PATH);
                                 // Image type = "ftcov"
                                 var directories = di.GetFiles("*.epub", SearchOption.TopDirectoryOnly);
                                 var directories1 = di.GetDirectories("*", SearchOption.TopDirectoryOnly);
                                 foreach (FileInfo file in directories)
                                 {
                                     if (file.Name == ls_item_value + ".epub")
                                     {
                                         XmlElement ls_ISBN_EPUBS_ZIPPED = ls_dom.CreateElement("ISBN_EPUBS_ZIPPED");
                                         ls_ProductH.AppendChild(ls_ISBN_EPUBS_ZIPPED);
                                         XmlText ls_ISBN_EPUBS_ZIPPED_text = ls_dom.CreateTextNode(Get_Size_in_KB_MB_GB((ulong)file.Length, 0));
                                         ls_ISBN_EPUBS_ZIPPED.AppendChild(ls_ISBN_EPUBS_ZIPPED_text);
                                         flag = "1";
                                         break;
                                     }
                                 }
                                 foreach (DirectoryInfo dir in directories1)
                                 {
                                     if (dir.Name == ls_item_value)
                                     {
                                         XmlElement ls_ISBN_EPUBS_UNZIPPED = ls_dom.CreateElement("ISBN_EPUBS_UNZIPPED");
                                         ls_ProductH.AppendChild(ls_ISBN_EPUBS_UNZIPPED);
                                         XmlText ls_ISBN_EPUBS_UNZIPPED_text = ls_dom.CreateTextNode(DirectorySize(dir, true).ToString("f2") + "MB");
                                         ls_ISBN_EPUBS_UNZIPPED.AppendChild(ls_ISBN_EPUBS_UNZIPPED_text);
                                         flag1 = "1";
                                         break;
                                     }
                                 }
                                 if (flag == "0")
                                 {
                                     XmlElement ls_ISBN_EPUBS_ZIPPED = ls_dom.CreateElement("ISBN_EPUBS_ZIPPED");
                                     ls_ProductH.AppendChild(ls_ISBN_EPUBS_ZIPPED);
                                     XmlText ls_ISBN_EPUBS_ZIPPED_text = ls_dom.CreateTextNode("-");
                                     ls_ISBN_EPUBS_ZIPPED.AppendChild(ls_ISBN_EPUBS_ZIPPED_text);
                                 }
                                 if (flag1 == "0")
                                 {
                                     XmlElement ls_ISBN_EPUBS_UNZIPPED = ls_dom.CreateElement("ISBN_EPUBS_UNZIPPED");
                                     ls_ProductH.AppendChild(ls_ISBN_EPUBS_UNZIPPED);
                                     XmlText ls_ISBN_EPUBS_UNZIPPED_text = ls_dom.CreateTextNode("-");
                                     ls_ISBN_EPUBS_UNZIPPED.AppendChild(ls_ISBN_EPUBS_UNZIPPED_text);
                                 }
                             }
                             else
                             {
                                 XmlElement ls_ISBN_EPUBS_ZIPPED = ls_dom.CreateElement("ISBN_EPUBS_ZIPPED");
                                 ls_ProductH.AppendChild(ls_ISBN_EPUBS_ZIPPED);
                                 XmlText ls_ISBN_EPUBS_ZIPPED_text = ls_dom.CreateTextNode("-");
                                 ls_ISBN_EPUBS_ZIPPED.AppendChild(ls_ISBN_EPUBS_ZIPPED_text);
                             }

                             ls_item_value = lds_DataStore.Tables[0].Rows[i]["PRODUCT_SK"].ToString();
                             ls_item_value = EscapeXMLCharacters(ls_item_value);
                             if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                             XmlElement ls_PRODUCT_SK = ls_dom.CreateElement("PRODUCT_SK");
                             ls_ProductH.AppendChild(ls_PRODUCT_SK);
                             XmlText ls_PRODUCT_SK_text = ls_dom.CreateTextNode(ls_item_value);
                             ls_PRODUCT_SK.AppendChild(ls_PRODUCT_SK_text);

                             ls_item_value = lds_DataStore.Tables[0].Rows[i]["AUTHOR_NAME"].ToString();
                             ls_item_value = EscapeXMLCharacters(ls_item_value);
                             if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                             XmlElement ls_AUTHOR_NAME = ls_dom.CreateElement("AUTHOR_NAME");
                             ls_ProductH.AppendChild(ls_AUTHOR_NAME);
                             XmlText ls_AUTHOR_NAME_text = ls_dom.CreateTextNode(ls_item_value);
                             ls_AUTHOR_NAME.AppendChild(ls_AUTHOR_NAME_text);

                             string ls_WEBSERVICEURL = System.Configuration.ConfigurationManager.AppSettings["WEBSERVICE_URL"];

                             ls_item_value = lds_DataStore.Tables[0].Rows[i]["IMAGE_FILE_NAME"].ToString();
                             ls_item_value = EscapeXMLCharacters(ls_item_value);
                             if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                             XmlElement ls_ImageFileName = ls_dom.CreateElement("IMAGE_FILE_NAME");
                             ls_ProductH.AppendChild(ls_ImageFileName);
                             XmlText ls_ImageFileName_text = ls_dom.CreateTextNode(ls_WEBSERVICEURL + "Thumbnails/" + ls_item_value);
                             ls_ImageFileName.AppendChild(ls_ImageFileName_text);

                             for (int ii = 0; ii <= lds_DataStore.Tables[0].Rows.Count - 1; ii++)
                             {

                                 ls_item_value = lds_DataStore.Tables[0].Rows[ii]["ATTRIBUTE_TYPE_ID"].ToString();
                                 ls_item_value = EscapeXMLCharacters(ls_item_value);
                                 if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                                 if (ls_item_value.Equals("COLOUR") || ls_item_value.Equals("Colour Level"))
                                 {

                                     ls_item_value = lds_DataStore.Tables[0].Rows[ii]["PRODUCT_ID"].ToString();
                                     ls_item_value = EscapeXMLCharacters(ls_item_value);
                                     if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                                     if (ls_product_id.Equals(ls_item_value))
                                     {
                                         ls_item_value = lds_DataStore.Tables[0].Rows[ii]["ATTRIBUTE_TYPE_VALUE"].ToString();
                                         ls_item_value = EscapeXMLCharacters(ls_item_value);
                                         if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                                         XmlElement ls_Color = ls_dom.CreateElement("COLOUR");
                                         ls_ProductH.AppendChild(ls_Color);
                                         XmlText ls_Color_text = ls_dom.CreateTextNode(ls_item_value);
                                         ls_Color.AppendChild(ls_Color_text);

                                     }
                                 }
                             }
                         }
                     }

                     XmlElement ls_Error = ls_dom.CreateElement("Error");
                     ls_Method.AppendChild(ls_Error);
                     XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                     ls_Error.AppendChild(ls_ErrorCode);
                     XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                     ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                     XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                     ls_Error.AppendChild(ls_ErrorDescription);
                     XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                     ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                     XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                     ls_Method.AppendChild(ls_DisplayCustomMessage);
                     XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                     ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                     XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                     ls_Method.AppendChild(ls_MessageCode);
                     XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                     ls_MessageCode.AppendChild(ls_MessageCode_text);

                 }
                 else
                 {
                     XmlElement ls_Error = ls_dom.CreateElement("Error");
                     ls_Method.AppendChild(ls_Error);
                     XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                     ls_Error.AppendChild(ls_ErrorCode);
                     XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                     ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                     XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                     ls_Error.AppendChild(ls_ErrorDescription);
                     XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                     ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                     XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                     ls_Method.AppendChild(ls_DisplayCustomMessage);
                     XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                     ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                     XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                     ls_Method.AppendChild(ls_MessageCode);
                     XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0012");
                     ls_MessageCode.AppendChild(ls_MessageCode_text);

                 }

                 SQLConn.Close();

                 return ls_dom;

             }
             catch (Exception exp)
             {
                 XmlElement ls_Error = ls_dom.CreateElement("Error");
                 ls_Method.AppendChild(ls_Error);
                 XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                 ls_Error.AppendChild(ls_ErrorCode);
                 XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                 ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                 XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                 ls_Error.AppendChild(ls_ErrorDescription);
                 XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                 ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                 XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                 ls_Method.AppendChild(ls_DisplayCustomMessage);
                 XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                 ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                 XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                 ls_Method.AppendChild(ls_MessageCode);
                 XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                 ls_MessageCode.AppendChild(ls_MessageCode_text);

                 SQLConn.Close();

                 return ls_dom;

             }

         }
         */

        [WebMethod]
        public XmlDocument GetBookShelfInfo(string as_user_login_name, string as_demo_mode, string information, string as_cust_subs_sk)//(string as_user_login_name,string as_cust_subs_sk,string as_demo_mode)
        {
            var watch = Stopwatch.StartNew();
            Log("GetBookShelfInfo", "Starting" + as_user_login_name + "," + as_demo_mode + "," + information + "," + as_cust_subs_sk);

            LogArguments("GetBookShelfInfo", as_user_login_name + ";" + as_demo_mode + ";", information);

            //Connection string to connect with database

            //string ls_ConnectionString = "";
            //string ls_query = "";
            string ls_item_value;
            string ls_product_id;
            string ls_PHYSICAL_FILE_PATH = System.Configuration.ConfigurationManager.AppSettings["PHYSICAL_FILE_PATH"];
            string ls_WEBSERVICE_URL = System.Configuration.ConfigurationManager.AppSettings["WEBSERVICE_URL"];
            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "GetBookShelfInfo");

            try
            {

                //Open connection with database
                SQLConn.Open();
                SqlCommand sqlcom = new SqlCommand();
                sqlcom.Connection = SQLConn;
                sqlcom.CommandType = CommandType.StoredProcedure;
                sqlcom.CommandText = "GET_BOOKSHELF_DATA_UPGRADED";
                sqlcom.Parameters.AddWithValue("@as_cust_subs_sk", as_cust_subs_sk);
                sqlcom.Parameters.AddWithValue("@as_user_login_name", as_user_login_name);
                DataSet lds_DataStore = new DataSet();
                var watch1 = Stopwatch.StartNew();
                Log("GetBookShelfInfo", "QUERYStarting" + as_user_login_name + "," + as_demo_mode + "," + information + "," + as_cust_subs_sk);
                SqlDataAdapter SQLAdapter = new SqlDataAdapter(sqlcom);
                //  SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                SQLAdapter.Fill(lds_DataStore);
                watch1.Stop();
                var elapsedMs1 = watch1.ElapsedMilliseconds;
                Log("GetBookShelfInfo", "Query Ended Successfully : " + elapsedMs1.ToString());
                //ls_query = ls_query + "SELECT PRODUCT_SK,(SELECT * FROM  eComm_Authors_Select(PRODUCT_SK)) AUTHOR_NAME ";
                //ls_query = ls_query + "INTO #tmp FROM CEN_PRODUCTS AS P JOIN CEN_MEDIA_TYPES AS MT ";
                //ls_query = ls_query + "ON P.MEDIA_TYPE_SK=MT.MEDIA_TYPE_SK ";
                //ls_query = ls_query + "WHERE MT.MEDIA_TYPE='ECO' AND P.ACTIVE='Y';  SELECT DISTINCT p.PRODUCT_ID,p.TITLE,CONVERT(int,atv.ATTRIBUTE_TYPE_VALUE) AS ATTRIBUTE_TYPE_VALUE,at.ATTRIBUTE_TYPE_ID,pim.IMAGE_FILE_NAME,";
                //ls_query = ls_query + "p.ISBN_13,p.PRODUCT_SK,T.AUTHOR_NAME ";
                //ls_query = ls_query + "FROM CEN_USERS u,";
                //ls_query = ls_query + "CEN_USER_ROLES ur, CEN_TRADING_PARTNER_USERS tpu,";
                //ls_query = ls_query + "CEN_CUSTOMER_SUBS_USERS csu, CEN_CUSTOMER_SUBSCRIPTIONS cs,";
                //ls_query = ls_query + "CEN_CUSTOMER_SUBS_ITEMS csi, CEN_PRODUCTS p,";
                //ls_query = ls_query + "CEN_PRODUCT_ATTRIBUTE_TYPE_DETAILS patd, CEN_ATTRIBUTE_TYPE_values atv,";
                //ls_query = ls_query + "CEN_ATTRIBUTE_TYPES at, CEN_PRODUCT_IMAGES pim, CEN_STUDENT_DETAILS sd1,";
                //ls_query = ls_query + "CEN_MEDIA_TYPES MT,#tmp AS T ";
                //ls_query = ls_query + "WHERE u.USER_SK = ur.USER_SK  AND ur.USER_ROLE_SK = tpu.USER_ROLE_SK ";
                //ls_query = ls_query + "AND tpu.TRAD_PART_USER_SK = csu.TRAD_PART_USER_SK ";
                //ls_query = ls_query + "AND csu.CUST_SUBS_SK = cs.CUST_SUBS_SK  AND csi.ACTIVE ='Y'  AND csu.ACTIVE = 'y' ";
                //ls_query = ls_query + "AND csi.CUST_SUBS_SK = cs.CUST_SUBS_SK  AND csi.PRODUCT_SK = p.PRODUCT_SK ";
                //ls_query = ls_query + "AND p.MEDIA_TYPE_SK=mt.MEDIA_TYPE_SK ";
                //ls_query = ls_query + "AND p.PRODUCT_SK = patd.PRODUCT_SK  AND patd.ATTRIBUTE_TYPE_value_SK = atv.ATTRIBUTE_TYPE_value_SK ";
                //ls_query = ls_query + "AND atv.ATTRIBUTE_TYPE_SK = at.ATTRIBUTE_TYPE_SK ";
                //ls_query = ls_query + "AND AT.ATTRIBUTE_TYPE_ID='GUIDED READING LEVEL' ";
                //ls_query = ls_query + "AND p.PRODUCT_SK = pim.PRODUCT_SK  AND pim.IMAGE_TYPE = 'FTCOV' AND T.PRODUCT_SK=P.PRODUCT_SK ";
                ////ls_query = ls_query + "AND p.ACTIVE ='Y'  AND MT.MEDIA_TYPE = 'ECO' AND CSi.CUST_SUBS_SK in (" + GetAllUserSubscriptions(as_user_login_name) +") ";
                //ls_query = ls_query + "AND p.ACTIVE ='Y'  AND MT.MEDIA_TYPE = 'ECO' AND CSi.CUST_SUBS_SK =" + as_cust_subs_sk;

                //ls_query = ls_query + " AND u.USER_LOGIN_NAME='" + as_user_login_name + "'  AND u.user_SK = sd1.user_sk AND  ISNUMERIC(ATV.ATTRIBUTE_TYPE_VALUE)=1 ";
                //ls_query = ls_query + "AND CONVERT(float,RTRIM(SUBSTRING(ATV.ATTRIBUTE_TYPE_VALUE,CHARINDEX(' ',ATV.ATTRIBUTE_TYPE_VALUE,1) +1,2))) ";
                //ls_query = ls_query + "between sd1.CURRENT_BOOK_READ_LEVEL_FROM and sd1.CURRENT_BOOK_READ_LEVEL_UPTO ";
                //ls_query = ls_query + "UNION ";
                //ls_query = ls_query + "SELECT DISTINCT  p.PRODUCT_ID, p.TITLE, CONVERT(int,atv.ATTRIBUTE_TYPE_VALUE) AS ATTRIBUTE_TYPE_VALUE, at.ATTRIBUTE_TYPE_ID, pim.IMAGE_FILE_NAME,p.ISBN_13, p.PRODUCT_SK,T.AUTHOR_NAME ";
                //ls_query = ls_query + "FROM CEN_USERS u, CEN_USER_ROLES ur,";
                //ls_query = ls_query + "CEN_TRADING_PARTNER_USERS tpu, CEN_CUSTOMER_SUBS_USERS csu,";
                //ls_query = ls_query + "CEN_CUSTOMER_SUBSCRIPTIONS cs, CEN_CUSTOMER_SUBS_ITEMS csi,";
                //ls_query = ls_query + "CEN_PRODUCTS p, CEN_PRODUCT_ATTRIBUTE_TYPE_DETAILS patd,";
                //ls_query = ls_query + "CEN_ATTRIBUTE_TYPE_values atv, CEN_ATTRIBUTE_TYPES at,";
                //ls_query = ls_query + "CEN_PRODUCT_IMAGES pim, CEN_TEACHER_DETAILS sd1,CEN_MEDIA_TYPES MT,#tmp AS T ";
                //ls_query = ls_query + "WHERE u.USER_SK = ur.USER_SK  AND ur.USER_ROLE_SK = tpu.USER_ROLE_SK ";
                //ls_query = ls_query + "AND tpu.TRAD_PART_USER_SK = csu.TRAD_PART_USER_SK ";
                //ls_query = ls_query + "AND p.MEDIA_TYPE_SK=mt.MEDIA_TYPE_SK ";
                //ls_query = ls_query + "AND csu.CUST_SUBS_SK = cs.CUST_SUBS_SK  AND csi.ACTIVE ='Y' ";
                //ls_query = ls_query + "AND csu.ACTIVE = 'y'  AND csi.CUST_SUBS_SK = cs.CUST_SUBS_SK ";
                //ls_query = ls_query + "AND csi.PRODUCT_SK = p.PRODUCT_SK  AND p.PRODUCT_SK = patd.PRODUCT_SK ";
                //ls_query = ls_query + "AND patd.ATTRIBUTE_TYPE_value_SK = atv.ATTRIBUTE_TYPE_value_SK  AND atv.ATTRIBUTE_TYPE_SK = at.ATTRIBUTE_TYPE_SK ";
                //ls_query = ls_query + "AND AT.ATTRIBUTE_TYPE_ID='GUIDED READING LEVEL' ";
                //ls_query = ls_query + "AND p.PRODUCT_SK = pim.PRODUCT_SK  AND pim.IMAGE_TYPE = 'FTCOV' AND T.PRODUCT_SK=P.PRODUCT_SK ";
                ////ls_query = ls_query + "AND p.ACTIVE ='Y'  AND MT.MEDIA_TYPE = 'ECO' AND CSi.CUST_SUBS_SK in (" + GetAllUserSubscriptions(as_user_login_name) +") ";

                //ls_query = ls_query + "AND p.ACTIVE ='Y'  AND MT.MEDIA_TYPE = 'ECO' AND CSi.CUST_SUBS_SK =" + as_cust_subs_sk;
                //ls_query = ls_query + " AND u.USER_LOGIN_NAME='" + as_user_login_name + "'  AND u.user_SK = sd1.user_sk AND  ISNUMERIC(ATV.ATTRIBUTE_TYPE_VALUE)=1  ";
                //ls_query = ls_query + "AND CONVERT(float,RTRIM(SUBSTRING(ATV.ATTRIBUTE_TYPE_VALUE,CHARINDEX(' ',ATV.ATTRIBUTE_TYPE_VALUE,1) +1,2))) ";
                //ls_query = ls_query + "between sd1.BOOK_LEVEL_AVAILABLE_FROM and sd1.BOOK_LEVEL_AVAILABLE_UPTO ORDER BY CONVERT(int,ATTRIBUTE_TYPE_VALUE) ASC; DROP TABLE #tmp;";

                //XmlElement ls_q = ls_dom.CreateElement("Query");
                //ls_Method.AppendChild(ls_q);
                //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query);
                //ls_q.AppendChild(ls_Query_text);

                //DataSet lds_DataStore = new DataSet();
                //System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                //SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                //SQLAdapter.Fill(lds_DataStore);

                XmlElement ls_rowcount = ls_dom.CreateElement("RowCount");
                ls_Method.AppendChild(ls_rowcount);
                XmlText ls_rowcount_text = ls_dom.CreateTextNode(lds_DataStore.Tables[0].Rows.Count.ToString());
                ls_rowcount.AppendChild(ls_rowcount_text);

                if (lds_DataStore.Tables[0].Rows.Count > 0)
                {
                    XmlElement ls_Products = ls_dom.CreateElement("PRODUCTS");
                    ls_Method.AppendChild(ls_Products);

                    for (int i = 0; i <= lds_DataStore.Tables[0].Rows.Count - 1; i++)
                    {

                        ls_item_value = lds_DataStore.Tables[0].Rows[i]["ATTRIBUTE_TYPE_ID"].ToString();
                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                        if (ls_item_value.Equals("GUIDED READING LEVEL") || ls_item_value.Equals("Guided Reading Level"))
                        {

                            XmlElement ls_ProductH = ls_dom.CreateElement("PRODUCT");
                            ls_Products.AppendChild(ls_ProductH);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["PRODUCT_ID"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            ls_product_id = ls_item_value;
                            XmlElement ls_Product = ls_dom.CreateElement("PRODUCT_ID");
                            ls_ProductH.AppendChild(ls_Product);
                            XmlText ls_Product_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_Product.AppendChild(ls_Product_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["TITLE"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_Title = ls_dom.CreateElement("TITLE");
                            ls_ProductH.AppendChild(ls_Title);
                            XmlText ls_Title_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_Title.AppendChild(ls_Title_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["ATTRIBUTE_TYPE_VALUE"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_AttributeTypeValue = ls_dom.CreateElement("PM_READING_LEVEL");
                            ls_ProductH.AppendChild(ls_AttributeTypeValue);
                            ls_item_value = ls_item_value.Replace("LEVEL ", "");
                            ls_item_value = ls_item_value.Replace("Level ", "");
                            XmlText ls_AttributeTypeValue_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_AttributeTypeValue.AppendChild(ls_AttributeTypeValue_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["ISBN_13"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_ISBN_13 = ls_dom.CreateElement("ISBN_13");
                            ls_ProductH.AppendChild(ls_ISBN_13);
                            XmlText ls_ISBN_13_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_ISBN_13.AppendChild(ls_ISBN_13_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["ISBN_13"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            string flag = "0", flag1 = "0";
                            if (ls_item_value != "-")
                            {
                                DirectoryInfo di = new DirectoryInfo(ls_PHYSICAL_FILE_PATH);
                                // Image type = "ftcov"
                                var directories = di.GetFiles("*.epub", SearchOption.TopDirectoryOnly);
                                var directories1 = di.GetDirectories("*", SearchOption.TopDirectoryOnly);
                                foreach (FileInfo file in directories)
                                {
                                    if (file.Name == ls_item_value + ".epub")
                                    {
                                        XmlElement ls_ISBN_EPUBS_ZIPPED = ls_dom.CreateElement("ISBN_EPUBS_ZIPPED");
                                        ls_ProductH.AppendChild(ls_ISBN_EPUBS_ZIPPED);
                                        XmlText ls_ISBN_EPUBS_ZIPPED_text = ls_dom.CreateTextNode(Get_Size_in_KB_MB_GB((ulong)file.Length, 0));
                                        ls_ISBN_EPUBS_ZIPPED.AppendChild(ls_ISBN_EPUBS_ZIPPED_text);
                                        flag = "1";
                                        break;
                                    }
                                }
                                foreach (DirectoryInfo dir in directories1)
                                {
                                    if (dir.Name == ls_item_value)
                                    {
                                        XmlElement ls_ISBN_EPUBS_UNZIPPED = ls_dom.CreateElement("ISBN_EPUBS_UNZIPPED");
                                        ls_ProductH.AppendChild(ls_ISBN_EPUBS_UNZIPPED);
                                        XmlText ls_ISBN_EPUBS_UNZIPPED_text = ls_dom.CreateTextNode(DirectorySize(dir, true).ToString("f2") + "MB");
                                        ls_ISBN_EPUBS_UNZIPPED.AppendChild(ls_ISBN_EPUBS_UNZIPPED_text);
                                        flag1 = "1";
                                        break;
                                    }
                                }
                                if (flag == "0")
                                {
                                    XmlElement ls_ISBN_EPUBS_ZIPPED = ls_dom.CreateElement("ISBN_EPUBS_ZIPPED");
                                    ls_ProductH.AppendChild(ls_ISBN_EPUBS_ZIPPED);
                                    XmlText ls_ISBN_EPUBS_ZIPPED_text = ls_dom.CreateTextNode("-");
                                    ls_ISBN_EPUBS_ZIPPED.AppendChild(ls_ISBN_EPUBS_ZIPPED_text);
                                }
                                if (flag1 == "0")
                                {
                                    XmlElement ls_ISBN_EPUBS_UNZIPPED = ls_dom.CreateElement("ISBN_EPUBS_UNZIPPED");
                                    ls_ProductH.AppendChild(ls_ISBN_EPUBS_UNZIPPED);
                                    XmlText ls_ISBN_EPUBS_UNZIPPED_text = ls_dom.CreateTextNode("-");
                                    ls_ISBN_EPUBS_UNZIPPED.AppendChild(ls_ISBN_EPUBS_UNZIPPED_text);
                                }
                            }
                            else
                            {
                                XmlElement ls_ISBN_EPUBS_ZIPPED = ls_dom.CreateElement("ISBN_EPUBS_ZIPPED");
                                ls_ProductH.AppendChild(ls_ISBN_EPUBS_ZIPPED);
                                XmlText ls_ISBN_EPUBS_ZIPPED_text = ls_dom.CreateTextNode("-");
                                ls_ISBN_EPUBS_ZIPPED.AppendChild(ls_ISBN_EPUBS_ZIPPED_text);
                            }

                            XmlElement ls_EPUB_URL = ls_dom.CreateElement("EPUB_URL");
                            ls_ProductH.AppendChild(ls_EPUB_URL);
                            XmlText ls_EPUB_URL_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + "/" + ls_item_value + ".epub");
                            ls_EPUB_URL.AppendChild(ls_EPUB_URL_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["PRODUCT_SK"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_PRODUCT_SK = ls_dom.CreateElement("PRODUCT_SK");
                            ls_ProductH.AppendChild(ls_PRODUCT_SK);
                            XmlText ls_PRODUCT_SK_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_PRODUCT_SK.AppendChild(ls_PRODUCT_SK_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["AUTHOR_NAME"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_AUTHOR_NAME = ls_dom.CreateElement("AUTHOR_NAME");
                            ls_ProductH.AppendChild(ls_AUTHOR_NAME);
                            XmlText ls_AUTHOR_NAME_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_AUTHOR_NAME.AppendChild(ls_AUTHOR_NAME_text);

                            string ls_WEBSERVICEURL = System.Configuration.ConfigurationManager.AppSettings["WEBSERVICE_URL"];

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["IMAGE_FILE_NAME"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_ImageFileName = ls_dom.CreateElement("IMAGE_FILE_NAME");
                            ls_ProductH.AppendChild(ls_ImageFileName);
                            XmlText ls_ImageFileName_text = ls_dom.CreateTextNode(ls_WEBSERVICEURL + "Thumbnails/" + ls_item_value);
                            ls_ImageFileName.AppendChild(ls_ImageFileName_text);

                            for (int ii = 0; ii <= lds_DataStore.Tables[0].Rows.Count - 1; ii++)
                            {

                                ls_item_value = lds_DataStore.Tables[0].Rows[ii]["ATTRIBUTE_TYPE_ID"].ToString();
                                ls_item_value = EscapeXMLCharacters(ls_item_value);
                                if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                                if (ls_item_value.Equals("COLOUR") || ls_item_value.Equals("Colour Level"))
                                {

                                    ls_item_value = lds_DataStore.Tables[0].Rows[ii]["PRODUCT_ID"].ToString();
                                    ls_item_value = EscapeXMLCharacters(ls_item_value);
                                    if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                                    if (ls_product_id.Equals(ls_item_value))
                                    {
                                        ls_item_value = lds_DataStore.Tables[0].Rows[ii]["ATTRIBUTE_TYPE_VALUE"].ToString();
                                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                                        XmlElement ls_Color = ls_dom.CreateElement("COLOUR");
                                        ls_ProductH.AppendChild(ls_Color);
                                        XmlText ls_Color_text = ls_dom.CreateTextNode(ls_item_value);
                                        ls_Color.AppendChild(ls_Color_text);

                                    }
                                }
                            }
                        }
                    }

                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                }
                else
                {
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0012");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                }

                SQLConn.Close();
                watch.Stop();
                var elapsedMs = watch.ElapsedMilliseconds;
                Log("GetBookShelfInfo", "Ended Successfully : " + elapsedMs.ToString());
                return ls_dom;

            }
            catch (Exception exp)
            {
                LogFileWrite(exp, as_user_login_name);
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                ls_MessageCode.AppendChild(ls_MessageCode_text);
                SQLConn.Close();
                watch.Stop();
                var elapsedMs = watch.ElapsedMilliseconds;
                Log("GetBookShelfInfo", "Ended with exception: " + elapsedMs.ToString());
                return ls_dom;

            }

        }

        [WebMethod]
        public XmlDocument GetBookInfo(string isbn, string information)//(string as_user_login_name,string as_cust_subs_sk,string as_demo_mode)
        {
            LogArguments("GetBookInfo", isbn, information);

            //Connection string to connect with database

            //string ls_ConnectionString = "";
            string ls_query = "";
            string ls_item_value;
            string ls_product_id;
            string ls_PHYSICAL_FILE_PATH = System.Configuration.ConfigurationManager.AppSettings["PHYSICAL_FILE_PATH"];
            string ls_WEBSERVICE_URL = System.Configuration.ConfigurationManager.AppSettings["WEBSERVICE_URL"];
            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "GetBookInfo");

            try
            {

                //Open connection with database
                SQLConn.Open();

                ls_query = string.Concat("SELECT PRODUCT_SK,(SELECT * FROM  eComm_Authors_Select(PRODUCT_SK)) AUTHOR_NAME ",
                                        "INTO #tmp FROM CEN_PRODUCTS AS P JOIN CEN_MEDIA_TYPES AS MT  ",
                                        "ON P.MEDIA_TYPE_SK=MT.MEDIA_TYPE_SK  ",
                                        "WHERE MT.MEDIA_TYPE='ECO' AND P.ACTIVE='Y';  ",
                                        "SELECT DISTINCT p.PRODUCT_ID,p.TITLE,CONVERT(int,atv.ATTRIBUTE_TYPE_VALUE) AS ATTRIBUTE_TYPE_VALUE,AT.ATTRIBUTE_TYPE_ID,PI.IMAGE_FILE_NAME, ",
                                        " p.ISBN_13,p.PRODUCT_SK,T.AUTHOR_NAME FROM CEN_PRODUCTS AS P ",
                                        "JOIN CEN_PRODUCT_ATTRIBUTE_TYPE_DETAILS AS PAD ON PAD.PRODUCT_SK=P.PRODUCT_SK ",
                                        "JOIN CEN_PRODUCT_IMAGES AS PI ON PI.PRODUCT_SK=P.PRODUCT_SK ",
                                        "JOIN #tmp AS T ON T.PRODUCT_SK=P.PRODUCT_SK ",
                                        "JOIN CEN_ATTRIBUTE_TYPE_VALUES AS ATV ON PAD.ATTRIBUTE_TYPE_value_SK=ATV.ATTRIBUTE_TYPE_value_SK  AND ISNUMERIC(ATV.ATTRIBUTE_TYPE_VALUE)=1 ",
                                        "JOIN CEN_ATTRIBUTE_TYPES AS AT ON ATV.ATTRIBUTE_TYPE_SK=AT.ATTRIBUTE_TYPE_SK  ",
                                        " JOIN CEN_MEDIA_TYPES AS M ON P.MEDIA_TYPE_SK=M.MEDIA_TYPE_SK ",
                                        " WHERE AT.ATTRIBUTE_TYPE_ID='GUIDED READING LEVEL' AND P.ACTIVE ='Y' AND PI.ACTIVE='Y' AND M.MEDIA_TYPE = 'ECO' AND P.ISBN_13=" + isbn,
                                        "ORDER BY CONVERT(int,atv.ATTRIBUTE_TYPE_VALUE) ",
                                        "DROP TABLE #tmp");
                //XmlElement ls_q = ls_dom.CreateElement("Query");
                //ls_Method.AppendChild(ls_q);
                //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query);
                //ls_q.AppendChild(ls_Query_text);

                DataSet lds_DataStore = new DataSet();
                System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                SQLAdapter.Fill(lds_DataStore);

                XmlElement ls_rowcount = ls_dom.CreateElement("RowCount");
                ls_Method.AppendChild(ls_rowcount);
                XmlText ls_rowcount_text = ls_dom.CreateTextNode(lds_DataStore.Tables[0].Rows.Count.ToString());
                ls_rowcount.AppendChild(ls_rowcount_text);

                if (lds_DataStore.Tables[0].Rows.Count > 0)
                {
                    XmlElement ls_Products = ls_dom.CreateElement("PRODUCTS");
                    ls_Method.AppendChild(ls_Products);

                    for (int i = 0; i <= lds_DataStore.Tables[0].Rows.Count - 1; i++)
                    {

                        ls_item_value = lds_DataStore.Tables[0].Rows[i]["ATTRIBUTE_TYPE_ID"].ToString();
                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                        if (ls_item_value.Equals("GUIDED READING LEVEL") || ls_item_value.Equals("Guided Reading Level"))
                        {

                            XmlElement ls_ProductH = ls_dom.CreateElement("PRODUCT");
                            ls_Products.AppendChild(ls_ProductH);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["PRODUCT_ID"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            ls_product_id = ls_item_value;
                            XmlElement ls_Product = ls_dom.CreateElement("PRODUCT_ID");
                            ls_ProductH.AppendChild(ls_Product);
                            XmlText ls_Product_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_Product.AppendChild(ls_Product_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["TITLE"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_Title = ls_dom.CreateElement("TITLE");
                            ls_ProductH.AppendChild(ls_Title);
                            XmlText ls_Title_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_Title.AppendChild(ls_Title_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["ATTRIBUTE_TYPE_VALUE"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_AttributeTypeValue = ls_dom.CreateElement("PM_READING_LEVEL");
                            ls_ProductH.AppendChild(ls_AttributeTypeValue);
                            ls_item_value = ls_item_value.Replace("LEVEL ", "");
                            ls_item_value = ls_item_value.Replace("Level ", "");
                            XmlText ls_AttributeTypeValue_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_AttributeTypeValue.AppendChild(ls_AttributeTypeValue_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["ISBN_13"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_ISBN_13 = ls_dom.CreateElement("ISBN_13");
                            ls_ProductH.AppendChild(ls_ISBN_13);
                            XmlText ls_ISBN_13_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_ISBN_13.AppendChild(ls_ISBN_13_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["ISBN_13"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            string flag = "0", flag1 = "0";
                            if (ls_item_value != "-")
                            {
                                DirectoryInfo di = new DirectoryInfo(ls_PHYSICAL_FILE_PATH);
                                // Image type = "ftcov"
                                var directories = di.GetFiles("*.epub", SearchOption.TopDirectoryOnly);
                                var directories1 = di.GetDirectories("*", SearchOption.TopDirectoryOnly);
                                foreach (FileInfo file in directories)
                                {
                                    if (file.Name == ls_item_value + ".epub")
                                    {
                                        XmlElement ls_ISBN_EPUBS_ZIPPED = ls_dom.CreateElement("ISBN_EPUBS_ZIPPED");
                                        ls_ProductH.AppendChild(ls_ISBN_EPUBS_ZIPPED);
                                        XmlText ls_ISBN_EPUBS_ZIPPED_text = ls_dom.CreateTextNode(Get_Size_in_KB_MB_GB((ulong)file.Length, 0));
                                        ls_ISBN_EPUBS_ZIPPED.AppendChild(ls_ISBN_EPUBS_ZIPPED_text);
                                        flag = "1";
                                        break;
                                    }
                                }
                                foreach (DirectoryInfo dir in directories1)
                                {
                                    if (dir.Name == ls_item_value)
                                    {
                                        XmlElement ls_ISBN_EPUBS_UNZIPPED = ls_dom.CreateElement("ISBN_EPUBS_UNZIPPED");
                                        ls_ProductH.AppendChild(ls_ISBN_EPUBS_UNZIPPED);
                                        XmlText ls_ISBN_EPUBS_UNZIPPED_text = ls_dom.CreateTextNode(DirectorySize(dir, true).ToString("f2") + "MB");
                                        ls_ISBN_EPUBS_UNZIPPED.AppendChild(ls_ISBN_EPUBS_UNZIPPED_text);
                                        flag1 = "1";
                                        break;
                                    }
                                }
                                if (flag == "0")
                                {
                                    XmlElement ls_ISBN_EPUBS_ZIPPED = ls_dom.CreateElement("ISBN_EPUBS_ZIPPED");
                                    ls_ProductH.AppendChild(ls_ISBN_EPUBS_ZIPPED);
                                    XmlText ls_ISBN_EPUBS_ZIPPED_text = ls_dom.CreateTextNode("-");
                                    ls_ISBN_EPUBS_ZIPPED.AppendChild(ls_ISBN_EPUBS_ZIPPED_text);
                                }
                                if (flag1 == "0")
                                {
                                    XmlElement ls_ISBN_EPUBS_UNZIPPED = ls_dom.CreateElement("ISBN_EPUBS_UNZIPPED");
                                    ls_ProductH.AppendChild(ls_ISBN_EPUBS_UNZIPPED);
                                    XmlText ls_ISBN_EPUBS_UNZIPPED_text = ls_dom.CreateTextNode("-");
                                    ls_ISBN_EPUBS_UNZIPPED.AppendChild(ls_ISBN_EPUBS_UNZIPPED_text);
                                }
                            }
                            else
                            {
                                XmlElement ls_ISBN_EPUBS_ZIPPED = ls_dom.CreateElement("ISBN_EPUBS_ZIPPED");
                                ls_ProductH.AppendChild(ls_ISBN_EPUBS_ZIPPED);
                                XmlText ls_ISBN_EPUBS_ZIPPED_text = ls_dom.CreateTextNode("-");
                                ls_ISBN_EPUBS_ZIPPED.AppendChild(ls_ISBN_EPUBS_ZIPPED_text);
                            }

                            XmlElement ls_EPUB_URL = ls_dom.CreateElement("EPUB_URL");
                            ls_ProductH.AppendChild(ls_EPUB_URL);
                            XmlText ls_EPUB_URL_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + "/" + ls_item_value + ".epub");
                            ls_EPUB_URL.AppendChild(ls_EPUB_URL_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["PRODUCT_SK"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_PRODUCT_SK = ls_dom.CreateElement("PRODUCT_SK");
                            ls_ProductH.AppendChild(ls_PRODUCT_SK);
                            XmlText ls_PRODUCT_SK_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_PRODUCT_SK.AppendChild(ls_PRODUCT_SK_text);

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["AUTHOR_NAME"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_AUTHOR_NAME = ls_dom.CreateElement("AUTHOR_NAME");
                            ls_ProductH.AppendChild(ls_AUTHOR_NAME);
                            XmlText ls_AUTHOR_NAME_text = ls_dom.CreateTextNode(ls_item_value);
                            ls_AUTHOR_NAME.AppendChild(ls_AUTHOR_NAME_text);

                            string ls_WEBSERVICEURL = System.Configuration.ConfigurationManager.AppSettings["WEBSERVICE_URL"];

                            ls_item_value = lds_DataStore.Tables[0].Rows[i]["IMAGE_FILE_NAME"].ToString();
                            ls_item_value = EscapeXMLCharacters(ls_item_value);
                            if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                            XmlElement ls_ImageFileName = ls_dom.CreateElement("IMAGE_FILE_NAME");
                            ls_ProductH.AppendChild(ls_ImageFileName);
                            XmlText ls_ImageFileName_text = ls_dom.CreateTextNode(ls_WEBSERVICEURL + "Thumbnails/" + ls_item_value);
                            ls_ImageFileName.AppendChild(ls_ImageFileName_text);

                            for (int ii = 0; ii <= lds_DataStore.Tables[0].Rows.Count - 1; ii++)
                            {

                                ls_item_value = lds_DataStore.Tables[0].Rows[ii]["ATTRIBUTE_TYPE_ID"].ToString();
                                ls_item_value = EscapeXMLCharacters(ls_item_value);
                                if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                                if (ls_item_value.Equals("COLOUR") || ls_item_value.Equals("Colour Level"))
                                {

                                    ls_item_value = lds_DataStore.Tables[0].Rows[ii]["PRODUCT_ID"].ToString();
                                    ls_item_value = EscapeXMLCharacters(ls_item_value);
                                    if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";

                                    if (ls_product_id.Equals(ls_item_value))
                                    {
                                        ls_item_value = lds_DataStore.Tables[0].Rows[ii]["ATTRIBUTE_TYPE_VALUE"].ToString();
                                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                                        XmlElement ls_Color = ls_dom.CreateElement("COLOUR");
                                        ls_ProductH.AppendChild(ls_Color);
                                        XmlText ls_Color_text = ls_dom.CreateTextNode(ls_item_value);
                                        ls_Color.AppendChild(ls_Color_text);

                                    }
                                }
                            }
                        }
                    }

                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                }
                else
                {
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0012");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                }

                SQLConn.Close();

                return ls_dom;

            }
            catch (Exception exp)
            {
                LogFileWrite(exp);
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                ls_MessageCode.AppendChild(ls_MessageCode_text);
                LogFileWrite(exp);
                SQLConn.Close();

                return ls_dom;

            }

        }


        [WebMethod]
        public XmlDocument GetePubTimeStamp(string as_user_login_name, string as_cust_subs_sk, string information)
        {
            LogArguments("GetBookShelfInfo", as_user_login_name + ";", information);

            //Connection string to connect with database

            //string ls_ConnectionString = "";
            string ls_query = "";
            string ls_item_value;
            string ls_product_id;
            string ls_PHYSICAL_FILE_PATH = System.Configuration.ConfigurationManager.AppSettings["PHYSICAL_FILE_PATH"];
            string ls_WEBSERVICE_URL = System.Configuration.ConfigurationManager.AppSettings["WEBSERVICE_URL"];
            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "GetBookShelfInfo");

            try
            {

                //Open connection with database
                SQLConn.Open();

                ls_query = ls_query + "SELECT PRODUCT_SK,(SELECT * FROM  eComm_Authors_Select(PRODUCT_SK)) AUTHOR_NAME ";
                ls_query = ls_query + "INTO #tmp FROM CEN_PRODUCTS AS P JOIN CEN_MEDIA_TYPES AS MT ";
                ls_query = ls_query + "ON P.MEDIA_TYPE_SK=MT.MEDIA_TYPE_SK ";
                ls_query = ls_query + "WHERE MT.MEDIA_TYPE='ECO' AND P.ACTIVE='Y'; ";
                ls_query = ls_query + "SELECT DISTINCT  p.ISBN_13,p.PRODUCT_SK ";
                ls_query = ls_query + "FROM CEN_USERS u,";
                ls_query = ls_query + "CEN_USER_ROLES ur, CEN_TRADING_PARTNER_USERS tpu,";
                ls_query = ls_query + "CEN_CUSTOMER_SUBS_USERS csu, CEN_CUSTOMER_SUBSCRIPTIONS cs,";
                ls_query = ls_query + "CEN_CUSTOMER_SUBS_ITEMS csi, CEN_PRODUCTS p,";
                ls_query = ls_query + "CEN_PRODUCT_ATTRIBUTE_TYPE_DETAILS patd, CEN_ATTRIBUTE_TYPE_values atv,";
                ls_query = ls_query + "CEN_ATTRIBUTE_TYPES at, CEN_PRODUCT_IMAGES pim, CEN_STUDENT_DETAILS sd1,";
                ls_query = ls_query + "CEN_MEDIA_TYPES MT,#tmp AS T ";
                ls_query = ls_query + "WHERE u.USER_SK = ur.USER_SK  AND ur.USER_ROLE_SK = tpu.USER_ROLE_SK ";
                ls_query = ls_query + "AND tpu.TRAD_PART_USER_SK = csu.TRAD_PART_USER_SK ";
                ls_query = ls_query + "AND csu.CUST_SUBS_SK = cs.CUST_SUBS_SK  AND csi.ACTIVE ='Y'  AND csu.ACTIVE = 'y' ";
                ls_query = ls_query + "AND csi.CUST_SUBS_SK = cs.CUST_SUBS_SK  AND csi.PRODUCT_SK = p.PRODUCT_SK ";
                ls_query = ls_query + "AND p.MEDIA_TYPE_SK=mt.MEDIA_TYPE_SK ";
                ls_query = ls_query + "AND p.PRODUCT_SK = patd.PRODUCT_SK  AND patd.ATTRIBUTE_TYPE_value_SK = atv.ATTRIBUTE_TYPE_value_SK ";
                ls_query = ls_query + "AND atv.ATTRIBUTE_TYPE_SK = at.ATTRIBUTE_TYPE_SK ";
                ls_query = ls_query + "AND AT.ATTRIBUTE_TYPE_ID='GUIDED READING LEVEL' ";
                ls_query = ls_query + "AND p.PRODUCT_SK = pim.PRODUCT_SK  AND pim.IMAGE_TYPE = 'FTCOV' AND T.PRODUCT_SK=P.PRODUCT_SK ";
                //ls_query = ls_query + "AND p.ACTIVE ='Y'  AND MT.MEDIA_TYPE = 'ECO' AND CSi.CUST_SUBS_SK in (" + GetAllUserSubscriptions(as_user_login_name) +") ";
                ls_query = ls_query + "AND p.ACTIVE ='Y'  AND MT.MEDIA_TYPE = 'ECO' AND CSi.CUST_SUBS_SK =" + as_cust_subs_sk;

                ls_query = ls_query + " AND u.USER_LOGIN_NAME='" + as_user_login_name + "'  AND u.user_SK = sd1.user_sk AND  ISNUMERIC(ATV.ATTRIBUTE_TYPE_VALUE)=1 ";
                ls_query = ls_query + "AND CONVERT(float,RTRIM(SUBSTRING(ATV.ATTRIBUTE_TYPE_VALUE,CHARINDEX(' ',ATV.ATTRIBUTE_TYPE_VALUE,1) +1,2))) ";
                ls_query = ls_query + "between sd1.CURRENT_BOOK_READ_LEVEL_FROM and sd1.CURRENT_BOOK_READ_LEVEL_UPTO ";
                ls_query = ls_query + "UNION ";
                ls_query = ls_query + "SELECT DISTINCT p.ISBN_13, p.PRODUCT_SK ";
                ls_query = ls_query + "FROM CEN_USERS u, CEN_USER_ROLES ur,";
                ls_query = ls_query + "CEN_TRADING_PARTNER_USERS tpu, CEN_CUSTOMER_SUBS_USERS csu,";
                ls_query = ls_query + "CEN_CUSTOMER_SUBSCRIPTIONS cs, CEN_CUSTOMER_SUBS_ITEMS csi,";
                ls_query = ls_query + "CEN_PRODUCTS p, CEN_PRODUCT_ATTRIBUTE_TYPE_DETAILS patd,";
                ls_query = ls_query + "CEN_ATTRIBUTE_TYPE_values atv, CEN_ATTRIBUTE_TYPES at,";
                ls_query = ls_query + "CEN_PRODUCT_IMAGES pim, CEN_TEACHER_DETAILS sd1,CEN_MEDIA_TYPES MT,#tmp AS T ";
                ls_query = ls_query + "WHERE u.USER_SK = ur.USER_SK  AND ur.USER_ROLE_SK = tpu.USER_ROLE_SK ";
                ls_query = ls_query + "AND tpu.TRAD_PART_USER_SK = csu.TRAD_PART_USER_SK ";
                ls_query = ls_query + "AND p.MEDIA_TYPE_SK=mt.MEDIA_TYPE_SK ";
                ls_query = ls_query + "AND csu.CUST_SUBS_SK = cs.CUST_SUBS_SK  AND csi.ACTIVE ='Y' ";
                ls_query = ls_query + "AND csu.ACTIVE = 'y'  AND csi.CUST_SUBS_SK = cs.CUST_SUBS_SK ";
                ls_query = ls_query + "AND csi.PRODUCT_SK = p.PRODUCT_SK  AND p.PRODUCT_SK = patd.PRODUCT_SK ";
                ls_query = ls_query + "AND patd.ATTRIBUTE_TYPE_value_SK = atv.ATTRIBUTE_TYPE_value_SK  AND atv.ATTRIBUTE_TYPE_SK = at.ATTRIBUTE_TYPE_SK ";
                ls_query = ls_query + "AND AT.ATTRIBUTE_TYPE_ID='GUIDED READING LEVEL' ";
                ls_query = ls_query + "AND p.PRODUCT_SK = pim.PRODUCT_SK  AND pim.IMAGE_TYPE = 'FTCOV' AND T.PRODUCT_SK=P.PRODUCT_SK ";
                //ls_query = ls_query + "AND p.ACTIVE ='Y'  AND MT.MEDIA_TYPE = 'ECO' AND CSi.CUST_SUBS_SK in (" + GetAllUserSubscriptions(as_user_login_name) +") ";

                ls_query = ls_query + "AND p.ACTIVE ='Y'  AND MT.MEDIA_TYPE = 'ECO' AND CSi.CUST_SUBS_SK =" + as_cust_subs_sk;
                ls_query = ls_query + " AND u.USER_LOGIN_NAME='" + as_user_login_name + "'  AND u.user_SK = sd1.user_sk AND  ISNUMERIC(ATV.ATTRIBUTE_TYPE_VALUE)=1  ";
                ls_query = ls_query + "AND CONVERT(float,RTRIM(SUBSTRING(ATV.ATTRIBUTE_TYPE_VALUE,CHARINDEX(' ',ATV.ATTRIBUTE_TYPE_VALUE,1) +1,2))) ";
                ls_query = ls_query + "between sd1.BOOK_LEVEL_AVAILABLE_FROM and sd1.BOOK_LEVEL_AVAILABLE_UPTO ORDER BY p.PRODUCT_SK ASC; DROP TABLE #tmp;";

                //XmlElement ls_q = ls_dom.CreateElement("Query");
                //ls_Method.AppendChild(ls_q);
                //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query);
                //ls_q.AppendChild(ls_Query_text);

                DataSet lds_DataStore = new DataSet();
                System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                SQLAdapter.Fill(lds_DataStore);

                if (lds_DataStore.Tables[0].Rows.Count > 0)
                {
                    XmlElement ls_Products = ls_dom.CreateElement("PRODUCTS");
                    ls_Method.AppendChild(ls_Products);

                    for (int i = 0; i <= lds_DataStore.Tables[0].Rows.Count - 1; i++)
                    {


                        XmlElement ls_ProductH = ls_dom.CreateElement("PRODUCT");
                        ls_Products.AppendChild(ls_ProductH);

                        ls_item_value = lds_DataStore.Tables[0].Rows[i]["ISBN_13"].ToString();
                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                        XmlElement ls_ISBN_13 = ls_dom.CreateElement("ISBN_13");
                        ls_ProductH.AppendChild(ls_ISBN_13);
                        XmlText ls_ISBN_13_text = ls_dom.CreateTextNode(ls_item_value);
                        ls_ISBN_13.AppendChild(ls_ISBN_13_text);


                        if (File.Exists(ls_PHYSICAL_FILE_PATH + lds_DataStore.Tables[0].Rows[i]["ISBN_13"].ToString() + ".epub"))
                        {
                            XmlElement ls_file1 = ls_dom.CreateElement("EPUB_FILE");
                            ls_ProductH.AppendChild(ls_file1);
                            XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + lds_DataStore.Tables[0].Rows[i]["ISBN_13"].ToString() + ".epub");
                            ls_file1.AppendChild(ls_file1_text);
                            //lboo_preview_pages = true;
                            XmlElement ls_file2 = ls_dom.CreateElement("EPUB_FILE_TIME_STAMP");
                            string ls_ePub_last_modified_time = File.GetLastWriteTime(ls_PHYSICAL_FILE_PATH + lds_DataStore.Tables[0].Rows[i]["ISBN_13"].ToString() + ".epub").ToString("dd/MM/yyyy HH:mm:ss tt");
                            ls_ProductH.AppendChild(ls_file2);
                            XmlText ls_file2_text = ls_dom.CreateTextNode(ls_ePub_last_modified_time);
                            ls_file2.AppendChild(ls_file2_text);
                        }

                    }

                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                }
                else
                {
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0012");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                }

                SQLConn.Close();

                return ls_dom;

            }
            catch (Exception exp)
            {
                LogFileWrite(exp);
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                ls_MessageCode.AppendChild(ls_MessageCode_text);

                SQLConn.Close();

                return ls_dom;

            }
        }

        [WebMethod]
        public XmlDocument DeleteMyWord(string as_SESS_HIST_MY_WORDS_SK, string information)
        {
            LogArguments("DeleteMyWord", as_SESS_HIST_MY_WORDS_SK + ";", information);
            //Connection string to connect with database 
            //string ls_ConnectionString = "";
            String ls_update_statement, ls_query, ls_product_sk, ls_word, ls_user_created;

            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "DeleteMyWord");

            //Open connection with database
            ls_query = "SELECT PRODUCT_SK,WORD,USER_CREATED from CEN_SESS_HIST_MY_WORDS where SESS_HIST_MY_WORDS_SK = " + as_SESS_HIST_MY_WORDS_SK;

            //XmlElement ls_q = ls_dom.CreateElement("Query");
            //ls_Method.AppendChild(ls_q);
            //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query);
            //ls_q.AppendChild(ls_Query_text);

            SQLConn.Open();

            DataSet lds_DataStore = new DataSet();
            System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
            SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
            SQLAdapter.Fill(lds_DataStore);

            if (lds_DataStore.Tables[0].Rows.Count == 1)
            {

                ls_product_sk = lds_DataStore.Tables[0].Rows[0]["product_sk"].ToString();
                ls_word = lds_DataStore.Tables[0].Rows[0]["WORD"].ToString();
                ls_user_created = lds_DataStore.Tables[0].Rows[0]["USER_CREATED"].ToString();

                ls_update_statement = "UPDATE CEN_SESS_HIST_MY_WORDS SET ACTIVE = 'N' WHERE PRODUCT_SK = " + ls_product_sk + " AND WORD = '" + ls_word + "' AND USER_CREATED = '" + ls_user_created + "'";

                //SqlParameter ls_param1 = new SqlParameter();
                //ls_param1.ParameterName = "@PRODUCT_SK";
                //ls_param1.Value = ls_product_sk;

                //SqlParameter ls_param2 = new SqlParameter();
                //ls_param2.ParameterName = "@WORD";
                //ls_param2.Value = ls_word;

                using (SQLConn)
                {
                    SqlCommand command = new SqlCommand(ls_update_statement, SQLConn);
                    //command.Parameters.Add(ls_param1);
                    //command.Parameters.Add(ls_param2);

                    //XmlElement ls_q = ls_dom.CreateElement("Query");
                    //ls_Method.AppendChild(ls_q);
                    //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_update_statement);
                    //ls_q.AppendChild(ls_Query_text);

                    //command.Connection.Open();

                    try
                    {
                        command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                        command.ExecuteNonQuery();
                        command.Connection.Close();

                        XmlElement ls_Error = ls_dom.CreateElement("Error");
                        ls_Method.AppendChild(ls_Error);
                        XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                        ls_Error.AppendChild(ls_ErrorCode);
                        XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                        ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                        XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                        ls_Error.AppendChild(ls_ErrorDescription);
                        XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                        ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                        XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                        ls_Method.AppendChild(ls_DisplayCustomMessage);
                        XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                        ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                        XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                        ls_Method.AppendChild(ls_MessageCode);
                        XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                        ls_MessageCode.AppendChild(ls_MessageCode_text);

                        SQLConn.Close();

                        return ls_dom;

                    }
                    catch (Exception exp)
                    {
                        XmlElement ls_Error = ls_dom.CreateElement("Error");
                        ls_Method.AppendChild(ls_Error);
                        XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                        ls_Error.AppendChild(ls_ErrorCode);
                        XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                        ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                        XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                        ls_Error.AppendChild(ls_ErrorDescription);
                        XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                        ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                        XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                        ls_Method.AppendChild(ls_DisplayCustomMessage);
                        XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                        ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                        XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                        ls_Method.AppendChild(ls_MessageCode);
                        XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                        ls_MessageCode.AppendChild(ls_MessageCode_text);

                        SQLConn.Close();

                        return ls_dom;
                    }
                }
            }
            else
            {
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                ls_MessageCode.AppendChild(ls_MessageCode_text);

                SQLConn.Close();

                return ls_dom;
            }
        }

        [WebMethod]
        public XmlDocument GetBookPreviewPages(string as_book_isbn, string information)
        {
            LogArguments("GetBookPreviewPages", as_book_isbn + ";", information);
            Boolean lboo_preview_pages = false;

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "GetBookPreviewPages");
            XmlElement ls_file = ls_dom.CreateElement("PreviewFiles");
            ls_Method.AppendChild(ls_file);

            string ls_PHYSICAL_FILE_PATH = System.Configuration.ConfigurationManager.AppSettings["PHYSICAL_FILE_PATH"];
            string ls_WEBSERVICE_URL = System.Configuration.ConfigurationManager.AppSettings["WEBSERVICE_URL"];

            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/cover.xhtml"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("File");
                ls_file.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/cover.xhtml");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
            }

            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/Title_TOC.xhtml"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("File");
                ls_file.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/Title_TOC.xhtml");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
            }

            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/glossary.xhtml"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("File");
                ls_file.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/glossary.xhtml");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
            }

            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/index.xhtml"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("File");
                ls_file.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/index.xhtml");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
            }

            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/back.xhtml"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("File");
                ls_file.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/back.xhtml");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
            }
            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + ".epub"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("EPUB_FILE");
                ls_file.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + ".epub");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
                XmlElement ls_file2 = ls_dom.CreateElement("EPUB_FILE_TIME_STAMP");
                string ls_ePub_last_modified_time = File.GetLastWriteTime(ls_PHYSICAL_FILE_PATH + as_book_isbn + ".epub").ToString("dd/MM/yyyy HH:mm:ss tt");
                ls_file.AppendChild(ls_file2);
                XmlText ls_file2_text = ls_dom.CreateTextNode(ls_ePub_last_modified_time);
                ls_file2.AppendChild(ls_file2_text);
            }

            XmlElement ls_Error = ls_dom.CreateElement("Error");
            ls_Method.AppendChild(ls_Error);
            XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");

            ls_Error.AppendChild(ls_ErrorCode);
            if (!lboo_preview_pages)
            {
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0018");
                ls_MessageCode.AppendChild(ls_MessageCode_text);
            }
            else
            {
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                ls_MessageCode.AppendChild(ls_MessageCode_text);
            }

            return ls_dom;

        }

        [WebMethod]
        public XmlDocument GetePubDetails(string as_book_isbn, string as_product_sk, string information)
        {
            LogArguments("GetePubDetails", as_book_isbn + ";" + as_product_sk, information);
            Boolean lboo_preview_pages = false;
            string ls_query, ls_item_value;

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "GetePubDetails");

            XmlElement ls_file = ls_dom.CreateElement("ContentFiles");
            ls_Method.AppendChild(ls_file);

            XmlElement ls_non_content_file = ls_dom.CreateElement("NonContentFiles");
            ls_Method.AppendChild(ls_non_content_file);

            XmlElement ls_smil_file = ls_dom.CreateElement("SmilFiles");
            ls_Method.AppendChild(ls_smil_file);

            string ls_PHYSICAL_FILE_PATH = System.Configuration.ConfigurationManager.AppSettings["PHYSICAL_FILE_PATH"];
            string ls_WEBSERVICE_URL = System.Configuration.ConfigurationManager.AppSettings["WEBSERVICE_URL"];

            {
                string ls_audio_file_path = ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/";
                XmlElement ls_audio_file_path_node = ls_dom.CreateElement("AUDIO_FILE_PATH");
                ls_Method.AppendChild(ls_audio_file_path_node);
                XmlText ls_audio_file_path_node_value = ls_dom.CreateTextNode(ls_audio_file_path);
                ls_audio_file_path_node.AppendChild(ls_audio_file_path_node_value);
            }

            {
                XmlElement ls_file1 = ls_dom.CreateElement("REPLACE_FILE_PATH_VALUE");
                ls_Method.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL);
                ls_file1.AppendChild(ls_file1_text);
            }

            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + ".epub"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("EPUB_FILE");
                ls_Method.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + ".epub");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
                XmlElement ls_file2 = ls_dom.CreateElement("EPUB_FILE_TIME_STAMP");
                string ls_ePub_last_modified_time = File.GetLastWriteTime(ls_PHYSICAL_FILE_PATH + as_book_isbn + ".epub").ToString("dd/MM/yyyy HH:mm:ss tt");
                ls_Method.AppendChild(ls_file2);
                XmlText ls_file2_text = ls_dom.CreateTextNode(ls_ePub_last_modified_time);
                ls_file2.AppendChild(ls_file2_text);
            }

            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/" + as_book_isbn + ".opf"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("OPF");
                ls_Method.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/" + as_book_isbn + ".opf");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
            }

            //Cover
            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/cover.xhtml"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("File");
                ls_non_content_file.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/cover.xhtml");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
            }

            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/cover.xhtml"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("File");
                ls_file.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/cover.xhtml");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
            }


            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/cover.smil"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("File");
                ls_smil_file.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/cover.smil");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
            }

            //Title
            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/title.xhtml"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("File");
                ls_non_content_file.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/title.xhtml");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
            }

            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/title.xhtml"))
            {
                if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/title.xhtml"))
                {
                    XmlElement ls_file1 = ls_dom.CreateElement("File");
                    ls_file.AppendChild(ls_file1);
                    XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/title.xhtml");
                    ls_file1.AppendChild(ls_file1_text);
                    lboo_preview_pages = true;
                }
            }

            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/title.xhtml"))
            {
                if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/title.smil"))
                {
                    XmlElement ls_file1 = ls_dom.CreateElement("File");
                    ls_smil_file.AppendChild(ls_file1);
                    XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/title.smil");
                    ls_file1.AppendChild(ls_file1_text);
                    lboo_preview_pages = true;
                }
            }
            //TOC
            //if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/Title_TOC.xhtml"))
            //{
            //    XmlElement ls_file1 = ls_dom.CreateElement("File");
            //    ls_non_content_file.AppendChild(ls_file1);
            //    XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/Title_TOC.xhtml");
            //    ls_file1.AppendChild(ls_file1_text);
            //    lboo_preview_pages = true;
            //}

            //if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/Title_TOC.xhtml"))
            //{
            //    XmlElement ls_file1 = ls_dom.CreateElement("File");
            //    ls_file.AppendChild(ls_file1);
            //    XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/Title_TOC.xhtml");
            //    ls_file1.AppendChild(ls_file1_text);
            //    lboo_preview_pages = true;
            //}

            //if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/Title_TOC.smil"))
            //{
            //    XmlElement ls_file1 = ls_dom.CreateElement("File");
            //    ls_smil_file.AppendChild(ls_file1);
            //    XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/Title_TOC.smil");
            //    ls_file1.AppendChild(ls_file1_text);
            //    lboo_preview_pages = true;
            //}
            string[] tocFiles = Directory.GetFiles(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/", "*_toc.xhtml");
            if (tocFiles.Length > 0)
            {
                string tocPath = Path.GetFileName(tocFiles[0]);
                if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/" + tocPath))
                {
                    XmlElement ls_file1 = ls_dom.CreateElement("File");
                    ls_non_content_file.AppendChild(ls_file1);
                    XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/" + tocPath);
                    ls_file1.AppendChild(ls_file1_text);
                    lboo_preview_pages = true;
                }

                if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/" + tocPath))
                {
                    XmlElement ls_file1 = ls_dom.CreateElement("File");
                    ls_file.AppendChild(ls_file1);
                    XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/" + tocPath);
                    ls_file1.AppendChild(ls_file1_text);
                    lboo_preview_pages = true;
                }
            }
            string[] tocFiles1 = Directory.GetFiles(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/", "*_toc.smil");
            if (tocFiles1.Length > 0)
            {
                string tocPath = Path.GetFileName(tocFiles1[0]);
                if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/" + tocPath))
                {
                    XmlElement ls_file1 = ls_dom.CreateElement("File");
                    ls_smil_file.AppendChild(ls_file1);
                    XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/" + tocPath);
                    ls_file1.AppendChild(ls_file1_text);
                    lboo_preview_pages = true;
                }
            }

            //else
            //{
            //    XmlElement ls_file1 = ls_dom.CreateElement("File");
            //    ls_smil_file.AppendChild(ls_file1);
            //    XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + "empty.smil");
            //    ls_file1.AppendChild(ls_file1_text);
            //    lboo_preview_pages = true;
            //}

            //Credits
            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/credits.xhtml"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("File");
                ls_non_content_file.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/credits.xhtml");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
            }

            //Teacher Notes
            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/tnotes.xhtml"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("File");
                ls_non_content_file.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/tnotes.xhtml");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
            }

            string ls_pad = "";

            for (int i = 2; i < 50; i++)
            {

                if (i < 9)
                    ls_pad = "00";

                if (i > 9)
                    ls_pad = "0";
                string s = ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/" + ls_pad + i.ToString() + ".xhtml";

                if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/page" + ls_pad + i.ToString() + ".xhtml"))
                {
                    XmlElement ls_file1 = ls_dom.CreateElement("File");
                    ls_file.AppendChild(ls_file1);
                    XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/page" + ls_pad + i.ToString() + ".xhtml");
                    ls_file1.AppendChild(ls_file1_text);
                    lboo_preview_pages = true;

                    if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/page" + ls_pad + i.ToString() + ".smil"))
                    {
                        XmlElement ls_file2 = ls_dom.CreateElement("File");
                        ls_smil_file.AppendChild(ls_file2);
                        XmlText ls_file2_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/page" + ls_pad + i.ToString() + ".smil");
                        ls_file2.AppendChild(ls_file2_text);
                        lboo_preview_pages = true;
                    }

                }
                /*
                else
                {
                    break;
                }
                */
            }

            //Glossary
            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/Glossary.xhtml"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("File");
                ls_non_content_file.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/Glossary.xhtml");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;

                if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/Glossary.xhtml"))
                {
                    XmlElement ls_file2 = ls_dom.CreateElement("File");
                    ls_file.AppendChild(ls_file2);
                    XmlText ls_file2_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/Glossary.xhtml");
                    ls_file2.AppendChild(ls_file2_text);
                    lboo_preview_pages = true;
                }

                if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/Glossary.smil"))
                {
                    XmlElement ls_file3 = ls_dom.CreateElement("File");
                    ls_smil_file.AppendChild(ls_file3);
                    XmlText ls_file3_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/Glossary.smil");
                    ls_file3.AppendChild(ls_file3_text);
                    lboo_preview_pages = true;
                }
                else
                {
                    XmlElement ls_file4 = ls_dom.CreateElement("File");
                    ls_smil_file.AppendChild(ls_file4);
                    XmlText ls_file4_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + "empty.smil");
                    ls_file4.AppendChild(ls_file4_text);
                    lboo_preview_pages = true;
                }
            }



            //Back Cover
            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/back.xhtml"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("File");
                ls_non_content_file.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/back.xhtml");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
            }

            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/back.xhtml"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("File");
                ls_file.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/back.xhtml");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
            }

            if (File.Exists(ls_PHYSICAL_FILE_PATH + as_book_isbn + "/OEBPS/back.smil"))
            {
                XmlElement ls_file1 = ls_dom.CreateElement("File");
                ls_smil_file.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/back.smil");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
            }
            else
            {
                XmlElement ls_file1 = ls_dom.CreateElement("File");
                ls_smil_file.AppendChild(ls_file1);
                XmlText ls_file1_text = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + "empty.smil");
                ls_file1.AppendChild(ls_file1_text);
                lboo_preview_pages = true;
            }

            XmlElement ls_page_audio = ls_dom.CreateElement("PageAudioFiles");
            ls_Method.AppendChild(ls_page_audio);

            ls_query = "SELECT ";
            ls_query = ls_query + "page_audio_file_name ";
            ls_query = ls_query + "FROM ";
            ls_query = ls_query + "CEN_IPAD_APP_PAGE_AUDIO CIAPA ";
            ls_query = ls_query + "WHERE ";
            ls_query = ls_query + "CIAPA.ISBN_13 = '" + as_book_isbn + "'";

            //XmlElement ls_q = ls_dom.CreateElement("Query");
            //ls_Method.AppendChild(ls_q);
            //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query);
            //ls_q.AppendChild(ls_Query_text);

            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);
            DataSet lds_DataStore = new DataSet();
            System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
            SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
            SQLAdapter.Fill(lds_DataStore);

            try
            {
                if (lds_DataStore.Tables[0].Rows.Count > 0)
                {
                    for (int ii = 0; ii <= lds_DataStore.Tables[0].Rows.Count - 1; ii++)
                    {

                        ls_item_value = lds_DataStore.Tables[0].Rows[ii]["page_audio_file_name"].ToString();
                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                        XmlElement ls_PageNo = ls_dom.CreateElement("Page" + ii.ToString());
                        ls_page_audio.AppendChild(ls_PageNo);
                        XmlText ls_page_audio_file_name = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/audio/page/" + ls_item_value.Trim());
                        ls_PageNo.AppendChild(ls_page_audio_file_name);
                    }

                }
            }
            catch (System.Xml.XmlException e)
            {
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0019");
                ls_MessageCode.AppendChild(ls_MessageCode_text);
            }

            XmlElement ls_word_audio = ls_dom.CreateElement("WordAudioFiles");
            ls_Method.AppendChild(ls_word_audio);

            ls_query = "";
            ls_query = "SELECT ";
            ls_query = ls_query + "WORD_NAME,WORD_AUDIO_FILE_NAME ";
            ls_query = ls_query + "FROM ";
            ls_query = ls_query + "CEN_IPAD_APP_WORD_AUDIO CIAWA ";
            ls_query = ls_query + "WHERE ";
            ls_query = ls_query + "CIAWA.ISBN_13 = '" + as_book_isbn + "'";

            //XmlElement ls_q1 = ls_dom.CreateElement("Query1");
            //ls_Method.AppendChild(ls_q1);
            //XmlText ls_Query_text1 = ls_dom.CreateTextNode(ls_query);
            //ls_q1.AppendChild(ls_Query_text1);

            DataSet lds_DataStore1 = new DataSet();
            System.Data.SqlClient.SqlDataAdapter SQLAdapter1 = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
            SQLAdapter1.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
            SQLAdapter1.Fill(lds_DataStore1);

            if (lds_DataStore1.Tables[0].Rows.Count > 0)
            {
                for (int ii = 0; ii <= lds_DataStore1.Tables[0].Rows.Count - 1; ii++)
                {

                    ls_item_value = lds_DataStore1.Tables[0].Rows[ii]["WORD_NAME"].ToString().Trim();
                    ls_item_value = EscapeForXMLNodeName(ls_item_value);
                    if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                    XmlElement ls_Word = ls_dom.CreateElement(ls_item_value);
                    ls_word_audio.AppendChild(ls_Word);

                    ls_item_value = lds_DataStore1.Tables[0].Rows[ii]["WORD_AUDIO_FILE_NAME"].ToString().Trim();
                    //ls_item_value = EscapeForXMLNodeName(ls_item_value);
                    XmlText ls_word_audio_file_name = ls_dom.CreateTextNode(ls_WEBSERVICE_URL + as_book_isbn + "/OEBPS/audio/word/" + ls_item_value.Trim());
                    ls_Word.AppendChild(ls_word_audio_file_name);

                }

            }

            if (!lboo_preview_pages)
            {
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("1");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0019");
                ls_MessageCode.AppendChild(ls_MessageCode_text);
            }
            else
            {
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                ls_MessageCode.AppendChild(ls_MessageCode_text);
            }

            return ls_dom;

        }

        [WebMethod]
        public XmlDocument SetMyWord(string as_sess_hist_sk, string as_product_sk, string as_word, string as_word_circled_time, string as_user_id, string information)
        {
            LogArguments("SetMyWord", as_sess_hist_sk + ";" + as_product_sk + ";" + as_word + ";" + as_word_circled_time + ";" + as_user_id, information);

            string ls_query = "";
            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "SetMyWord");

            ls_query = "INSERT INTO CEN_SESS_HIST_MY_WORDS (SESS_HIST_SK,WORD,WORD_CIRCLED_AT,IS_CLEARED_FROM_IPAD,ACTIVE,DATE_CREATED,USER_CREATED,PRODUCT_SK) VALUES (@txt1,@txt2,@txt3,@txt4,@txt5,@txt6,@txt7,@txt8)";
            string ls_insert_statement = "INSERT INTO CEN_SESS_HIST_MY_WORDS (SESS_HIST_SK,WORD,WORD_CIRCLED_AT,IS_CLEARED_FROM_IPAD,ACTIVE,DATE_CREATED,USER_CREATED,PRODUCT_SK) VALUES (" + as_sess_hist_sk + ",'" + as_word + "','" + DateTime.Today + "','N','Y','" + DateTime.Today + "','" + as_user_id + "'," + as_product_sk + ")";

            SqlParameter ls_param1 = new SqlParameter();
            ls_param1.ParameterName = "@txt1";
            ls_param1.Value = Convert.ToInt32(as_sess_hist_sk);

            SqlParameter ls_param2 = new SqlParameter();
            ls_param2.ParameterName = "@txt2";
            ls_param2.Value = EscapeSQLCharacters(as_word);
            //ls_param2.Value = as_word;

            SqlParameter ls_param3 = new SqlParameter();
            ls_param3.ParameterName = "@txt3";
            ls_param3.Value = DateTime.Today;

            SqlParameter ls_param4 = new SqlParameter();
            ls_param4.ParameterName = "@txt4";
            ls_param4.Value = "N";

            SqlParameter ls_param5 = new SqlParameter();
            ls_param5.ParameterName = "@txt5";
            ls_param5.Value = "Y";

            SqlParameter ls_param6 = new SqlParameter();
            ls_param6.ParameterName = "@txt6";
            ls_param6.Value = DateTime.Today;

            SqlParameter ls_param7 = new SqlParameter();
            ls_param7.ParameterName = "@txt7";
            ls_param7.Value = as_user_id;

            SqlParameter ls_param8 = new SqlParameter();
            ls_param8.ParameterName = "@txt8";
            ls_param8.Value = Convert.ToInt32(as_product_sk);

            using (SqlConnection connection = new SqlConnection(ls_ConnectionString))
            {
                SqlCommand command = new SqlCommand(ls_query, connection);
                command.Parameters.Add(ls_param1);
                command.Parameters.Add(ls_param2);
                command.Parameters.Add(ls_param3);
                command.Parameters.Add(ls_param4);
                command.Parameters.Add(ls_param5);
                command.Parameters.Add(ls_param6);
                command.Parameters.Add(ls_param7);
                command.Parameters.Add(ls_param8);
                command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                command.Connection.Open();

                try
                {
                    command.ExecuteNonQuery();

                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    command.Connection.Close();

                }

                catch (Exception exp)
                {
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_insert_statement);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    SendMail("Exception in iPad Web Services", exp.Source + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                    return ls_dom;
                }

                return ls_dom;
            }

        }

        [WebMethod]
        public XmlDocument SetMyWordWithISBN(string as_sess_hist_sk, string as_product_sk, string as_word, string as_word_circled_time, string as_user_id, string as_isbn_13, string information)
        {
            LogArguments("SetMyWord", as_sess_hist_sk + ";" + as_product_sk + ";" + as_word + ";" + as_word_circled_time + ";" + as_user_id, information);

            string ls_query = "";
            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "SetMyWord");

            ls_query = "INSERT INTO CEN_SESS_HIST_MY_WORDS (SESS_HIST_SK,WORD,WORD_CIRCLED_AT,IS_CLEARED_FROM_IPAD,ACTIVE,DATE_CREATED,USER_CREATED,PRODUCT_SK,ISBN_13) VALUES (@txt1,@txt2,@txt3,@txt4,@txt5,@txt6,@txt7,@txt8,@txt9)";
            string ls_insert_statement = "INSERT INTO CEN_SESS_HIST_MY_WORDS (SESS_HIST_SK,WORD,WORD_CIRCLED_AT,IS_CLEARED_FROM_IPAD,ACTIVE,DATE_CREATED,USER_CREATED,PRODUCT_SK) VALUES (" + as_sess_hist_sk + ",'" + as_word + "','" + DateTime.Today + "','N','Y','" + DateTime.Today + "','" + as_user_id + "'," + as_product_sk + ")";

            SqlParameter ls_param1 = new SqlParameter();
            ls_param1.ParameterName = "@txt1";
            ls_param1.Value = Convert.ToInt32(as_sess_hist_sk);

            SqlParameter ls_param2 = new SqlParameter();
            ls_param2.ParameterName = "@txt2";
            ls_param2.Value = EscapeSQLCharacters(as_word);
            //ls_param2.Value = as_word;

            SqlParameter ls_param3 = new SqlParameter();
            ls_param3.ParameterName = "@txt3";
            ls_param3.Value = DateTime.Today;

            SqlParameter ls_param4 = new SqlParameter();
            ls_param4.ParameterName = "@txt4";
            ls_param4.Value = "N";

            SqlParameter ls_param5 = new SqlParameter();
            ls_param5.ParameterName = "@txt5";
            ls_param5.Value = "Y";

            SqlParameter ls_param6 = new SqlParameter();
            ls_param6.ParameterName = "@txt6";
            ls_param6.Value = DateTime.Today;

            SqlParameter ls_param7 = new SqlParameter();
            ls_param7.ParameterName = "@txt7";
            ls_param7.Value = as_user_id;

            SqlParameter ls_param8 = new SqlParameter();
            ls_param8.ParameterName = "@txt8";
            ls_param8.Value = Convert.ToInt32(as_product_sk);

            SqlParameter ls_param9 = new SqlParameter();
            ls_param9.ParameterName = "@txt9";
            ls_param9.Value = as_isbn_13;

            using (SqlConnection connection = new SqlConnection(ls_ConnectionString))
            {
                SqlCommand command = new SqlCommand(ls_query, connection);
                command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                command.Parameters.Add(ls_param1);
                command.Parameters.Add(ls_param2);
                command.Parameters.Add(ls_param3);
                command.Parameters.Add(ls_param4);
                command.Parameters.Add(ls_param5);
                command.Parameters.Add(ls_param6);
                command.Parameters.Add(ls_param7);
                command.Parameters.Add(ls_param8);
                command.Parameters.Add(ls_param9);

                command.Connection.Open();

                try
                {
                    command.ExecuteNonQuery();

                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    command.Connection.Close();

                }

                catch (Exception exp)
                {
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_insert_statement);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    SendMail("Exception in iPad Web Services", exp.Source + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                    return ls_dom;
                }

                return ls_dom;
            }

        }

        [WebMethod]
        public XmlDocument SetMyEdit(string as_sess_hist_sk, string as_page_name, string as_edited_text, string as_user_id, string information)
        {

            //SendMail("Incoming Edit String", as_edited_text, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"]);
            LogArguments("SetMyEdit", as_sess_hist_sk + ";" + as_page_name + ";" + as_edited_text + ";" + as_user_id, information);

            string ls_sql_statement, ls_query;
            Boolean lb_new_mode = false;

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "SetMyEdit");

            if (as_sess_hist_sk.Length == 0 || as_sess_hist_sk.Equals(System.DBNull.Value))
                as_sess_hist_sk = "0";

            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            try
            {

                //Open connection with database
                SQLConn.Open();

                ls_query = "SELECT SESS_HIST_SK,PAGENAME,CONTENTS,ACTIVE FROM CEN_SESS_HIST_MY_EDITS WHERE SESS_HIST_SK = " + as_sess_hist_sk + " AND PAGENAME = '" + as_page_name + "' AND USER_CREATED = '" + as_user_id + "'";
                DataSet lds_DataStore = new DataSet();
                System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                SQLAdapter.Fill(lds_DataStore);

                //string ls_query1 = "SELECT SESS_HIST_SK,PAGENAME,CONTENTS,ACTIVE FROM CEN_SESS_HIST_MY_EDITS WHERE SESS_HIST_SK = " + as_sess_hist_sk + " AND PAGENAME = '" + as_page_name + "' AND USER_CREATED = '" + as_user_id + "'";
                //XmlElement ls_q = ls_dom.CreateElement("Query");
                //ls_Method.AppendChild(ls_q);
                //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query1);
                //ls_q.AppendChild(ls_Query_text);

                if (lds_DataStore.Tables[0].Rows.Count == 0)
                {
                    lb_new_mode = true;
                }
                else
                {
                    lb_new_mode = false;
                }

                //string ls_query1 = "INSERT INTO CEN_SESS_HIST_MY_EDITS (SESS_HIST_SK,PAGENAME,CONTENTS,ACTIVE,DATE_CREATED,USER_CREATED) VALUES " + "(" + "" + ",'" + as_page_name + "','" + as_edited_text + "'," + "'Y'" + ",'" + DateTime.Today + "','" + as_user_id + "')"; 
                //XmlElement ls_q = ls_dom.CreateElement("Query");
                //ls_Method.AppendChild(ls_q);
                //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query1);
                //ls_q.AppendChild(ls_Query_text);

                //XmlElement ls_sess_hist_sk = ls_dom.CreateElement("as_sess_hist_sk");
                //ls_Method.AppendChild(ls_sess_hist_sk);
                //XmlText ls_sess_hist_sk_text = ls_dom.CreateTextNode(as_sess_hist_sk);
                //ls_sess_hist_sk.AppendChild(ls_sess_hist_sk_text);


                using (SqlConnection connection = new SqlConnection(ls_ConnectionString))
                {

                    if (lb_new_mode)
                    {
                        ls_sql_statement = "INSERT INTO CEN_SESS_HIST_MY_EDITS (SESS_HIST_SK,PAGENAME,CONTENTS,ACTIVE,DATE_CREATED,USER_CREATED) VALUES (@txt1,@txt2,@txt3,@txt4,@txt5,@txt6)";

                        SqlCommand command = new SqlCommand(ls_sql_statement, connection);

                        SqlParameter ls_param1 = new SqlParameter();
                        ls_param1.ParameterName = "@txt1";
                        ls_param1.Value = as_sess_hist_sk;

                        SqlParameter ls_param2 = new SqlParameter();
                        ls_param2.ParameterName = "@txt2";
                        ls_param2.Value = as_page_name;

                        SqlParameter ls_param3 = new SqlParameter();
                        ls_param3.ParameterName = "@txt3";
                        ls_param3.Value = EscapeSQLCharacters(as_edited_text);

                        SqlParameter ls_param4 = new SqlParameter();
                        ls_param4.ParameterName = "@txt4";
                        ls_param4.Value = "Y";

                        SqlParameter ls_param5 = new SqlParameter();
                        ls_param5.ParameterName = "@txt5";
                        ls_param5.Value = DateTime.Today;

                        SqlParameter ls_param6 = new SqlParameter();
                        ls_param6.ParameterName = "@txt6";
                        ls_param6.Value = as_user_id;
                        command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                        command.Parameters.Add(ls_param1);
                        command.Parameters.Add(ls_param2);
                        command.Parameters.Add(ls_param3);
                        command.Parameters.Add(ls_param4);
                        command.Parameters.Add(ls_param5);
                        command.Parameters.Add(ls_param6);

                        command.Connection.Open();
                        command.ExecuteNonQuery();
                        command.Connection.Close();

                    }
                    else
                    {
                        ls_sql_statement = "UPDATE CEN_SESS_HIST_MY_EDITS SET CONTENTS = '" + as_edited_text + "' WHERE USER_CREATED = '" + as_user_id + "' AND SESS_HIST_SK = " + as_sess_hist_sk + " And PAGENAME = '" + as_page_name + "'";
                        //XmlElement ls_sess_hist_sk = ls_dom.CreateElement("ls_sql_statement");
                        //ls_Method.AppendChild(ls_sess_hist_sk);
                        //XmlText ls_sess_hist_sk_text = ls_dom.CreateTextNode(ls_sql_statement);
                        //ls_sess_hist_sk.AppendChild(ls_sess_hist_sk_text);
                        SqlCommand command = new SqlCommand(ls_sql_statement, connection);
                        command.Connection.Open();
                        command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                        command.ExecuteNonQuery();
                        command.Connection.Close();

                    }

                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                }
            }
            catch (Exception exp)
            {
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.StackTrace);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                ls_MessageCode.AppendChild(ls_MessageCode_text);

                SendMail("Exception in iPad Web Services", exp.Source + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                return ls_dom;
            }

            return ls_dom;
        }

        [WebMethod]
        public XmlDocument SetMyRecording(string as_sess_hist_sk, string as_page_name, string as_file_content, string as_record_start_time, string as_record_end_time, string as_user_id, string information)
        {
            LogArguments("SetMyRecording", as_sess_hist_sk + ";" + as_page_name + ";" + as_record_start_time + ";" + as_record_end_time + ";" + as_user_id, information);

            string ls_sql_statement, ls_query;
            Boolean lb_new_mode = false;

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "SetMyRecording");

            if (as_sess_hist_sk.Length == 0 || as_sess_hist_sk.Equals(System.DBNull.Value))
                as_sess_hist_sk = "0";

            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            try
            {

                //Open connection with database
                SQLConn.Open();

                ls_query = "SELECT SESS_HIST_SK,PAGE_NAME,RCRD_FILE_PATH FROM CEN_SESS_HIST_MY_RECORDINGS WHERE PAGE_NAME = '" + as_page_name + "' AND USER_CREATED = '" + as_user_id + "' AND SESS_HIST_SK = " + as_sess_hist_sk;
                DataSet lds_DataStore = new DataSet();
                System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                SQLAdapter.Fill(lds_DataStore);

                //XmlElement ls_q = ls_dom.CreateElement("Query");
                //ls_Method.AppendChild(ls_q);
                //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query);
                //ls_q.AppendChild(ls_Query_text);

                if (lds_DataStore.Tables[0].Rows.Count == 0)
                {
                    lb_new_mode = true;
                }
                else
                {
                    lb_new_mode = false;
                }

                using (SqlConnection connection = new SqlConnection(ls_ConnectionString))
                {
                    string ls_recording_filepath = System.Configuration.ConfigurationManager.AppSettings["recording_file_path"];

                    if (lb_new_mode)
                    {
                        ls_sql_statement = "INSERT INTO CEN_SESS_HIST_MY_RECORDINGS (SESS_HIST_SK,PAGE_NAME,RCRD_START_TIME,RCRD_END_TIME,RCRD_FILE_PATH,ACTIVE,DATE_CREATED,USER_CREATED) VALUES (@txt1,@txt2,@txt3,@txt4,@txt5,@txt6,@txt7,@txt8)";

                        SqlCommand command = new SqlCommand(ls_sql_statement, connection);

                        SqlParameter ls_param1 = new SqlParameter();
                        ls_param1.ParameterName = "@txt1";
                        ls_param1.Value = as_sess_hist_sk;

                        SqlParameter ls_param2 = new SqlParameter();
                        ls_param2.ParameterName = "@txt2";
                        ls_param2.Value = as_page_name;

                        SqlParameter ls_param3 = new SqlParameter();
                        ls_param3.ParameterName = "@txt3";
                        ls_param3.Value = DateTime.Today;// Convert.ToDateTime(as_record_start_time);

                        SqlParameter ls_param4 = new SqlParameter();
                        ls_param4.ParameterName = "@txt4";
                        ls_param4.Value = DateTime.Today;// Convert.ToDateTime(as_record_end_time);

                        SqlParameter ls_param5 = new SqlParameter();
                        ls_param5.ParameterName = "@txt5";
                        //ls_param5.Value = as_file_content;
                        ls_param5.Value = as_user_id + as_page_name + as_sess_hist_sk + ".txt";

                        System.IO.StreamWriter file = new System.IO.StreamWriter(ls_recording_filepath + ls_param5.Value);
                        file.WriteLine(as_file_content);
                        file.Close();

                        SqlParameter ls_param6 = new SqlParameter();
                        ls_param6.ParameterName = "@txt6";
                        ls_param6.Value = "Y";

                        SqlParameter ls_param7 = new SqlParameter();
                        ls_param7.ParameterName = "@txt7";
                        ls_param7.Value = DateTime.Today;

                        SqlParameter ls_param8 = new SqlParameter();
                        ls_param8.ParameterName = "@txt8";
                        ls_param8.Value = as_user_id;
                        command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                        command.Parameters.Add(ls_param1);
                        command.Parameters.Add(ls_param2);
                        command.Parameters.Add(ls_param3);
                        command.Parameters.Add(ls_param4);
                        command.Parameters.Add(ls_param5);
                        command.Parameters.Add(ls_param6);
                        command.Parameters.Add(ls_param7);
                        command.Parameters.Add(ls_param8);

                        command.Connection.Open();
                        command.ExecuteNonQuery();
                        command.Connection.Close();

                    }
                    else
                    {

                        string ls_file_name = as_user_id + as_page_name + as_sess_hist_sk + ".txt";
                        string ls_recording_file = ls_recording_filepath + ls_file_name;

                        if (System.IO.File.Exists(ls_recording_file))
                        {
                            try
                            {
                                System.IO.File.Delete(ls_recording_file);

                                System.IO.StreamWriter file = new System.IO.StreamWriter(ls_recording_file);
                                file.WriteLine(as_file_content);
                                file.Close();

                            }
                            catch (System.IO.IOException e)
                            {


                            }
                        }
                        else
                        {
                            System.IO.StreamWriter file = new System.IO.StreamWriter(ls_recording_file);
                            file.WriteLine(as_file_content);
                            file.Close();
                        }

                        ls_sql_statement = "UPDATE CEN_SESS_HIST_MY_RECORDINGS SET RCRD_FILE_PATH = '" + ls_file_name + "' WHERE USER_CREATED = '" + as_user_id + "' AND SESS_HIST_SK = " + as_sess_hist_sk + " And PAGE_NAME = '" + as_page_name + "'";
                        //XmlElement ls_sess_hist_sk = ls_dom.CreateElement("ls_sql_statement");
                        //ls_Method.AppendChild(ls_sess_hist_sk);
                        //XmlText ls_sess_hist_sk_text = ls_dom.CreateTextNode(ls_sql_statement);
                        //ls_sess_hist_sk.AppendChild(ls_sess_hist_sk_text);
                        SqlCommand command = new SqlCommand(ls_sql_statement, connection);
                        command.Connection.Open();
                        command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                        command.ExecuteNonQuery();
                        command.Connection.Close();

                    }

                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                }
            }
            catch (Exception exp)
            {
                LogFileWrite(exp);
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.StackTrace);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                ls_MessageCode.AppendChild(ls_MessageCode_text);

                SendMail("Exception in iPad Web Services", exp.Source + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                return ls_dom;
            }

            return ls_dom;

        }

        [WebMethod]
        public XmlDocument GetMyEdit(string as_sess_hist_sk, string as_page_name, string as_user_id, string information)
        {
            LogArguments("GetMyEdit", as_sess_hist_sk + ";" + as_page_name + ";" + as_user_id, information);
            string ls_item_value, ls_query;

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "GetMyEdit");

            if (as_sess_hist_sk.Length == 0)
                as_sess_hist_sk = "0";

            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            try
            {

                //Open connection with database
                SQLConn.Open();

                ls_query = "SELECT SESS_HIST_SK,PAGENAME,CONTENTS,ACTIVE FROM CEN_SESS_HIST_MY_EDITS WHERE PAGENAME = '" + as_page_name + "' AND USER_CREATED = '" + as_user_id + "' AND sess_hist_sk = " + as_sess_hist_sk;
                DataSet lds_DataStore = new DataSet();
                System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                SQLAdapter.Fill(lds_DataStore);

                //XmlElement ls_q = ls_dom.CreateElement("Query");
                //ls_Method.AppendChild(ls_q);
                //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query);
                //ls_q.AppendChild(ls_Query_text);

                XmlElement ls_EDITED_TEXT = ls_dom.CreateElement("EDITED_TEXT");
                ls_Method.AppendChild(ls_EDITED_TEXT);

                if (lds_DataStore.Tables[0].Rows.Count == 1)
                {
                    ls_item_value = lds_DataStore.Tables[0].Rows[0]["CONTENTS"].ToString();
                    ls_item_value = EscapeXMLCharacters(ls_item_value);
                    if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "-";
                    XmlElement ls_CONTENTS = ls_dom.CreateElement("CONTENTS");
                    ls_EDITED_TEXT.AppendChild(ls_CONTENTS);
                    XmlText ls_CONTENTS_text = ls_dom.CreateTextNode(ls_item_value);
                    ls_CONTENTS.AppendChild(ls_CONTENTS_text);

                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    SQLConn.Close();

                }
            }
            catch (Exception exp)
            {
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                ls_MessageCode.AppendChild(ls_MessageCode_text);

                SQLConn.Close();

                return ls_dom;
            }

            return ls_dom;
        }

        [WebMethod]
        public XmlDocument GetMyRecording(string as_sess_hist_sk, string as_page_name, string as_user_id, string information)
        {
            LogArguments("GetMyRecording", as_sess_hist_sk + ";" + as_page_name + ";" + as_user_id, information);

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "GetMyRecording");

            string ls_recording_filepath = System.Configuration.ConfigurationManager.AppSettings["recording_file_path"];
            string ls_file_name = as_user_id + as_page_name + as_sess_hist_sk + ".txt";

            if (as_sess_hist_sk.Length == 0)
                as_sess_hist_sk = "0";

            if (System.IO.File.Exists(ls_recording_filepath + ls_file_name))
            {
                StreamReader streamReader = new StreamReader(ls_recording_filepath + ls_file_name);
                string text = streamReader.ReadToEnd();
                streamReader.Close();

                XmlElement ls_RECORDED_DATA = ls_dom.CreateElement("RECORDED_DATA");
                ls_Method.AppendChild(ls_RECORDED_DATA);

                XmlElement ls_CONTENTS = ls_dom.CreateElement("RECORDED_DATA");
                ls_RECORDED_DATA.AppendChild(ls_CONTENTS);
                XmlText ls_CONTENTS_text = ls_dom.CreateTextNode(text);
                ls_CONTENTS.AppendChild(ls_CONTENTS_text);

                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                ls_MessageCode.AppendChild(ls_MessageCode_text);

            }
            else
            {
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                ls_MessageCode.AppendChild(ls_MessageCode_text);

                return ls_dom;
            }

            return ls_dom;
        }

        [WebMethod]
        public XmlDocument GetPageMarkers(string as_sess_hist_sk, string as_user_id, string as_isbn, string information)
        {

            LogArguments("GetPageMarkers", as_sess_hist_sk + ";" + as_user_id + ";" + as_isbn, information);

            string ls_item_value, ls_query;

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "GetPageMarkers");

            if (as_sess_hist_sk.Length == 0)
                as_sess_hist_sk = "0";

            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            try
            {

                //Open connection with database
                SQLConn.Open();

                ls_query = "SELECT PAGE_NAME FROM CEN_SESS_HIST_MY_RECORDINGS WHERE SUBSTRING(PAGE_NAME,1,13) = '" + as_isbn + "' AND SESS_HIST_SK = " + as_sess_hist_sk + " AND USER_CREATED = '" + as_user_id + "' Order By PAGE_NAME";
                DataSet lds_DataStore = new DataSet();
                System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                SQLAdapter.Fill(lds_DataStore);

                XmlElement ls_RECORDING_MARKERS = ls_dom.CreateElement("RECORDING_MARKERS");
                ls_Method.AppendChild(ls_RECORDING_MARKERS);

                if (lds_DataStore.Tables[0].Rows.Count > 0)
                {
                    string[] ls_page_name_split;

                    for (int ii = 0; ii <= lds_DataStore.Tables[0].Rows.Count - 1; ii++)
                    {
                        ls_item_value = lds_DataStore.Tables[0].Rows[ii]["PAGE_NAME"].ToString();
                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "";

                        ls_page_name_split = ls_item_value.Split('-');

                        if (ls_page_name_split.Length > 0)
                        {
                            XmlElement ls_PAGE_NUMBER = ls_dom.CreateElement("PAGE_NUMBER");
                            ls_RECORDING_MARKERS.AppendChild(ls_PAGE_NUMBER);
                            XmlText ls_PAGE_NUMBER_text = ls_dom.CreateTextNode(ls_page_name_split[1]);
                            ls_PAGE_NUMBER.AppendChild(ls_PAGE_NUMBER_text);
                        }
                    }

                }

                ls_query = "SELECT PAGENAME FROM CEN_SESS_HIST_MY_EDITS WHERE SUBSTRING(PAGENAME,1,13) = '" + as_isbn + "' AND SESS_HIST_SK = " + as_sess_hist_sk + " AND USER_CREATED = '" + as_user_id + "' Order By PAGENAME";
                DataSet lds_DataStore1 = new DataSet();
                System.Data.SqlClient.SqlDataAdapter SQLAdapter1 = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                SQLAdapter1.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                SQLAdapter1.Fill(lds_DataStore1);

                XmlElement ls_EDIT_MARKERS = ls_dom.CreateElement("EDIT_MARKERS");
                ls_Method.AppendChild(ls_EDIT_MARKERS);

                if (lds_DataStore1.Tables[0].Rows.Count > 0)
                {
                    string[] ls_page_name_split;

                    for (int ii = 0; ii <= lds_DataStore1.Tables[0].Rows.Count - 1; ii++)
                    {
                        ls_item_value = lds_DataStore1.Tables[0].Rows[ii]["PAGENAME"].ToString();
                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "";

                        ls_page_name_split = ls_item_value.Split('-');

                        if (ls_page_name_split.Length > 0)
                        {
                            XmlElement ls_PAGE_NUMBER = ls_dom.CreateElement("PAGE_NUMBER");
                            ls_EDIT_MARKERS.AppendChild(ls_PAGE_NUMBER);
                            XmlText ls_PAGE_NUMBER_text = ls_dom.CreateTextNode(ls_page_name_split[1]);
                            ls_PAGE_NUMBER.AppendChild(ls_PAGE_NUMBER_text);
                        }
                    }

                }

                ls_query = "SELECT PAGE_NAME FROM CEN_SESS_HIST_MY_DRAWS WHERE SUBSTRING(PAGE_NAME,1,13) = '" + as_isbn + "' AND SESS_HIST_SK = " + as_sess_hist_sk + " AND USER_CREATED = '" + as_user_id + "' Order By PAGE_NAME";
                DataSet lds_DataStore2 = new DataSet();
                System.Data.SqlClient.SqlDataAdapter SQLAdapter2 = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                SQLAdapter2.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                SQLAdapter2.Fill(lds_DataStore2);

                XmlElement ls_DRAW_MARKERS = ls_dom.CreateElement("DRAW_MARKERS");
                ls_Method.AppendChild(ls_DRAW_MARKERS);

                if (lds_DataStore2.Tables[0].Rows.Count > 0)
                {
                    string[] ls_page_name_split;

                    for (int ii = 0; ii <= lds_DataStore2.Tables[0].Rows.Count - 1; ii++)
                    {
                        ls_item_value = lds_DataStore2.Tables[0].Rows[ii]["PAGE_NAME"].ToString();
                        ls_item_value = EscapeXMLCharacters(ls_item_value);
                        if ((ls_item_value.Equals(System.DBNull.Value)) || (ls_item_value.Length == 0)) ls_item_value = "";

                        ls_page_name_split = ls_item_value.Split('-');

                        if (ls_page_name_split.Length > 0)
                        {
                            XmlElement ls_PAGE_NUMBER = ls_dom.CreateElement("PAGE_NUMBER");
                            ls_DRAW_MARKERS.AppendChild(ls_PAGE_NUMBER);
                            XmlText ls_PAGE_NUMBER_text = ls_dom.CreateTextNode(ls_page_name_split[1]);
                            ls_PAGE_NUMBER.AppendChild(ls_PAGE_NUMBER_text);
                        }
                    }

                }

                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                ls_MessageCode.AppendChild(ls_MessageCode_text);

                SQLConn.Close();

            }
            catch (Exception exp)
            {
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                ls_MessageCode.AppendChild(ls_MessageCode_text);

                SQLConn.Close();

                return ls_dom;
            }

            return ls_dom;
        }

        [WebMethod]
        public XmlDocument SetMyDraws(string as_sess_hist_sk, string as_page_name, string as_user_id, string information)
        {
            LogArguments("SetMyDraws", as_sess_hist_sk + ";" + as_page_name + ";" + as_user_id, information);
            string ls_sql_statement, ls_query;

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "SetMyDraw");

            if (as_sess_hist_sk.Length == 0 || as_sess_hist_sk.Equals(System.DBNull.Value))
                as_sess_hist_sk = "0";

            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            try
            {

                //Open connection with database
                SQLConn.Open();

                ls_query = "SELECT SESS_HIST_SK FROM CEN_SESS_HIST_MY_DRAWS WHERE SESS_HIST_SK = " + as_sess_hist_sk + " AND PAGE_NAME = '" + as_page_name + "' AND USER_CREATED = '" + as_user_id + "'";
                DataSet lds_DataStore = new DataSet();
                System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
                SQLAdapter.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                SQLAdapter.Fill(lds_DataStore);

                if (lds_DataStore.Tables[0].Rows.Count == 0)
                {
                    using (SqlConnection connection = new SqlConnection(ls_ConnectionString))
                    {
                        ls_sql_statement = "INSERT INTO CEN_SESS_HIST_MY_DRAWS (SESS_HIST_SK,PAGE_NAME,DATE_CREATED,USER_CREATED) VALUES (@txt1,@txt2,@txt3,@txt4)";

                        SqlCommand command = new SqlCommand(ls_sql_statement, connection);

                        SqlParameter ls_param1 = new SqlParameter();
                        ls_param1.ParameterName = "@txt1";
                        ls_param1.Value = as_sess_hist_sk;

                        SqlParameter ls_param2 = new SqlParameter();
                        ls_param2.ParameterName = "@txt2";
                        ls_param2.Value = as_page_name;

                        SqlParameter ls_param3 = new SqlParameter();
                        ls_param3.ParameterName = "@txt3";
                        ls_param3.Value = DateTime.Today;// Convert.ToDateTime(as_record_start_time);

                        SqlParameter ls_param4 = new SqlParameter();
                        ls_param4.ParameterName = "@txt4";
                        ls_param4.Value = as_user_id;

                        command.Parameters.Add(ls_param1);
                        command.Parameters.Add(ls_param2);
                        command.Parameters.Add(ls_param3);
                        command.Parameters.Add(ls_param4);

                        command.Connection.Open();
                        command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                        command.ExecuteNonQuery();
                        command.Connection.Close();

                    }
                }

                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                ls_MessageCode.AppendChild(ls_MessageCode_text);

            }
            catch (Exception exp)
            {

                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                ls_MessageCode.AppendChild(ls_MessageCode_text);

                return ls_dom;

            }

            return ls_dom;
        }

        [WebMethod]
        public XmlDocument DeleteMyDraws(string as_user_id, string information)
        {
            LogArguments("DeleteMyDraws", as_user_id, information);
            //Connection string to connect with database 
            //string ls_ConnectionString = "";
            String ls_delete_statement;

            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "ClearMyDraws");

            //Open connection with database
            SQLConn.Open();

            ls_delete_statement = "DELETE FROM CEN_SESS_HIST_MY_DRAWS WHERE USER_CREATED = '" + as_user_id + "'";

            using (SqlConnection connection = new SqlConnection(ls_ConnectionString))
            {
                SqlCommand command = new SqlCommand(ls_delete_statement, connection);

                //XmlElement ls_q = ls_dom.CreateElement("Query");
                //ls_Method.AppendChild(ls_q);
                //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_update_statement);
                //ls_q.AppendChild(ls_Query_text);

                command.Connection.Open();

                try
                {
                    command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                    command.ExecuteNonQuery();
                    command.Connection.Close();

                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    SQLConn.Close();

                    return ls_dom;

                }
                catch (Exception exp)
                {
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_failure);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    SQLConn.Close();

                    return ls_dom;
                }
            }

        }

        [WebMethod]
        public XmlDocument CreateSessionForBookShelfReading(string as_cust_subs_sk, string as_user_name, string as_user_sk, string as_product_sk, string as_call_type, string as_session_product_sk, string as_session_member_sk, string information)
        {

            LogArguments("CreateSessionForBookShelfReading", as_cust_subs_sk + ";" + as_user_name + ";" + as_product_sk + ";" + as_call_type + ";" + as_session_member_sk + ";" + as_session_member_sk, information);

            //string ls_user_name = as_user_name;

            //as_user_name = ls_user_name.Split(':')[0];
            //int li_book_opened_seconds = Convert.ToInt32(ls_user_name.Split(':')[1]);

            string as_cust_subs_sk1 = "", ls_query = "", ls_query1, ls_CUST_SUBS_USER_SK = "", ls_CUST_SUBS_ITEM_SK = "";
            Object ls_SESSION_PRODUCT_SK = "";
            Object ls_SESSION_MEMBER_SK = "";

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "CreateSessionForBookShelfReading");

            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            try
            {
                // as_cust_subs_sk1 = GetSubscriptionofProduct(as_user_name, as_product_sk);

                ls_query = "INSERT INTO CEN_SESSIONS (CUST_SUBS_SK,SESSION_NAME,WORK_TYPE,SESSION_TYPE,ACTIVE,DATE_CREATED,USER_CREATED,CREATED_BY_CUST_SUBS_USER_SK,SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_STATUS,IS_NAME_MANUAL_OVERRIDE) VALUES (@txt1,@txt2,@txt3,@txt4,@txt5,@txt6,@txt7,@txt8,@txt9,@txt10,@txt11,@txt12); select @@identity;";

                SqlParameter ls_param1 = new SqlParameter();
                ls_param1.ParameterName = "@txt1";
                ls_param1.Value = Convert.ToInt32(as_cust_subs_sk1);

                SqlParameter ls_param2 = new SqlParameter();
                ls_param2.ParameterName = "@txt2";
                ls_param2.Value = "BookShelf";

                SqlParameter ls_param3 = new SqlParameter();
                ls_param3.ParameterName = "@txt3";
                ls_param3.Value = "BOOK";

                SqlParameter ls_param4 = new SqlParameter();
                ls_param4.ParameterName = "@txt4";
                ls_param4.Value = "Independent";

                SqlParameter ls_param5 = new SqlParameter();
                ls_param5.ParameterName = "@txt5";
                ls_param5.Value = "Y";

                SqlParameter ls_param6 = new SqlParameter();
                ls_param6.ParameterName = "@txt6";
                ls_param6.Value = DateTime.Today;

                SqlParameter ls_param7 = new SqlParameter();
                ls_param7.ParameterName = "@txt7";
                ls_param7.Value = as_user_name;

                ls_query1 = "SELECT SubUsers.CUST_SUBS_USER_SK FROM CEN_CUSTOMER_SUBS_USERS AS SubUsers JOIN CEN_TRADING_PARTNER_USERS AS TradingPartners ON SubUsers.TRAD_PART_USER_SK=TradingPartners.TRAD_PART_USER_SK JOIN CEN_USER_ROLES as UserRoles ON TradingPartners.USER_ROLE_SK =UserRoles.USER_ROLE_SK JOIN CEN_ROLES AS R ON UserRoles.ROLE_SK=R.ROLE_SK JOIN CEN_USERS AS Users ON UserRoles.USER_SK=Users.USER_SK WHERE Users.USER_LOGIN_NAME='" + as_user_name + "' AND SubUsers.CUST_SUBS_SK= " + as_cust_subs_sk1 + " AND SubUsers.ACTIVE='Y' AND R.ROLE_ID IN ('SUBS ADMIN','TEACHER','STUDENT')";

                SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);
                DataSet lds_DataStore3 = new DataSet();
                System.Data.SqlClient.SqlDataAdapter SQLAdapter3 = new System.Data.SqlClient.SqlDataAdapter(ls_query1, SQLConn);
                SQLAdapter3.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                SQLAdapter3.Fill(lds_DataStore3);

                SqlParameter ls_param8 = new SqlParameter();

                if (lds_DataStore3.Tables[0].Rows.Count > 0)
                {
                    ls_CUST_SUBS_USER_SK = lds_DataStore3.Tables[0].Rows[0]["CUST_SUBS_USER_SK"].ToString();
                    ls_CUST_SUBS_USER_SK = EscapeXMLCharacters(ls_CUST_SUBS_USER_SK);
                    if ((ls_CUST_SUBS_USER_SK.Equals(System.DBNull.Value)) || (ls_CUST_SUBS_USER_SK.Length == 0)) ls_CUST_SUBS_USER_SK = "-";

                    ls_param8.ParameterName = "@txt8";
                    ls_param8.Value = Convert.ToInt32(ls_CUST_SUBS_USER_SK);

                }

                SqlParameter ls_param9 = new SqlParameter();
                ls_param9.ParameterName = "@txt9";
                ls_param9.Value = DateTime.Today;

                SqlParameter ls_param10 = new SqlParameter();
                ls_param10.ParameterName = "@txt10";
                ls_param10.Value = DateTime.Today.AddDays(7);

                SqlParameter ls_param11111 = new SqlParameter();
                ls_param11111.ParameterName = "@txt11";
                ls_param11111.Value = "Active";

                SqlParameter ls_param12 = new SqlParameter();
                ls_param12.ParameterName = "@txt12";
                ls_param12.Value = "Y";

                using (SqlConnection connection = new SqlConnection(ls_ConnectionString))
                {
                    SqlCommand command = new SqlCommand(ls_query, connection);
                    command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                    command.Parameters.Add(ls_param1);
                    command.Parameters.Add(ls_param2);
                    command.Parameters.Add(ls_param3);
                    command.Parameters.Add(ls_param4);
                    command.Parameters.Add(ls_param5);
                    command.Parameters.Add(ls_param6);
                    command.Parameters.Add(ls_param7);
                    command.Parameters.Add(ls_param8);
                    command.Parameters.Add(ls_param9);
                    command.Parameters.Add(ls_param10);
                    command.Parameters.Add(ls_param11111);
                    command.Parameters.Add(ls_param12);

                    command.Connection.Open();

                    try
                    {
                        if (as_call_type.Equals("B"))
                        {

                            Object ls_SESSION_SK;
                            ls_SESSION_SK = command.ExecuteScalar();
                            //command.ExecuteNonQuery();

                            /*ls_query1 = "SELECT SESSION_SK FROM CEN_SESSIONS where SESSION_TYPE = 'Independent' and USER_CREATED = '" + as_user_name + "'";

                            DataSet lds_DataStore4 = new DataSet();
                            System.Data.SqlClient.SqlDataAdapter SQLAdapter4 = new System.Data.SqlClient.SqlDataAdapter(ls_query1, SQLConn);
                            SQLAdapter4.Fill(lds_DataStore4);

                            if (lds_DataStore4.Tables[0].Rows.Count > 0)
                            {
                                ls_SESSION_SK = lds_DataStore4.Tables[0].Rows[0]["SESSION_SK"].ToString();
                                ls_SESSION_SK = EscapeXMLCharacters(ls_SESSION_SK.ToString());
                                if ((ls_SESSION_SK.ToString().Equals(System.DBNull.Value)) || (ls_SESSION_SK.ToString().Length == 0)) ls_SESSION_SK = "-";
                                XmlElement ls_q = ls_dom.CreateElement("SESSION_SK");
                                ls_Method.AppendChild(ls_q);
                                XmlText ls_Query_text = ls_dom.CreateTextNode(ls_SESSION_SK.ToString());
                                ls_q.AppendChild(ls_Query_text);


                            }
                            else
                            {
                                ls_SESSION_SK = command.ExecuteScalar();
                                //command.ExecuteNonQuery();
                            }
                            */
                            ls_query = "INSERT INTO CEN_SESSION_MEMBERS (SESSION_SK,CUST_SUBS_USER_SK,MEMBER_TYPE,ADDED_DATE,ACTIVE,DATE_CREATED,USER_CREATED) VALUES (@txt11,@txt22,@txt33,@txt44,@txt55,@txt66,@txt77); select @@identity;";

                            SqlParameter ls_param11 = new SqlParameter();
                            ls_param11.ParameterName = "@txt11";
                            ls_param11.Value = Convert.ToInt32(ls_SESSION_SK.ToString());

                            SqlParameter ls_param22 = new SqlParameter();
                            ls_param22.ParameterName = "@txt22";
                            ls_param22.Value = ls_CUST_SUBS_USER_SK;

                            // your code comes here 
                            //ls_query1 = "SELECT ";
                            //ls_query1 = ls_query1 + "CSU.CUST_SUBS_USER_SK ";
                            //ls_query1 = ls_query1 + "FROM ";
                            //ls_query1 = ls_query1 + "CEN_CUSTOMER_SUBS_USERS CSU ";
                            //ls_query1 = ls_query1 + "WHERE ";
                            //ls_query1 = ls_query1 + "( CSU.CUST_SUBS_SK = '" + as_cust_subs_sk + "')";

                            //DataSet lds_DataStore1 = new DataSet();
                            //System.Data.SqlClient.SqlDataAdapter SQLAdapter1 = new System.Data.SqlClient.SqlDataAdapter(ls_query1, connection);
                            //SQLAdapter1.Fill(lds_DataStore1);

                            //if (lds_DataStore1.Tables[0].Rows.Count > 0)
                            //{
                            //ls_CUST_SUBS_USER_SK = lds_DataStore1.Tables[0].Rows[0]["CUST_SUBS_USER_SK"].ToString();
                            //ls_CUST_SUBS_USER_SK = EscapeXMLCharacters(ls_CUST_SUBS_USER_SK);
                            //if ((ls_CUST_SUBS_USER_SK.Equals(System.DBNull.Value)) || (ls_CUST_SUBS_USER_SK.Length == 0)) ls_CUST_SUBS_USER_SK = "-";
                            //}

                            SqlParameter ls_param33 = new SqlParameter();
                            ls_param33.ParameterName = "@txt33";
                            ls_param33.Value = "USER";

                            SqlParameter ls_param44 = new SqlParameter();
                            ls_param44.ParameterName = "@txt44";
                            ls_param44.Value = DateTime.Today;

                            SqlParameter ls_param55 = new SqlParameter();
                            ls_param55.ParameterName = "@txt55";
                            ls_param55.Value = "Y";

                            SqlParameter ls_param66 = new SqlParameter();
                            ls_param66.ParameterName = "@txt66";
                            ls_param66.Value = DateTime.Today;

                            SqlParameter ls_param77 = new SqlParameter();
                            ls_param77.ParameterName = "@txt77";
                            ls_param77.Value = as_user_name;

                            SqlCommand command1 = new SqlCommand(ls_query, connection);
                            command1.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                            command1.Parameters.Add(ls_param11);
                            command1.Parameters.Add(ls_param22);
                            command1.Parameters.Add(ls_param33);
                            command1.Parameters.Add(ls_param44);
                            command1.Parameters.Add(ls_param55);
                            command1.Parameters.Add(ls_param66);
                            command1.Parameters.Add(ls_param77);

                            //command1.Connection.Open();

                            ls_SESSION_MEMBER_SK = command1.ExecuteScalar();

                            ls_query = "INSERT INTO CEN_SESSION_PRODUCTS (SESSION_SK,CUST_SUBS_ITEM_SK,ADDED_DATE,ACTIVE,DATE_CREATED,USER_CREATED) VALUES (@txt111,@txt222,@txt333,@txt444,@txt555,@txt666); select @@identity;";

                            SqlParameter ls_param111 = new SqlParameter();
                            ls_param111.ParameterName = "@txt111";
                            ls_param111.Value = Convert.ToInt32(ls_SESSION_SK.ToString());

                            SqlParameter ls_param222 = new SqlParameter();

                            // your code comes here 
                            ls_query1 = "SELECT ";
                            ls_query1 = ls_query1 + "CSI.CUST_SUBS_ITEM_SK ";
                            ls_query1 = ls_query1 + "FROM ";
                            ls_query1 = ls_query1 + "CEN_CUSTOMER_SUBS_ITEMS CSI ";
                            ls_query1 = ls_query1 + "WHERE ";
                            ls_query1 = ls_query1 + "( CSI.CUST_SUBS_SK = " + as_cust_subs_sk1 + ") AND ";
                            ls_query1 = ls_query1 + "( CSI.PRODUCT_SK = " + as_product_sk + ")";

                            //XmlElement ls_q = ls_dom.CreateElement("Query");
                            //ls_Method.AppendChild(ls_q);
                            //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query1);
                            //ls_q.AppendChild(ls_Query_text);

                            DataSet lds_DataStore2 = new DataSet();
                            System.Data.SqlClient.SqlDataAdapter SQLAdapter2 = new System.Data.SqlClient.SqlDataAdapter(ls_query1, connection);
                            SQLAdapter2.Fill(lds_DataStore2);

                            if (lds_DataStore2.Tables[0].Rows.Count > 0)
                            {
                                ls_CUST_SUBS_ITEM_SK = lds_DataStore2.Tables[0].Rows[0]["CUST_SUBS_ITEM_SK"].ToString();
                                ls_CUST_SUBS_ITEM_SK = EscapeXMLCharacters(ls_CUST_SUBS_ITEM_SK);
                                if ((ls_CUST_SUBS_ITEM_SK.Equals(System.DBNull.Value)) || (ls_CUST_SUBS_ITEM_SK.Length == 0)) ls_CUST_SUBS_ITEM_SK = "-";

                                ls_param222.ParameterName = "@txt222";
                                ls_param222.Value = ls_CUST_SUBS_ITEM_SK;
                            }

                            SqlParameter ls_param333 = new SqlParameter();
                            ls_param333.ParameterName = "@txt333";
                            ls_param333.Value = DateTime.Today;

                            SqlParameter ls_param444 = new SqlParameter();
                            ls_param444.ParameterName = "@txt444";
                            ls_param444.Value = "Y";

                            SqlParameter ls_param555 = new SqlParameter();
                            ls_param555.ParameterName = "@txt555";
                            ls_param555.Value = DateTime.Today;

                            SqlParameter ls_param666 = new SqlParameter();
                            ls_param666.ParameterName = "@txt666";
                            ls_param666.Value = as_user_name;

                            XmlElement ls_q1 = ls_dom.CreateElement("ls_CUST_SUBS_ITEM_SK");
                            ls_Method.AppendChild(ls_q1);
                            XmlText ls_Query1_text = ls_dom.CreateTextNode(ls_CUST_SUBS_ITEM_SK);
                            ls_q1.AppendChild(ls_Query1_text);

                            SqlCommand command2 = new SqlCommand(ls_query, connection);
                            command2.Parameters.Add(ls_param111);
                            command2.Parameters.Add(ls_param222);
                            command2.Parameters.Add(ls_param333);
                            command2.Parameters.Add(ls_param444);
                            command2.Parameters.Add(ls_param555);
                            command2.Parameters.Add(ls_param666);
                            command2.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                            //command1.Connection.Open();

                            ls_SESSION_PRODUCT_SK = command2.ExecuteScalar();
                            //command.ExecuteNonQuery();

                        }

                        XmlElement ls_q2 = ls_dom.CreateElement("ls_SESSION_PRODUCT_SK");
                        ls_Method.AppendChild(ls_q2);
                        XmlText ls_Query2_text = ls_dom.CreateTextNode(ls_SESSION_PRODUCT_SK.ToString());
                        ls_q2.AppendChild(ls_Query2_text);
                        XmlElement ls_q3 = ls_dom.CreateElement("ls_SESSION_MEMBER_SK");
                        ls_Method.AppendChild(ls_q3);
                        XmlText ls_Query3_text = ls_dom.CreateTextNode(ls_SESSION_MEMBER_SK.ToString());
                        ls_q3.AppendChild(ls_Query3_text);
                        ls_query = "INSERT INTO CEN_SESSION_HISTORY (SESSION_MEMBER_SK,SESSION_PRODUCT_SK,SESS_OPENED_TIME,BOOK_OPENED_AT,BOOK_CLOSED_AT,ACTIVE,DATE_CREATED,USER_CREATED) VALUES (@txt1111,@txt2222,@txt3333,@txt4444,@txt5555,@txt6666,@txt7777,@txt8888); select @@identity;";

                        SqlParameter ls_param1111 = new SqlParameter();
                        ls_param1111.ParameterName = "@txt1111";

                        if (as_call_type.Equals("B"))
                        {
                            ls_param1111.Value = Convert.ToInt32(ls_SESSION_MEMBER_SK.ToString());
                        }
                        else
                        {
                            ls_param1111.Value = Convert.ToInt32(as_session_member_sk);
                        }

                        SqlParameter ls_param2222 = new SqlParameter();
                        ls_param2222.ParameterName = "@txt2222";

                        if (as_call_type.Equals("B"))
                        {
                            ls_param2222.Value = Convert.ToInt32(ls_SESSION_PRODUCT_SK.ToString());
                        }
                        else
                        {
                            ls_param2222.Value = Convert.ToInt32(as_session_product_sk);
                        }

                        SqlParameter ls_param3333 = new SqlParameter();
                        ls_param3333.ParameterName = "@txt3333";
                        ls_param3333.Value = DateTime.Now;

                        SqlParameter ls_param4444 = new SqlParameter();
                        ls_param4444.ParameterName = "@txt4444";
                        ls_param4444.Value = DateTime.Now;

                        SqlParameter ls_param5555 = new SqlParameter();
                        ls_param5555.ParameterName = "@txt5555";
                        ls_param5555.Value = DateTime.Now;

                        SqlParameter ls_param6666 = new SqlParameter();
                        ls_param6666.ParameterName = "@txt6666";
                        ls_param6666.Value = "Y";

                        SqlParameter ls_param7777 = new SqlParameter();
                        ls_param7777.ParameterName = "@txt7777";
                        ls_param7777.Value = DateTime.Today;

                        SqlParameter ls_param8888 = new SqlParameter();
                        ls_param8888.ParameterName = "@txt8888";
                        ls_param8888.Value = as_user_name;

                        //XmlElement ls_q1 = ls_dom.CreateElement("ls_CUST_SUBS_ITEM_SK");
                        //ls_Method.AppendChild(ls_q1);
                        //XmlText ls_Query1_text = ls_dom.CreateTextNode(ls_CUST_SUBS_ITEM_SK);
                        //ls_q1.AppendChild(ls_Query1_text);

                        SqlCommand command3 = new SqlCommand(ls_query, connection);
                        command3.Parameters.Add(ls_param1111);
                        command3.Parameters.Add(ls_param2222);
                        command3.Parameters.Add(ls_param3333);
                        command3.Parameters.Add(ls_param4444);
                        command3.Parameters.Add(ls_param5555);
                        command3.Parameters.Add(ls_param6666);
                        command3.Parameters.Add(ls_param7777);
                        command3.Parameters.Add(ls_param8888);
                        command3.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                        //command1.Connection.Open();

                        Object ls_SESS_HIST_SK;
                        ls_SESS_HIST_SK = command3.ExecuteScalar();
                        //command.ExecuteNonQuery();

                        XmlElement ls_SESS_HIST_SK_node = ls_dom.CreateElement("SESS_HIST_SK");
                        ls_Method.AppendChild(ls_SESS_HIST_SK_node);
                        XmlText ls_SESS_HIST_SK_node_text = ls_dom.CreateTextNode(ls_SESS_HIST_SK.ToString());
                        ls_SESS_HIST_SK_node.AppendChild(ls_SESS_HIST_SK_node_text);
                        XmlElement ls_Error = ls_dom.CreateElement("Error");
                        ls_Method.AppendChild(ls_Error);
                        XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                        ls_Error.AppendChild(ls_ErrorCode);
                        XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                        ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                        XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                        ls_Error.AppendChild(ls_ErrorDescription);
                        XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                        ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                        XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                        ls_Method.AppendChild(ls_DisplayCustomMessage);
                        XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                        ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                        XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                        ls_Method.AppendChild(ls_MessageCode);
                        XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                        ls_MessageCode.AppendChild(ls_MessageCode_text);

                        command.Connection.Close();

                    }
                    catch (Exception exp)
                    {
                        XmlElement ls_Error = ls_dom.CreateElement("Error");
                        ls_Method.AppendChild(ls_Error);
                        XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                        ls_Error.AppendChild(ls_ErrorCode);
                        XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                        ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                        XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                        ls_Error.AppendChild(ls_ErrorDescription);
                        XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.Message);
                        ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                        XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                        ls_Method.AppendChild(ls_DisplayCustomMessage);
                        XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                        ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                        XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                        ls_Method.AppendChild(ls_MessageCode);
                        XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                        ls_MessageCode.AppendChild(ls_MessageCode_text);
                        LogFileWrite(exp);
                        SendMail("Exception in iPad Web Services - CreateSessionForBookShelfReading(" + as_cust_subs_sk1 + ";" + as_user_name + ";" + as_product_sk + ";" + as_call_type + ";" + as_session_member_sk + ";" + as_session_member_sk + ")", ls_CUST_SUBS_USER_SK + exp.Message + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                        return ls_dom;
                    }

                    return ls_dom;
                }
            }
            catch (Exception exp)
            {
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.Message);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                ls_MessageCode.AppendChild(ls_MessageCode_text);
                LogFileWrite(exp);
                SendMail("Exception in iPad Web Services - CreateSessionForBookShelfReading(" + as_cust_subs_sk1 + ";" + as_user_name + ";" + as_product_sk + ";" + as_call_type + ";" + as_session_member_sk + ";" + as_session_member_sk + ")", ls_CUST_SUBS_USER_SK + exp.Message + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                return ls_dom;
            }
        }

        [WebMethod]
        public XmlDocument CreateSessionForBookReading(string as_cust_subs_sk, string as_user_name, string as_user_sk, string as_product_sk, string as_call_type, string as_session_product_sk, string as_session_member_sk, string as_book_read_time, string information)
        {
            LogArguments("CreateSessionForBookReading", as_cust_subs_sk + ";" + as_user_name + ";" + as_product_sk + ";" + as_call_type + ";" + as_session_member_sk + ";" + as_session_member_sk + ";" + as_book_read_time, information);

            //string ls_user_name = as_user_name;

            //as_user_name = ls_user_name.Split(':')[0];
            //int li_book_opened_seconds = Convert.ToInt32(ls_user_name.Split(':')[1]);

            string ls_query = "", ls_query1, ls_CUST_SUBS_USER_SK = "", ls_CUST_SUBS_ITEM_SK = "";
            Object ls_SESSION_PRODUCT_SK = "";
            Object ls_SESSION_MEMBER_SK = "";

            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "CreateSessionForBookShelfReading");
            try
            {
                //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];

                // as_cust_subs_sk = GetSubscriptionofProduct(as_user_name, as_product_sk);

                ls_query = "INSERT INTO CEN_SESSIONS (CUST_SUBS_SK,SESSION_NAME,WORK_TYPE,SESSION_TYPE,ACTIVE,DATE_CREATED,USER_CREATED,CREATED_BY_CUST_SUBS_USER_SK,SESSION_CREATED_DATE,SESSION_EXPIRY_DATE,SESSION_STATUS,IS_NAME_MANUAL_OVERRIDE) VALUES (@txt1,@txt2,@txt3,@txt4,@txt5,@txt6,@txt7,@txt8,@txt9,@txt10,@txt11,@txt12); select @@identity;";

                SqlParameter ls_param1 = new SqlParameter();
                ls_param1.ParameterName = "@txt1";
                ls_param1.Value = Convert.ToInt32(as_cust_subs_sk);

                SqlParameter ls_param2 = new SqlParameter();
                ls_param2.ParameterName = "@txt2";
                ls_param2.Value = "BookShelf";

                SqlParameter ls_param3 = new SqlParameter();
                ls_param3.ParameterName = "@txt3";
                ls_param3.Value = "BOOK";

                SqlParameter ls_param4 = new SqlParameter();
                ls_param4.ParameterName = "@txt4";
                ls_param4.Value = "Independent";

                SqlParameter ls_param5 = new SqlParameter();
                ls_param5.ParameterName = "@txt5";
                ls_param5.Value = "Y";

                SqlParameter ls_param6 = new SqlParameter();
                ls_param6.ParameterName = "@txt6";
                ls_param6.Value = DateTime.Today;

                SqlParameter ls_param7 = new SqlParameter();
                ls_param7.ParameterName = "@txt7";
                ls_param7.Value = as_user_name;

                ls_query1 = "SELECT SubUsers.CUST_SUBS_USER_SK FROM CEN_CUSTOMER_SUBS_USERS AS SubUsers JOIN CEN_TRADING_PARTNER_USERS AS TradingPartners ON SubUsers.TRAD_PART_USER_SK=TradingPartners.TRAD_PART_USER_SK JOIN CEN_USER_ROLES as UserRoles ON TradingPartners.USER_ROLE_SK =UserRoles.USER_ROLE_SK JOIN CEN_ROLES AS R ON UserRoles.ROLE_SK=R.ROLE_SK JOIN CEN_USERS AS Users ON UserRoles.USER_SK=Users.USER_SK WHERE Users.USER_LOGIN_NAME='" + as_user_name + "' AND SubUsers.CUST_SUBS_SK= " + as_cust_subs_sk + " AND SubUsers.ACTIVE='Y' AND R.ROLE_ID IN ('SUBS ADMIN','TEACHER','STUDENT')";

                SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);
                DataSet lds_DataStore3 = new DataSet();
                System.Data.SqlClient.SqlDataAdapter SQLAdapter3 = new System.Data.SqlClient.SqlDataAdapter(ls_query1, SQLConn);
                SQLAdapter3.Fill(lds_DataStore3);

                SqlParameter ls_param8 = new SqlParameter();

                if (lds_DataStore3.Tables[0].Rows.Count > 0)
                {
                    ls_CUST_SUBS_USER_SK = lds_DataStore3.Tables[0].Rows[0]["CUST_SUBS_USER_SK"].ToString();
                    ls_CUST_SUBS_USER_SK = EscapeXMLCharacters(ls_CUST_SUBS_USER_SK);
                    if ((ls_CUST_SUBS_USER_SK.Equals(System.DBNull.Value)) || (ls_CUST_SUBS_USER_SK.Length == 0)) ls_CUST_SUBS_USER_SK = "-";

                    ls_param8.ParameterName = "@txt8";
                    ls_param8.Value = Convert.ToInt32(ls_CUST_SUBS_USER_SK);

                }

                SqlParameter ls_param9 = new SqlParameter();
                ls_param9.ParameterName = "@txt9";
                ls_param9.Value = DateTime.Today;

                SqlParameter ls_param10 = new SqlParameter();
                ls_param10.ParameterName = "@txt10";
                ls_param10.Value = DateTime.Today.AddDays(7);

                SqlParameter ls_param11111 = new SqlParameter();
                ls_param11111.ParameterName = "@txt11";
                ls_param11111.Value = "Active";

                SqlParameter ls_param12 = new SqlParameter();
                ls_param12.ParameterName = "@txt12";
                ls_param12.Value = "Y";

                using (SqlConnection connection = new SqlConnection(ls_ConnectionString))
                {
                    SqlCommand command = new SqlCommand(ls_query, connection);
                    command.Parameters.Add(ls_param1);
                    command.Parameters.Add(ls_param2);
                    command.Parameters.Add(ls_param3);
                    command.Parameters.Add(ls_param4);
                    command.Parameters.Add(ls_param5);
                    command.Parameters.Add(ls_param6);
                    command.Parameters.Add(ls_param7);
                    command.Parameters.Add(ls_param8);
                    command.Parameters.Add(ls_param9);
                    command.Parameters.Add(ls_param10);
                    command.Parameters.Add(ls_param11111);
                    command.Parameters.Add(ls_param12);
                    command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());

                    command.Connection.Open();

                    try
                    {
                        if (as_call_type.Equals("B"))
                        {

                            Object ls_SESSION_SK;
                            ls_SESSION_SK = command.ExecuteScalar();
                            //command.ExecuteNonQuery();

                            /*ls_query1 = "SELECT SESSION_SK FROM CEN_SESSIONS where SESSION_TYPE = 'Independent' and USER_CREATED = '" + as_user_name + "'";

                            DataSet lds_DataStore4 = new DataSet();
                            System.Data.SqlClient.SqlDataAdapter SQLAdapter4 = new System.Data.SqlClient.SqlDataAdapter(ls_query1, SQLConn);
                            SQLAdapter4.Fill(lds_DataStore4);

                            if (lds_DataStore4.Tables[0].Rows.Count > 0)
                            {
                                ls_SESSION_SK = lds_DataStore4.Tables[0].Rows[0]["SESSION_SK"].ToString();
                                ls_SESSION_SK = EscapeXMLCharacters(ls_SESSION_SK.ToString());
                                if ((ls_SESSION_SK.ToString().Equals(System.DBNull.Value)) || (ls_SESSION_SK.ToString().Length == 0)) ls_SESSION_SK = "-";
                                XmlElement ls_q = ls_dom.CreateElement("SESSION_SK");
                                ls_Method.AppendChild(ls_q);
                                XmlText ls_Query_text = ls_dom.CreateTextNode(ls_SESSION_SK.ToString());
                                ls_q.AppendChild(ls_Query_text);


                            }
                            else
                            {
                                ls_SESSION_SK = command.ExecuteScalar();
                                //command.ExecuteNonQuery();
                            }
                            */
                            ls_query = "INSERT INTO CEN_SESSION_MEMBERS (SESSION_SK,CUST_SUBS_USER_SK,MEMBER_TYPE,ADDED_DATE,ACTIVE,DATE_CREATED,USER_CREATED) VALUES (@txt11,@txt22,@txt33,@txt44,@txt55,@txt66,@txt77); select @@identity;";

                            SqlParameter ls_param11 = new SqlParameter();
                            ls_param11.ParameterName = "@txt11";
                            ls_param11.Value = Convert.ToInt32(ls_SESSION_SK.ToString());

                            SqlParameter ls_param22 = new SqlParameter();
                            ls_param22.ParameterName = "@txt22";
                            ls_param22.Value = ls_CUST_SUBS_USER_SK;

                            // your code comes here 
                            //ls_query1 = "SELECT ";
                            //ls_query1 = ls_query1 + "CSU.CUST_SUBS_USER_SK ";
                            //ls_query1 = ls_query1 + "FROM ";
                            //ls_query1 = ls_query1 + "CEN_CUSTOMER_SUBS_USERS CSU ";
                            //ls_query1 = ls_query1 + "WHERE ";
                            //ls_query1 = ls_query1 + "( CSU.CUST_SUBS_SK = '" + as_cust_subs_sk + "')";

                            //DataSet lds_DataStore1 = new DataSet();
                            //System.Data.SqlClient.SqlDataAdapter SQLAdapter1 = new System.Data.SqlClient.SqlDataAdapter(ls_query1, connection);
                            //SQLAdapter1.Fill(lds_DataStore1);

                            //if (lds_DataStore1.Tables[0].Rows.Count > 0)
                            //{
                            //ls_CUST_SUBS_USER_SK = lds_DataStore1.Tables[0].Rows[0]["CUST_SUBS_USER_SK"].ToString();
                            //ls_CUST_SUBS_USER_SK = EscapeXMLCharacters(ls_CUST_SUBS_USER_SK);
                            //if ((ls_CUST_SUBS_USER_SK.Equals(System.DBNull.Value)) || (ls_CUST_SUBS_USER_SK.Length == 0)) ls_CUST_SUBS_USER_SK = "-";
                            //}

                            SqlParameter ls_param33 = new SqlParameter();
                            ls_param33.ParameterName = "@txt33";
                            ls_param33.Value = "USER";

                            SqlParameter ls_param44 = new SqlParameter();
                            ls_param44.ParameterName = "@txt44";
                            ls_param44.Value = DateTime.Today;

                            SqlParameter ls_param55 = new SqlParameter();
                            ls_param55.ParameterName = "@txt55";
                            ls_param55.Value = "Y";

                            SqlParameter ls_param66 = new SqlParameter();
                            ls_param66.ParameterName = "@txt66";
                            ls_param66.Value = DateTime.Today;

                            SqlParameter ls_param77 = new SqlParameter();
                            ls_param77.ParameterName = "@txt77";
                            ls_param77.Value = as_user_name;

                            SqlCommand command1 = new SqlCommand(ls_query, connection);
                            command1.Parameters.Add(ls_param11);
                            command1.Parameters.Add(ls_param22);
                            command1.Parameters.Add(ls_param33);
                            command1.Parameters.Add(ls_param44);
                            command1.Parameters.Add(ls_param55);
                            command1.Parameters.Add(ls_param66);
                            command1.Parameters.Add(ls_param77);
                            command1.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());

                            //command1.Connection.Open();

                            ls_SESSION_MEMBER_SK = command1.ExecuteScalar();

                            ls_query = "INSERT INTO CEN_SESSION_PRODUCTS (SESSION_SK,CUST_SUBS_ITEM_SK,ADDED_DATE,ACTIVE,DATE_CREATED,USER_CREATED) VALUES (@txt111,@txt222,@txt333,@txt444,@txt555,@txt666); select @@identity;";

                            SqlParameter ls_param111 = new SqlParameter();
                            ls_param111.ParameterName = "@txt111";
                            ls_param111.Value = Convert.ToInt32(ls_SESSION_SK.ToString());

                            SqlParameter ls_param222 = new SqlParameter();

                            // your code comes here 
                            ls_query1 = "SELECT ";
                            ls_query1 = ls_query1 + "CSI.CUST_SUBS_ITEM_SK ";
                            ls_query1 = ls_query1 + "FROM ";
                            ls_query1 = ls_query1 + "CEN_CUSTOMER_SUBS_ITEMS CSI ";
                            ls_query1 = ls_query1 + "WHERE ";
                            ls_query1 = ls_query1 + "( CSI.CUST_SUBS_SK = " + as_cust_subs_sk + ") AND ";
                            ls_query1 = ls_query1 + "( CSI.PRODUCT_SK = " + as_product_sk + ")";

                            //XmlElement ls_q = ls_dom.CreateElement("Query");
                            //ls_Method.AppendChild(ls_q);
                            //XmlText ls_Query_text = ls_dom.CreateTextNode(ls_query1);
                            //ls_q.AppendChild(ls_Query_text);

                            DataSet lds_DataStore2 = new DataSet();
                            System.Data.SqlClient.SqlDataAdapter SQLAdapter2 = new System.Data.SqlClient.SqlDataAdapter(ls_query1, connection);
                            SQLAdapter2.SelectCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                            SQLAdapter2.Fill(lds_DataStore2);

                            if (lds_DataStore2.Tables[0].Rows.Count > 0)
                            {
                                ls_CUST_SUBS_ITEM_SK = lds_DataStore2.Tables[0].Rows[0]["CUST_SUBS_ITEM_SK"].ToString();
                                ls_CUST_SUBS_ITEM_SK = EscapeXMLCharacters(ls_CUST_SUBS_ITEM_SK);
                                if ((ls_CUST_SUBS_ITEM_SK.Equals(System.DBNull.Value)) || (ls_CUST_SUBS_ITEM_SK.Length == 0)) ls_CUST_SUBS_ITEM_SK = "-";

                                ls_param222.ParameterName = "@txt222";
                                ls_param222.Value = ls_CUST_SUBS_ITEM_SK;
                            }

                            SqlParameter ls_param333 = new SqlParameter();
                            ls_param333.ParameterName = "@txt333";
                            ls_param333.Value = DateTime.Today;

                            SqlParameter ls_param444 = new SqlParameter();
                            ls_param444.ParameterName = "@txt444";
                            ls_param444.Value = "Y";

                            SqlParameter ls_param555 = new SqlParameter();
                            ls_param555.ParameterName = "@txt555";
                            ls_param555.Value = DateTime.Today;

                            SqlParameter ls_param666 = new SqlParameter();
                            ls_param666.ParameterName = "@txt666";
                            ls_param666.Value = as_user_name;

                            XmlElement ls_q1 = ls_dom.CreateElement("ls_CUST_SUBS_ITEM_SK");
                            ls_Method.AppendChild(ls_q1);
                            XmlText ls_Query1_text = ls_dom.CreateTextNode(ls_CUST_SUBS_ITEM_SK);
                            ls_q1.AppendChild(ls_Query1_text);

                            SqlCommand command2 = new SqlCommand(ls_query, connection);
                            command2.Parameters.Add(ls_param111);
                            command2.Parameters.Add(ls_param222);
                            command2.Parameters.Add(ls_param333);
                            command2.Parameters.Add(ls_param444);
                            command2.Parameters.Add(ls_param555);
                            command2.Parameters.Add(ls_param666);
                            command2.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                            //command1.Connection.Open();

                            ls_SESSION_PRODUCT_SK = command2.ExecuteScalar();
                            //command.ExecuteNonQuery();

                        }

                        XmlElement ls_q2 = ls_dom.CreateElement("ls_SESSION_PRODUCT_SK");
                        ls_Method.AppendChild(ls_q2);
                        XmlText ls_Query2_text = ls_dom.CreateTextNode(ls_SESSION_PRODUCT_SK.ToString());
                        ls_q2.AppendChild(ls_Query2_text);
                        XmlElement ls_q3 = ls_dom.CreateElement("ls_SESSION_MEMBER_SK");
                        ls_Method.AppendChild(ls_q3);
                        XmlText ls_Query3_text = ls_dom.CreateTextNode(ls_SESSION_MEMBER_SK.ToString());
                        ls_q3.AppendChild(ls_Query3_text);
                        ls_query = "INSERT INTO CEN_SESSION_HISTORY (SESSION_MEMBER_SK,SESSION_PRODUCT_SK,SESS_OPENED_TIME,BOOK_OPENED_AT,BOOK_CLOSED_AT,ACTIVE,DATE_CREATED,USER_CREATED) VALUES (@txt1111,@txt2222,@txt3333,@txt4444,@txt5555,@txt6666,@txt7777,@txt8888); select @@identity;";

                        SqlParameter ls_param1111 = new SqlParameter();
                        ls_param1111.ParameterName = "@txt1111";

                        if (as_call_type.Equals("B"))
                        {
                            ls_param1111.Value = Convert.ToInt32(ls_SESSION_MEMBER_SK.ToString());
                        }
                        else
                        {
                            ls_param1111.Value = Convert.ToInt32(as_session_member_sk);
                        }

                        SqlParameter ls_param2222 = new SqlParameter();
                        ls_param2222.ParameterName = "@txt2222";

                        if (as_call_type.Equals("B"))
                        {
                            ls_param2222.Value = Convert.ToInt32(ls_SESSION_PRODUCT_SK.ToString());
                        }
                        else
                        {
                            ls_param2222.Value = Convert.ToInt32(as_session_product_sk);
                        }

                        SqlParameter ls_param3333 = new SqlParameter();
                        ls_param3333.ParameterName = "@txt3333";
                        //ls_param3333.Value = DateTime.Now;
                        ls_param3333.Value = Convert.ToDateTime(as_book_read_time);

                        SqlParameter ls_param4444 = new SqlParameter();
                        ls_param4444.ParameterName = "@txt4444";
                        //ls_param4444.Value = DateTime.Now;
                        ls_param4444.Value = Convert.ToDateTime(as_book_read_time);

                        SqlParameter ls_param5555 = new SqlParameter();
                        ls_param5555.ParameterName = "@txt5555";
                        //ls_param5555.Value = DateTime.Now;
                        ls_param5555.Value = Convert.ToDateTime(as_book_read_time);

                        SqlParameter ls_param6666 = new SqlParameter();
                        ls_param6666.ParameterName = "@txt6666";
                        ls_param6666.Value = "Y";

                        SqlParameter ls_param7777 = new SqlParameter();
                        ls_param7777.ParameterName = "@txt7777";
                        ls_param7777.Value = DateTime.Today;

                        SqlParameter ls_param8888 = new SqlParameter();
                        ls_param8888.ParameterName = "@txt8888";
                        ls_param8888.Value = as_user_name;

                        //XmlElement ls_q1 = ls_dom.CreateElement("ls_CUST_SUBS_ITEM_SK");
                        //ls_Method.AppendChild(ls_q1);
                        //XmlText ls_Query1_text = ls_dom.CreateTextNode(ls_CUST_SUBS_ITEM_SK);
                        //ls_q1.AppendChild(ls_Query1_text);

                        SqlCommand command3 = new SqlCommand(ls_query, connection);
                        command3.Parameters.Add(ls_param1111);
                        command3.Parameters.Add(ls_param2222);
                        command3.Parameters.Add(ls_param3333);
                        command3.Parameters.Add(ls_param4444);
                        command3.Parameters.Add(ls_param5555);
                        command3.Parameters.Add(ls_param6666);
                        command3.Parameters.Add(ls_param7777);
                        command3.Parameters.Add(ls_param8888);
                        command3.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                        //command1.Connection.Open();

                        Object ls_SESS_HIST_SK;
                        ls_SESS_HIST_SK = command3.ExecuteScalar();
                        //command.ExecuteNonQuery();

                        XmlElement ls_SESS_HIST_SK_node = ls_dom.CreateElement("SESS_HIST_SK");
                        ls_Method.AppendChild(ls_SESS_HIST_SK_node);
                        XmlText ls_SESS_HIST_SK_node_text = ls_dom.CreateTextNode(ls_SESS_HIST_SK.ToString());
                        ls_SESS_HIST_SK_node.AppendChild(ls_SESS_HIST_SK_node_text);
                        XmlElement ls_Error = ls_dom.CreateElement("Error");
                        ls_Method.AppendChild(ls_Error);
                        XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                        ls_Error.AppendChild(ls_ErrorCode);
                        XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                        ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                        XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                        ls_Error.AppendChild(ls_ErrorDescription);
                        XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                        ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                        XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                        ls_Method.AppendChild(ls_DisplayCustomMessage);
                        XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                        ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                        XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                        ls_Method.AppendChild(ls_MessageCode);
                        XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                        ls_MessageCode.AppendChild(ls_MessageCode_text);

                        command.Connection.Close();

                    }
                    catch (Exception exp)
                    {
                        XmlElement ls_Error = ls_dom.CreateElement("Error");
                        ls_Method.AppendChild(ls_Error);
                        XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                        ls_Error.AppendChild(ls_ErrorCode);
                        XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                        ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                        XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                        ls_Error.AppendChild(ls_ErrorDescription);
                        XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.Message);
                        ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                        XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                        ls_Method.AppendChild(ls_DisplayCustomMessage);
                        XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                        ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                        XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                        ls_Method.AppendChild(ls_MessageCode);
                        XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                        ls_MessageCode.AppendChild(ls_MessageCode_text);

                        SendMail("Exception in iPad Web Services - CreateSessionForBookShelfReading(" + as_cust_subs_sk + ";" + as_user_name + ";" + as_product_sk + ";" + as_call_type + ";" + as_session_member_sk + ";" + as_session_member_sk + ")", ls_CUST_SUBS_USER_SK + exp.Message + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                        return ls_dom;
                    }

                    return ls_dom;
                }
            }
            catch (Exception exp)
            {
                XmlElement ls_Error = ls_dom.CreateElement("Error");
                ls_Method.AppendChild(ls_Error);
                XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                ls_Error.AppendChild(ls_ErrorCode);
                XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                ls_Error.AppendChild(ls_ErrorDescription);
                XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.Message);
                ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                ls_Method.AppendChild(ls_DisplayCustomMessage);
                XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                ls_Method.AppendChild(ls_MessageCode);
                XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                ls_MessageCode.AppendChild(ls_MessageCode_text);

                SendMail("Exception in iPad Web Services - CreateSessionForBookShelfReading(" + as_cust_subs_sk + ";" + as_user_name + ";" + as_product_sk + ";" + as_call_type + ";" + as_session_member_sk + ";" + as_session_member_sk + ")", ls_CUST_SUBS_USER_SK + exp.Message + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                return ls_dom;
            }
        }

        [WebMethod]
        public string Decrypt1(string text, string information)
        {
            LogArguments("Decrypt1", text, information);
            byte[] toEncryptArray = Convert.FromBase64String(text);
            return UTF8Encoding.UTF8.GetString(toEncryptArray);
        }
        protected string Decrypt(string text)
        {
            byte[] toEncryptArray = Convert.FromBase64String(text);
            return UTF8Encoding.UTF8.GetString(toEncryptArray);
        }

        protected string Encrypt(string text)
        {
            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(text);
            return Convert.ToBase64String(toEncryptArray, 0, toEncryptArray.Length);
        }

        [WebMethod]
        public XmlDocument SetBookReadCloseTime(string as_sess_hist_sk, string as_time, string information)
        {

            LogArguments("SetBookReadCloseTime", as_sess_hist_sk + ";" + as_time, information);
            //Connection string to connect with database 

            //string ls_ConnectionString = "";
            string ls_update_statement;

            //ls_ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            ls_update_statement = "UPDATE CEN_SESSION_HISTORY " + "SET BOOK_CLOSED_AT = @time " + " WHERE SESS_HIST_SK = @SESS_HIST_SK";

            SqlParameter ls_param1 = new SqlParameter();
            ls_param1.ParameterName = "@time";
            ls_param1.Value = Convert.ToDateTime(as_time);

            SqlParameter ls_param2 = new SqlParameter();
            ls_param2.ParameterName = "@SESS_HIST_SK";
            ls_param2.Value = as_sess_hist_sk;

            XmlDocument ls_dom = new XmlDocument();

            using (SqlConnection connection = new SqlConnection(ls_ConnectionString))
            {
                SqlCommand command = new SqlCommand(ls_update_statement, connection);
                command.Parameters.Add(ls_param1);
                command.Parameters.Add(ls_param2);

                command.Connection.Open();

                try
                {
                    command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                    command.ExecuteNonQuery();

                    XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
                    ls_dom.AppendChild(ls_WebResponse);
                    XmlElement ls_Method = ls_dom.CreateElement("Method");
                    ls_WebResponse.AppendChild(ls_Method);
                    ls_Method.SetAttribute("RequestName", "SetBookReadCloseTime");
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    command.Connection.Close();
                }

                catch (Exception exp)
                {
                    XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
                    ls_dom.AppendChild(ls_WebResponse);
                    XmlElement ls_Method = ls_dom.CreateElement("Method");
                    ls_WebResponse.AppendChild(ls_Method);
                    ls_Method.SetAttribute("RequestName", "SetBookReadCloseTime");
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.StackTrace);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);
                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);
                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    SendMail("Exception in iPad Web Services", exp.Source + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                    command.Connection.Close();

                    return ls_dom;
                }
            }

            return ls_dom;
        }

        [WebMethod]
        public XmlDocument GetGuestUserKey(string information)
        {
            LogArguments("GetGuestUserKey", "", information);
            string ls_query = "";
            XmlDocument ls_dom = new XmlDocument();
            XmlElement ls_WebResponse = ls_dom.CreateElement("WebResponse");
            ls_dom.AppendChild(ls_WebResponse);
            XmlElement ls_Method = ls_dom.CreateElement("Method");
            ls_WebResponse.AppendChild(ls_Method);
            ls_Method.SetAttribute("RequestName", "GetGuestUserKey");

            ls_query = "INSERT INTO CEN_IPAD_APP_GUEST_CONTROL (GUEST_USER_LOGIN_TIME) VALUES (@txt1);select @@identity;";

            SqlParameter ls_param1 = new SqlParameter();
            ls_param1.ParameterName = "@txt1";
            ls_param1.Value = DateTime.Today;

            using (SqlConnection connection = new SqlConnection(ls_ConnectionString))
            {
                SqlCommand command = new SqlCommand(ls_query, connection);
                command.Parameters.Add(ls_param1);
                command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                command.Connection.Open();

                try
                {
                    object ls_GUEST_USER_KEY_SK;
                    ls_GUEST_USER_KEY_SK = command.ExecuteScalar();

                    XmlElement ls_GUEST_USER_KEY_SK_node = ls_dom.CreateElement("GUEST_USER_LOGIN_NAME");
                    ls_Method.AppendChild(ls_GUEST_USER_KEY_SK_node);
                    XmlText ls_GUEST_USER_KEY_SK_text = ls_dom.CreateTextNode("GUEST" + ls_GUEST_USER_KEY_SK.ToString());
                    ls_GUEST_USER_KEY_SK_node.AppendChild(ls_GUEST_USER_KEY_SK_text);

                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("0");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(ls_success);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    command.Connection.Close();

                }

                catch (Exception exp)
                {
                    XmlElement ls_Error = ls_dom.CreateElement("Error");
                    ls_Method.AppendChild(ls_Error);
                    XmlElement ls_ErrorCode = ls_dom.CreateElement("ErrorCode");
                    ls_Error.AppendChild(ls_ErrorCode);
                    XmlText ls_ErrorCode_text = ls_dom.CreateTextNode("-1");
                    ls_ErrorCode.AppendChild(ls_ErrorCode_text);
                    XmlElement ls_ErrorDescription = ls_dom.CreateElement("ErrorDescription");
                    ls_Error.AppendChild(ls_ErrorDescription);
                    XmlText ls_ErrorDescription_text = ls_dom.CreateTextNode(exp.Message);
                    ls_ErrorDescription.AppendChild(ls_ErrorDescription_text);

                    XmlElement ls_DisplayCustomMessage = ls_dom.CreateElement("DisplayCustomMessage");
                    ls_Method.AppendChild(ls_DisplayCustomMessage);
                    XmlText ls_DisplayCustomMessage_text = ls_dom.CreateTextNode("0");
                    ls_DisplayCustomMessage.AppendChild(ls_DisplayCustomMessage_text);

                    XmlElement ls_MessageCode = ls_dom.CreateElement("MessageCode");
                    ls_Method.AppendChild(ls_MessageCode);
                    XmlText ls_MessageCode_text = ls_dom.CreateTextNode("M0001");
                    ls_MessageCode.AppendChild(ls_MessageCode_text);

                    SendMail("Exception in iPad Web Services", exp.Source + exp.StackTrace, System.Configuration.ConfigurationManager.AppSettings["ExceptionMailAddress"], System.Configuration.ConfigurationManager.AppSettings["ExceptionCCAddress"]);

                    return ls_dom;
                }

                return ls_dom;
            }

        }

        private void LogArguments(string as_method_name, string as_arguments, string information)
        {
            try
            {
                string ls_query = string.Empty, iOSversion = string.Empty, iPadversion = string.Empty, Appversion = string.Empty, IPaddress = string.Empty, userID = string.Empty, CreatedOn = string.Empty;
                if (information != string.Empty)
                {
                    iOSversion = information.Split('|')[0];
                    iPadversion = information.Split('|')[1];
                    Appversion = information.Split('|')[2];
                    IPaddress = information.Split('|')[3];
                    userID = information.Split('|')[4];
                    CreatedOn = DateTime.Now.ToString();
                }

                ls_query = "INSERT INTO CEN_IPAD_APP_WS_LOG (method_name,method_arguments,iOSversion,iPadversion,Appversion,IPaddress,userID,CreatedOn) VALUES (@txt1,@txt2,@txt3,@txt4,@txt5,@txt6,@txt7,@txt8)";

                SqlParameter ls_param1 = new SqlParameter();
                ls_param1.ParameterName = "@txt1";
                ls_param1.Value = as_method_name;

                SqlParameter ls_param2 = new SqlParameter();
                ls_param2.ParameterName = "@txt2";
                ls_param2.Value = as_arguments;

                SqlParameter ls_param3 = new SqlParameter();
                ls_param3.ParameterName = "@txt3";
                ls_param3.Value = iOSversion;

                SqlParameter ls_param4 = new SqlParameter();
                ls_param4.ParameterName = "@txt4";
                ls_param4.Value = iPadversion;

                SqlParameter ls_param5 = new SqlParameter();
                ls_param5.ParameterName = "@txt5";
                ls_param5.Value = Appversion;

                SqlParameter ls_param6 = new SqlParameter();
                ls_param6.ParameterName = "@txt6";
                ls_param6.Value = IPaddress;

                SqlParameter ls_param7 = new SqlParameter();
                ls_param7.ParameterName = "@txt7";
                ls_param7.Value = userID;

                SqlParameter ls_param8 = new SqlParameter();
                ls_param8.ParameterName = "@txt8";
                ls_param8.Value = CreatedOn;



                using (SqlConnection connection = new SqlConnection(ls_ConnectionString))
                {
                    SqlCommand command = new SqlCommand(ls_query, connection);
                    command.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                    command.Parameters.Add(ls_param1);
                    command.Parameters.Add(ls_param2);
                    command.Parameters.Add(ls_param3);
                    command.Parameters.Add(ls_param4);
                    command.Parameters.Add(ls_param5);
                    command.Parameters.Add(ls_param6);
                    command.Parameters.Add(ls_param7);
                    command.Parameters.Add(ls_param8);

                    command.Connection.Open();

                    try
                    {
                        //   LogFileWrite(new Exception("Before call Log"));
                        command.ExecuteNonQuery();
                        //   LogFileWrite(new Exception("After call log"));
                    }
                    catch (Exception exp)
                    {
                        LogFileWrite(exp);
                    }
                }
            }
            catch (Exception ex) { LogFileWrite(ex); }
        }

        protected string ConvertToTitleCase(string as_string)
        {
            CultureInfo cultureInfo = System.Threading.Thread.CurrentThread.CurrentCulture;
            TextInfo textInfo = cultureInfo.TextInfo;
            as_string = textInfo.ToTitleCase(as_string);

            return as_string;

        }

        [WebMethod]
        public string EscapedString(string as_string)
        {
            return EscapeSQLCharacters(as_string);
        }

        [WebMethod]
        public string GetProductSkForISBN13(string as_ISBN13, string information)
        {
            LogArguments("GetProductSkForISBN13", as_ISBN13, information);
            // your code comes here 
            string ls_query, ls_product_sk;
            ls_query = "SELECT PRODUCT_SK from CEN_PRODUCTS where ISBN_13 = '" + as_ISBN13 + "'";

            SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);
            SQLConn.Open();

            DataSet lds_DataStore = new DataSet();
            System.Data.SqlClient.SqlDataAdapter SQLAdapter = new System.Data.SqlClient.SqlDataAdapter(ls_query, SQLConn);
            SQLAdapter.Fill(lds_DataStore);

            if (lds_DataStore.Tables[0].Rows.Count > 0)
            {

                ls_product_sk = lds_DataStore.Tables[0].Rows[0]["PRODUCT_SK"].ToString();
                SQLConn.Close();

                return ls_product_sk;
            }
            else
            {
                return "-1";
            }
        }

        public static void LogFileWrite(Exception e, string username = "before login")
        {
            if (e.Source != "mscorlib" && e.Message.ToLower() != "thread was being aborted." && e.Message.ToLower() != "the document has no pages.")
            {
                FileStream fileStream = null;
                StreamWriter streamWriter = null;
                try
                {
                    string logFilePath = string.Concat(ConfigurationManager.AppSettings["LogFilePath"].ToString(), "Ipad App Exceptions - ", DateTime.Today.ToString("dd-MM-yyyy"), "." + "txt");

                    if (logFilePath.Equals("")) return;
                    #region Create the Log file directory if it does not exists
                    DirectoryInfo logDirInfo = null;
                    FileInfo logFileInfo = new FileInfo(logFilePath);
                    logDirInfo = new DirectoryInfo(logFileInfo.DirectoryName);
                    if (!logDirInfo.Exists) logDirInfo.Create();
                    #endregion Create the Log file directory if it does not exists

                    if (!logFileInfo.Exists)
                    {
                        fileStream = logFileInfo.Create();
                    }
                    else
                    {
                        fileStream = new FileStream(logFilePath, FileMode.Append);
                    }
                    streamWriter = new StreamWriter(fileStream);
                    streamWriter.WriteLine(string.Concat("\r\n-----------------------------------", DateTime.Now, "---------------------------------------------",
                        "\r\n User Name : ", username, "\r\n Type: ", e.GetType(),
                        "\r\n Source: ", e.Source, "\r\n Exception: ", e.Message, "\r\n Description: ", e.StackTrace, "\r\n-----------------------------------------------------------------------------------------------------------------"));
                    string body = string.Concat("<html",
                     "<body>",
                         "<h4>-----------------------------------", DateTime.Now, "--------------------------------------------- </h4>",
                         "<h4>Type: ", e.GetType(), "</h4><h4>Source: ", e.Source, "</h4><h4> Exception: ",
                           e.Message, "</h4><h4> Description: ", e.StackTrace, "</h4><h4>-----------------------------------------------------------------------------------------------------------------</h4>",
                     "</body>",
                 "</html>");
                    //StudentsController.Instance.SendExceptionMail(body, e.Message, Null.SetNullInteger(HttpContext.Current.Session["Subscription"]));
                }
                catch (Exception ex) { }
                finally
                {
                    if (streamWriter != null) streamWriter.Close();
                    if (fileStream != null) fileStream.Close();
                }
            }
        }

        public string GetSubscriptionofProduct(string as_user_name, string as_product_sk)
        {
            string ls_query = "", ls_CUST_SUBS_SK = "";
            try
            {
                ls_query = "SELECT DISTINCT TOP 1 csu.CUST_SUBS_SK " +
                           "FROM CEN_USERS u " +
                           "JOIN CEN_USER_ROLES ur ON ur.USER_SK=U.USER_SK " +
                           "JOIN CEN_TRADING_PARTNER_USERS tpu ON tpu.USER_ROLE_SK=ur.USER_ROLE_SK " +
                           "JOIN CEN_CUSTOMER_SUBS_USERS csu ON csu.TRAD_PART_USER_SK=tpu.TRAD_PART_USER_SK " +
                           "JOIN CEN_CUSTOMER_SUBSCRIPTIONS cs ON csu.CUST_SUBS_SK=cs.CUST_SUBS_SK " +
                           "JOIN CEN_CUSTOMER_SUBS_ITEMS csi ON csi.CUST_SUBS_SK=cs.CUST_SUBS_SK " +
                           "WHERE csi.ACTIVE ='Y' AND csu.ACTIVE = 'y' AND cs.ACTIVE='Y' AND " +
                           "u.USER_LOGIN_NAME='" + as_user_name + "' AND " +
                           "csi.PRODUCT_SK=" + as_product_sk;

                SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);
                SqlCommand sqlCommand = new SqlCommand(ls_query, SQLConn);
                sqlCommand.Connection.Open();
                sqlCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                ls_CUST_SUBS_SK = sqlCommand.ExecuteScalar().ToString();
                sqlCommand.Connection.Close();
            }
            catch (Exception exp)
            {
                LogFileWrite(exp);
            }
            return ls_CUST_SUBS_SK;
        }

        public string GetAllUserSubscriptions(string as_user_name)
        {
            string ls_query = "", ls_CUST_SUBS_SK = "";
            try
            {
                ls_query = "SELECT DISTINCT csu.CUST_SUBS_SK " +
                           "FROM CEN_USERS u " +
                           "JOIN CEN_USER_ROLES ur ON ur.USER_SK=U.USER_SK " +
                           "JOIN CEN_TRADING_PARTNER_USERS tpu ON tpu.USER_ROLE_SK=ur.USER_ROLE_SK " +
                           "JOIN CEN_CUSTOMER_SUBS_USERS csu ON csu.TRAD_PART_USER_SK=tpu.TRAD_PART_USER_SK " +
                           "JOIN CEN_CUSTOMER_SUBSCRIPTIONS cs ON csu.CUST_SUBS_SK=cs.CUST_SUBS_SK " +
                           "WHERE csu.ACTIVE = 'y' AND cs.ACTIVE='Y' AND " +
                           "u.USER_LOGIN_NAME='" + as_user_name + "'";

                SqlConnection SQLConn = new SqlConnection(ls_ConnectionString);
                SqlCommand sqlCommand = new SqlCommand(ls_query, SQLConn);
                sqlCommand.Connection.Open();
                sqlCommand.CommandTimeout = int.Parse(ConfigurationManager.AppSettings["cmdtimeout"].ToString());
                var res = sqlCommand.ExecuteReader();
                while (res.Read())
                {
                    ls_CUST_SUBS_SK = string.Concat(ls_CUST_SUBS_SK, ",", res["CUST_SUBS_SK"]);
                }
                sqlCommand.Connection.Close();
            }
            catch (Exception exp)
            {
                LogFileWrite(exp);
            }
            return ls_CUST_SUBS_SK.TrimStart(',');
        }

        /// <summary>
        ///  Writes values to log file for developer verification
        /// </summary>
        /// <param name="e"></param>
        public static void LogValues(string value)
        {
            FileStream fileStream = null;
            StreamWriter streamWriter = null;
            try
            {
                string logFilePath = string.Concat(ConfigurationManager.AppSettings["LogFilePath"].ToString(), "IPAD Value Check - ", DateTime.Today.ToString("dd-MM-yyyy"), "." + "txt");

                if (logFilePath.Equals("")) return;
                #region Create the Log file directory if it does not exists
                DirectoryInfo logDirInfo = null;
                FileInfo logFileInfo = new FileInfo(logFilePath);
                logDirInfo = new DirectoryInfo(logFileInfo.DirectoryName);
                if (!logDirInfo.Exists) logDirInfo.Create();
                #endregion Create the Log file directory if it does not exists

                if (!logFileInfo.Exists)
                {
                    fileStream = logFileInfo.Create();
                }
                else
                {
                    fileStream = new FileStream(logFilePath, FileMode.Append);
                }
                streamWriter = new StreamWriter(fileStream);
                var uri = new Uri(HttpContext.Current.Request.Url.AbsoluteUri);
                streamWriter.WriteLine(string.Concat("\r\n-----------------------------------", DateTime.Now, "---------------------------------------------",
                   "\r\n Website: ", uri.Host,
                    "\r\n Given Text : ", value, "\r\n-----------------------------------------------------------------------------------------------------------------"));

                // TeacherController.Instance.SendExceptionMail(body, e.Message, Null.SetNullInteger(HttpContext.Current.Session["Subscription"]));
            }
            finally
            {
                if (streamWriter != null) streamWriter.Close();
                if (fileStream != null) fileStream.Close();
            }
        }
    }
}
