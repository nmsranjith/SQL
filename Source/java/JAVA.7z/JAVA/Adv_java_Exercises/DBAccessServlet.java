package com.htc.jee.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.annotation.Resource;
import javax.sql.DataSource;

public class DBAccessServlet extends HttpServlet {

  @Resource(name="jdbc/myOracle",type=javax.sql.DataSource.class)
  DataSource ds;

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   process(request,response);         
  }
  
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    process(request,response);     	
  }
  
  private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException {
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    String tblName = request.getParameter("tbl");
    if(tblName == null){
        tblName = "dept";
    }
    Connection conn = null;
    try{
    conn = ds.getConnection();
    Statement stmt = conn.createStatement();
    ResultSet rs = stmt.executeQuery("select *  from "+tblName);
    ResultSetMetaData rsmd = rs.getMetaData();
    int colCnt = rsmd.getColumnCount();
    while(rs.next()){
      for(int i=0;i<colCnt;i++){
        out.print("&nbsp;&nbsp;"+rs.getString(i+1));  
      }
      out.println("<br/>");
    }
    }catch(SQLException sqe){
      sqe.printStackTrace(out);
    }
    finally{
        try{ 
          if(conn != null) conn.close();
        }catch(SQLException se){     
        }
    }
  }

}
