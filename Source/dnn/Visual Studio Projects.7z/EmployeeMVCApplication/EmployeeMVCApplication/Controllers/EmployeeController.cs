﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EmployeeMVCApplication.Models;

namespace EmployeeMVCApplication.Controllers
{
    public class EmployeeController : Controller
    {
        //
        // GET: /Employee/

        public ActionResult Index()
        {
            NorthwindDataContext nwd = new NorthwindDataContext();
            //Northwind nwd = new Northwind();
            return View(nwd.Northwinds);
        }

        //
        // GET: /Employee/Details/5

        public ActionResult Details(int id)
        {
            return View(GetEmployee(id));
        }

        //
        // GET: /Employee/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /Employee/Create

        [HttpPost]
        public ActionResult Create(Employee emp)
        {
            try
            {
                NorthwindDataContext nw = new NorthwindDataContext();
                //nw.AddToEmployees(emp);
                ////nw.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        
        //
        // GET: /Employee/Edit/5
 
        public ActionResult Edit(int id)
        {
            return View();
        }

        //
        // POST: /Employee/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, Employee emp)
        {
            try
            {
                //Northwind nw = new Northwind();
                //Employee origEmp = GetEmployee(nw.employeeid);
                //nw.Employees.Attach(emp);
                //nw.ApplyOriginalValues("Employees", origEmp);
                //nw.SaveChanges();
 
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Employee/Delete/5
 
        public ActionResult Delete(int id)
        {
            return View();
        }

        //
        // POST: /Employee/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
 
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        [NonAction]
        private Employee GetEmployee(int id)
        {
            NorthwindDataContext ndc = new NorthwindDataContext();
            var emp = (from v in ndc.Northwinds
                       where v.employeeid == id
                       select v).First();
            Employee employee = new Employee();
            employee.EmployeeID = emp.employeeid;
            employee.FirstName = emp.firstname;
            employee.LastName = emp.lastname;
            employee.HomePhone = emp.phonenumber;
            employee.Address = emp.address;
            return employee;
        }
    }
}
