﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using Lib.Web.Mvc.JQuery.JqGrid;
using WFMSTest.Models;

namespace WFMSTest.Controllers
{
    public class TypeController : Controller
    {

        #region WFMS Type Menu

            #region Member Declaretion
            char[] ActiveFlag = { 'Y', 'N' };
            char[] CheckList = { 'Y', 'N' };
            char[] WaitActivity = { 'Y', 'N' };
            string[] LockStatus = { null,"ALLOW", "BLOCKED" };
            #endregion


            #region WFMS Object Types
                    public ActionResult WFMS_ObjectType()
                    {
                        if(Session["Username"]!=null)
                            return View();
                        else
                            return RedirectToAction("WFMS_Login","Home");
                    }

                    [AcceptVerbs(HttpVerbs.Post)]      
                    public ActionResult ObjectTypes(JqGridRequest request)
                    {
                        WFMS_ObjectTypes objWFMS_ObjectTypes= new WFMS_ObjectTypes();
                      
                        //for sorting
                        string sortingName = string.Empty;

                        if (request.SortingName.Equals("ID"))
                        {
                            sortingName = request.SortingName.Replace("ID", "PIT_ID");
                        }
                        else if(request.SortingName.Equals("Description"))
                        {
                            sortingName = request.SortingName.Replace("Description", "PIT_Description");
                        }
                        else if(request.SortingName.Equals("Category"))
                        {
                            sortingName = request.SortingName.Replace("Category", "PIT_Category");
                        }
                        else if (request.SortingName.Equals("SortOrder"))
                        {
                            sortingName = request.SortingName.Replace("SortOrder", "PIT_SORT_ORDER");
                        }

                        int totalRecords = objWFMS_ObjectTypes.GetObjectTypeCount();
            
                        JqGridResponse response = new JqGridResponse()
                        { 
                            //Total pages count
                            TotalPagesCount = (int)Math.Ceiling((float)totalRecords / (float)request.RecordsCount),
                            //Page number
                            PageIndex = request.PageIndex,
                            //Total records count
                            TotalRecordsCount = totalRecords
                        };
                        //Table with rows data
                        foreach (PMA_PROJECT_ITEM_TYPE itemType in objWFMS_ObjectTypes.GetObjectTypes(sortingName, request.SortingOrder.ToString(), request.PageIndex, request.RecordsCount))
                        {                           
                            WFMS_ObjectTypes activeFlag_WFMS_ObjectTypes = new WFMS_ObjectTypes();
                            if (itemType.PIT_ACTIVE_FLAG == 'Y')
                                activeFlag_WFMS_ObjectTypes.ActiveFlag = "<input id='Checkbox1' type='checkbox' checked='checked' disabled='disabled' />";// "<img src='../../Content/Images/checkbox-checked-md.png' width='30px' height='30px'/>";

                            else
                                activeFlag_WFMS_ObjectTypes.ActiveFlag = "<input id='Checkbox1' type='checkbox' disabled='disabled' />";//"<img src='C:\\Users\\ranjithm\\documents\\visual studio 2010\\Projects\\WFMSTest\\WFMSTest\\Content\\Images\\InActive.jpg' alt='test' width='25px' height='25px'/>";
                                                         
                            response.Records.Add(new JqGridRecord(Convert.ToString(itemType.PIT_ID), new List<object>()
                            {
                                itemType.PIT_SK,                                
                                activeFlag_WFMS_ObjectTypes.ActiveFlag,
                                itemType.PIT_ID,
                                itemType.PIT_DESCRIPTION,
                                itemType.PIT_CATEGORY,
                                itemType.PIT_SORT_ORDER
                             }));
                        }

                       //Return data as json
                        return new JqGridJsonResult() { Data = response };
                    }
                
                    [AcceptVerbs(HttpVerbs.Post)]
                    public ActionResult InsertObjectType(WFMS_ObjectTypes viewModel)
                    {
                        PMA_PROJECT_ITEM_TYPE objWFMS_ObjectTypes = new PMA_PROJECT_ITEM_TYPE();
                        objWFMS_ObjectTypes.PIT_USER_CREATED = Session["Username"].ToString();
                        objWFMS_ObjectTypes.PIT_COMPANY_ID = Session["CompanyName"].ToString();
                        objWFMS_ObjectTypes.PIT_ID = viewModel.ID;
                        objWFMS_ObjectTypes.PIT_DESCRIPTION = viewModel.Description;
                        objWFMS_ObjectTypes.PIT_CATEGORY =category[int.Parse(viewModel.Category)];
                        objWFMS_ObjectTypes.PIT_ACTIVE_FLAG = ActiveFlag[int.Parse(viewModel.Active.ToString())];
                        objWFMS_ObjectTypes.PIT_SORT_ORDER = viewModel.SortOrder;
                        objWFMS_ObjectTypes.PIT_ACTIVE_DATE = DateTime.Now;
                        objWFMS_ObjectTypes.PIT_DATE_CREATED = DateTime.Now;
                        return Json(viewModel.AddObjectType(objWFMS_ObjectTypes));
                    }
        
                    [AcceptVerbs(HttpVerbs.Post)]
                    public ActionResult UpdateObjectType(WFMS_ObjectTypes viewModel)
                    {

                        PMA_PROJECT_ITEM_TYPE objWFMS_ObjectTypes = viewModel.GetObjectType(viewModel.ID);
                        objWFMS_ObjectTypes.PIT_ID = viewModel.ID;
                        objWFMS_ObjectTypes.PIT_DESCRIPTION = viewModel.Description;
                        objWFMS_ObjectTypes.PIT_CATEGORY = category[int.Parse(viewModel.Category)];
                        objWFMS_ObjectTypes.PIT_ACTIVE_FLAG = ActiveFlag[int.Parse(viewModel.Active.ToString())];
                        objWFMS_ObjectTypes.PIT_SORT_ORDER = viewModel.SortOrder;

                        try
                        {
                            viewModel.SubmitChanges();
                        }
                        catch
                        {
                            return Json(false);
                        }

                        return Json(true);
                    }

                    [AcceptVerbs(HttpVerbs.Post)]
                    public bool DeleteObjectType(string id)
                    {     
                        string[] objectTypeIdss = id.Split(',');
                        WFMS_ObjectTypes viewModel = new WFMS_ObjectTypes();
                        return viewModel.DeleteObjectType(objectTypeIdss);                        
                    }

                    static Dictionary<int, string> category = new Dictionary<int, string>();
                    public ActionResult GetCategories()
                    {
                        WFMS_ObjectTypes viewModel = new WFMS_ObjectTypes();          
                        category.Clear();
                        string[] categories= viewModel.GetCategories();            
                        for (int i = 0; i < categories.Length; i++)          
                            category.Add(i, categories[i]);            
                            return PartialView("Select", category);
                    }

            #endregion


            #region WFMS Role Types
                    public ActionResult WFMS_RoleType()
                    {
                        if (Session["Username"] != null)
                            return View();
                        else
                            return RedirectToAction("WFMS_Login", "Home");
                    }

                    [AcceptVerbs(HttpVerbs.Post)]
                    public ActionResult RoleTypes(JqGridRequest request)
                    {
                        WFMS_RoleTypes objWFMS_RoleTypes = new WFMS_RoleTypes();


                        int totalRecords = objWFMS_RoleTypes.GetRolesTypeCount();
                        string sortingName = string.Empty;

                        if (request.SortingName.Equals("ID"))
                        {
                            sortingName = request.SortingName.Replace("ID", "RO_ID");
                        }
                        else if (request.SortingName.Equals("Description"))
                        {
                            sortingName = request.SortingName.Replace("Description", "RO_Description");
                        }
                        else if (request.SortingName.Equals("SortOrder"))
                        {
                            sortingName = request.SortingName.Replace("SortOrder", "RO_SORT_ORDER");
                        }
                        JqGridResponse response = new JqGridResponse()
                        {
                            //Total pages count
                            TotalPagesCount = (int)Math.Ceiling((float)totalRecords / (float)request.RecordsCount),
                            //Page number
                            PageIndex = request.PageIndex,
                            //Total records count
                            TotalRecordsCount = totalRecords
                        };
                        //Table with rows data
                        foreach (PMA_ROLE roleType in objWFMS_RoleTypes.GetRoleTypes(sortingName,request.SortingOrder.ToString(), request.PageIndex, request.RecordsCount))
                        {
                            if (roleType.RO_ACTIVE_FLAG == 'Y')
                                objWFMS_RoleTypes.ActiveFlag = "<input id='Checkbox1' type='checkbox' checked='checked' disabled='disabled' />";// "<img src='../../Content/Images/checkbox-checked-md.png' width='30px' height='30px'/>";

                            else
                                objWFMS_RoleTypes.ActiveFlag = "<input id='Checkbox1' type='checkbox' disabled='disabled' />";//"<img src='C:\\Users\\ranjithm\\documents\\visual studio 2010\\Projects\\WFMSTest\\WFMSTest\\Content\\Images\\InActive.jpg' alt='test' width='25px' height='25px'/>";
                                     
                            response.Records.Add(new JqGridRecord(Convert.ToString(roleType.RO_ID), new List<object>()
                            {
                                roleType.RO_SK,                                                 
                                objWFMS_RoleTypes.ActiveFlag,
                                roleType.RO_ID,
                                roleType.RO_DESCRIPTION,  
                                roleType.RO_SORT_ORDER
                             }));
                        }

                        //Return data as json
                        return new JqGridJsonResult() { Data = response };
                    }

                    [AcceptVerbs(HttpVerbs.Post)]
                    public ActionResult InsertRoleType(WFMS_RoleTypes viewModel)
                    {
                        PMA_ROLE objWFMS_RoleTypes = new PMA_ROLE();
                        objWFMS_RoleTypes.RO_USER_CREATED = Session["Username"].ToString();
                        objWFMS_RoleTypes.RO_COMPANY_ID = Session["CompanyName"].ToString();
                        objWFMS_RoleTypes.RO_ID = viewModel.ID;
                        objWFMS_RoleTypes.RO_DESCRIPTION = viewModel.Description;
                        objWFMS_RoleTypes.RO_ACTIVE_FLAG = ActiveFlag[int.Parse(viewModel.Active.ToString())];
                        objWFMS_RoleTypes.RO_SORT_ORDER = viewModel.SortOrder;                        
                        objWFMS_RoleTypes.RO_ACTIVE_DATE = DateTime.Now;
                        objWFMS_RoleTypes.RO_DATE_CREATED = DateTime.Now;
                        return Json(viewModel.AddRoleType(objWFMS_RoleTypes));
                    }

                    [AcceptVerbs(HttpVerbs.Post)]
                    public ActionResult UpdateRoleType(WFMS_RoleTypes viewModel)
                    {

                        PMA_ROLE objWFMS_RoleTypes = viewModel.GetRoleType(viewModel.ID);
                        objWFMS_RoleTypes.RO_ID = viewModel.ID;
                        objWFMS_RoleTypes.RO_DESCRIPTION = viewModel.Description;
                        objWFMS_RoleTypes.RO_ACTIVE_FLAG = ActiveFlag[int.Parse(viewModel.Active.ToString())];
                        objWFMS_RoleTypes.RO_SORT_ORDER = viewModel.SortOrder;

                        try
                        {
                            viewModel.SubmitChanges();
                        }
                        catch
                        {
                            return Json(false);
                        }

                        return Json(true);
                    }

                    [AcceptVerbs(HttpVerbs.Post)]
                    public bool DeleteRoleType(string id)
                    {
                        string[] RoleTypeIds = id.Split(',');
                        WFMS_RoleTypes viewModel = new WFMS_RoleTypes();
                        return viewModel.DeleteRoleType(RoleTypeIds);
                    }

            #endregion


            #region WFMS Activity Types
                    public ActionResult WFMS_ActivityType()
                    {
                        if (Session["Username"] != null)
                            return View();
                        else
                            return RedirectToAction("WFMS_Login", "Home");
                    }

                    [AcceptVerbs(HttpVerbs.Post)]
                    public ActionResult ActivityTypes(JqGridRequest request)
                    {
                        WFMS_ActivityTypes objWFMS_ActivityTypes = new WFMS_ActivityTypes();


                        int totalRecords = objWFMS_ActivityTypes.GetActivityTypeCount();

                        JqGridResponse response = new JqGridResponse()
                        {
                            //Total pages count
                            TotalPagesCount = (int)Math.Ceiling((float)totalRecords / (float)request.RecordsCount),
                            //Page number
                            PageIndex = request.PageIndex,
                            //Total records count
                            TotalRecordsCount = totalRecords
                        };

                        string sortingName = string.Empty;

                        if (request.SortingName.Equals("ID"))
                        {
                            sortingName = request.SortingName.Replace("ID", "AVT_ID");
                        }
                        else if (request.SortingName.Equals("Description"))
                        {
                            sortingName = request.SortingName.Replace("Description", "AVT_DESCRIPTION");
                        }
                        else if (request.SortingName.Equals("LockStatus"))
                        {
                            sortingName = request.SortingName.Replace("LockStatus", "AVT_LOCK_STATUS");
                        }
                        else if (request.SortingName.Equals("WaitActivity"))
                        {
                            sortingName = request.SortingName.Replace("WaitActivity", "AVT_WAIT_ACTIVITY");
                        }
                        else if (request.SortingName.Equals("CheckList"))
                        {
                            sortingName = request.SortingName.Replace("CheckList", "AVT_CHECK_LIST_REQUIRED");
                        }
                        else if (request.SortingName.Equals("SortOrder"))
                        {
                            sortingName = request.SortingName.Replace("SortOrder", "AVT_SORT_ORDER");
                        }

                        //Table with rows data
                        foreach (PMA_ACTIVITY_TYPE activityType in objWFMS_ActivityTypes.GetActivityTypes(sortingName,request.SortingOrder.ToString(), request.PageIndex, request.RecordsCount))
                        {
                            if (activityType.AVT_ACTIVE_FLAG == 'Y')
                                objWFMS_ActivityTypes.ActiveFlag = "<input id='Checkbox1' type='checkbox' checked='checked' disabled='disabled' />";// "<img src='../../Content/Images/checkbox-checked-md.png' width='30px' height='30px'/>";

                            else
                                objWFMS_ActivityTypes.ActiveFlag = "<input id='Checkbox1' type='checkbox' disabled='disabled' />";//"<img src='C:\\Users\\ranjithm\\documents\\visual studio 2010\\Projects\\WFMSTest\\WFMSTest\\Content\\Images\\InActive.jpg' alt='test' width='25px' height='25px'/>";
                                
                            response.Records.Add(new JqGridRecord(Convert.ToString(activityType.AVT_ID), new List<object>()
                            {
                                activityType.AVT_SK,
                                objWFMS_ActivityTypes.ActiveFlag,
                                activityType.AVT_ID,
                                activityType.AVT_DESCRIPTION,                   
                                activityType.AVT_LOCK_STATUS,
                                activityType.AVT_WAIT_ACTIVITY,
                                activityType.AVT_CHECK_LIST_REQUIRED,
                                activityType.AVT_SORT_ORDER
                             }));
                        }

                        //Return data as json
                        return new JqGridJsonResult() { Data = response };
                    }

                    [AcceptVerbs(HttpVerbs.Post)]
                    public ActionResult UpdateActivityType(WFMS_ActivityTypes viewModel)
                    {
                        PMA_ACTIVITY_TYPE objWFMS_ActivityTypes = viewModel.GetActivityType(viewModel.ID);
                        objWFMS_ActivityTypes.AVT_ID = viewModel.ID;
                        objWFMS_ActivityTypes.AVT_DESCRIPTION = viewModel.Description;
                        objWFMS_ActivityTypes.AVT_CHECK_LIST_REQUIRED = CheckList[int.Parse(viewModel.CheckList.ToString())];
                        objWFMS_ActivityTypes.AVT_LOCK_STATUS = LockStatus[int.Parse(viewModel.LockStatus.ToString())];
                        objWFMS_ActivityTypes.AVT_WAIT_ACTIVITY = WaitActivity[int.Parse(viewModel.WaitActivity.ToString())];
                        objWFMS_ActivityTypes.AVT_ACTIVE_FLAG = viewModel.Active[0];
                        objWFMS_ActivityTypes.AVT_SORT_ORDER = viewModel.SortOrder;
                        objWFMS_ActivityTypes.AVT_USER_MODIFIED = Session["Username"].ToString();
                        objWFMS_ActivityTypes.AVT_DATE_MODIFIED = DateTime.Now;
                        try
                        {
                            viewModel.SubmitChanges();
                        }
                        catch
                        {
                            return Json(false);
                        }

                        return Json(true);

                    }

                    [AcceptVerbs(HttpVerbs.Post)]
                    public bool DeleteActivityType(string id)
                    {
                        string[] MethodologyTypeIds = id.Split(',');
                        WFMS_ActivityTypes viewModel = new WFMS_ActivityTypes();
                        return viewModel.DeleteActivityType(MethodologyTypeIds);

                    }


            #endregion


            #region WFMS Methodology Types
                    public ActionResult WFMS_MethodologyType()
                    {
                        if (Session["Username"] != null)
                            return View();
                        else
                            return RedirectToAction("WFMS_Login", "Home");
                    }

                    [AcceptVerbs(HttpVerbs.Post)]
                    public ActionResult MethodologyTypes(JqGridRequest request)
                    {
                        WFMS_MethodologyTypes objWFMS_MethodologyTypes = new WFMS_MethodologyTypes();


                        int totalRecords = objWFMS_MethodologyTypes.GetMethodologyTypeCount();

                        JqGridResponse response = new JqGridResponse()
                        {
                            //Total pages count
                            TotalPagesCount = (int)Math.Ceiling((float)totalRecords / (float)request.RecordsCount),
                            //Page number
                            PageIndex = request.PageIndex,
                            //Total records count
                            TotalRecordsCount = totalRecords
                        };

                        string sortingName = string.Empty;

                        if (request.SortingName.Equals("ID"))
                        {
                            sortingName = request.SortingName.Replace("ID", "MT_ID");
                        }
                        else if (request.SortingName.Equals("Description"))
                        {
                            sortingName = request.SortingName.Replace("Description", "MT_Description");
                        }
                        else if (request.SortingName.Equals("SortOrder"))
                        {
                            sortingName = request.SortingName.Replace("SortOrder", "MT_SORT_ORDER");
                        }

                        //Table with rows data
                        foreach (PMA_METHODOLOGY_TYPE methodologyType in objWFMS_MethodologyTypes.GetMethodologyTypes(sortingName,request.SortingOrder.ToString(), request.PageIndex, request.RecordsCount))
                        {
                            if (methodologyType.MT_ACTIVE_FLAG == 'Y')
                                objWFMS_MethodologyTypes.ActiveFlag = "<input id='Checkbox1' type='checkbox' checked='checked' disabled='disabled' />";// "<img src='../../Content/Images/checkbox-checked-md.png' width='30px' height='30px'/>";

                            else
                                objWFMS_MethodologyTypes.ActiveFlag = "<input id='Checkbox1' type='checkbox' disabled='disabled' />";//"<img src='C:\\Users\\ranjithm\\documents\\visual studio 2010\\Projects\\WFMSTest\\WFMSTest\\Content\\Images\\InActive.jpg' alt='test' width='25px' height='25px'/>";
                             
                            response.Records.Add(new JqGridRecord(Convert.ToString(methodologyType.MT_ID), new List<object>()
                            {
                                methodologyType.MT_SK,
                                objWFMS_MethodologyTypes.ActiveFlag,
                                methodologyType.MT_ID,
                                methodologyType.MT_DESCRIPTION,
                                methodologyType.MT_SORT_ORDER
                             }));
                        }

                        //Return data as json
                        return new JqGridJsonResult() { Data = response };
                    }

        
                    [AcceptVerbs(HttpVerbs.Post)]
                    public ActionResult InsertMethodologyType(WFMS_MethodologyTypes viewModel)
                    {
                        PMA_METHODOLOGY_TYPE objWFMS_MethodologyTypes = new PMA_METHODOLOGY_TYPE();
                        objWFMS_MethodologyTypes.MT_USER_CREATED = Session["Username"].ToString();
                        objWFMS_MethodologyTypes.MT_COMPANY_ID = Session["CompanyName"].ToString();
                        objWFMS_MethodologyTypes.MT_ID = viewModel.ID;
                        objWFMS_MethodologyTypes.MT_DESCRIPTION = viewModel.Description;
                        objWFMS_MethodologyTypes.MT_ACTIVE_FLAG = ActiveFlag[int.Parse(viewModel.Active.ToString())];
                        objWFMS_MethodologyTypes.MT_SORT_ORDER = viewModel.SortOrder;
                        objWFMS_MethodologyTypes.MT_ACTIVE_DATE = DateTime.Now;
                        objWFMS_MethodologyTypes.MT_DATE_CREATED = DateTime.Now;
                        return Json(viewModel.AddMethodologyType(objWFMS_MethodologyTypes));
                    }

                    [AcceptVerbs(HttpVerbs.Post)]
                    public ActionResult UpdateMethodologyType(WFMS_MethodologyTypes viewModel)
                    {
                        PMA_METHODOLOGY_TYPE objWFMS_MethodologyTypes = viewModel.GetMethodologyType(viewModel.ID);
                        objWFMS_MethodologyTypes.MT_ID = viewModel.ID;
                        objWFMS_MethodologyTypes.MT_DESCRIPTION = viewModel.Description;         
                        objWFMS_MethodologyTypes.MT_ACTIVE_FLAG = ActiveFlag[int.Parse(viewModel.Active.ToString())];
                        objWFMS_MethodologyTypes.MT_SORT_ORDER = viewModel.SortOrder;
                        objWFMS_MethodologyTypes.MT_USER_MODIFIED = Session["Username"].ToString();
                        objWFMS_MethodologyTypes.MT_DATE_MODIFIED = DateTime.Now;
                        try
                        {
                            viewModel.SubmitChanges();
                        }
                        catch
                        {
                            return Json(false);
                        }

                        return Json(true);

                    }

                    [AcceptVerbs(HttpVerbs.Post)]
                    public bool DeleteMethodologyType(string id)
                    {
                        string[] MethodologyTypeIds = id.Split(',');
                        WFMS_MethodologyTypes viewModel = new WFMS_MethodologyTypes();
                        return viewModel.DeleteMethodologyType(MethodologyTypeIds);            
                      
                    }

            #endregion

        
            #region WFMS Role Activity Associated Types

                    public ActionResult WFMS_RoleActivityAssociatedType()
                    {
                        if (Session["Username"] != null)
                            return View();
                        else
                            return RedirectToAction("WFMS_Login", "Home");
                    }

                    [AcceptVerbs(HttpVerbs.Post)]
                    public ActionResult RoleActivityAssociatedTypes(JqGridRequest request)
                    {
                        WFMS_RoleActivityAssociatedTypes objWFMS_RoleActivityAssociatedTypes = new WFMS_RoleActivityAssociatedTypes();


                        int totalRecords = objWFMS_RoleActivityAssociatedTypes.GetRolesActivityAssociatedTypeCount();

                        JqGridResponse response = new JqGridResponse()
                        {
                            //Total pages count
                            TotalPagesCount = (int)Math.Ceiling((float)totalRecords / (float)request.RecordsCount),
                            //Page number
                            PageIndex = request.PageIndex,
                            //Total records count
                            TotalRecordsCount = totalRecords
                        };

                        string sortingName = string.Empty;

                        if (request.SortingName.Equals("ID"))
                        {
                            sortingName = request.SortingName.Replace("ID", "RAAT_ID");
                        }
                        else if (request.SortingName.Equals("Description"))
                        {
                            sortingName = request.SortingName.Replace("Description", "RAAT_Description");
                        }

                        //Table with rows data
                        foreach (PMA_ROLE_ATY_ASSO_TYPE objRoleAcivityAssociatedType in objWFMS_RoleActivityAssociatedTypes.GetRoleActivityAssociatedTypes(sortingName,request.SortingOrder.ToString(), request.PageIndex, request.RecordsCount))
                        {
                            if (objRoleAcivityAssociatedType.RAAT_ACTIVE_FLAG == 'Y')
                                objWFMS_RoleActivityAssociatedTypes.ActiveFlag = "<input id='Checkbox1' type='checkbox' checked='checked' disabled='disabled' />";// "<img src='../../Content/Images/checkbox-checked-md.png' width='30px' height='30px'/>";

                            else
                                objWFMS_RoleActivityAssociatedTypes.ActiveFlag = "<input id='Checkbox1' type='checkbox' disabled='disabled' />";//"<img src='C:\\Users\\ranjithm\\documents\\visual studio 2010\\Projects\\WFMSTest\\WFMSTest\\Content\\Images\\InActive.jpg' alt='test' width='25px' height='25px'/>";
                             
                            response.Records.Add(new JqGridRecord(Convert.ToString(objRoleAcivityAssociatedType.RAAT_ID), new List<object>()
                            {
                                objRoleAcivityAssociatedType.RAAT_SK,
                                objWFMS_RoleActivityAssociatedTypes.ActiveFlag,
                                objRoleAcivityAssociatedType.RAAT_ID,
                                objRoleAcivityAssociatedType.RAAT_DESCRIPTION, 
                                objRoleAcivityAssociatedType.RAAT_SORT_ORDER
                             }));
                        }

                        //Return data as json
                        return new JqGridJsonResult() { Data = response };
                    }


                    [AcceptVerbs(HttpVerbs.Post)]
                    public ActionResult InsertRoleActivityAssociatedType(WFMS_RoleActivityAssociatedTypes viewModel)
                    {
                        PMA_ROLE_ATY_ASSO_TYPE objWFMS_RoleActivityAssociatedTypes = new PMA_ROLE_ATY_ASSO_TYPE();
                        objWFMS_RoleActivityAssociatedTypes.RAAT_USER_CREATED = Session["Username"].ToString();
                        objWFMS_RoleActivityAssociatedTypes.RAAT_COMPANY_ID = Session["CompanyName"].ToString();
                        objWFMS_RoleActivityAssociatedTypes.RAAT_ID = viewModel.ID;
                        objWFMS_RoleActivityAssociatedTypes.RAAT_DESCRIPTION = viewModel.Description;
                        objWFMS_RoleActivityAssociatedTypes.RAAT_ACTIVE_FLAG = ActiveFlag[int.Parse(viewModel.Active.ToString())];
                        objWFMS_RoleActivityAssociatedTypes.RAAT_SORT_ORDER = viewModel.SortOrder;
                        objWFMS_RoleActivityAssociatedTypes.RAAT_ACTIVE_DATE = DateTime.Now;
                        objWFMS_RoleActivityAssociatedTypes.RAAT_DATE_CREATED = DateTime.Now;
                        return Json(viewModel.AddRoleActivityAssociatedType(objWFMS_RoleActivityAssociatedTypes));
                    }

                    [AcceptVerbs(HttpVerbs.Post)]
                    public ActionResult UpdateRoleActivityAssociatedType(WFMS_RoleActivityAssociatedTypes viewModel)
                    {

                        PMA_ROLE_ATY_ASSO_TYPE objWFMS_RoleActivityAssociatedTypes = viewModel.GetRoleActivityAssociatedType(viewModel.ID);                 
                        objWFMS_RoleActivityAssociatedTypes.RAAT_ID = viewModel.ID;
                        objWFMS_RoleActivityAssociatedTypes.RAAT_DESCRIPTION = viewModel.Description;
                        objWFMS_RoleActivityAssociatedTypes.RAAT_ACTIVE_FLAG = ActiveFlag[int.Parse(viewModel.Active.ToString())];
                        objWFMS_RoleActivityAssociatedTypes.RAAT_SORT_ORDER = viewModel.SortOrder;                     
                        objWFMS_RoleActivityAssociatedTypes.RAAT_USER_MODIFIED = Session["Username"].ToString();
                        objWFMS_RoleActivityAssociatedTypes.RAAT_DATE_MODIFIED = DateTime.Now;
                        try
                        {
                           bool test= viewModel.SubmitChanges();
                        }
                        catch
                        {
                            return Json(false);
                        }

                        return Json(true);
                    }

                    [AcceptVerbs(HttpVerbs.Post)]
                    public bool DeleteRoleActivityAssociatedType(string id)
                    {
                        string[] RoleActivityAssociatedTypeIds = id.Split(',');
                        WFMS_RoleActivityAssociatedTypes viewModel = new WFMS_RoleActivityAssociatedTypes();
                        return viewModel.DeleteRoleActivityAssociatedType(RoleActivityAssociatedTypeIds);

                    }
            #endregion


            #region WFMS Status Types
                    public ActionResult WFMS_StatusType()
                    {
                        if (Session["Username"] != null)
                            return View();
                        else
                            return RedirectToAction("WFMS_Login", "Home");
                    }

                    [AcceptVerbs(HttpVerbs.Post)]
                    public ActionResult StatusTypes(JqGridRequest request)
                    {
                        WFMS_StatusTypes objWFMS_StatusTypes = new WFMS_StatusTypes();


                        int totalRecords = objWFMS_StatusTypes.GetStatusTypeCount();

                        JqGridResponse response = new JqGridResponse()
                        {
                            //Total pages count
                            TotalPagesCount = (int)Math.Ceiling((float)totalRecords / (float)request.RecordsCount),
                            //Page number
                            PageIndex = request.PageIndex,
                            //Total records count
                            TotalRecordsCount = totalRecords
                        };

                        string sortingName = string.Empty;

                        if (request.SortingName.Equals("ID"))
                        {
                            sortingName = request.SortingName.Replace("ID", "STST_ID");
                        }
                        else if (request.SortingName.Equals("Description"))
                        {
                            sortingName = request.SortingName.Replace("Description", "STST_Description");
                        }
                        else if (request.SortingName.Equals("SortOrder"))
                        {
                            sortingName = request.SortingName.Replace("SortOrder", "STST_SORT_ORDER");
                        }

                        //Table with rows data
                        foreach (PMA_STATUS_TYPE statusType in objWFMS_StatusTypes.GetStatusTypes(sortingName, request.SortingOrder.ToString(), request.PageIndex, request.RecordsCount))
                        {
                            if (statusType.STST_ACTIVE_FLAG == 'Y')
                                objWFMS_StatusTypes.ActiveFlag = "<input id='Checkbox1' type='checkbox' checked='checked' disabled='disabled' />";// "<img src='../../Content/Images/checkbox-checked-md.png' width='30px' height='30px'/>";

                            else
                                objWFMS_StatusTypes.ActiveFlag = "<input id='Checkbox1' type='checkbox' disabled='disabled' />";//"<img src='C:\\Users\\ranjithm\\documents\\visual studio 2010\\Projects\\WFMSTest\\WFMSTest\\Content\\Images\\InActive.jpg' alt='test' width='25px' height='25px'/>";
                            
                            response.Records.Add(new JqGridRecord(Convert.ToString(statusType.STST_ID), new List<object>()
                            {
                                statusType.STST_SK,
                                objWFMS_StatusTypes.ActiveFlag,
                                statusType.STST_ID,
                                statusType.STST_DESCRIPTION,
                                statusType.STST_SORT_ORDER
                             }));
                        }

                        //Return data as json
                        return new JqGridJsonResult() { Data = response };
                    }


                    [AcceptVerbs(HttpVerbs.Post)]
                    public ActionResult InsertStatusType(WFMS_StatusTypes viewModel)
                    {
                        PMA_STATUS_TYPE objWFMS_StatusTypes = new PMA_STATUS_TYPE();
                        objWFMS_StatusTypes.STST_USER_CREATED = Session["Username"].ToString();
                        objWFMS_StatusTypes.STST_COMPANY_ID = Session["CompanyName"].ToString();
                        objWFMS_StatusTypes.STST_ID = viewModel.ID;
                        objWFMS_StatusTypes.STST_DESCRIPTION = viewModel.Description;
                        objWFMS_StatusTypes.STST_ACTIVE_FLAG = ActiveFlag[int.Parse(viewModel.Active.ToString())];
                        objWFMS_StatusTypes.STST_SORT_ORDER = viewModel.SortOrder;
                        objWFMS_StatusTypes.STST_ACTIVE_DATE = DateTime.Now;
                        objWFMS_StatusTypes.STST_DATE_CREATED = DateTime.Now;
                        return Json(viewModel.AddStatusType(objWFMS_StatusTypes));
                    }

                    [AcceptVerbs(HttpVerbs.Post)]
                    public ActionResult UpdateStatusType(WFMS_StatusTypes viewModel)
                    {
                        PMA_STATUS_TYPE objWFMS_StatusTypes = viewModel.GetStatusType(viewModel.ID);
                        objWFMS_StatusTypes.STST_ID = viewModel.ID;
                        objWFMS_StatusTypes.STST_DESCRIPTION = viewModel.Description;
                        objWFMS_StatusTypes.STST_ACTIVE_FLAG = ActiveFlag[int.Parse(viewModel.Active.ToString())];
                        objWFMS_StatusTypes.STST_SORT_ORDER = viewModel.SortOrder;
                        objWFMS_StatusTypes.STST_USER_MODIFIED = Session["Username"].ToString();
                        objWFMS_StatusTypes.STST_DATE_MODIFIED = DateTime.Now;
                        try
                        {
                            viewModel.SubmitChanges();
                        }
                        catch
                        {
                            return Json(false);
                        }

                        return Json(true);
                    }

                    [AcceptVerbs(HttpVerbs.Post)]
                    public bool DeleteStatusType(string id)
                    {
                        string[] StatusTypeIds = id.Split(',');
                        WFMS_StatusTypes viewModel = new WFMS_StatusTypes();
                        return viewModel.DeleteStatusType(StatusTypeIds);

                    }
            #endregion    
        #endregion
    }
}
