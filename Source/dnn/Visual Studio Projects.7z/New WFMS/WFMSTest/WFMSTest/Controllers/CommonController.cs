﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WFMSTest.Controllers
{
    public class CommonController : Controller
    {
        //
        // GET: /Common/

        public ActionResult WFMS_LookUp()
        {
            return View();
        }

    }
}
