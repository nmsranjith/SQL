﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using Lib.Web.Mvc.JQuery.JqGrid;
using WFMSTest.Models;

namespace WFMSTest.Controllers
{
    public class MasterDetailsController : Controller
    {
        //
        // GET: /Master/

        public ActionResult WFMS_Status()
        {
            if (Session["Username"] != null)
                return View();
            else
                return RedirectToAction("WFMS_Login", "Home");
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Status(JqGridRequest request,string time)
        {
            WFMS_Status objWFMS_Status = new WFMS_Status();

            //for sorting
            string sortingName = string.Empty;

            if (request.SortingName.Equals("ID"))
            {
                sortingName = request.SortingName.Replace("ID", "STS_ID");
            }
            else if (request.SortingName.Equals("Description"))
            {
                sortingName = request.SortingName.Replace("Description", "STS_Description");
            }

            int totalRecords = objWFMS_Status.GetStatusCount();

            JqGridResponse response = new JqGridResponse()
            {
                //Total pages count
                TotalPagesCount = (int)Math.Ceiling((float)totalRecords / (float)request.RecordsCount),
                //Page number
                PageIndex = request.PageIndex,
                //Total records count
                TotalRecordsCount = totalRecords
            };
            //Table with rows data
            foreach (PMA_STATUS itemType in objWFMS_Status.GetStatus(sortingName, request.SortingOrder.ToString(), request.PageIndex, request.RecordsCount))
            {
                if (itemType.STS_ACTIVE_FLAG == 'Y')
                    objWFMS_Status.ActiveFlag = "<input id='Checkbox1' type='checkbox' checked='checked' disabled='disabled' />";// "<img src='../../Content/Images/checkbox-checked-md.png' width='30px' height='30px'/>";

                else
                    objWFMS_Status.ActiveFlag = "<input id='Checkbox1' type='checkbox' disabled='disabled' />";//"<img src='C:\\Users\\ranjithm\\documents\\visual studio 2010\\Projects\\WFMSTest\\WFMSTest\\Content\\Images\\InActive.jpg' alt='test' width='25px' height='25px'/>";

                response.Records.Add(new JqGridRecord(Convert.ToString(itemType.STS_ID), new List<object>()
                            {                                
                                itemType.STS_ID,
                                itemType.STS_DESCRIPTION,
                                itemType.STS_SORT_ORDER
                             }));
            }

            //Return data as json
            return new JqGridJsonResult() { Data = response };
        }

    }
}
