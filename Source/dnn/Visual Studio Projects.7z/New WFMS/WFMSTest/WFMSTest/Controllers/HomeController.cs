﻿using System;
using System.Linq;
using System.Web.Mvc;
using WFMSTest.Models;
using System.Text;
using System.Security.Cryptography;
using Lib.Web.Mvc.JQuery.JqGrid;
using System.Collections.Generic;
namespace WFMSTest.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult WFMS_Login()
        {
            return View();
        }       

        [HttpPost]
        public JsonResult Login(FormCollection collection)
        {
            WFMS_Login loginUser = new WFMS_Login
            {
                PRS_ID = collection["Username"],
                PRS_Password = Convert.ToBase64String(new MD5CryptoServiceProvider().ComputeHash(new UTF8Encoding().GetBytes(collection["Password"]))),
                PRS_CompanyName = collection["CompanyName"]
            };
            string sss=Convert.ToBase64String(new SHA1CryptoServiceProvider().ComputeHash(new UTF8Encoding().GetBytes(collection["Username"])));

            WFMS_DataBaseDataContext datacontext = new WFMS_DataBaseDataContext();
            var login_check = (from user in datacontext.PMA_PERSONs
                               where (user.PRS_ID == loginUser.PRS_ID) & (user.PRS_PASSWORD == loginUser.PRS_Password) & (user.PRS_COMPANY_ID == loginUser.PRS_CompanyName)
                               select user).Count();
                return Json(login_check,JsonRequestBehavior.AllowGet);
            
        }

        public ActionResult WFMS_Menu()
        {
            if (Session["Username"] != null)
            {
                return View();
            }
            else
                return RedirectToAction("WFMS_Login", "Home");
        }
       

        public void SetUserSession(FormCollection collection)
        {
            Session["Username"] = collection["Username"];
            Session["CompanyName"] = collection["CompanyName"];            
        }

        public void StopSession()
        {
            Session.Clear();
        }
        public ActionResult WFMS_Logout()
        {
            return View();
        }
        public ActionResult GetCategories()
        {
            WFMS_ObjectTypes viewModel = new WFMS_ObjectTypes();           
            Dictionary<int, string> category = new Dictionary<int, string>();
            string[] categories = viewModel.GetCategories();
            for (int i = 0; i < categories.Length; i++)
                category.Add(i, categories[i]);
            return PartialView("Select", category);
        }
      
      }
}
