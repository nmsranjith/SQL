﻿$(function () {
    $('#ObjectTypesGrid').jqGrid({
        url: '/Type/ObjectTypes',
        datatype: 'json',
        mtype: 'POST',
        colNames: ['SI.No', 'Active', 'ID', 'Description', 'Category', 'Sort Order'],
        colModel: [
                            { name: 'SI.No', index: 'SI.No', align: 'left', width: 10, editable: false, hidden: true },
                            { name: 'Active', index: 'Active', align: 'center',sortable: false, width: 100, editable: true, edittype: 'select', editoptions: { value: "0:Yes;1:No" }, editrules: { required: true }, search: true, sortable:false },
                            { name: 'ID', index: 'ID', align: 'left', width: 175, editable: true, search: true, edittype: 'text'},
                            { name: 'Description', index: 'Description', width: 340, align: 'left', editable: true, sortable:true, edittype: 'text', editoptions: { maxlength: 40 }, editrules: { required: true }, search: true },
                            { name: 'Category', index: 'Category', align: 'left', width: 125, editable: true, edittype: 'select', editoptions: { dataUrl: '/Type/GetCategories' }, editrules: { required: true }, search: true },
                            { name: 'SortOrder', index: 'SortOrder', width: 100,sortable: false, align: 'left', sortable:false, editable: true, edittype: 'text', editoptions: { maxlength: 10 }, editrules: { integer: true, minValue: 0} }
                            ],
        pager: $('#ObjectTypesGridPager'),
        rowNum: 15,
        sortname: 'SortOrder',
        height: '100%',
        width: '100%',
        sort : 'desc',
        rownumbers: true,
        viewrecords: true, shrinkToFit: true,
        multiselect: true,
        postData: objectTypeIds,
        reloadAfterSubmit: true,
        caption: 'Object Types'
    });
    var objectTypeIds;
    objectTypeIds = jQuery("#ObjectTypesGrid").jqGrid('getGridParam', 'selarrrow');
    $('#ObjectTypesGrid').jqGrid('navGrid', '#ObjectTypesGridPager',
                { add: true, del: true, edit: true, sort: true,search:false},
                { width: 'auto', url: '/Type/UpdateObjectType', closeAfterEdit: true, closeOnEscape: true, beforeShowForm: function (form) { $('#tr_ID', form).hide(); } },
                { width: 'auto', url: '/Type/InsertObjectType', closeAfterAdd: true, closeOnEscape: true, beforeShowForm: function (form) { $('#tr_ID', form).show(); } },
                { width: 'auto', url: '/Type/DeleteObjectType'}
        );

});


