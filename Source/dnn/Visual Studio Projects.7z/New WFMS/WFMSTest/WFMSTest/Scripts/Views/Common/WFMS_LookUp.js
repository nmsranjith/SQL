﻿
$(
function () {

    $('<center>' +
        '<table>' +
            '<tr>' +
                '<td>Status Id</td>' +
                '<td><input id="StatusIdTextBox" type="text"/></td>' +
                '<td>Description</td>' +
                '<td><input id="DescriptionTextBox" type="text"/></td>' +
            '</tr>' +
        '</table>' +
      '</center>').insertBefore('#LookUpGrid');

    $('#LookUpGrid').jqGrid({
        url: '/MasterDetails/Status',
        datatype: 'json',
        mtype: 'POST',
        colNames: ['ID', 'Description'],
        colModel: [
                            { name: 'ID', index: 'ID', align: 'left', width: 175 },
                            { name: 'Description', index: 'Description', width: 340, align: 'left' },
                           ],
        pager: $('#LookUpGridPager'),
        rowNum: 15,
        sortname: 'ID',
        height: '100%',
        width: '100%',
        sortorder: 'asc',
        rownumbers: true,
        viewrecords: true, shrinkToFit: true,
        postData: LookUpIds,
        reloadAfterSubmit: true,
        caption: 'LookUp Details',
        onSelectRow: function (id) {
            cells(id);
        }
    });

    var LookUpId;
    var LookUpIds = jQuery("#LookUpGrid").jqGrid('getGridParam', 'selarrow');


});

var name;
function cells(id) {
    name = $('#LookUpGrid').jqGrid('getCell', id, 'Description');
    $('#StatusTypeId').val(id);
    $('#Description').val(name);
}








//$(var x = location.search.substr(1).split(""); alert(x); window.opener.document.getElementById('&'+x+'&').value = id; 
//function () {
//    $('#LookUpGrid').jqGrid({
//        url: '/MasterDetails/Status',
//        datatype: 'json',
//        mtype: 'POST',
//        colNames: ['ID', 'Description'],
//        colModel: [
//                            { name: 'ID', index: 'ID', align: 'left', width: 175},
//                            { name: 'Description', index: 'Description', width: 340, align: 'left'},
//                           ],
//        pager: $('#LookUpGridPager'),
//        rowNum: 15,
//        sortname: 'ID',
//        height: '100%',
//        width: '100%',
//        sortorder: 'asc',
//        rownumbers: true,
//        viewrecords: true, shrinkToFit: true,       
//        postData: LookUpIds,
//        reloadAfterSubmit: true,
//        caption: 'LookUp Details',        
//        onSelectRow: function(id){ alert('Selected row ID ' + id); },
//        ondblClickRow: function (id) { alert('Selected row ID ' + id); }
//    });
//    var LookUpId;
//   var LookUpIds = jQuery("#LookUpGrid").jqGrid('getGridParam', 'selarrow');
//});