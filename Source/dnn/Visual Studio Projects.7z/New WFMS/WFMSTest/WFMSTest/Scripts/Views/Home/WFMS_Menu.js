﻿

$(
    function Index() {

        $('<center><div><table id="Menu">' +
                    '<tr>' +
                        '<td><img src="../../Content/Images/logo.gif"></td>' +
                        '<td><center style="margin-left:17%;"><img src="../../Content/Images/banner1.gif"></center></td>' +
                     '</tr>' +
                     '<tr id="banner2">' +
                        '<td style="width:155px;height:29px;"><center><img src="../../Content/Images/WFMS.gif" alt="wfmslogo"/></td>' +
                            '<td id="User">'+
                                    '<strong style="margin-left:69%;"><i style="color:maroon;font-size:1.2em;">Welcome</i> &nbsp&nbsp&nbsp <big style="font-size:1.2em;">' + $('#Username').val() +'</big>'+
                                    '&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<b id="LogoutLinkButton" class="Links">Logout</b></strong></div></center>' +
                                    '<div id="MenuItems" style="margin-top:3px;"></div>' +
                         '</td>' +
                    '</tr></table></div></center>').insertBefore('#end');

        $('#menu').appendTo('#MenuItems');
        $('#menu').css({ 'visibility': 'visible' });

        $('<input id="text" type="hidden" />').insertAfter('#end');

        $('<p id="main"><img src="../../Content/Images/map.gif"/></p>' +
                  '<div id="footer"><hr width="900px"/>Copyright&nbsp;©&nbsp;2012&nbsp;WFMS</div>').insertAfter('#Menu');

        /************************************/
        $('#ObjectType').click(function () {
            test = 2;
            $('#main').load(refreshTest());
        });
        $('#ActvityType').click(function () {
            $('#main').load('/Type/WFMS_ActivityType/');
        });
        $('#MethodologyType').click(function () {
            test = 3;
            $('#main').load('/Type/WFMS_MethodologyType/');
        });
        $('#RoleType').click(function () {
            $('#main').load('/Type/WFMS_RoleType/');
        });
        $('#RoleActivityAssociatedType').click(function () {
            $('#main').load('/Type/WFMS_RoleActivityAssociatedType/');
        });
        $('#StatusType').click(function () {
            $('#main').load('/Type/WFMS_StatusType/');
        });
        $('#Status').click(function () {
            $('#main').load('/MasterDetails/WFMS_Status/');
        });
        /*************************************/

//        $('#LogoutLinkButton').click(function () {
//            test = 1;
//            $('#banner2').remove();
//            $('#main').empty();
//            $('#switcher').remove();
//            $('#main').load('/Home/Logout/');
//        });

        $('#LogoutLinkButton').click(function () {
            $.ajax({
                url: "/Home/StopSession/",
                type: "post",
                success: function () { window.location.replace("/Home/WFMS_Logout/"); }
            });
        });

        $('.dropdown').each(function () {
            $(this).parent().eq(0).hover(function () {
                $('.dropdown:eq(0)', this).show();
            }, function () {
                $('.dropdown:eq(0)', this).hide();
            });
        });



        // $("#tabs").tabs();
        var switcher = $('#switcher');
        if (switcher)
            switcher.themeswitcher();


    }
);
    var test = 0;
    function refreshTest() 
    {
       
        if (test == 0) {
            return "/Home/Menu/";
        }
        else if (test == 1) {
            return "/Home/Logout/";
        //window.location.transfer('/Home/Logout/');
        }
        else if(test==2) {
            return "/Type/WFMS_ObjectType/";
        }
        else if (test == 3) {
            return "/Type/WFMS_MethodologyType/";
        }
    }
