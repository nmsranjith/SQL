﻿$(
    function () {
            $('<center>'+
                    '<div style="margin-top:100px;">'+
                            '<img src="../../Content/Images/logo.gif" alt=""/>'+
                            '<img src="../../Content/Images/banner1.gif" alt="" style="margin-left:100px;"/>'+
                    '</div>'+

                    '<div style="margin-top:10px;"> '+
                            '<img src="../../Content/Images/Logout.jpg" alt="loggedout" />'+
                            '<br />'+
                            'Click here to &nbsp '+
                            '<b id="BackToLogin" class="Links">Login</b>'+
                    '</div>'+
               '</center>').insertBefore('#end');
  
        $('#BackToLogin').click(function () { window.location.replace('/Home/WFMS_Login/'); });
    }
);