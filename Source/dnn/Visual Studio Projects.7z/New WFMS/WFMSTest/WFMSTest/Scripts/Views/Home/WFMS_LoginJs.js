﻿
var UserFlag = 0, PasswordFlag = 0, CompanyFlag = 0;

$(function Login() {
    $('<center><div style="margin-top:150px;"><span id="Message" value=" " style="color:red;"/>' +
                                  '<div class="login"><div class="sec">' +
                                    '<table class="loginTable"><tr><td>User Name</td><td><input id="UsernameTextBox" type="text" class="username"/></td><td><span id="UsernameSpan" style="color:red;"></span></td></tr>' +
                                                    '<tr><td>Password</td><td><input id="PasswordTextBox" type="password" class="password" /></td><td><span id="PasswordSpan" style="color:red;"></span></td></tr>' +
                                                    '<tr><td>Company Name</td><td><input id="CompanyNameTextBox" type="text" class="company" /></td><td><span id="CompanyNameSpan" style="color:red;"></span></td></tr>' +
                                                    '<tr align="center"><td colspan="2"></td></tr>' +
                                    '</table><input id="LogonButton" type="button" value="   Logon" class="button"/>' +
                                  '</div></div></center>').insertBefore('#end');
    $('#LogonButton').click(
    function () {
        if (UserFlag == 0 && PasswordFlag == 0 && CompanyFlag == 0) {
            var loginDetails = { Username: $("#UsernameTextBox").val(), Password: $("#PasswordTextBox").val(), CompanyName: $("#CompanyNameTextBox").val() };
            $.ajax(
            {
                type: "POST",
                url: '/Home/Login',
                data: loginDetails,
                dataType: "json",
                success: function (data) {
                    if (data == 1) {
                        $.ajax(
                        {
                            url: '/Home/SetUserSession',
                            data: loginDetails,
                            dataType: "json",
                            type: "post",
                            success: function () { window.location.replace("/Home/WFMS_Menu"); }
                        })

                    }
                    else {
                        $('#Message').empty();
                        $('#Message').append("Invalid User Name or Password or Company Name");
                    }
                }
            })
        }
        else {
            $('#Message').empty();
            $('#Message').append("Please fill the Mandatory Fields");
            if (UserFlag == 1)
                $('#UsernameTextBox').focus();
            else if (PasswordFlag == 1)
                $('#PasswordTextBox').focus();
            else if (CompanyFlag == 1)
                $('#CompanyNameTextBox').focus();                

        }
    });
});


    $(document).keypress(function(event) {
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode == '13') {
        $('#LogonButton').click();
        }
    });
$(
    function Validation() {
        if ($("#UsernameTextBox").val().length == 0) {
            $("#UsernameSpan").append("*");
            UserFlag = 1;
            $('#UsernameTextBox').focus();
        }
        if ($("#PasswordTextBox").val().length == 0) {
            $("#PasswordSpan").append("*");
            PasswordFlag = 1;
        }

        if ($("#CompanyNameTextBox").val().length == 0) {
            $("#CompanyNameSpan").append("*");
            CompanyFlag = 1;
        }


        $("#UsernameTextBox").change(function () {
            $("#UsernameSpan").empty();
            if ($("#UsernameTextBox").val().length == 0) {
                $("#UsernameSpan").append("*");
                UserFlag = 1;
            }
            else
                UserFlag = 0;
        });


        $("#PasswordTextBox").change(function () {

            $("#PasswordSpan").empty();
            if ($("#PasswordTextBox").val().length == 0) {
                $("#PasswordSpan").append("*");
                PasswordFlag = 1;
            }
            else 
                PasswordFlag = 0;               

        });


        $("#CompanyNameTextBox").change(function () {

            $("#CompanyNameSpan").empty();
            if ($("#CompanyNameTextBox").val().length == 0) {
                $("#CompanyNameSpan").append("*");
                CompanyFlag = 1;
            }
            else
                CompanyFlag = 0;
        }); 

    }
);


    function User() {
        $(function () {
            $.ajax(
                        {
                            url: '/Home/UserSession',
                            data: { Username: $("#UsernameTextBox").val() },
                            dataType: "json",
                            type: "post"                        
                        })
        });
    }