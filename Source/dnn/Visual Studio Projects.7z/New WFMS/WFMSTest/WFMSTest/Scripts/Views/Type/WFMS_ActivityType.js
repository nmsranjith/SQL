﻿$(function () {
    $('#ActivityTypeGrid').jqGrid({
        url: '/Type/ActivityTypes',     
        editurl: '/Type/UpdateActivityType',
        //event for inline edit
        onSelectRow: function (currentSelectedRow) {
            if (currentSelectedRow && currentSelectedRow != $.lastSelectedRow) {
                //save changes in row 
                $('#ActivityTypeGrid').jqGrid('saveRow', $.lastSelectedRow, false);
                $.lastSelectedRow = currentSelectedRow;
            }
            //trigger inline edit for row
            $('#ActivityTypeGrid').jqGrid('editRow', $.lastSelectedRow, true);
        },
        datatype: 'json',
        mtype: 'POST',
        colNames: ['SI.No', 'Active', 'ID', 'Description', 'Lock Status', 'Wait Activity', 'Check List', 'Sort Order'],
        colModel: [
                            { name: 'SI.No', index: 'SI.No', align: 'left', width: 100, editable: false, hidden: true },
                            { name: 'Active', index: 'Active', align: 'center', width: 75, editable: true, edittype: 'checkbox', editoptions: { value: "Yes:No" }, sortable: false, editrules: { required: true} },
                            { name: 'ID', index: 'ID', align: 'left', width: 150, editable: false},
                            { name: 'Description', index: 'Description', width: 310, align: 'left', editable: true, sortable: true, edittype: 'text', editoptions: { maxlength: 40 }, editrules: { required: true }},
                            { name: 'LockStatus', index: 'LockStatus', align: 'left', width: 100, editable: true, sortable: true, edittype: 'select', editoptions: { value: "0:;1:Allow;2:Blocked"} },
                            { name: 'WaitActivity', index: 'WaitActivity', width: 75, align: 'left', editable: true, sortable: true, edittype: 'select', editoptions: { value: "0:Yes;1:No" }, editrules: { required: true} },
                            { name: 'CheckList', index: 'CheckList', align: 'left', width: 75, editable: true, edittype: 'select', sortable: true, editoptions: { value: "0:Yes;1:No" }, editrules: { required: true} },
                            { name: 'SortOrder', index: 'SortOrder', width: 75, align: 'left', editable: true, edittype: 'text', sortable: false, editoptions: { maxlength: 10 }, editrules: { integer: true, minValue: 0} }
                            ],
        pager: $('#ActivityTypePager'),
        rowNum: 15,
        sortname: 'SortOrder',
        height: '100%',
        width: '100%',
        sortorder: 'desc',
        rownumbers: true,
        shrinkToFit: true,     
        viewrecords:true,        
        caption: 'Activity Types'
    });

    $('#ActivityTypeGrid').jqGrid('navGrid', '#ActivityTypePager',
                { add: false, del: true, edit: false, search: false },
                {},{},
                { width: 'auto', url: '/Type/DeleteActivityType' });

   // $("#ActivityTypeGrid").jqGrid('gridResize', { minWidth: 350, maxWidth: 900, minHeight: 80, maxHeight: 500 });   
});

/*
$(document).ready(function () {
    $('#ActivityTypeGridTree').treeGrid({
        //enabled TreeGrid
        treeGrid: true,
        //set TreeGrid model
        treeGridModel: 'adjacency',
        //set expand column
        ExpandColumn: 'ID',
        //url from wich data should be requested
        url: '/Type/ActivityTypes',
        //type of data
        datatype: 'json',
        //url access method type
        mtype: 'POST',
        //columns names
        colNames: ['SI.No', 'Active', 'ID', 'Description', 'Lock Status', 'Wait Activity', 'Check List', 'Sort Order'],
        colModel: [
                            { name: 'SI.No', index: 'SI.No', align: 'left', width: 100, editable: false, hidden: true },
                            { name: 'Active', index: 'Active', align: 'center', width: 75, editable: true, edittype: 'checkbox', editoptions: { value: "Yes:No" }, sortable: false, editrules: { required: true} },
                            { name: 'ID', index: 'ID', align: 'left', width: 150, editable: false },
                            { name: 'Description', index: 'Description', width: 310, align: 'left', editable: true, sortable: true, edittype: 'text', editoptions: { maxlength: 40 }, editrules: { required: true} },
                            { name: 'LockStatus', index: 'LockStatus', align: 'left', width: 100, editable: true, sortable: true, edittype: 'select', editoptions: { value: "0:;1:Allow;2:Blocked"} },
                            { name: 'WaitActivity', index: 'WaitActivity', width: 75, align: 'left', editable: true, sortable: true, edittype: 'select', editoptions: { value: "0:Yes;1:No" }, editrules: { required: true} },
                            { name: 'CheckList', index: 'CheckList', align: 'left', width: 75, editable: true, edittype: 'select', sortable: true, editoptions: { value: "0:Yes;1:No" }, editrules: { required: true} },
                            { name: 'SortOrder', index: 'SortOrder', width: 75, align: 'left', editable: true, edittype: 'text', sortable: false, editoptions: { maxlength: 10 }, editrules: { integer: true, minValue: 0} }
                            ],
        //grid height
        height: '100%', pager : "#ptreegrid",caption: "Treegrid example",
        //all rows
        rowNum: -1 
    });*/
});

