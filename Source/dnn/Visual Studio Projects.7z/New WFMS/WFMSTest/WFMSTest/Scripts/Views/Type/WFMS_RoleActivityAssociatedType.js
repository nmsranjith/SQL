﻿$(function () {
    $('#RoleActivityAssociatedTypeGrid').jqGrid({
        url: '/Type/RoleActivityAssociatedTypes',
        datatype: 'json',
        mtype: 'POST',
        colNames: ['SI.No', 'Active', 'ID', 'Description', 'SortOrder'],
        colModel: [
                            { name: 'SI.No', index: 'SI.No', align: 'left', width: 150, editable: false, hidden: true },
                            { name: 'Active', index: 'Active', align: 'center', sortable: false, width: 150, editable: true, edittype: 'select', editoptions: { value: "0:Yes;1:No" }, editrules: { required: true }, search: true },
                            { name: 'ID', index: 'ID', align: 'left', width: 225, sortable: true, editable: true, search: true, edittype: 'text' },
                            { name: 'Description', index: 'Description', width: 340, align: 'left', sortable: true, editable: true, sortable: true, edittype: 'text', editoptions: { maxlength: 40 }, editrules: { required: true }, search: true },
                            { name: 'SortOrder', index: 'SortOrder', width: 140, sortable: false, align: 'left', editable: true, edittype: 'text', editoptions: { maxlength: 10 }, editrules: { integer: true, minValue: 0} }
                            ],
        pager: $('#RoleActivityAssociatedTypePager'),
        rowNum: 15,
        sortname: 'SortOrder',
        height: '100%',
        width: '100%',
        sortorder: 'desc',
        rownumbers: true,
        viewrecords: true, shrinkToFit: true,
        multiselect: true,
        postData: objectTypeIds,
        caption: 'Role Activity Associated Types'
    });
    var objectTypeIds;
    objectTypeIds = jQuery("#RoleActivityAssociatedTypeGrid").jqGrid('getGridParam', 'selarrrow');
    $('#RoleActivityAssociatedTypeGrid').jqGrid('navGrid', '#RoleActivityAssociatedTypePager',
                { add: true, del: true, edit: true, search: true, sort: true, gridModel: true, gridNames: true, formtype: 'vertical', autosearch: true },
                { width: 'auto', url: '/Type/UpdateRoleActivityAssociatedType', closeAfterEdit: true, closeOnEscape: true, beforeShowForm: function (form) { $('#tr_ID', form).hide(); } },
                { width: 'auto', url: '/Type/InsertRoleActivityAssociatedType', closeAfterAdd: true, closeOnEscape: true, beforeShowForm: function (form) { $('#tr_ID', form).show(); } },
                { width: 'auto', url: '/Type/DeleteRoleActivityAssociatedType' }
        );

    
});

