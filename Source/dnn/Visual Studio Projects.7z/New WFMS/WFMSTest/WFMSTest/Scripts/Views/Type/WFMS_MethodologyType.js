﻿$(function () {
    $('#MethodologyTypeGrid').jqGrid({
        url: '/Type/MethodologyTypes',
        datatype: 'json',
        mtype: 'POST',
        colNames: ['SI.No', 'Active', 'ID', 'Description', 'SortOrder'],
        colModel: [
                            { name: 'SI.No', index: 'SI.No', align: 'left', width: 150, editable: false, hidden: true },
                            { name: 'Active', index: 'Active', align: 'center', width: 125, editable: true, sortable: false, edittype: 'select', editoptions: { value: "0:Yes;1:No" }, editrules: { required: true }, search: true },
                            { name: 'ID', index: 'ID', align: 'left', width: 200, editable: true, search: true, edittype: 'text',sortable: true },
                            { name: 'Description', index: 'Description', width: 400, align: 'left', editable: true, sortable: true, edittype: 'text', editoptions: { maxlength: 40 }, editrules: { required: true }, search: true },
                            { name: 'SortOrder', index: 'SortOrder', width: 125, align: 'left', sortable: false, editable: true, edittype: 'text', editoptions: { maxlength: 10 }, editrules: { integer: true, minValue: 0} }
                            ],
        pager: $('#MethodologyTypePager'),
        rowNum: 15,
        sortname: 'SortOrder',
        height: '100%',
        width: '100%',
        sortorder: 'desc',
        rownumbers: true,
        viewrecords: true, shrinkToFit: true,
        multiselect: true,
        postData: methodologyTypeIds,
        caption: 'Methodology Types'
    });
    var methodologyTypeIds;
    methodologyTypeIds = jQuery("#MethodologyTypeGrid").jqGrid('getGridParam', 'selarrrow');
    $('#MethodologyTypeGrid').jqGrid('navGrid', '#MethodologyTypePager',
                { add: true, del: true, edit: true, search: true, sort: true, gridModel: true, gridNames: true, formtype: 'vertical', autosearch: true },
                { width: 'auto', url: '/Type/UpdateMethodologyType', closeAfterEdit: true, closeOnEscape: true, beforeShowForm: function (form) { $('#tr_ID', form).hide(); } },
                { width: 'auto', url: '/Type/InsertMethodologyType', closeAfterAdd: true, closeOnEscape: true, beforeShowForm: function (form) { $('#tr_ID', form).show(); } },
                { width: 'auto', url: '/Type/DeleteMethodologyType' }
        );
});

