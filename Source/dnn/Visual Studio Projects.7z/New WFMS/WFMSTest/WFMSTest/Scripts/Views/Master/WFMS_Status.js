﻿$(function () {

    $('<center>' +
        '<div>' +
            '<table>' +
                '<tr align="left">' +
                    '<td>Status Type ID</td>' +
                    '<td><input type="text" id="StatusTypeId" readonly="readonly"/><td><input type="button" id="SelectStatusId" class="SearchButton" OnClientClick="javascript:return rowAction(this.name);" /></td>' +
                    '<td>Description</td>' +
                    '<td><input type="text" id="Description" readonly="readonly"/><td></td>' +
                    '<td colspan="2"><input type="submit" id="SearchButton" value="Search"/>' +
                '</tr>' +
            '</table>' +
            '</table>' +
        '</div>' +
      '</center><br/>').insertAfter('#first');

    $('#SearchButton').click(function () {
        $('#StatusGrid').jqGrid({
            url: '/MasterDetails/Status',
            datatype: 'json',
            mtype: 'POST',
            colNames: ['ID', 'Description'],
            colModel: [
                            { name: 'ID', index: 'ID', align: 'left', width: 175, editable: true, search: true, edittype: 'text' },
                            { name: 'Description', index: 'Description', width: 340, align: 'left', editable: true, sortable: true, edittype: 'text', editoptions: { maxlength: 40 }, editrules: { required: true }, search: true },
                      ],
            pager: $('#StatusGridPager'),
            rowNum: 15,
            sortname: 'ID',
            height: '100%',
            width: '100%',
            sortorder: 'asc',
            viewrecords: true, shrinkToFit: true,
            //  postData: StatusIds,
            reloadAfterSubmit: true,
            caption: 'Status Details',
            onSelectRow: function (id) {
                cells(id);
            }

        })
        $('#StatusGrid').jqGrid('navGrid', '#StatusGridPager',
                    { add: true, del: true, edit: true, sort: true, search: false },
                    { width: 'auto', url: '/MasterDetails/UpdateStatus', closeAfterEdit: true, closeOnEscape: true, beforeShowForm: function (form) { $('#tr_ID', form).hide(); } },
                    { width: 'auto', url: '/MasterDetails/InsertStatus', closeAfterAdd: true, closeOnEscape: true, beforeShowForm: function (form) { $('#tr_ID', form).show(); } },
                    { width: 'auto', url: '/MasterDetails/DeleteStatus' }
            );
    }
    );


    $('#SelectStatusId').click(function () {
        rowAction();
    });

    $('#StatusTypeId').dblclick(function () {
        rowAction();
    });

});


$(function() {         
    $('#dialogContent').dialog({ 
    autoOpen: false,              
    modal: true,             
    bgiframe: true,             
    title: "MySql Membership Config Tool",          
    width: '600',              
    height: '525'                 
    });
}); 

function rowAction() {
    $('#dialogContent').dialog({
        autoOpen: false,
        modal: true,
        bgiframe: true,
        title: "MySql Membership Config Tool",
        width: '600',
        height: '550'
    });

    $('#dialogContent').dialog('option', 'buttons',
    {
        "OK": function () { $('#dialogContent').dialog("close");  },
        "Cancel": function () { $(this).dialog("close"); }
    });
       
$('#dialogContent').dialog('open');

$('#Content').load('/Common/WFMS_LookUp/');            
return false;         
} 