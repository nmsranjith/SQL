﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Diagnostics;
using System.Text;

namespace WFMSTest.Models
{
    public class WFMS_RoleTypes
    {

        public string ID { get; set; }
        public string Description { get; set; }
        public char Active { get; set; }
        public int SortOrder { get; set; }
        public string ActiveFlag { get; set; }

        WFMS_DataBaseDataContext dataContext = new WFMS_DataBaseDataContext();
        public int GetRolesTypeCount()
        {
            return dataContext.PMA_ROLEs.Count();
        }
        public IQueryable<PMA_ROLE> GetRoleTypes(string sortingName,string sortDirection, int pageIndex, int pageSize)
        {
            return (from roleTypes in dataContext.PMA_ROLEs select roleTypes).Skip(pageIndex * pageSize).Take(pageSize).OrderBy(sortingName + "  " + sortDirection);
        }

        
        
        public bool AddRoleType(PMA_ROLE roleType)
        {
            try
            {
                roleType.RO_DEFECT_ANALYZER ='N';
                roleType.RO_REQ_REQUIRED ='N';
                roleType.RO_TIMECARD_APPROVAL ='N';
                roleType.RO_CAN_ALLOCATE ='N';
                roleType.RO_ALL_PROJECT ='N';
                roleType.RO_SYSTEM_GENERATED='N';
                dataContext.PMA_ROLEs.InsertOnSubmit(roleType);
                dataContext.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
                return false;
            }
        }

        public PMA_ROLE GetRoleType(string roleType_ID)
        {
            return dataContext.PMA_ROLEs.First(p => p.RO_ID == roleType_ID);
        }


        public bool DeleteRoleType(string[] roleType_Id)
        {
            try
            {
                for (int i = 0; i < roleType_Id.Length; i++)
                    dataContext.PMA_ROLEs.DeleteOnSubmit(dataContext.PMA_ROLEs.First(p => p.RO_ID == roleType_Id[i]));
                dataContext.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
                return false;
            }
        }

        public void SubmitChanges()
        {           
            dataContext.SubmitChanges();               
        }

        #region Methods
        public string GetFilterExpression()
        {
            StringBuilder filterExpressionBuilder = new StringBuilder();
            if (!String.IsNullOrWhiteSpace(ID))
                filterExpressionBuilder.Append(String.Format("ID = {0} AND ", ID));
            if (!String.IsNullOrWhiteSpace(Description))
                filterExpressionBuilder.Append(String.Format("Description = \"{0}\" AND ", Description));

            if (!String.IsNullOrWhiteSpace(Active.ToString()))
                filterExpressionBuilder.Append(String.Format("Active = {0} AND ", Active));

            if (filterExpressionBuilder.Length > 0)
                filterExpressionBuilder.Remove(filterExpressionBuilder.Length - 5, 5);
            return filterExpressionBuilder.ToString();
        }
        #endregion
    }
}