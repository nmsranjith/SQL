﻿using System;
using System.Linq;
using System.Diagnostics;
using System.Data;
using System.Text;
using System.Web.UI.WebControls;

namespace WFMSTest.Models
{
    public class WFMS_ObjectTypes
    {
        public string ID { get; set; }
        public string Description { get; set; }
        public string Category { get; set; }
        public char Active { get; set; }
        public int SortOrder { get; set; }
        public string ActiveFlag { get; set; }

        WFMS_DataBaseDataContext dataContext = new WFMS_DataBaseDataContext();
        public int GetObjectTypeCount()
        {
                return dataContext.PMA_PROJECT_ITEM_TYPEs.Count();
        }

        public IQueryable<PMA_PROJECT_ITEM_TYPE> GetObjectTypes(string sortingName, string sortDirection, int pageIndex, int pageSize)
        {
            return (from objtypes in dataContext.PMA_PROJECT_ITEM_TYPEs select objtypes).Skip(pageIndex * pageSize).Take(pageSize).OrderBy(sortingName+"  "+sortDirection);
         }

        public bool AddObjectType(PMA_PROJECT_ITEM_TYPE objectType)
        {
            try
            {
                dataContext.PMA_PROJECT_ITEM_TYPEs.InsertOnSubmit(objectType);
                objectType.PIT_APPROVAL_REQD = 'Y';
                objectType.PIT_ALERT_FLAG = 'N';
                objectType.PIT_APPROVAL_REQD = 'N';
                objectType.PIT_CONFIGURABLE = 'Y';
                objectType.PIT_COURSE_YN = 'Y';
                objectType.PIT_DBT_YN = 'N';
                objectType.PIT_TESTCON_YN = 'N';
                objectType.PIT_GROUP_ALLOCATION = 'N';
                objectType.PIT_INTERIM_BASELINE = 'N';
                objectType.PIT_LEAF_INDICATOR = 'Y';
                objectType.PIT_REQ_YN = 'N';
                objectType.PIT_REVIEW_REQD = 'N';           
                dataContext.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
                return false;
            }
        }

        public PMA_PROJECT_ITEM_TYPE GetObjectType(string objectType_ID)
        {
            return dataContext.PMA_PROJECT_ITEM_TYPEs.First(p => p.PIT_ID == objectType_ID);
        }


        public bool DeleteObjectType(string[] objectType_Id)
        {
            try
            {
                for (int i = 0; i < objectType_Id.Length;i++)
                    dataContext.PMA_PROJECT_ITEM_TYPEs.DeleteOnSubmit(dataContext.PMA_PROJECT_ITEM_TYPEs.First(p => p.PIT_ID == objectType_Id[i]));
                dataContext.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
                return false;
            }
        }

        public string[] GetCategories()
        {
            var test =(from p1 in dataContext.PMA_STATUS_TYPEs where  p1.STST_ID=="WF_PIT_CATEGORY" select new { p1.STST_SK}).FirstOrDefault();
            var test1=(from p in dataContext.PMA_STATUS
             where p.STS_STST_SK == test.STST_SK 
             select new { p.STS_ID });
            var aa = test1.ToArray();
            string[] aaa=new string[aa.Count()];
            for (int i = 0; i < aa.Count(); i++)
            {
                aaa[i] = aa[i].STS_ID;
            }

                return aaa;
        }

        public void SubmitChanges()
        {
            dataContext.SubmitChanges();
        }

        #region Methods
        public string GetFilterExpression()
        {
            StringBuilder filterExpressionBuilder = new StringBuilder();
            if (!String.IsNullOrWhiteSpace(ID))
                filterExpressionBuilder.Append(String.Format("ID = {0} AND ", ID));
            if (!String.IsNullOrWhiteSpace(Description))
                filterExpressionBuilder.Append(String.Format("Description = \"{0}\" AND ", Description));
            if (!String.IsNullOrWhiteSpace(Category))
                filterExpressionBuilder.Append(String.Format("Category = {0} AND ", Category));
           
            if (!String.IsNullOrWhiteSpace(Active.ToString()))
                filterExpressionBuilder.Append(String.Format("Active = {0} AND ", Active));

            if (filterExpressionBuilder.Length > 0)
                filterExpressionBuilder.Remove(filterExpressionBuilder.Length - 5, 5);
            return filterExpressionBuilder.ToString();
        }
        #endregion
       
    }
}