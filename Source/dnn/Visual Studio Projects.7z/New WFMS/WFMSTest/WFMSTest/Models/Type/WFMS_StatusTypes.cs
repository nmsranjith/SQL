﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Diagnostics;
using System.Text;

namespace WFMSTest.Models
{
    public class WFMS_StatusTypes
    {

        public string ID { get; set; }
        public string Description { get; set; }
        public char Active { get; set; }
        public int SortOrder { get; set; }
        public string ActiveFlag { get; set; }

        WFMS_DataBaseDataContext dataContext = new WFMS_DataBaseDataContext();
        public int GetStatusTypeCount()
        {
            return dataContext.PMA_STATUS_TYPEs.Count();
        }
        public IQueryable<PMA_STATUS_TYPE> GetStatusTypes(string sortingName,string sortDirection, int pageIndex, int pageSize)
        {
            return (from objtypes in dataContext.PMA_STATUS_TYPEs select objtypes).Skip(pageIndex * pageSize).Take(pageSize).OrderBy(sortingName + "  " + sortDirection);
        }


        public bool AddStatusType(PMA_STATUS_TYPE statusType)
        {
            try
            {
                dataContext.PMA_STATUS_TYPEs.InsertOnSubmit(statusType);
                dataContext.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
                return false;
            }
        }

        public PMA_STATUS_TYPE GetStatusType(string statusType_ID)
        {
            return dataContext.PMA_STATUS_TYPEs.First(p => p.STST_ID == statusType_ID);
        }


        public bool DeleteStatusType(string[] statusType_Id)
        {
            try
            {
                for (int i = 0; i < statusType_Id.Length; i++)
                    dataContext.PMA_STATUS_TYPEs.DeleteOnSubmit(dataContext.PMA_STATUS_TYPEs.First(p => p.STST_ID == statusType_Id[i]));
                dataContext.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
                return false;
            }
        }

        public void SubmitChanges()
        {
            dataContext.SubmitChanges();
        }

        #region Methods
        public string GetFilterExpression()
        {
            StringBuilder filterExpressionBuilder = new StringBuilder();
            if (!String.IsNullOrWhiteSpace(ID))
                filterExpressionBuilder.Append(String.Format("ID = {0} AND ", ID));
            if (!String.IsNullOrWhiteSpace(Description))
                filterExpressionBuilder.Append(String.Format("Description = \"{0}\" AND ", Description));

            if (!String.IsNullOrWhiteSpace(Active.ToString()))
                filterExpressionBuilder.Append(String.Format("Active = {0} AND ", Active));

            if (filterExpressionBuilder.Length > 0)
                filterExpressionBuilder.Remove(filterExpressionBuilder.Length - 5, 5);
            return filterExpressionBuilder.ToString();
        }
        #endregion
    }
}