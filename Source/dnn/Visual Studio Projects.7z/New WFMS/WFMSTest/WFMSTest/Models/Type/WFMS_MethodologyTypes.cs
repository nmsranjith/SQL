﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Diagnostics;
using System.Text;

namespace WFMSTest.Models
{
    public class WFMS_MethodologyTypes
    {

        public string ID { get; set; }
        public string Description { get; set; }
        public char Active { get; set; }
        public int SortOrder { get; set; }
        public string  ActiveFlag { get; set; }


        WFMS_DataBaseDataContext dataContext = new WFMS_DataBaseDataContext();
        public int GetMethodologyTypeCount()
        {
            return dataContext.PMA_METHODOLOGY_TYPEs.Count();
        }

        public IQueryable<PMA_METHODOLOGY_TYPE> GetMethodologyTypes(string sortingName, string sortDirection, int pageIndex, int pageSize)
        {
            return (from objtypes in dataContext.PMA_METHODOLOGY_TYPEs select objtypes).Skip(pageIndex * pageSize).Skip(pageIndex * pageSize).Take(pageSize).OrderBy(sortingName + "  " + sortDirection);
        }

        public bool AddMethodologyType(PMA_METHODOLOGY_TYPE methodologyType)
        {
            try
            {
                dataContext.PMA_METHODOLOGY_TYPEs.InsertOnSubmit(methodologyType);               
                dataContext.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
                return false;
            }
        }

        public PMA_METHODOLOGY_TYPE GetMethodologyType(string methodologyType_ID)
        {
            return dataContext.PMA_METHODOLOGY_TYPEs.First(p => p.MT_ID == methodologyType_ID);
        }


        public bool DeleteMethodologyType(string[] methodologyType_Id)
        {
            try
            {
                for (int i = 0; i < methodologyType_Id.Length; i++)
                    dataContext.PMA_METHODOLOGY_TYPEs.DeleteOnSubmit(dataContext.PMA_METHODOLOGY_TYPEs.First(p => p.MT_ID == methodologyType_Id[i]));
                dataContext.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
                return false;
            }
        }

        public void SubmitChanges()
        {            
                dataContext.SubmitChanges();                
        }

        #region Methods
        public string GetFilterExpression()
        {
            StringBuilder filterExpressionBuilder = new StringBuilder();
            if (!String.IsNullOrWhiteSpace(ID))
                filterExpressionBuilder.Append(String.Format("ID = {0} AND ", ID));
            if (!String.IsNullOrWhiteSpace(Description))
                filterExpressionBuilder.Append(String.Format("Description = \"{0}\" AND ", Description));
           
            if (!String.IsNullOrWhiteSpace(Active.ToString()))
                filterExpressionBuilder.Append(String.Format("Active = {0} AND ", Active));

            if (filterExpressionBuilder.Length > 0)
                filterExpressionBuilder.Remove(filterExpressionBuilder.Length - 5, 5);
            return filterExpressionBuilder.ToString();
        }
        #endregion
    }
}