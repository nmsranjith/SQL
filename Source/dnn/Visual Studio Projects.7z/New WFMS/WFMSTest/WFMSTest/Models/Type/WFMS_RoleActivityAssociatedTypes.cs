﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Diagnostics;
using System.Text;

namespace WFMSTest.Models
{
    public class WFMS_RoleActivityAssociatedTypes
    {

        public string ID { get; set; }
        public string Description { get; set; }
        public char Active { get; set; }
        public int SortOrder { get; set; }
        public string ActiveFlag { get; set; }

        WFMS_DataBaseDataContext dataContext = new WFMS_DataBaseDataContext();

        public int GetRolesActivityAssociatedTypeCount()
        {
            return dataContext.PMA_ROLE_ATY_ASSO_TYPEs.Count();
        }

        public IQueryable<PMA_ROLE_ATY_ASSO_TYPE> GetRoleActivityAssociatedTypes(string sortingName, string sortDirection, int pageIndex, int pageSize)
        {
            return (from roleActivityTypes in dataContext.PMA_ROLE_ATY_ASSO_TYPEs select roleActivityTypes).Skip(pageIndex * pageSize).Take(pageSize).OrderBy(sortingName + "  " + sortDirection);
        }

        public bool AddRoleActivityAssociatedType(PMA_ROLE_ATY_ASSO_TYPE roleActivityAssociatedType)
        {
            try
            {
                dataContext.PMA_ROLE_ATY_ASSO_TYPEs.InsertOnSubmit(roleActivityAssociatedType);
                dataContext.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
                return false;
            }
        }


        public PMA_ROLE_ATY_ASSO_TYPE GetRoleActivityAssociatedType(string roleActivityAssociatedType_ID)
        {
            return dataContext.PMA_ROLE_ATY_ASSO_TYPEs.First(p => p.RAAT_ID == roleActivityAssociatedType_ID);
        }


        public bool DeleteRoleActivityAssociatedType(string[] roleActivityAssociatedType_Id)
        {
            try
            {
                for (int i = 0; i < roleActivityAssociatedType_Id.Length; i++)
                    dataContext.PMA_ROLE_ATY_ASSO_TYPEs.DeleteOnSubmit(dataContext.PMA_ROLE_ATY_ASSO_TYPEs.First(p => p.RAAT_ID == roleActivityAssociatedType_Id[i]));
                dataContext.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
                return false;
            }
        }

        public bool SubmitChanges()
        {
            try
            {
                dataContext.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
                return false;
            }
           
        }

        #region Methods
        public string GetFilterExpression()
        {
            StringBuilder filterExpressionBuilder = new StringBuilder();
            if (!String.IsNullOrWhiteSpace(ID))
                filterExpressionBuilder.Append(String.Format("ID = {0} AND ", ID));
            if (!String.IsNullOrWhiteSpace(Description))
                filterExpressionBuilder.Append(String.Format("Description = \"{0}\" AND ", Description));
            
            if (!String.IsNullOrWhiteSpace(Active.ToString()))
                filterExpressionBuilder.Append(String.Format("Active = {0} AND ", Active));

            if (filterExpressionBuilder.Length > 0)
                filterExpressionBuilder.Remove(filterExpressionBuilder.Length - 5, 5);
            return filterExpressionBuilder.ToString();
        }
        #endregion
    }
}