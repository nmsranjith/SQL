﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Diagnostics;
using System.Text;

namespace WFMSTest.Models
{
    public class WFMS_ActivityTypes
    {
        public string ID { get; set; }
        public string Description { get; set; }
        public string LockStatus { get; set; }
        public char WaitActivity { get; set; }
        public char CheckList { get; set; }
        public string Active { get; set; }
        public int SortOrder { get; set; }
        public string ActiveFlag { get; set; }


        WFMS_DataBaseDataContext dataContext = new WFMS_DataBaseDataContext();
        public int GetActivityTypeCount()
        {
            return dataContext.PMA_ACTIVITY_TYPEs.Count();
        }
        public IQueryable<PMA_ACTIVITY_TYPE> GetActivityTypes(string sortingName, string sortDirection, int pageIndex, int pageSize)
        {
            return (from roleTypes in dataContext.PMA_ACTIVITY_TYPEs select roleTypes).Skip(pageIndex * pageSize).Take(pageSize).OrderBy(sortingName + "  " + sortDirection);
        }

        public PMA_ACTIVITY_TYPE GetActivityType(string activityType_ID)
        {
            return dataContext.PMA_ACTIVITY_TYPEs.First(p => p.AVT_ID == activityType_ID);
        }


        public bool DeleteActivityType(string[] activityType_Id)
        {
            try
            {
                for (int i = 0; i < activityType_Id.Length; i++)
                    dataContext.PMA_ACTIVITY_TYPEs.DeleteOnSubmit(dataContext.PMA_ACTIVITY_TYPEs.First(p => p.AVT_ID == activityType_Id[i]));
                dataContext.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
                return false;
            }
        }

        public void SubmitChanges()
        {
            dataContext.SubmitChanges();
        }

        #region Methods
        public string GetFilterExpression()
        {
            StringBuilder filterExpressionBuilder = new StringBuilder();
            if (!String.IsNullOrWhiteSpace(ID))
                filterExpressionBuilder.Append(String.Format("ID = {0} AND ", ID));
            if (!String.IsNullOrWhiteSpace(Description))
                filterExpressionBuilder.Append(String.Format("Description = \"{0}\" AND ", Description));
           
            if (!String.IsNullOrWhiteSpace(Active.ToString()))
                filterExpressionBuilder.Append(String.Format("Active = {0} AND ", Active));

            if (!String.IsNullOrWhiteSpace(LockStatus))
                filterExpressionBuilder.Append(String.Format("LockStatus = {0} AND ", LockStatus));
            if (!String.IsNullOrWhiteSpace(WaitActivity.ToString()))
                filterExpressionBuilder.Append(String.Format("WaitActivity = \"{0}\" AND ", WaitActivity));

            if (!String.IsNullOrWhiteSpace(CheckList.ToString()))
                filterExpressionBuilder.Append(String.Format("CheckList = {0} AND ", CheckList));
            if (filterExpressionBuilder.Length > 0)
                filterExpressionBuilder.Remove(filterExpressionBuilder.Length - 5, 5);
            return filterExpressionBuilder.ToString();
        }
        #endregion
       
    }
}