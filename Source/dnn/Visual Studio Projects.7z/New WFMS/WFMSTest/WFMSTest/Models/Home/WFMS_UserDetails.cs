﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WFMSTest.Models
{
    public class WFMS_UserDetails
    {
    }
    public class WFMS_Login
    {
        public string PRS_ID { get; set; }
        public string PRS_Password { get; set; }
        public string PRS_CompanyName { get; set; }
    }
}