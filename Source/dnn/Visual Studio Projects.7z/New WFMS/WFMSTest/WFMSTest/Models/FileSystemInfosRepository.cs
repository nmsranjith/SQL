﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using jqGrid.Models;
using System.IO;

namespace jqGrid.Repositories
{
    public static class FileSystemInfosRepository
    {
        #region Fields
        private static List<string> _treeGridIdMappings;
        private const string _fileSystemInfoRoot = @"E:\Books\";
        #endregion

        #region Constructor
        static FileSystemInfosRepository()
        {
            _treeGridIdMappings = new List<string>();
        }
        #endregion

        #region Methods
        public static int? GetTreeGridId(FileSystemInfo item)
        {
            if (item.FullName == _fileSystemInfoRoot)
                return null;
            else if (_treeGridIdMappings.Contains(item.FullName))
                return _treeGridIdMappings.IndexOf(item.FullName);
            else
            {
                _treeGridIdMappings.Add(item.FullName);
                return (_treeGridIdMappings.Count - 1);
            }
        }

        public static DirectoryInfo GetDirectoryInfo(int? treeGridId)
        {
            if (treeGridId.HasValue)
            {
                if ((_treeGridIdMappings.Count > treeGridId.Value) && Directory.Exists(_treeGridIdMappings[treeGridId.Value]))
                    return new DirectoryInfo(_treeGridIdMappings[treeGridId.Value]);
                else
                    return null;
            }
            else
                return new DirectoryInfo(_fileSystemInfoRoot);
        }

        public static IEnumerable<FileSystemInfo> GetFileSystemInfos(int? rootTreeGridId)
        {
            DirectoryInfo rootDirectoryInfo = GetDirectoryInfo(rootTreeGridId);

            if (rootDirectoryInfo != null)
                return from childFileSystemInfo in rootDirectoryInfo.GetFileSystemInfos()
                       orderby childFileSystemInfo is DirectoryInfo descending
                       select childFileSystemInfo;
            else
                return null;
        }
        #endregion
    }
}
