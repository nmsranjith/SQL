﻿using System;
using System.Linq;
using System.Diagnostics;

namespace WFMSTest.Models
{
    public class WFMS_Status
    {
        public string ID { get; set; }
        public string Description { get; set; }   
        public int SortOrder { get; set; }
        public string ActiveFlag { get; set; }

        WFMS_DataBaseDataContext dataContext = new WFMS_DataBaseDataContext();
        public int GetStatusCount()
        {
            return dataContext.PMA_STATUS.Count();
        }

        public IQueryable<PMA_STATUS> GetStatus(string sortingName, string sortDirection, int pageIndex, int pageSize)
        {
            return (from status in dataContext.PMA_STATUS select status).Skip(pageIndex * pageSize).Take(pageSize).OrderBy(sortingName + "  " + sortDirection);
        }

        public bool AddStatus(PMA_STATUS status)
        {
            try
            {
                return true;
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
                return false;
            }
        }

        public PMA_STATUS GetStatus(string status_Id)
        {
            return dataContext.PMA_STATUS.First(p => p.STS_ID == status_Id);
        }


        public bool DeleteStatus(string[] status_Id)
        {
            try
            {
                for (int i = 0; i < status_Id.Length; i++)
                    dataContext.PMA_STATUS.DeleteOnSubmit(dataContext.PMA_STATUS.First(p => p.STS_ID == status_Id[i]));
                dataContext.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                Debug.Write(ex.Message);
                return false;
            }
        }

        public void SubmitChanges()
        {
            dataContext.SubmitChanges();
        }
    }
}