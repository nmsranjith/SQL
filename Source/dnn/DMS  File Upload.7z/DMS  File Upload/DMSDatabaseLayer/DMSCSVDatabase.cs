﻿using System;
using System.Collections.Generic;
using System.Data;
using DMSCommon.DAO;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;
using System.Xml.Linq;
using DMSCommon;
using DMSCommon.Common;

namespace DMSDatabaseLayer
{
   public class DMSCSVDatabase
    {
        #region " Global variable Declaration "
        private SqlConnection m_SqlConnectionObject;
        private SqlCommand m_SqlCommandObject;
        private SqlDataReader m_SqlDataReaderObject;


        private static string m_ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        private static string m_DateFormat = ConfigurationManager.AppSettings.Get("DateFormat");
        #endregion

        #region " Public Methods "
        /// <summary>
        /// This Method is used to Insert the CSV Values in the database
        /// </summary>
        /// <param name="v_CCsvInfoList">List of CCSVInfo object</param>
        //public void InsertCSVValues(ref List<CCSVInfo> v_CCsvInfoList)
        //{
        //    CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "WriteExceptionInExcel", "Started");
        //    try
        //    {
        //        m_SqlConnectionObject = new SqlConnection(m_ConnectionString);
        //        m_SqlConnectionObject.Open();

        //        m_SqlCommandObject = new SqlCommand();

        //        m_SqlCommandObject.Connection = m_SqlConnectionObject;

        //        m_SqlCommandObject.Parameters.Add(new SqlParameter("@FeedXml", SqlDbType.Xml, int.MaxValue, ParameterDirection.Input, false, 0, 0, "@FeedXml", DataRowVersion.Current, GetCSVXML(v_CCsvInfoList).ToString()));
        //        m_SqlCommandObject.CommandType = CommandType.StoredProcedure;
        //        m_SqlCommandObject.CommandText = "dbo.DMS_InsertCVSFileValues";
        //        m_SqlCommandObject.ExecuteNonQuery();
        //        //CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "DMSDataBase.InsertCSVValues()", "dbo.DMS_InsertCVSFileValues Procedure Executed succesfully");
        //    }
        //    catch (Exception ex)
        //    {
        //        //CLogHelper.Instance.LogErrorInfo(ex, "DMSDataBase.InsertCSVValues()");
        //        throw (ex);
        //    }
        //    finally
        //    {
        //        if ((m_SqlCommandObject != null))
        //            m_SqlCommandObject = null;

        //        if ((m_SqlConnectionObject != null))
        //        {
        //            m_SqlConnectionObject.Close();
        //            m_SqlConnectionObject = null;
        //        }
        //    }
        //    //CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "DMSDataBase.InsertCSVValues()", "... Completed");
        //}


        /// <summary>
        /// This method will updated the CSV Values and Insert the records in Search tables
        /// </summary>
        /// <param name="v_CCsvInfoList">Collection List of CFileInfo object which is used for updateing the CSV Table</param>
        /// <param name="v_CFileInfoList">Collection List of CFileInfo object which is used for inserting the records in the search table</param>
        /// <param name="v_IsUpdateCSVFileOnlyBool">Flag to check only to update CSV table</param>
        //public void UpdateCSVAndInsertSearchValues(List<CCSVInfo> v_CCsvInfoList, List<CFileInfo> v_CFileInfoList, bool v_IsUpdateCSVFileOnlyBool)
        //{
        //    //CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "DMSDataBase.UpdateCSVAndInsertSearchValues()", "... Started");
        //    try
        //    {
        //        m_SqlConnectionObject = new SqlConnection(m_ConnectionString);
        //        m_SqlConnectionObject.Open();
        //        m_SqlCommandObject = new SqlCommand();
        //        m_SqlCommandObject.Connection = m_SqlConnectionObject;

        //        m_SqlCommandObject.Parameters.Add(new SqlParameter("@CSVInfoXml", SqlDbType.Xml, int.MaxValue, ParameterDirection.Input, false, 0, 0, "@CSVInfoXml", DataRowVersion.Current, GetCSVXML(v_CCsvInfoList).ToString()));
        //        m_SqlCommandObject.Parameters.Add(new SqlParameter("@FileInfoXml", SqlDbType.Xml, int.MaxValue, ParameterDirection.Input, false, 0, 0, "@FileInfoXml", DataRowVersion.Current, GetFileInfoXML(v_CFileInfoList).ToString()));
        //        m_SqlCommandObject.Parameters.Add(new SqlParameter("@UpdateDigitalFilesCSVInfoOnly", SqlDbType.Bit, int.MaxValue, ParameterDirection.Input, false, 0, 0, "@UpdateCSVFileInfoOnly", DataRowVersion.Current, v_IsUpdateCSVFileOnlyBool));


        //        m_SqlCommandObject.CommandType = CommandType.StoredProcedure;
        //        m_SqlCommandObject.CommandText = "dbo.DMS_UpdateCVSFileValues";
        //        m_SqlCommandObject.ExecuteNonQuery();

        //        //CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "DMSDataBase.UpdateCSVAndInsertSearchValues()", "dbo.DMS_UpdateCVSFileValues Procedure Executed succesfully");
        //    }
        //    catch (Exception ex)
        //    {
        //        //CLogHelper.Instance.LogErrorInfo(ex, "DMSDataBase.UpdateCSVAndInsertSearchValues()");
        //        throw (ex);
        //    }
        //    finally
        //    {
        //        if ((m_SqlCommandObject != null))
        //            m_SqlCommandObject = null;

        //        if ((m_SqlConnectionObject != null))
        //        {
        //            m_SqlConnectionObject.Close();
        //            m_SqlConnectionObject = null;
        //        }
        //    }
        //    //CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "DMSDataBase.UpdateCSVAndInsertSearchValues()", "... Completed");
        //}


        /// <summary>
        /// This Function will get the CSVFile Information from the database
        /// </summary>
        /// <param name="v_IsActiveRecordBool">Flag to get Active or Inactive Files</param>
        /// <returns>List of CCSVInfo object</returns>
        //public List<CCSVInfo> GetCSVUnmovedData(bool v_IsActiveRecordBool)
        //{
        //    //CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "DMSDataBase.GetCSVUnmovedData()", "... Started");
        //    List<CCSVInfo> CCsvInfoList = null;

        //    try
        //    {
        //        m_SqlConnectionObject = new SqlConnection(m_ConnectionString);
        //        m_SqlConnectionObject.Open();




        //        m_SqlCommandObject = new SqlCommand();

        //        m_SqlCommandObject.Connection = m_SqlConnectionObject;

        //        m_SqlCommandObject.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit, int.MaxValue, ParameterDirection.Input, false, 0, 0, "@IsActive", DataRowVersion.Current, v_IsActiveRecordBool));
        //        m_SqlCommandObject.CommandType = CommandType.StoredProcedure;
        //        m_SqlCommandObject.CommandText = "dbo.DMS_GetCSVUnmovedData";
        //        m_SqlCommandObject.ExecuteNonQuery();


        //        m_SqlDataReaderObject = m_SqlCommandObject.ExecuteReader();

        //        CCsvInfoList = new List<CCSVInfo>();
        //        while (m_SqlDataReaderObject.Read())
        //        {
        //            CCSVInfo CCSVInfoObject = new CCSVInfo();

        //            CCSVInfoObject.FileId = Convert.ToInt32(m_SqlDataReaderObject["FileId"]);
        //            CCSVInfoObject.FileName = Convert.ToString(m_SqlDataReaderObject["FileName"]);
        //            CCSVInfoObject.ClientCode = Convert.ToString(m_SqlDataReaderObject["ClientCode"]);
        //            CCSVInfoObject.ParentFolderName = Convert.ToString(m_SqlDataReaderObject["ParentFolderName"]);
        //            CCSVInfoObject.IsProcessFlag = Convert.ToChar(m_SqlDataReaderObject["IsProcessed"]);
        //            CCSVInfoObject.IsMovedToManualProcess = Convert.ToChar(m_SqlDataReaderObject["IsMovedToManualProcess"]);
        //            CCSVInfoObject.Reason = Convert.ToString(m_SqlDataReaderObject["Reason"]);

        //            CCsvInfoList.Add(CCSVInfoObject);

        //            if (CCSVInfoObject != null)
        //                CCSVInfoObject = null;
        //        }

        //        return CCsvInfoList;
        //    }
        //    catch (Exception ex)
        //    {
        //       // CLogHelper.Instance.LogErrorInfo(ex, "DMSDataBase.GetCSVUnmovedData()");
        //        throw (ex);
        //    }
        //    finally
        //    {
        //        if ((m_SqlCommandObject != null))
        //            m_SqlCommandObject = null;

        //        if ((m_SqlConnectionObject != null))
        //        {
        //            m_SqlConnectionObject.Close();
        //            m_SqlConnectionObject = null;
        //        }
        //        if ((m_SqlDataReaderObject != null))
        //            m_SqlDataReaderObject = null;


        //        //CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "DMSDataBase.GetCSVUnmovedData()", "... Completed");
        //    }
        //}

        #endregion

        #region " Private Methods "

        /// <summary>
        /// This Function will return string as XML format from the passed collection list
        /// </summary>
        /// <param name="v_CFileInfoList">List of CFileInfo object</param>
        /// <returns>XML string</returns>
        //private string GetFileInfoXML(List<CFileInfo> v_CFileInfoList)
        //{
        //    //CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "DMSDataBase.GetFileInfoXML()", "... Started");
        //    XElement XElementObject = null;
        //    try
        //    {
        //        //Using LINQ to create an xml object
        //        XElementObject = new XElement("FileInfo",
        //                            from lstHome in v_CFileInfoList
        //                            //where lstHome.IsFileAlreadyExist.Trim().Length.Equals(0)
        //                            select new XElement("File",
        //                                 new XElement("FileId", Convert.ToString(lstHome.FileId)),
        //                                 new XElement("UploadedDateTime", Convert.ToDateTime(lstHome.UploadedDateTime).ToString(m_DateFormat)),
        //                                 new XElement("OldFileName", lstHome.OldFileName),
        //                                 new XElement("NewFileName", lstHome.FileName),
        //                                 new XElement("NewFilePath", lstHome.FilePath),
        //                                 new XElement("FileSize", lstHome.FileSize),
        //                                 new XElement("ClientCode", lstHome.ClientCode),
        //                                 new XElement("DocType", lstHome.DocType),
        //                                 new XElement("Institute", lstHome.Institute),
        //                                 new XElement("FileDate", Convert.ToDateTime(lstHome.PaymentDate).ToString(m_DateFormat))
        //                                 ));
        //        return XElementObject.ToString();

        //    }
        //    catch (Exception ex)
        //    {
        //        //CLogHelper.Instance.LogErrorInfo(ex, "DMSDataBase.GetFileInfoXML()");
        //        throw (ex);
        //    }
        //    finally
        //    {
        //        if (XElementObject != null)
        //            XElementObject = null;
        //        //CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "DMSDataBase.GetFileInfoXML()", "... Completed");
        //    }
        //}

        /// <summary>
        /// This Function will return string as XML format from the passed collection list
        /// </summary>
        /// <param name="v_CFileInfoList">List of CCsvInfo object</param>
        /// <returns>XML string</returns>
        private string GetCSVXML(List<CCSVInfo> v_CCsvInfoList)
        {
           // CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "DMSDataBase.GetCSVXML()", "... Started");
            XElement XElementObject = null;
            try
            {
                //Using LINQ to create an xml object
                XElementObject = new XElement("CVS",
                                    from lstHome in v_CCsvInfoList
                                    select new XElement("File",
                                        new XElement("FileId", Convert.ToString(lstHome.FileId)),
                                        new XElement("FileName", lstHome.FileName),
                                        new XElement("ClientCode", lstHome.ClientCode),
                                        new XElement("ParentFolderName", lstHome.ParentFolderName),
                                        new XElement("IsProcessed", lstHome.IsProcessFlag),
                                        new XElement("IsMovedToManualProcess", lstHome.IsMovedToManualProcess),
                                        new XElement("Reason", lstHome.Reason)
                                        ));
                return XElementObject.ToString();
            }
            catch (Exception ex)
            {
               // CLogHelper.Instance.LogErrorInfo(ex, "DMSDataBase.GetCSVXML()");
                throw (ex);
            }
            finally
            {
                if (XElementObject != null)
                    XElementObject = null;
               // CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "DMSDataBase.GetCSVXML()", "... Completed");
            }
        }

        #endregion
    }
}
