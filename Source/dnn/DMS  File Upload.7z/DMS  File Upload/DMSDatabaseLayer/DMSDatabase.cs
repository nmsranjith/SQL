﻿/*
Name                : DMSDatabase.cs
Author              : Suchithra Baskaran
Purpose             : Database class for renaming and  uploading files 
Date Created        : 17 Aug 2012
Revision History    :
Modified by         :
Date Modified       :
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using DMSCommon;
using System.Xml.Linq;
using DMSCommon.Common;
using DMSCommon.DAO;

namespace DMSDatabaseLayer
{
    public class DMSDatabase
    {
        #region "Global Variables"
        private Database databaseObject;
        private DbCommand dbCommandObject;

        private static string m_ConnectionString = ConfigurationManager.ConnectionStrings["DMSConnection"].ConnectionString;

        #endregion

        /// <summary>
        /// Function to fetch the document types and return
        /// </summary>
        /// <returns>Datatable</returns>
        public DataTable GetDocumentTypes()
        {
            DataTable documentTypesDatatable;
            try
            {
                databaseObject = DatabaseFactory.CreateDatabase();
                dbCommandObject = databaseObject.GetStoredProcCommand("DMS_GetDocumentTypes");
                documentTypesDatatable = databaseObject.ExecuteDataSet(dbCommandObject).Tables[0];
                return documentTypesDatatable;
            }
            catch (DbException dbException)
            {
                throw dbException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                databaseObject = null;
                dbCommandObject = null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="filePath"></param>
        /// <param name="fileSize"></param>
        /// <param name="clientCode"></param>
        /// <param name="docType"></param>
        /// <param name="insititute"></param>
        /// <param name="paymentDate"></param>
        /// <returns></returns>
        //public bool InsertIndividualFile(string fileName, string filePath, string fileSize, string clientCode, string docType, string insititute, DateTime paymentDate)
        public bool InsertIndividualFile(string fileName, string filePath, string fileSize, string clientCode, string docType, string insititute, DateTime paymentDate, ref List<CCSVInfo> exceptionInfoListObject)
        {
            int noOfRowsInserted = 0;
            CCSVInfo exceptionInfoObject;
            try
            {
                databaseObject = DatabaseFactory.CreateDatabase();
                dbCommandObject = databaseObject.GetStoredProcCommand("DMS_InsertRepositoryFilesInfo");
                databaseObject.AddInParameter(dbCommandObject, "@fileName", DbType.String, fileName);
                databaseObject.AddInParameter(dbCommandObject, "@filePath", DbType.String, filePath);
                databaseObject.AddInParameter(dbCommandObject, "@fileSize", DbType.String, fileSize);
                databaseObject.AddInParameter(dbCommandObject, "@clientCode", DbType.String, clientCode);
                databaseObject.AddInParameter(dbCommandObject, "@docType", DbType.String, docType);
                databaseObject.AddInParameter(dbCommandObject, "@insititute", DbType.String, insititute);
                databaseObject.AddInParameter(dbCommandObject, "@paymentDate", DbType.DateTime, paymentDate);
                noOfRowsInserted = databaseObject.ExecuteNonQuery(dbCommandObject);

                if (noOfRowsInserted > 0)
                {
                    CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Records inserted in table : " + 1, "");
                    return true;
                }
                else
                {
                    CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Records inserted in table : " + 0, "");
                    //Insert the record into exception info list
                    exceptionInfoObject = new CCSVInfo();
                    exceptionInfoObject.ClientCode = clientCode;
                    exceptionInfoObject.FileName = fileName;
                    exceptionInfoObject.Reason = "File Name already available in the Database";
                    exceptionInfoListObject.Add(exceptionInfoObject);
                    return false;
                }
            }
            catch (DbException dbException)
            {
                throw dbException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (databaseObject != null)
                    databaseObject = null;
                if (dbCommandObject != null)
                    dbCommandObject = null;
            }
        }

        //public bool InsertFileInformationBulkly(List<CFileInfo> filesInfoList)
        public bool InsertFileInformationBulkly(List<CFileInfo> filesInfoList, ref List<CCSVInfo> exceptionInfoListObject)
        {
            int noOfRowsInserted = 0;
            DataTable alreadyInsertedRecordsTable;
            List<CCSVInfo> alreadyInsertedRecords;
            try
            {
                databaseObject = DatabaseFactory.CreateDatabase();
                dbCommandObject = databaseObject.GetStoredProcCommand("DMS_RepositoryFilesBulkInsert");
                databaseObject.AddInParameter(dbCommandObject, "@FileInfoXml", DbType.Xml, GetXML(filesInfoList));
                alreadyInsertedRecordsTable = databaseObject.ExecuteDataSet(dbCommandObject).Tables[0];

                noOfRowsInserted = filesInfoList.Count - alreadyInsertedRecordsTable.Rows.Count;

                //Add the already inserted records to the exception list
                alreadyInsertedRecords = alreadyInsertedRecordsTable.AsEnumerable()
                                        .Select(row => new CCSVInfo()
                                        {
                                            ClientCode = row.Field<string>(0),
                                            FileName = row.Field<string>(1),
                                            ParentFolderName = row.Field<string>(2),
                                            Reason = row.Field<string>(3)
                                        }).ToList();

                exceptionInfoListObject.AddRange(alreadyInsertedRecords);


                CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Records inserted in table : " + noOfRowsInserted,"");

                if (noOfRowsInserted > 0)
                    return true;
                else
                    return false;
            }
            catch (DbException dbException)
            {
                throw dbException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (databaseObject  != null)
                databaseObject = null;
                if (dbCommandObject != null)
                dbCommandObject = null;
            }
        }

        private string GetXML(List<CFileInfo> v_fileInfoList)
        {
            XElement XElementObject = null;
            try
            {
                XElementObject = new XElement("CVS",
                                    from lstHome in v_fileInfoList
                                    select new XElement("File",
                                        new XElement("FileName", lstHome.FileName),
                                        new XElement("FilePath", lstHome.FilePath),
                                        new XElement("FileSize", lstHome.FileSize),
                                        new XElement("ClientCode", lstHome.ClientCode),
                                        new XElement("DocType", lstHome.DocType),
                                        new XElement("Institute", lstHome.Institute),
                                        new XElement("PaymentDate", Convert.ToDateTime(lstHome.PaymentDate)),
                                        new XElement("UploadedDateTime",lstHome.UploadedDateTime)
                                        ));

                return XElementObject.ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (XElementObject != null)
                    XElementObject = null;
            }
        }
    }
}
