﻿/* 
Name                : CCSVInfo.cs
Author              : Suchithra Baskaran
Purpose             : CSV DAO class
Date Created        : 21 Aug 2012
Revision History    :
Modified by         :
Date Modified       :
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DMSCommon.DAO
{
    public class CCSVInfo
    {


        #region " Private Variables "
        private int m_intFileId;
        private string m_strFileName;
        private string m_strClientCode;
        private string m_strParentFolderName;
        private char m_strIsProcessFlag;

        private char m_strIsMovedToManualProcess;

        private string m_ReasonString = "";

        public string Reason
        {
            get { return m_ReasonString; }
            set { m_ReasonString = value; }
        }

        public int FileId
        {
            get { return m_intFileId; }
            set { m_intFileId = value; }
        }

        public string FileName
        {
            get { return m_strFileName; }
            set { m_strFileName = value; }
        }

        public string ClientCode
        {
            get { return m_strClientCode; }
            set { m_strClientCode = value; }
        }

        public string ParentFolderName
        {
            get { return m_strParentFolderName; }
            set { m_strParentFolderName = value; }
        }

        public char IsProcessFlag
        {
            get { return m_strIsProcessFlag; }
            set { m_strIsProcessFlag = value; }
        }

        public char IsMovedToManualProcess
        {
            get { return m_strIsMovedToManualProcess; }
            set { m_strIsMovedToManualProcess = value; }
        }

        #endregion

    }
}
