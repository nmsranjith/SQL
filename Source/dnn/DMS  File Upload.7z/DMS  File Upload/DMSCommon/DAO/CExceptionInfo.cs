﻿/* 
Name                : CExceptionInfo.cs
Author              : Suchithra Baskaran
Purpose             : Exception Information DAO class
Date Created        : 21 Aug 2012
Revision History    :
Modified by         :
Date Modified       :
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DMSCommon.DAO
{
    public class CExceptionInfo
    {
        private string m_strFileName;
        private string m_strClientCode;
        private string m_strFolderName;
        private string m_strReason;

        public string FileName
        {
            get
            {
                return m_strFileName;
            }
            set
            {
                m_strFileName = value;
            }
        }

        public string ClientCode
        {
            get
            {
                return m_strClientCode;
            }
            set
            {
                m_strClientCode = value;
            }
        }

        public string FolderName
        {
            get
            {
                return m_strFolderName;
            }
            set
            {
                m_strFolderName = value;
            }
        }

        public string Reason
        {
            get
            {
                return m_strReason;
            }
            set
            {
                m_strReason = value;
            }
        }
    }
}
