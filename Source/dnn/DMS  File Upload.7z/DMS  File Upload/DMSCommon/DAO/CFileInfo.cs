﻿/* 
Name                : CFileInfo.cs
Author              : Suchithra Baskaran
Purpose             : File Information DAO class
Date Created        : 21 Aug 2012
Revision History    :
Modified by         :
Date Modified       :
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DMSCommon
{
    public class CFileInfo
    {
        #region "Private Variables"

        private string m_strFileName;
        private string m_strFilePath;
        private string m_strFileSize;
        private string m_strClientCode;
        private string m_strDocType;
        private string m_strInstitute;
        private DateTime m_uploadDateTime;
        private string m_paymentDate;

        private string m_OldFilePathString;
        private string m_OldFileNameString;
        private int m_FileIdInteger;

        #endregion

        public string FileName
        {
            get
            {
                return m_strFileName;
            }
            set
            {
                m_strFileName = value;
            }
        }

        public string FilePath
        {
            get
            {
                return m_strFilePath;
            }
            set
            {
                m_strFilePath = value;
            }
        }

        public string FileSize
        {
            get
            {
                return m_strFileSize;
            }
            set
            {
                m_strFileSize = value;
            }
        }

        public string ClientCode
        {
            get
            {
                return m_strClientCode;
            }
            set
            {
                m_strClientCode = value;
            }
        }

        public string DocType
        {
            get
            {
                return m_strDocType;
            }
            set
            {
                m_strDocType = value;
            }
        }

        public string Institute
        {
            get
            {
                return m_strInstitute;
            }
            set
            {
                m_strInstitute = value;
            }
        }

        public DateTime UploadedDateTime
        {
            get
            {
                return m_uploadDateTime;
            }
            set
            {
                m_uploadDateTime = value;
            }
        }

        public string PaymentDate
        {
            get
            {
                return m_paymentDate;
            }
            set
            {
                m_paymentDate = value;
            }
        }

        public string OldFilePath
        {
            get { return m_OldFilePathString; }
            set { m_OldFilePathString = value; }
        }
        
        public string OldFileName
        {
            get { return m_OldFileNameString; }
            set { m_OldFileNameString = value; }
        }

        public int FileId
        {
            get { return m_FileIdInteger; }
            set { m_FileIdInteger = value; }
        }
    }

}
