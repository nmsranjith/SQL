﻿/* 
Name                : CExceptionFile.cs
Author              : Suchithra Baskaran
Purpose             : DAO class
Date Created        : 21 Aug 2012
Revision History    :
Modified by         :
Date Modified       :
 */

using DMSCommon.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using Microsoft.Office.Interop.Excel;
using DMSCommon.DAO;
using System.IO;
using System.Configuration;

namespace DMSCommon
{
    public class CExceptionFile
    {
        string exceptionCSVPathString = ConfigurationManager.AppSettings.Get("UploadExceptionCasesCSVPath");
        string deLimiter = ",";

        /// <summary>
        /// 
        /// </summary>
        /// <param name="v_exceptionInfoListObject"></param>
        //public void WriteExceptionInExcel(List<CCSVInfo> v_exceptionInfoListObject)
        public string WriteExceptionInExcel(List<CCSVInfo> v_exceptionInfoListObject)
        {
            StringBuilder sb = null;
            try
            {
                if (!Directory.Exists(exceptionCSVPathString.Substring(0, exceptionCSVPathString.LastIndexOf("\\"))))
                    Directory.CreateDirectory(exceptionCSVPathString.Substring(0, exceptionCSVPathString.LastIndexOf("\\")));

                sb = new StringBuilder();
                sb.AppendLine(string.Join(",", new string[] { "File Name", "Client Code", "Folder Name", "Reason" }));

                foreach (CCSVInfo info in v_exceptionInfoListObject)
                {
                    if (info.Reason == "")
                    {
                        if (info.ClientCode == "")
                            info.Reason = "Client Code not available";

                        if (info.ParentFolderName == "")
                            info.Reason = "File Name not available";
                    }

                    sb.AppendLine(string.Join(deLimiter, new string[] { info.FileName, info.ClientCode, info.ParentFolderName, info.Reason }));
                }

               exceptionCSVPathString = exceptionCSVPathString.Substring(0, exceptionCSVPathString.LastIndexOf(".")) + "-" + DateTime.Now.ToString("ddMMyyyy hh mm ss") + ".csv";
               File.WriteAllText(exceptionCSVPathString, sb.ToString());

               return exceptionCSVPathString;
            }
            catch (Exception ex)
            {
                CLogHelper.Instance.LogErrorInfo(ex, "ExceptionFile.WriteExceptionInExcel" + DateTime.Now);
                throw ex;
            }
            finally
            {
                sb = null;
            }
        }
    }
}
