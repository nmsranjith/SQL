﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Text;
using System.IO;
namespace DMSCommon.Common
{
     public sealed class CLogHelper
    {
        private static CLogHelper currentController = null;

        /// <summary>
        /// Get CUtility object Instance 
        /// </summary>
        /// <returns>CUtility object</returns>
        public static CLogHelper Instance
        {
            get
            {
                if ((currentController == null))
                {
                    currentController = new CLogHelper();
                }
                return currentController;
            }
        }



        /// <summary>
        /// This function used to Log Information in AppLog
        /// </summary>
        /// <param name="v_enmTraceType">Trace type enumeration</param>
        /// <param name="v_strfunctionName">function Name</param>
        /// <param name="v_strMessage">Message to be logged</param>   
        /// <Copyright>© by Meijer Stores Limited</Copyright>
        public void LogProcessInfo(TraceEventType v_enmTraceType, string v_strfunctionName, string v_strMessage)
        {
            SetUp(System.Configuration.ConfigurationManager.AppSettings.Get("DMSAppProcessLogFileName"));

            if (System.Configuration.ConfigurationManager.AppSettings.Get("LocalLog").Equals("Y"))
            {
                //Log(v_enmTraceType, v_strfunctionName, v_strMessage);
                AppLog(v_enmTraceType, v_strfunctionName, v_strMessage);
            }

            //if ((Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings.Get("EnableConsoleDebugging"))))
            //{
            //    Console.WriteLine(v_strfunctionName + ":" + v_strMessage);
            //}

        }

       

        public void LogApplicationInfo(string v_strMessage)
        {
            SetUp(System.Configuration.ConfigurationManager.AppSettings.Get("DMSAppLogFileName"));

            LogApplication(v_strMessage);

            Console.WriteLine(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss:ffff") + "| " + v_strMessage);
        }

        public void LogServiceApplication(string v_strMessage)
        {
            SetUp(System.Configuration.ConfigurationManager.AppSettings.Get("RenameFailLogFileName"));

            LogApplication(v_strMessage);

            Console.WriteLine(v_strMessage);

        }


        //public void Exception(LogErrorInfo v_objException, string v_strfunctionName)
        //{
        //    //SetUp(System.Configuration.ConfigurationManager.AppSettings.Get("DMSAppProcessLogFileName"));
        //    SetUp(System.Configuration.ConfigurationManager.AppSettings.Get("DMSAppErrorLogFileName"));

        //    if (((v_objException != null)))
        //    {
        //        //this.Log(TraceEventType.Error, v_strfunctionName, v_objException.Message);
        //        this.ErrorLog(TraceEventType.Error, v_strfunctionName, v_objException.Message);
        //    }
        //}


        #region " Log Helper "
        private int m_intLogFileNumber;
        private long m_lngLogFileSize;
        private string m_strLogFileDirectory;
        private string m_strLogFileName;

        private string m_strLogFilePrefix;

        private void SetUp(string v_strLogPrefix)
        {
            if (v_strLogPrefix.Trim().Length == 0)
            {
                this.m_strLogFilePrefix = "AppLog";
            }
            else
            {
                this.m_strLogFilePrefix = v_strLogPrefix;
            }
            try
            {
                this.m_strLogFileDirectory = System.Configuration.ConfigurationManager.AppSettings.Get((this.m_strLogFilePrefix + "-LogFileDirectory"));
            }
            catch (Exception exception1)
            {
                Exception exception = exception1;
                this.m_strLogFileDirectory = "";
            }
            if (m_strLogFileDirectory.Trim().Length == 0)
            {
                this.m_strLogFileDirectory = ".";
            }
            try
            {
                this.m_lngLogFileSize = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings.Get((this.m_strLogFilePrefix + "-LogFileSize")));
            }
            catch (Exception exception4)
            {
                Exception exception2 = exception4;
                this.m_lngLogFileSize = 0x8000;
            }
            if ((this.m_lngLogFileSize == 0))
            {
                this.m_lngLogFileSize = 0x8000;
            }
            try
            {
                this.m_intLogFileNumber = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings.Get((this.m_strLogFilePrefix + "-LogFileNumber")));
            }
            catch (Exception exception5)
            {
                Exception exception3 = exception5;
                this.m_intLogFileNumber = 1;
            }
            if ((this.m_intLogFileNumber == 0))
            {
                this.m_intLogFileNumber = 1;
            }

            CheckAndCreateDefaultLogDirectory();
            this.m_strLogFileName = this.GetLogFileName();

        }


        private void CheckAndCreateDefaultLogDirectory()
        {
            if (!System.IO.Directory.Exists(this.m_strLogFileDirectory))
            {
                System.IO.Directory.CreateDirectory(this.m_strLogFileDirectory);
            }
        }



        private string GetLogFileName()
        {
            int num = 0;
            string str2 = null;
            string[] files = Directory.GetFiles(this.m_strLogFileDirectory, (this.m_strLogFilePrefix + "*"));
            if ((files.Length == 0))
            {
                return (this.m_strLogFileDirectory + "\\" + this.m_strLogFilePrefix + "1.log");
            }
            int num2 = (files.Length - 1);
            num = 0;
            while ((num <= num2))
            {
                if ((files[num].Length < this.m_lngLogFileSize))
                {
                    return files[num];
                }
                num += 1;
            }
            if ((files.Length < this.m_intLogFileNumber))
            {
                int num3 = this.m_intLogFileNumber;
                num = 1;
                while ((num <= num3))
                {
                    str2 = string.Concat(new string[] {
					this.m_strLogFileDirectory,
					"\\",
					this.m_strLogFilePrefix,
					num.ToString(),
					".log"
				});
                    if (!File.Exists(str2))
                    {
                        return str2;
                    }
                    num += 1;
                }
            }
            DateTime now = DateTime.Now;
            string str = "";
            int intLogFileNumber = this.m_intLogFileNumber;
            num = 1;
            while ((num <= intLogFileNumber))
            {
                str2 = string.Concat(new string[] {
				this.m_strLogFileDirectory,
				"\\",
				this.m_strLogFilePrefix,
				num.ToString(),
				".log"
			});
                if ((DateTime.Compare(File.GetLastWriteTime(str2), now) < 0))
                {
                    now = File.GetLastWriteTime(str2);
                    str = str2;
                }
                num += 1;
            }
            if (str.Trim().Length == 0)
            {
                str = (this.m_strLogFileDirectory + "\\" + this.m_strLogFilePrefix + "1.log");
            }
            try
            {
                File.Delete(str);
            }
            catch (Exception exception1)
            {
                Exception exception = exception1;
            }
            return str;
        }


        private void LogApplication(string v_strMessage)
        {
            StreamWriter writer = null;
            try
            {
                writer = File.AppendText(this.m_strLogFileName);
            }
            catch (Exception exception1)
            {
                Exception exception = exception1;
                return;
            }
            try
            {
                writer.WriteLine(v_strMessage);
            }
            catch
            {
                return;
            }
            finally
            {
                try
                {
                    writer.Close();
                }
                catch (Exception exception5)
                {
                    Exception exception3 = exception5;
                }
            }
        }


        //private void Log(TraceEventType v_enumEventType, string v_strMethod, string v_strMessage)
        private void AppLog(TraceEventType v_enumEventType, string v_strMethod, string v_strMessage)
        {
            StreamWriter writer = null;
            try
            {
                writer = File.AppendText(this.m_strLogFileName);
            }
            catch (Exception exception1)
            {
                Exception exception = exception1;
                return;
            }
            try
            {
                writer.WriteLine(string.Concat(new string[] {
				v_strMethod
			}));
            }
            catch
            {
                return;
            }
            finally
            {
                try
                {
                    writer.Close();
                }
                catch (Exception exception5)
                {
                    Exception exception3 = exception5;
                }
            }
        }

        private void ErrorLog(TraceEventType v_enumEventType, string v_strMethod, string v_strMessage)
        {
            StreamWriter writer = null;
            try
            {
                writer = File.AppendText(this.m_strLogFileName);
            }
            catch (Exception exception1)
            {
                Exception exception = exception1;
                return;
            }
            try
            {
                writer.WriteLine(string.Concat(new string[] {
                                 DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss:ffff"),
                                 "|",
                                 v_enumEventType.ToString(),
                                 "|",
                                 v_strMethod,
                                 "|",
                                 v_strMessage
                }));
            }
            catch
            {
                return;
            }
            finally
            {
                try
                {
                    writer.Close();
                }
                catch (Exception exception5)
                {
                    Exception exception3 = exception5;
                }
            }
        }


        #endregion
    }
}
