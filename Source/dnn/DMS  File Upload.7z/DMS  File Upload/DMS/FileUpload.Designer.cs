﻿namespace DMS
{
    partial class FileUpload
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.folderProgressLabel = new System.Windows.Forms.Label();
            this.filesProgressLabel = new System.Windows.Forms.Label();
            this.progressLabel = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.cancelButton = new System.Windows.Forms.Button();
            this.uploadButton = new System.Windows.Forms.Button();
            this.uploadTypeComboBox = new System.Windows.Forms.ComboBox();
            this.uploadTypeLabel = new System.Windows.Forms.Label();
            this.uploadBasedOnClientCodeGroupBox = new System.Windows.Forms.GroupBox();
            this.clientCodeFolderTextBox = new System.Windows.Forms.TextBox();
            this.clientCodeFolderBrowsebutton = new System.Windows.Forms.Button();
            this.clientCodeFolderLabel = new System.Windows.Forms.Label();
            this.uploadToFTPGroupBox = new System.Windows.Forms.GroupBox();
            this.sourceFolderTextBox = new System.Windows.Forms.TextBox();
            this.FTPFolderTextBox = new System.Windows.Forms.TextBox();
            this.sourceFolderlabel = new System.Windows.Forms.Label();
            this.FTPFolderLabel = new System.Windows.Forms.Label();
            this.sourceFolderBrowseButton = new System.Windows.Forms.Button();
            this.uploadBasedOnFilenameGroupBox = new System.Windows.Forms.GroupBox();
            this.uploadBasedOnFilenameTextBox = new System.Windows.Forms.TextBox();
            this.uploadBasedOnFileNameBrowseButton = new System.Windows.Forms.Button();
            this.uploadBasedOnFileNameSourceFolderLabel = new System.Windows.Forms.Label();
            this.uploadBasedOnIndividualFileGroupBox = new System.Windows.Forms.GroupBox();
            this.documentTypeComboBox = new System.Windows.Forms.ComboBox();
            this.clientCodeLabel = new System.Windows.Forms.Label();
            this.securityCodeTextBox = new System.Windows.Forms.TextBox();
            this.securityCodeLabel = new System.Windows.Forms.Label();
            this.browseIndividualFileButton = new System.Windows.Forms.Button();
            this.clientCodeTextBox = new System.Windows.Forms.TextBox();
            this.fileTextBox = new System.Windows.Forms.TextBox();
            this.selectFileLabel = new System.Windows.Forms.Label();
            this.documentTypeLabel = new System.Windows.Forms.Label();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.selectDateLabel = new System.Windows.Forms.Label();
            this.uploadBasedOnCSVGroupBox = new System.Windows.Forms.GroupBox();
            this.selectCSVFilelabel = new System.Windows.Forms.Label();
            this.uploadCSVSourceFolderBrowseButton = new System.Windows.Forms.Button();
            this.selectCSVFiletextBox = new System.Windows.Forms.TextBox();
            this.csvFileSourceFolderTextbox = new System.Windows.Forms.TextBox();
            this.csvFileSourceFolderLabel = new System.Windows.Forms.Label();
            this.browseCSVFileButton = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panel1.SuspendLayout();
            this.uploadBasedOnClientCodeGroupBox.SuspendLayout();
            this.uploadToFTPGroupBox.SuspendLayout();
            this.uploadBasedOnFilenameGroupBox.SuspendLayout();
            this.uploadBasedOnIndividualFileGroupBox.SuspendLayout();
            this.uploadBasedOnCSVGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.folderProgressLabel);
            this.panel1.Controls.Add(this.filesProgressLabel);
            this.panel1.Controls.Add(this.progressLabel);
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.cancelButton);
            this.panel1.Controls.Add(this.uploadButton);
            this.panel1.Controls.Add(this.uploadTypeComboBox);
            this.panel1.Controls.Add(this.uploadTypeLabel);
            this.panel1.Controls.Add(this.uploadBasedOnCSVGroupBox);
            this.panel1.Controls.Add(this.uploadBasedOnClientCodeGroupBox);
            this.panel1.Controls.Add(this.uploadToFTPGroupBox);
            this.panel1.Controls.Add(this.uploadBasedOnFilenameGroupBox);
            this.panel1.Controls.Add(this.uploadBasedOnIndividualFileGroupBox);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(468, 208);
            this.panel1.TabIndex = 0;
            // 
            // folderProgressLabel
            // 
            this.folderProgressLabel.AutoSize = true;
            this.folderProgressLabel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.folderProgressLabel.Location = new System.Drawing.Point(202, 180);
            this.folderProgressLabel.Name = "folderProgressLabel";
            this.folderProgressLabel.Size = new System.Drawing.Size(91, 18);
            this.folderProgressLabel.TabIndex = 43;
            this.folderProgressLabel.Text = "Folder out of ";
            // 
            // filesProgressLabel
            // 
            this.filesProgressLabel.AutoSize = true;
            this.filesProgressLabel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.filesProgressLabel.Location = new System.Drawing.Point(15, 180);
            this.filesProgressLabel.Name = "filesProgressLabel";
            this.filesProgressLabel.Size = new System.Drawing.Size(118, 18);
            this.filesProgressLabel.TabIndex = 42;
            this.filesProgressLabel.Text = "Files 100 out of 10";
            // 
            // progressLabel
            // 
            this.progressLabel.AutoSize = true;
            this.progressLabel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.progressLabel.Location = new System.Drawing.Point(199, 159);
            this.progressLabel.Name = "progressLabel";
            this.progressLabel.Size = new System.Drawing.Size(0, 18);
            this.progressLabel.TabIndex = 39;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(7, 154);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(314, 23);
            this.progressBar1.Step = 1;
            this.progressBar1.TabIndex = 38;
            this.progressBar1.Visible = false;
            // 
            // cancelButton
            // 
            this.cancelButton.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelButton.Location = new System.Drawing.Point(393, 153);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(63, 25);
            this.cancelButton.TabIndex = 4;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // uploadButton
            // 
            this.uploadButton.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uploadButton.Location = new System.Drawing.Point(327, 152);
            this.uploadButton.Name = "uploadButton";
            this.uploadButton.Size = new System.Drawing.Size(60, 26);
            this.uploadButton.TabIndex = 3;
            this.uploadButton.Text = "Upload";
            this.uploadButton.UseVisualStyleBackColor = true;
            this.uploadButton.Click += new System.EventHandler(this.uploadButton_Click);
            // 
            // uploadTypeComboBox
            // 
            this.uploadTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.uploadTypeComboBox.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uploadTypeComboBox.FormattingEnabled = true;
            this.uploadTypeComboBox.Items.AddRange(new object[] {
            "Upload to FTP",
            "Upload based on CSV",
            "Upload based on Filename",
            "Upload based on ClientCode",
            "Upload Individual File"});
            this.uploadTypeComboBox.Location = new System.Drawing.Point(103, 6);
            this.uploadTypeComboBox.Name = "uploadTypeComboBox";
            this.uploadTypeComboBox.Size = new System.Drawing.Size(283, 26);
            this.uploadTypeComboBox.TabIndex = 1;
            this.uploadTypeComboBox.SelectedIndexChanged += new System.EventHandler(this.uploadTypeComboBox_SelectedIndexChanged);
            // 
            // uploadTypeLabel
            // 
            this.uploadTypeLabel.AutoSize = true;
            this.uploadTypeLabel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uploadTypeLabel.Location = new System.Drawing.Point(11, 8);
            this.uploadTypeLabel.Name = "uploadTypeLabel";
            this.uploadTypeLabel.Size = new System.Drawing.Size(85, 18);
            this.uploadTypeLabel.TabIndex = 0;
            this.uploadTypeLabel.Text = "Upload Type";
            // 
            // uploadBasedOnClientCodeGroupBox
            // 
            this.uploadBasedOnClientCodeGroupBox.Controls.Add(this.clientCodeFolderTextBox);
            this.uploadBasedOnClientCodeGroupBox.Controls.Add(this.clientCodeFolderBrowsebutton);
            this.uploadBasedOnClientCodeGroupBox.Controls.Add(this.clientCodeFolderLabel);
            this.uploadBasedOnClientCodeGroupBox.Location = new System.Drawing.Point(7, 36);
            this.uploadBasedOnClientCodeGroupBox.Name = "uploadBasedOnClientCodeGroupBox";
            this.uploadBasedOnClientCodeGroupBox.Size = new System.Drawing.Size(448, 113);
            this.uploadBasedOnClientCodeGroupBox.TabIndex = 26;
            this.uploadBasedOnClientCodeGroupBox.TabStop = false;
            // 
            // clientCodeFolderTextBox
            // 
            this.clientCodeFolderTextBox.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clientCodeFolderTextBox.Location = new System.Drawing.Point(125, 16);
            this.clientCodeFolderTextBox.Name = "clientCodeFolderTextBox";
            this.clientCodeFolderTextBox.Size = new System.Drawing.Size(283, 26);
            this.clientCodeFolderTextBox.TabIndex = 23;
            // 
            // clientCodeFolderBrowsebutton
            // 
            this.clientCodeFolderBrowsebutton.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clientCodeFolderBrowsebutton.Image = global::DMS.Properties.Resources.BrowseFolderIcon;
            this.clientCodeFolderBrowsebutton.Location = new System.Drawing.Point(414, 16);
            this.clientCodeFolderBrowsebutton.Name = "clientCodeFolderBrowsebutton";
            this.clientCodeFolderBrowsebutton.Size = new System.Drawing.Size(30, 26);
            this.clientCodeFolderBrowsebutton.TabIndex = 24;
            this.clientCodeFolderBrowsebutton.UseVisualStyleBackColor = true;
            this.clientCodeFolderBrowsebutton.Click += new System.EventHandler(this.clientCodeFolderBrowsebutton_Click);
            // 
            // clientCodeFolderLabel
            // 
            this.clientCodeFolderLabel.AutoSize = true;
            this.clientCodeFolderLabel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clientCodeFolderLabel.Location = new System.Drawing.Point(3, 19);
            this.clientCodeFolderLabel.Name = "clientCodeFolderLabel";
            this.clientCodeFolderLabel.Size = new System.Drawing.Size(123, 18);
            this.clientCodeFolderLabel.TabIndex = 22;
            this.clientCodeFolderLabel.Text = "Client Code Folder";
            // 
            // uploadToFTPGroupBox
            // 
            this.uploadToFTPGroupBox.Controls.Add(this.sourceFolderTextBox);
            this.uploadToFTPGroupBox.Controls.Add(this.FTPFolderTextBox);
            this.uploadToFTPGroupBox.Controls.Add(this.sourceFolderlabel);
            this.uploadToFTPGroupBox.Controls.Add(this.FTPFolderLabel);
            this.uploadToFTPGroupBox.Controls.Add(this.sourceFolderBrowseButton);
            this.uploadToFTPGroupBox.Location = new System.Drawing.Point(7, 38);
            this.uploadToFTPGroupBox.Name = "uploadToFTPGroupBox";
            this.uploadToFTPGroupBox.Size = new System.Drawing.Size(448, 113);
            this.uploadToFTPGroupBox.TabIndex = 37;
            this.uploadToFTPGroupBox.TabStop = false;
            // 
            // sourceFolderTextBox
            // 
            this.sourceFolderTextBox.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sourceFolderTextBox.Location = new System.Drawing.Point(95, 16);
            this.sourceFolderTextBox.Name = "sourceFolderTextBox";
            this.sourceFolderTextBox.Size = new System.Drawing.Size(283, 26);
            this.sourceFolderTextBox.TabIndex = 32;
            // 
            // FTPFolderTextBox
            // 
            this.FTPFolderTextBox.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FTPFolderTextBox.Location = new System.Drawing.Point(95, 47);
            this.FTPFolderTextBox.Name = "FTPFolderTextBox";
            this.FTPFolderTextBox.ReadOnly = true;
            this.FTPFolderTextBox.Size = new System.Drawing.Size(283, 26);
            this.FTPFolderTextBox.TabIndex = 35;
            // 
            // sourceFolderlabel
            // 
            this.sourceFolderlabel.AutoSize = true;
            this.sourceFolderlabel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sourceFolderlabel.Location = new System.Drawing.Point(3, 19);
            this.sourceFolderlabel.Name = "sourceFolderlabel";
            this.sourceFolderlabel.Size = new System.Drawing.Size(93, 18);
            this.sourceFolderlabel.TabIndex = 31;
            this.sourceFolderlabel.Text = "Source Folder";
            // 
            // FTPFolderLabel
            // 
            this.FTPFolderLabel.AutoSize = true;
            this.FTPFolderLabel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FTPFolderLabel.Location = new System.Drawing.Point(3, 50);
            this.FTPFolderLabel.Name = "FTPFolderLabel";
            this.FTPFolderLabel.Size = new System.Drawing.Size(73, 18);
            this.FTPFolderLabel.TabIndex = 34;
            this.FTPFolderLabel.Text = "FTP Folder";
            // 
            // sourceFolderBrowseButton
            // 
            this.sourceFolderBrowseButton.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sourceFolderBrowseButton.Image = global::DMS.Properties.Resources.BrowseFolderIcon;
            this.sourceFolderBrowseButton.Location = new System.Drawing.Point(381, 16);
            this.sourceFolderBrowseButton.Name = "sourceFolderBrowseButton";
            this.sourceFolderBrowseButton.Size = new System.Drawing.Size(30, 26);
            this.sourceFolderBrowseButton.TabIndex = 33;
            this.sourceFolderBrowseButton.UseVisualStyleBackColor = true;
            this.sourceFolderBrowseButton.Click += new System.EventHandler(this.sourceFolderBrowseButton_Click);
            // 
            // uploadBasedOnFilenameGroupBox
            // 
            this.uploadBasedOnFilenameGroupBox.Controls.Add(this.uploadBasedOnFilenameTextBox);
            this.uploadBasedOnFilenameGroupBox.Controls.Add(this.uploadBasedOnFileNameBrowseButton);
            this.uploadBasedOnFilenameGroupBox.Controls.Add(this.uploadBasedOnFileNameSourceFolderLabel);
            this.uploadBasedOnFilenameGroupBox.Location = new System.Drawing.Point(7, 38);
            this.uploadBasedOnFilenameGroupBox.Name = "uploadBasedOnFilenameGroupBox";
            this.uploadBasedOnFilenameGroupBox.Size = new System.Drawing.Size(448, 113);
            this.uploadBasedOnFilenameGroupBox.TabIndex = 21;
            this.uploadBasedOnFilenameGroupBox.TabStop = false;
            this.uploadBasedOnFilenameGroupBox.Text = "  ";
            // 
            // uploadBasedOnFilenameTextBox
            // 
            this.uploadBasedOnFilenameTextBox.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uploadBasedOnFilenameTextBox.Location = new System.Drawing.Point(95, 16);
            this.uploadBasedOnFilenameTextBox.Name = "uploadBasedOnFilenameTextBox";
            this.uploadBasedOnFilenameTextBox.Size = new System.Drawing.Size(283, 26);
            this.uploadBasedOnFilenameTextBox.TabIndex = 18;
            // 
            // uploadBasedOnFileNameBrowseButton
            // 
            this.uploadBasedOnFileNameBrowseButton.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uploadBasedOnFileNameBrowseButton.Image = global::DMS.Properties.Resources.BrowseFolderIcon;
            this.uploadBasedOnFileNameBrowseButton.Location = new System.Drawing.Point(382, 16);
            this.uploadBasedOnFileNameBrowseButton.Name = "uploadBasedOnFileNameBrowseButton";
            this.uploadBasedOnFileNameBrowseButton.Size = new System.Drawing.Size(30, 26);
            this.uploadBasedOnFileNameBrowseButton.TabIndex = 19;
            this.uploadBasedOnFileNameBrowseButton.UseVisualStyleBackColor = true;
            this.uploadBasedOnFileNameBrowseButton.Click += new System.EventHandler(this.uploadBasedOnFileNameBrowseButton_Click);
            // 
            // uploadBasedOnFileNameSourceFolderLabel
            // 
            this.uploadBasedOnFileNameSourceFolderLabel.AutoSize = true;
            this.uploadBasedOnFileNameSourceFolderLabel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uploadBasedOnFileNameSourceFolderLabel.Location = new System.Drawing.Point(3, 19);
            this.uploadBasedOnFileNameSourceFolderLabel.Name = "uploadBasedOnFileNameSourceFolderLabel";
            this.uploadBasedOnFileNameSourceFolderLabel.Size = new System.Drawing.Size(93, 18);
            this.uploadBasedOnFileNameSourceFolderLabel.TabIndex = 12;
            this.uploadBasedOnFileNameSourceFolderLabel.Text = "Source Folder";
            // 
            // uploadBasedOnIndividualFileGroupBox
            // 
            this.uploadBasedOnIndividualFileGroupBox.Controls.Add(this.documentTypeComboBox);
            this.uploadBasedOnIndividualFileGroupBox.Controls.Add(this.clientCodeLabel);
            this.uploadBasedOnIndividualFileGroupBox.Controls.Add(this.securityCodeTextBox);
            this.uploadBasedOnIndividualFileGroupBox.Controls.Add(this.securityCodeLabel);
            this.uploadBasedOnIndividualFileGroupBox.Controls.Add(this.browseIndividualFileButton);
            this.uploadBasedOnIndividualFileGroupBox.Controls.Add(this.clientCodeTextBox);
            this.uploadBasedOnIndividualFileGroupBox.Controls.Add(this.fileTextBox);
            this.uploadBasedOnIndividualFileGroupBox.Controls.Add(this.selectFileLabel);
            this.uploadBasedOnIndividualFileGroupBox.Controls.Add(this.documentTypeLabel);
            this.uploadBasedOnIndividualFileGroupBox.Controls.Add(this.dateTimePicker);
            this.uploadBasedOnIndividualFileGroupBox.Controls.Add(this.selectDateLabel);
            this.uploadBasedOnIndividualFileGroupBox.Location = new System.Drawing.Point(7, 38);
            this.uploadBasedOnIndividualFileGroupBox.Name = "uploadBasedOnIndividualFileGroupBox";
            this.uploadBasedOnIndividualFileGroupBox.Size = new System.Drawing.Size(448, 113);
            this.uploadBasedOnIndividualFileGroupBox.TabIndex = 34;
            this.uploadBasedOnIndividualFileGroupBox.TabStop = false;
            // 
            // documentTypeComboBox
            // 
            this.documentTypeComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.documentTypeComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.documentTypeComboBox.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.documentTypeComboBox.FormattingEnabled = true;
            this.documentTypeComboBox.Location = new System.Drawing.Point(295, 15);
            this.documentTypeComboBox.Name = "documentTypeComboBox";
            this.documentTypeComboBox.Size = new System.Drawing.Size(110, 26);
            this.documentTypeComboBox.TabIndex = 33;
            // 
            // clientCodeLabel
            // 
            this.clientCodeLabel.AutoSize = true;
            this.clientCodeLabel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clientCodeLabel.Location = new System.Drawing.Point(3, 19);
            this.clientCodeLabel.Name = "clientCodeLabel";
            this.clientCodeLabel.Size = new System.Drawing.Size(80, 18);
            this.clientCodeLabel.TabIndex = 5;
            this.clientCodeLabel.Text = "Client Code";
            // 
            // securityCodeTextBox
            // 
            this.securityCodeTextBox.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.securityCodeTextBox.Location = new System.Drawing.Point(95, 47);
            this.securityCodeTextBox.Name = "securityCodeTextBox";
            this.securityCodeTextBox.Size = new System.Drawing.Size(92, 26);
            this.securityCodeTextBox.TabIndex = 32;
            // 
            // securityCodeLabel
            // 
            this.securityCodeLabel.AutoSize = true;
            this.securityCodeLabel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.securityCodeLabel.Location = new System.Drawing.Point(3, 50);
            this.securityCodeLabel.Name = "securityCodeLabel";
            this.securityCodeLabel.Size = new System.Drawing.Size(93, 18);
            this.securityCodeLabel.TabIndex = 31;
            this.securityCodeLabel.Text = "Security Code";
            // 
            // browseIndividualFileButton
            // 
            this.browseIndividualFileButton.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.browseIndividualFileButton.Image = global::DMS.Properties.Resources.BrowseFileIcon;
            this.browseIndividualFileButton.Location = new System.Drawing.Point(381, 80);
            this.browseIndividualFileButton.Name = "browseIndividualFileButton";
            this.browseIndividualFileButton.Size = new System.Drawing.Size(30, 26);
            this.browseIndividualFileButton.TabIndex = 27;
            this.browseIndividualFileButton.UseVisualStyleBackColor = true;
            this.browseIndividualFileButton.Click += new System.EventHandler(this.browseIndividualFileButton_Click);
            // 
            // clientCodeTextBox
            // 
            this.clientCodeTextBox.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clientCodeTextBox.Location = new System.Drawing.Point(95, 16);
            this.clientCodeTextBox.Name = "clientCodeTextBox";
            this.clientCodeTextBox.Size = new System.Drawing.Size(92, 26);
            this.clientCodeTextBox.TabIndex = 6;
            // 
            // fileTextBox
            // 
            this.fileTextBox.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fileTextBox.Location = new System.Drawing.Point(95, 80);
            this.fileTextBox.Name = "fileTextBox";
            this.fileTextBox.Size = new System.Drawing.Size(283, 26);
            this.fileTextBox.TabIndex = 26;
            // 
            // selectFileLabel
            // 
            this.selectFileLabel.AutoSize = true;
            this.selectFileLabel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectFileLabel.Location = new System.Drawing.Point(3, 80);
            this.selectFileLabel.Name = "selectFileLabel";
            this.selectFileLabel.Size = new System.Drawing.Size(72, 18);
            this.selectFileLabel.TabIndex = 25;
            this.selectFileLabel.Text = "Select File";
            // 
            // documentTypeLabel
            // 
            this.documentTypeLabel.AutoSize = true;
            this.documentTypeLabel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.documentTypeLabel.Location = new System.Drawing.Point(192, 19);
            this.documentTypeLabel.Name = "documentTypeLabel";
            this.documentTypeLabel.Size = new System.Drawing.Size(105, 18);
            this.documentTypeLabel.TabIndex = 3;
            this.documentTypeLabel.Text = "Document Type";
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.CalendarFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker.Location = new System.Drawing.Point(295, 48);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(110, 26);
            this.dateTimePicker.TabIndex = 8;
            // 
            // selectDateLabel
            // 
            this.selectDateLabel.AutoSize = true;
            this.selectDateLabel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectDateLabel.Location = new System.Drawing.Point(192, 48);
            this.selectDateLabel.Name = "selectDateLabel";
            this.selectDateLabel.Size = new System.Drawing.Size(37, 18);
            this.selectDateLabel.TabIndex = 7;
            this.selectDateLabel.Text = "Date";
            // 
            // uploadBasedOnCSVGroupBox
            // 
            this.uploadBasedOnCSVGroupBox.Controls.Add(this.selectCSVFilelabel);
            this.uploadBasedOnCSVGroupBox.Controls.Add(this.uploadCSVSourceFolderBrowseButton);
            this.uploadBasedOnCSVGroupBox.Controls.Add(this.selectCSVFiletextBox);
            this.uploadBasedOnCSVGroupBox.Controls.Add(this.csvFileSourceFolderTextbox);
            this.uploadBasedOnCSVGroupBox.Controls.Add(this.csvFileSourceFolderLabel);
            this.uploadBasedOnCSVGroupBox.Controls.Add(this.browseCSVFileButton);
            this.uploadBasedOnCSVGroupBox.Location = new System.Drawing.Point(7, 38);
            this.uploadBasedOnCSVGroupBox.Name = "uploadBasedOnCSVGroupBox";
            this.uploadBasedOnCSVGroupBox.Size = new System.Drawing.Size(448, 113);
            this.uploadBasedOnCSVGroupBox.TabIndex = 21;
            this.uploadBasedOnCSVGroupBox.TabStop = false;
            // 
            // selectCSVFilelabel
            // 
            this.selectCSVFilelabel.AutoSize = true;
            this.selectCSVFilelabel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectCSVFilelabel.Location = new System.Drawing.Point(3, 19);
            this.selectCSVFilelabel.Name = "selectCSVFilelabel";
            this.selectCSVFilelabel.Size = new System.Drawing.Size(58, 18);
            this.selectCSVFilelabel.TabIndex = 14;
            this.selectCSVFilelabel.Text = "CSV File";
            // 
            // uploadCSVSourceFolderBrowseButton
            // 
            this.uploadCSVSourceFolderBrowseButton.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uploadCSVSourceFolderBrowseButton.Image = global::DMS.Properties.Resources.BrowseFolderIcon;
            this.uploadCSVSourceFolderBrowseButton.Location = new System.Drawing.Point(384, 47);
            this.uploadCSVSourceFolderBrowseButton.Name = "uploadCSVSourceFolderBrowseButton";
            this.uploadCSVSourceFolderBrowseButton.Size = new System.Drawing.Size(30, 26);
            this.uploadCSVSourceFolderBrowseButton.TabIndex = 19;
            this.uploadCSVSourceFolderBrowseButton.UseVisualStyleBackColor = true;
            this.uploadCSVSourceFolderBrowseButton.Click += new System.EventHandler(this.uploadCSVSourceFolderBrowseButton_Click);
            // 
            // selectCSVFiletextBox
            // 
            this.selectCSVFiletextBox.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectCSVFiletextBox.Location = new System.Drawing.Point(95, 16);
            this.selectCSVFiletextBox.Name = "selectCSVFiletextBox";
            this.selectCSVFiletextBox.Size = new System.Drawing.Size(283, 26);
            this.selectCSVFiletextBox.TabIndex = 15;
            // 
            // csvFileSourceFolderTextbox
            // 
            this.csvFileSourceFolderTextbox.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.csvFileSourceFolderTextbox.Location = new System.Drawing.Point(95, 47);
            this.csvFileSourceFolderTextbox.Name = "csvFileSourceFolderTextbox";
            this.csvFileSourceFolderTextbox.Size = new System.Drawing.Size(283, 26);
            this.csvFileSourceFolderTextbox.TabIndex = 18;
            // 
            // csvFileSourceFolderLabel
            // 
            this.csvFileSourceFolderLabel.AutoSize = true;
            this.csvFileSourceFolderLabel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.csvFileSourceFolderLabel.Location = new System.Drawing.Point(3, 50);
            this.csvFileSourceFolderLabel.Name = "csvFileSourceFolderLabel";
            this.csvFileSourceFolderLabel.Size = new System.Drawing.Size(93, 18);
            this.csvFileSourceFolderLabel.TabIndex = 12;
            this.csvFileSourceFolderLabel.Text = "Source Folder";
            // 
            // browseCSVFileButton
            // 
            this.browseCSVFileButton.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.browseCSVFileButton.Image = global::DMS.Properties.Resources.BrowseFileIcon;
            this.browseCSVFileButton.Location = new System.Drawing.Point(384, 16);
            this.browseCSVFileButton.Name = "browseCSVFileButton";
            this.browseCSVFileButton.Size = new System.Drawing.Size(30, 27);
            this.browseCSVFileButton.TabIndex = 16;
            this.browseCSVFileButton.UseVisualStyleBackColor = true;
            this.browseCSVFileButton.Click += new System.EventHandler(this.browseCSVFileButton_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.DefaultExt = "*.CSV";
            this.openFileDialog1.Title = "Select CSV File";
            // 
            // FileUpload
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(490, 232);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FileUpload";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "File Upload";
            this.Load += new System.EventHandler(this.FileUpload_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.uploadBasedOnClientCodeGroupBox.ResumeLayout(false);
            this.uploadBasedOnClientCodeGroupBox.PerformLayout();
            this.uploadToFTPGroupBox.ResumeLayout(false);
            this.uploadToFTPGroupBox.PerformLayout();
            this.uploadBasedOnFilenameGroupBox.ResumeLayout(false);
            this.uploadBasedOnFilenameGroupBox.PerformLayout();
            this.uploadBasedOnIndividualFileGroupBox.ResumeLayout(false);
            this.uploadBasedOnIndividualFileGroupBox.PerformLayout();
            this.uploadBasedOnCSVGroupBox.ResumeLayout(false);
            this.uploadBasedOnCSVGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox uploadTypeComboBox;
        private System.Windows.Forms.Label uploadTypeLabel;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Button uploadButton;
        private System.Windows.Forms.GroupBox uploadBasedOnClientCodeGroupBox;
        private System.Windows.Forms.TextBox clientCodeFolderTextBox;
        private System.Windows.Forms.Button clientCodeFolderBrowsebutton;
        private System.Windows.Forms.Label clientCodeFolderLabel;
        private System.Windows.Forms.Button sourceFolderBrowseButton;
        private System.Windows.Forms.Label FTPFolderLabel;
        private System.Windows.Forms.Label sourceFolderlabel;
        private System.Windows.Forms.TextBox FTPFolderTextBox;
        private System.Windows.Forms.TextBox sourceFolderTextBox;
        private System.Windows.Forms.GroupBox uploadToFTPGroupBox;
        private System.Windows.Forms.GroupBox uploadBasedOnCSVGroupBox;
        private System.Windows.Forms.Label selectCSVFilelabel;
        private System.Windows.Forms.Button uploadCSVSourceFolderBrowseButton;
        private System.Windows.Forms.TextBox selectCSVFiletextBox;
        private System.Windows.Forms.TextBox csvFileSourceFolderTextbox;
        private System.Windows.Forms.Label csvFileSourceFolderLabel;
        private System.Windows.Forms.Button browseCSVFileButton;
        private System.Windows.Forms.GroupBox uploadBasedOnFilenameGroupBox;
        private System.Windows.Forms.TextBox uploadBasedOnFilenameTextBox;
        private System.Windows.Forms.Button uploadBasedOnFileNameBrowseButton;
        private System.Windows.Forms.Label uploadBasedOnFileNameSourceFolderLabel;
        private System.Windows.Forms.GroupBox uploadBasedOnIndividualFileGroupBox;
        private System.Windows.Forms.ComboBox documentTypeComboBox;
        private System.Windows.Forms.Label clientCodeLabel;
        private System.Windows.Forms.TextBox securityCodeTextBox;
        private System.Windows.Forms.Label securityCodeLabel;
        private System.Windows.Forms.Button browseIndividualFileButton;
        private System.Windows.Forms.TextBox clientCodeTextBox;
        private System.Windows.Forms.TextBox fileTextBox;
        private System.Windows.Forms.Label selectFileLabel;
        private System.Windows.Forms.Label documentTypeLabel;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.Label selectDateLabel;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label progressLabel;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label filesProgressLabel;
        private System.Windows.Forms.Label folderProgressLabel;

    }
}