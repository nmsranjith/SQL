﻿/* 
Name                : FileUpload.cs
Author              : Suchithra Baskaran
Purpose             : This screen is used to rename and upload files the files to repository
Date Created        : 16 Aug 2012
Revision History    :
Modified by         :
Date Modified       :
 */

using DMSBusinessLayer;
using DMSCommon;
using DMSCommon.DAO;
using DMSCommon.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.IO;
using Microsoft.Office.Interop.Excel;

namespace DMS
{
    public partial class FileUpload : Form
    {
        public FileUpload()
        {
            InitializeComponent();
        }

        string csvExceptionFile;

        /// <summary>
        /// Hide all the group boxes on page load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FileUpload_Load(object sender, EventArgs e)
        {
            try
            {
                //Hide all the group boxes
                uploadToFTPGroupBox.Visible = false;
                uploadToFTPGroupBox.Visible = true;
                uploadBasedOnCSVGroupBox.Visible = false;
                uploadBasedOnFilenameGroupBox.Visible = false;
                uploadBasedOnClientCodeGroupBox.Visible = false;
                uploadBasedOnIndividualFileGroupBox.Visible = false;

                uploadButton.Visible = false;
                cancelButton.Visible = false;

                uploadTypeComboBox.SelectedIndex = 0;

                //Clear the progress
                progressBar1.Minimum = 0;
                progressBar1.Maximum = 100;
                folderProgressLabel.Text = "";
                filesProgressLabel.Text = "";

                // Start the BackgroundWorker.
                backgroundWorker1.RunWorkerAsync();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK,MessageBoxIcon.Error);
                CLogHelper.Instance.LogErrorInfo(ex, "FileUpload.FileUpload_Load" + DateTime.Now + DateTime.Now);
            }
        }

        /// <summary>
        /// Close the application
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Method to rename and upload files based on the option selected in the upload type
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uploadButton_Click(object sender, EventArgs e)
        {
            CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "", "");
            CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Execution Details", "");
            CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "========================", "");
            CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Started at : " + DateTime.Now, "");
            CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Upload Type : " + uploadTypeComboBox.SelectedItem, "");

            DMSBusiness dmsBusinessObject = null;
            try
            {
                dmsBusinessObject = new DMSBusiness();

                if (uploadTypeComboBox.SelectedItem == "Upload to FTP")
                {
                    if (sourceFolderTextBox.Text != "" && FTPFolderTextBox.Text != "")
                    {
                        progressBar1.Visible = true;
                        progressBar1.PerformStep();

                        progressBar1.Step = 10;
                        progressBar1.PerformStep();

                        System.Windows.Forms.Application.DoEvents();
                        filesProgressLabel.Text = "Uploading Files";
                        System.Windows.Forms.Application.DoEvents();

                        progressBar1.Step = 30;
                        progressBar1.PerformStep();

                            //Copy files to FTP
                            dmsBusinessObject.CopyFilesToFTP(sourceFolderTextBox.Text, FTPFolderTextBox.Text);

                            progressBar1.PerformStep();
                            progressBar1.Step = 100;
                            progressBar1.PerformStep();

                            System.Windows.Forms.Application.DoEvents();
                            filesProgressLabel.Text = "Files Uploaded";
                            System.Windows.Forms.Application.DoEvents();

                            MessageBox.Show("Files uploaded to FTP", "File Uplaod", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else if (sourceFolderTextBox.Text == "")
                    {
                        MessageBox.Show("Select source folder for uploading files to FTP", "Validation", MessageBoxButtons.OK,MessageBoxIcon.Information);
                        sourceFolderTextBox.Focus();
                    }
                    else if (FTPFolderTextBox.Text == "")
                    {
                        MessageBox.Show("Select FTP folder to upload files", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        FTPFolderTextBox.Focus();
                    }
                }
                else if (uploadTypeComboBox.SelectedItem == "Upload based on CSV")
                {
                    

                    if (selectCSVFiletextBox.Text != "" && csvFileSourceFolderTextbox.Text != "")
                    {
                        progressBar1.Visible = true;
                        //Validate the CSV file selected before start uploading
                        FileInfo fi = new FileInfo(selectCSVFiletextBox.Text);
                        if (fi.Extension == ".csv")
                        {
                            List<CCSVInfo> exceptionFileInfoListObject = new List<CCSVInfo>();
                            exceptionFileInfoListObject = dmsBusinessObject.UploadBasedOnCSV(csvFileSourceFolderTextbox.Text, selectCSVFiletextBox.Text, ref  progressBar1, ref filesProgressLabel);
                            if (exceptionFileInfoListObject.Count > 0)
                            {
                                CExceptionFile exceptionWriteObject = new CExceptionFile();
                                //Write the exception in the CSV file
                                csvExceptionFile = exceptionWriteObject.WriteExceptionInExcel(exceptionFileInfoListObject);

                                
                                progressBar1.Step = 100;
                                progressBar1.PerformStep();

                                MessageBox.Show("Some of the records are not processed", "File Upload", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                var rk = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\excel.exe");
                                if (rk != null)
                                {
                                    Microsoft.Office.Interop.Excel.Application _app = new Microsoft.Office.Interop.Excel.Application();
                                    Microsoft.Office.Interop.Excel.Workbooks _workbooks = _app.Workbooks;
                                    _workbooks.OpenText(csvExceptionFile);
                                    _app.Visible = true;
                                }
                                else
                                {
                                    //Interaction.Shell("notepad.exe " + Strings.Chr(34) + g_strTransReportFileName + Strings.Chr(34), AppWinStyle.NormalFocus);
                                    System.Diagnostics.Process.Start(csvExceptionFile);
                                }

                            }
                            else
                                MessageBox.Show("Files Uploaded Successfully", "File Uplaod", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Selected file is not a valid CSV file", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            selectCSVFiletextBox.Clear();
                            selectCSVFiletextBox.Focus();
                        }
                    }
                    else if (selectCSVFiletextBox.Text == "")
                    {
                        MessageBox.Show("Select CSV file to upload files", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        selectCSVFiletextBox.Focus();
                    }
                    else if (csvFileSourceFolderTextbox.Text == "")
                    {
                        MessageBox.Show("Select source folder to upload files", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        csvFileSourceFolderTextbox.Focus();
                    }
                }
                else if (uploadTypeComboBox.SelectedItem == "Upload based on Filename")
                {
                    if (uploadBasedOnFilenameTextBox.Text != "")
                    {

                        progressBar1.Visible = true;
                        //Check whether atleast one file exists in the selected path
                        if (dmsBusinessObject.CheckForFiles(uploadBasedOnFilenameTextBox.Text))
                        {
                            List<CCSVInfo> exceptionFileInfoListObject = new List<CCSVInfo>();

                            exceptionFileInfoListObject = dmsBusinessObject.UploadBasedOnFileName(uploadBasedOnFilenameTextBox.Text, ref progressBar1,ref folderProgressLabel, ref filesProgressLabel);

                            if (exceptionFileInfoListObject.Count <= 0)
                                MessageBox.Show("Files Uploaded Successfully", "File Upload", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            else if (exceptionFileInfoListObject.Count > 0)
                            {
                                CExceptionFile exceptionWriteObject = new CExceptionFile();
                                //Write the exception in the CSV file
                                csvExceptionFile = exceptionWriteObject.WriteExceptionInExcel(exceptionFileInfoListObject);

                                progressBar1.Step = 100;
                                progressBar1.PerformStep();

                                MessageBox.Show("Some of the records are not processed", "File Upload", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                //Open the CSV
                                var rk = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\excel.exe");
                                if (rk != null)
                                {
                                    Microsoft.Office.Interop.Excel.Application _app = new Microsoft.Office.Interop.Excel.Application();
                                    Microsoft.Office.Interop.Excel.Workbooks _workbooks = _app.Workbooks;
                                    _workbooks.OpenText(csvExceptionFile);
                                    _app.Visible = true;
                                }
                                else
                                {
                                    System.Diagnostics.Process.Start(csvExceptionFile);
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("No files available under hte selected folder", "Validation Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Select source folder to upload files", "Validation Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        uploadBasedOnFilenameTextBox.Focus();
                    }
                }
                else if (uploadTypeComboBox.SelectedItem == "Upload based on ClientCode")
                {
                    if (clientCodeFolderTextBox.Text != "")
                    {
                        progressBar1.Visible = true;
                        //Check whether atleast one sub folder is avaialble under the selected folder
                        if (dmsBusinessObject.CheckForSubFolder(clientCodeFolderTextBox.Text))
                        {
                            //Check atleast one file available to start processing
                            if (dmsBusinessObject.CheckForFiles(clientCodeFolderTextBox.Text))
                            {
                                progressBar1.Step = 1;
                                progressBar1.PerformStep();

                                List<CCSVInfo> exceptionFileInfoListObject = new List<CCSVInfo>();
                                exceptionFileInfoListObject = dmsBusinessObject.UploadBasedOnClientCode(clientCodeFolderTextBox.Text,ref progressBar1, ref folderProgressLabel, ref filesProgressLabel);

                                if (exceptionFileInfoListObject.Count <= 0)
                                    MessageBox.Show("Files Uploaded Successfully", "File Upload", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                else if (exceptionFileInfoListObject.Count > 0)
                                {
                                    CExceptionFile exceptionWriteObject = new CExceptionFile();
                                    //Write the exception in the CSV file
                                    csvExceptionFile = exceptionWriteObject.WriteExceptionInExcel(exceptionFileInfoListObject);

                                    progressBar1.Step = 100;
                                    progressBar1.PerformStep();

                                    MessageBox.Show("Some of the records are not processed", "File Upload", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    var rk = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\excel.exe");
                                    if (rk != null)
                                    {
                                        Microsoft.Office.Interop.Excel.Application _app = new Microsoft.Office.Interop.Excel.Application();
                                        Microsoft.Office.Interop.Excel.Workbooks _workbooks = _app.Workbooks;
                                        _workbooks.OpenText(csvExceptionFile);
                                        _app.Visible = true;
                                    }
                                    else
                                    {
                                        System.Diagnostics.Process.Start(csvExceptionFile);
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show("No files available under the selected folder", "Validation Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                        else
                        {
                            MessageBox.Show("No sub folders available under the selected folder", "Validation Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Select Client Code Folder to upload CSV files", "File Upload", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        clientCodeFolderTextBox.Focus();
                    }
                }
                else if (uploadTypeComboBox.SelectedItem == "Upload Individual File")
                {
                    
                    string documentType;

                    if (documentTypeComboBox.SelectedIndex > -1)
                        documentType = ((System.Data.DataRowView)(documentTypeComboBox.SelectedItem)).Row.ItemArray[0].ToString();
                    else
                        documentType = documentTypeComboBox.Text;

                    if (clientCodeTextBox.Text != "" && documentType != "" && securityCodeTextBox.Text != "" && fileTextBox.Text != "")
                    {
                        progressBar1.Visible = true;
                        progressBar1.Step = 10;
                        progressBar1.PerformStep();
                        System.Windows.Forms.Application.DoEvents();
                        filesProgressLabel.Text = "Uploading File";
                        System.Windows.Forms.Application.DoEvents();

                        CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Total Files : 1", "");

                        progressBar1.Step = 30;
                        progressBar1.PerformStep();

                        List<CCSVInfo> exceptionFileInfoListObject = new List<CCSVInfo>();
                        exceptionFileInfoListObject = dmsBusinessObject.UploadIndividualFile(clientCodeTextBox.Text, documentType, securityCodeTextBox.Text, dateTimePicker.Value.ToString("ddMMMyyyy").ToUpper(), fileTextBox.Text);

                        if (exceptionFileInfoListObject != null)
                        {
                            if (exceptionFileInfoListObject.Count > 0)
                            {
                                CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Processed Count : 0", "");
                                CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Un Processed Count : 1", "");

                                CExceptionFile exceptionWriteObject = new CExceptionFile();
                                //Write the exception in the CSV file
                                csvExceptionFile = exceptionWriteObject.WriteExceptionInExcel(exceptionFileInfoListObject);

                                progressBar1.Step = 100;
                                progressBar1.PerformStep();

                                MessageBox.Show("File not processed", "File Upload", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                var rk = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\excel.exe");
                                if (rk != null)
                                {
                                    Microsoft.Office.Interop.Excel.Application _app = new Microsoft.Office.Interop.Excel.Application();
                                    Microsoft.Office.Interop.Excel.Workbooks _workbooks = _app.Workbooks;
                                    _workbooks.OpenText(csvExceptionFile);
                                    _app.Visible = true;
                                }
                                else
                                {
                                    System.Diagnostics.Process.Start(csvExceptionFile);
                                }
                            }
                            else
                            {
                                CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Processed Count : 1", "");
                                CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Un Processed Count : 0", "");

                                progressBar1.Step = 100;
                                progressBar1.PerformStep();
                                System.Windows.Forms.Application.DoEvents();
                                filesProgressLabel.Text = "File Uploaded";
                                System.Windows.Forms.Application.DoEvents();
                                MessageBox.Show("File uploaded successfully", "File Upload", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                        
                    }
                    else if (clientCodeTextBox.Text == "")
                    {
                        MessageBox.Show("Enter Client Code", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        clientCodeTextBox.Focus();
                    }
                    else if (documentType == "")
                    {
                        MessageBox.Show("Enter/Select Doc Type", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        documentTypeComboBox.Focus();
                    }
                    else if (securityCodeTextBox.Text == "")
                    {
                        MessageBox.Show("Enter Security Code", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        securityCodeTextBox.Focus();
                    }
                    else if (fileTextBox.Text == "")
                    {
                        MessageBox.Show("Select file to upload", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        fileTextBox.Focus();
                    }
                    
                }
                CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Ended at : " + DateTime.Now, "");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                CLogHelper.Instance.LogErrorInfo(ex, "FileUpload.uploadButton_Click" + DateTime.Now);
            }
            finally
            {
                if (dmsBusinessObject != null)
                    dmsBusinessObject = null;
            }
        }

        /// <summary>
        /// Method to show and hide the corresponding group boxes based on the upload type
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uploadTypeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (uploadTypeComboBox.SelectedIndex != -1)
                {
                    if (uploadTypeComboBox.SelectedItem == "Upload to FTP")
                    {
                        uploadToFTPGroupBox.Visible = true;
                        uploadBasedOnCSVGroupBox.Visible = false;
                        uploadBasedOnFilenameGroupBox.Visible = false;
                        uploadBasedOnClientCodeGroupBox.Visible = false;
                        uploadBasedOnIndividualFileGroupBox.Visible = false;

                        uploadButton.Visible = true;
                        cancelButton.Visible = true;
                        progressBar1.Visible = false;

                        //Clear the controls
                        sourceFolderTextBox.Clear();
                        FTPFolderTextBox.Clear();

                        progressBar1.Minimum = 0;
                        progressBar1.Maximum = 100;
                        folderProgressLabel.Text = "";
                        filesProgressLabel.Text = "";
                        progressBar1.Value = 0;

                        //Display the FTP folder path from config
                        FTPFolderTextBox.Text = ConfigurationManager.AppSettings.Get("FTPFolderPath");
                    }
                    else if (uploadTypeComboBox.SelectedItem == "Upload based on CSV")
                    {
                        uploadToFTPGroupBox.Visible = false;
                        uploadBasedOnFilenameGroupBox.Visible = false;
                        uploadBasedOnClientCodeGroupBox.Visible = false;
                        uploadBasedOnCSVGroupBox.Visible = true;
                        uploadBasedOnIndividualFileGroupBox.Visible = false;

                        selectCSVFiletextBox.Clear();
                        csvFileSourceFolderTextbox.Clear();

                        progressBar1.Minimum = 0;
                        progressBar1.Maximum = 100;
                        folderProgressLabel.Text = "";
                        filesProgressLabel.Text = "";
                        progressBar1.Value = 0;

                        uploadButton.Visible = true;
                        cancelButton.Visible = true;
                        progressBar1.Visible = false;
                    }
                    else if (uploadTypeComboBox.SelectedItem == "Upload based on Filename")
                    {
                        uploadToFTPGroupBox.Visible = false;
                        uploadBasedOnCSVGroupBox.Visible = false;
                        uploadBasedOnClientCodeGroupBox.Visible = false;
                        uploadBasedOnFilenameGroupBox.Visible = true;
                        uploadBasedOnIndividualFileGroupBox.Visible = false;

                        //Clear the control
                        uploadBasedOnFilenameTextBox.Clear();

                        progressBar1.Minimum = 0;
                        progressBar1.Maximum = 100;
                        folderProgressLabel.Text = "";
                        filesProgressLabel.Text = "";
                        progressBar1.Value = 0;

                        uploadButton.Visible = true;
                        cancelButton.Visible = true;
                        progressBar1.Visible = false;
                    }
                    else if (uploadTypeComboBox.SelectedItem == "Upload based on ClientCode")
                    {
                        uploadToFTPGroupBox.Visible = false;
                        uploadBasedOnCSVGroupBox.Visible = false;
                        uploadBasedOnFilenameGroupBox.Visible = false;
                        uploadBasedOnClientCodeGroupBox.Visible = true;
                        uploadBasedOnIndividualFileGroupBox.Visible = false;

                        //Clear the control
                        clientCodeFolderTextBox.Clear();

                        progressBar1.Minimum = 0;
                        progressBar1.Maximum = 100;
                        folderProgressLabel.Text = "";
                        filesProgressLabel.Text = "";
                        progressBar1.Value = 0;

                        uploadButton.Visible = true;
                        cancelButton.Visible = true;
                        progressBar1.Visible = false;
                    }
                    else if (uploadTypeComboBox.SelectedItem == "Upload Individual File")
                    {
                        uploadBasedOnIndividualFileGroupBox.Visible = true;
                        uploadToFTPGroupBox.Visible = false;
                        uploadBasedOnCSVGroupBox.Visible = false;
                        uploadBasedOnClientCodeGroupBox.Visible = false;

                        progressBar1.Minimum = 0;
                        progressBar1.Maximum = 100;
                        folderProgressLabel.Text = "";
                        filesProgressLabel.Text = "";
                        progressBar1.Value = 0;

                        //Clear the control
                        clientCodeTextBox.Clear();
                        //documentTypeComboBox.SelectedIndex = -1;
                        securityCodeTextBox.Clear();
                        dateTimePicker.Value = DateTime.Now;
                        fileTextBox.Clear();

                        uploadButton.Visible = true;
                        cancelButton.Visible = true;
                        progressBar1.Visible = false;
                        //Populate the document type combo box
                        BindDocumentType();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                CLogHelper.Instance.LogErrorInfo(ex, "FileUpload.uploadTypeComboBox_SelectedIndexChanged" + DateTime.Now);
            }
        }

        /// <summary>
        /// Function to set the properties of File Open Dialog control
        /// </summary>
        /// <returns>object</returns>
        private object SetFileOpenDialogProperties(string fileType)
        {
            var _with1 = openFileDialog1;
            if (fileType == "csv")
            {
                _with1.Title = "Select CSV File";
                _with1.Filter = "Comma Separated Files(.csv)|*.csv";
                _with1.FileName = "*.csv";
            }
            else
            {
                _with1.Title = "Select PDF File";
                _with1.Filter = "PDF Files(.pdf)|*.pdf";
                _with1.FileName = "*.pdf";
            }
            return openFileDialog1.ShowDialog();
        }

        /// <summary>
        /// Function to set the properties of Folder Open Dialog control
        /// </summary>
        /// <returns></returns>
        private object SetFolderOpenDialogProperties()
        {
            var _with = folderBrowserDialog1;
            return folderBrowserDialog1.ShowDialog();
        }

        /// <summary>
        /// Method to list the directories/Files
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void sourceFolderBrowseButton_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(SetFolderOpenDialogProperties()) == 1)            
                sourceFolderTextBox.Text = folderBrowserDialog1.SelectedPath;
        }

        private void uploadBasedOnFileNameBrowseButton_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(SetFolderOpenDialogProperties()) == 1)
                uploadBasedOnFilenameTextBox.Text = folderBrowserDialog1.SelectedPath;
        }

        private void browseIndividualFileButton_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(SetFileOpenDialogProperties("pdf")) == 1)
                fileTextBox.Text = openFileDialog1.FileName;
        }

        private void browseCSVFileButton_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(SetFileOpenDialogProperties("csv")) == 1)
                selectCSVFiletextBox.Text = openFileDialog1.FileName;
        }

        private void uploadCSVSourceFolderBrowseButton_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(SetFolderOpenDialogProperties()) == 1)
                csvFileSourceFolderTextbox.Text = folderBrowserDialog1.SelectedPath;
        }

        private void clientCodeFolderBrowsebutton_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(SetFolderOpenDialogProperties()) == 1)
                clientCodeFolderTextBox.Text = folderBrowserDialog1.SelectedPath;
        }

        /// <summary>
        /// Function to bind the document type to the combo box control
        /// </summary>
        private void BindDocumentType()
        {
            DMSBusiness dmsBusinessObject = null;
            try
            {
                dmsBusinessObject = new DMSBusiness();
                documentTypeComboBox.DataSource = dmsBusinessObject.GetDocumentTypes();
                documentTypeComboBox.DisplayMember = "DocType";
                documentTypeComboBox.ValueMember = "DocType";
                documentTypeComboBox.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dmsBusinessObject != null)
                    dmsBusinessObject = null;
            }
        }

        //private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        //{
        //    for (int i = 1; i <= 100; i++)
        //    {
        //        // Wait 100 milliseconds.
        //        //Thread.Sleep(100);
        //        // Report progress.
        //        backgroundWorker1.ReportProgress(i);
        //    }
        //}

    }
}

