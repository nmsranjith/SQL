﻿/*
Name                : DMSBusiness.cs
Author              : Suchithra Baskaran
Purpose             : Business logic layer for renaming and uploading the files
Date Created        : 17 Aug 2012
Revision History    :
Modified by         :
Date Modified       :
*/

using DMSDatabaseLayer;
using DMSCommon;
using DMSCommon.Common;
using DMSCommon.DAO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.Configuration;
using System.Net;
using Microsoft.VisualBasic;
using System.Windows.Forms;

namespace DMSBusinessLayer
{
    public class DMSBusiness
    {
        #region "Variable Declaration"

        DMSDatabase dmsDatabaseObject;
        string fileSize;
        CCSVInfo exceptionInfoObject;
        List<CCSVInfo> exceptionInfoListObject;

        #endregion

        #region "Public Methods"

        /// <summary>
        /// Function to return the Document Types
        /// </summary>
        /// <returns>Datatable</returns>
        public DataTable GetDocumentTypes()
        {
            try
            {
                dmsDatabaseObject = new DMSDatabase();
                return dmsDatabaseObject.GetDocumentTypes();
            }
            catch (Exception ex)
            {
                CLogHelper.Instance.LogErrorInfo(ex, "DMSBusiness.GetDocumentTypes" + DateTime.Now);
                throw ex;
            }
            finally
            {
                if (dmsDatabaseObject != null)
                    dmsDatabaseObject = null;
            }
        }

        /// <summary>
        /// Function to upload the individual file
        /// </summary>
        /// <param name="v_ClientCode"></param>
        /// <param name="v_DocumentType"></param>
        /// <param name="v_SecurityCode"></param>
        /// <param name="v_dateTime"></param>
        /// <param name="v_FilePath"></param>
        //public bool UploadIndividualFile(string v_ClientCode, string v_DocumentType, string v_SecurityCode, string v_dateTime, string v_FilePath)
        public List<CCSVInfo> UploadIndividualFile(string v_ClientCode, string v_DocumentType, string v_SecurityCode, string v_dateTime, string v_FilePath)
        {
            try
            {
                exceptionInfoListObject = new List<CCSVInfo>();
                dmsDatabaseObject = new DMSDatabase();
                //Frame the file name
                string fileName = FrameFileName(v_ClientCode, v_DocumentType, v_SecurityCode, v_dateTime, v_FilePath.Split('.')[1]);
                //Frame the destination path where file needs to move
                string destinationPath = FrameDestinationPath(v_DocumentType, v_SecurityCode, v_dateTime, fileName);
                //Rename and move the file to the destination path
                RenameAndUploadFile(v_FilePath, destinationPath);

                //Insert the record in the DB
                string filePath = v_DocumentType + "\\" + v_SecurityCode + "\\" + v_dateTime + "\\";

                //return dmsDatabaseObject.InsertIndividualFile(fileName, filePath, fileSize, v_ClientCode, v_DocumentType, v_SecurityCode, Convert.ToDateTime(v_dateTime));
                dmsDatabaseObject.InsertIndividualFile(fileName, filePath, fileSize, v_ClientCode, v_DocumentType, v_SecurityCode, Convert.ToDateTime(v_dateTime),ref exceptionInfoListObject);
                return exceptionInfoListObject;
            }
            catch (Exception ex)
            {
                CLogHelper.Instance.LogErrorInfo(ex, "DMSBusiness.UploadIndividualFile" + DateTime.Now);
                throw ex;
            }
            finally
            {
                if (dmsDatabaseObject != null)
                dmsDatabaseObject = null;
            }
        }

        /// <summary>
        /// Rename and upload the files under the selected folder
        /// </summary>
        /// <param name="clientCode"></param>
        /// <returns>string</returns>
        //public string UploadBasedOnClientCode(string clientCode)
        public List<CCSVInfo> UploadBasedOnClientCode(string clientCode,ref System.Windows.Forms.ProgressBar progressBar1, ref System.Windows.Forms.Label folderProgressLabel, ref System.Windows.Forms.Label fileProgressLabel)
        {
            CFileInfo fileInformationDAOObejct;
            List<CFileInfo> fileInformationListObject;
            CExceptionFile exceptionFile;
            int filesCount = 1;
            bool isInserted = false;
            string result = "";
            int folderCount = 0;
            int totalFolderCount = 0;
            int totalFilesCount = 0;
            bool isValidDate = false;
            bool isValidFile = false;
            try
            {
                //CLearing the previous upload counts
                totalNumberOfFiles = 0;
                numberOfProcessedFiles = 0;
                numberOfUnprocessedFiles = 0;

                exceptionInfoListObject  = new List<CCSVInfo>();
                fileInformationListObject = new List<CFileInfo>();
                DirectoryInfo clientCodeDirectory = new DirectoryInfo(clientCode);
                DirectoryInfo[] clientCodeSubDirectories = clientCodeDirectory.GetDirectories();
                dmsDatabaseObject = new DMSDatabase();
                string fileName,destinationPath;

                if (clientCodeSubDirectories.Length > 0) //IF condition for parent directory sub directories
                {
                    progressBar1.Step = 1;
                    totalFolderCount = clientCodeSubDirectories.Length;
                    //Iterating the sub directories
                    foreach (DirectoryInfo subDirectoryInfo in clientCodeSubDirectories)
                    {
                        folderCount += 1;
                        filesCount = 1;

                        totalNumberOfFiles += subDirectoryInfo.GetFiles().Length;

                        //folderProgressLabel.Text = "Folder " + folderCount + " out of " + totalFolderCount;

                        //Before getting the files, check whether the sub directory name is in proper format
                        if (subDirectoryInfo.Name.Split('-').Length == 3)
                        {
                            isValidFile = true;
                            isValidDate = true;
                            try { Convert.ToDateTime(subDirectoryInfo.Name.Split('-')[2]); }
                            catch { isValidDate = false; }
                        }
                        if(isValidFile && isValidDate)
                        {

                            //Fetching and iterating the files in the sub directories
                            if (subDirectoryInfo.GetFiles().Length > 0)
                            {
                                foreach (FileInfo fileInfo in subDirectoryInfo.GetFiles())
                                {
                                    //totalFilesCount  = subDirectoryInfo.GetFiles().Length;                                    
                                    //fileProgressLabel.Text = "Files " + filesCount + " out of " + totalFilesCount;
                                    //Processed files count
                                    numberOfProcessedFiles += 1;
                                    progressBar1.PerformStep();
                                    Application.DoEvents();
                                    fileProgressLabel.Text = "Files Uploded : " + numberOfProcessedFiles + " out of " + totalNumberOfFiles;
                                    Application.DoEvents();

                                    //If there are more than one files, appned the files count
                                    if (filesCount > 1)
                                    {
                                        //Frame the file name
                                        fileName = clientCodeDirectory.Name + "-" + subDirectoryInfo.Name + '_' + filesCount + fileInfo.Extension;
                                        //Frame the destination path
                                        destinationPath = FrameDestinationPath(subDirectoryInfo.Name.Split('-')[0], subDirectoryInfo.Name.Split('-')[1], subDirectoryInfo.Name.Split('-')[2], fileName);
                                    }
                                    else
                                    {
                                        //Frame the file name
                                        fileName = clientCodeDirectory.Name + "-" + subDirectoryInfo.Name + fileInfo.Extension;
                                        //Frame the destination path
                                        destinationPath = FrameDestinationPath(subDirectoryInfo.Name.Split('-')[0], subDirectoryInfo.Name.Split('-')[1], subDirectoryInfo.Name.Split('-')[2], fileName);
                                    }

                                    filesCount += 1;
                                    //Move and rename the file to destination path
                                    RenameAndUploadFile(fileInfo.FullName, destinationPath);

                                    //After moving the file, make a note of moved files in DAO so that update the details in DB
                                    fileInformationDAOObejct = new CFileInfo();
                                    fileInformationDAOObejct.FileName = fileName;
                                    fileInformationDAOObejct.ClientCode = clientCodeDirectory.Name;
                                    fileInformationDAOObejct.DocType = subDirectoryInfo.Name.Split('-')[0];
                                    fileInformationDAOObejct.Institute = subDirectoryInfo.Name.Split('-')[1];
                                    fileInformationDAOObejct.PaymentDate = subDirectoryInfo.Name.Split('-')[2];
                                    //fileInformationDAOObejct.FilePath = subDirectoryInfo. .Name;
                                    fileInformationDAOObejct.FilePath = fileInformationDAOObejct.DocType + "\\" + fileInformationDAOObejct.Institute + "\\" + fileInformationDAOObejct.PaymentDate + "\\";
                                    fileInformationDAOObejct.FileSize = fileSize;
                                    fileInformationDAOObejct.UploadedDateTime = DateTime.Now;

                                    //Add the DAO objec to List collection
                                    fileInformationListObject.Add(fileInformationDAOObejct);
                                    fileInformationDAOObejct = null;
                                }
                                subDirectoryInfo.Delete();
                            }
                        }
                        else
                        {
                            //Unprocessed files count, since the folder name is not in the proper format, all the files unde this folder would be unprocessed
                            numberOfUnprocessedFiles += subDirectoryInfo.GetFiles().Length;

                            exceptionInfoObject = new CCSVInfo();
                            exceptionInfoObject.ParentFolderName = subDirectoryInfo.Name;
                            if (!isValidFile)
                                exceptionInfoObject.Reason = "Directory name is not in proper format";
                            else
                                exceptionInfoObject.Reason = "Date is not in proper format";
                            exceptionInfoListObject.Add(exceptionInfoObject);
                            exceptionInfoObject = null;
                        }
                    }

                    totalNumberOfFiles = numberOfUnprocessedFiles + numberOfProcessedFiles;

                    CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Total File : " + totalNumberOfFiles, "");
                    CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Processed Count : " + numberOfProcessedFiles, "");
                    CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "UnProcessed Count : " + numberOfUnprocessedFiles,"");

                    //Update in DB by bulk insertion (Refer DMSFileWatcher for bulk insertion)
                    //isInserted = dmsDatabaseObject.InsertFileInformationBulkly(fileInformationListObject);
                    isInserted = dmsDatabaseObject.InsertFileInformationBulkly(fileInformationListObject,ref exceptionInfoListObject);

                    CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Processed files based on Client Code", "Inserted Successfully" + DateTime.Now);

                }
                return exceptionInfoListObject;
            }
            catch (Exception ex)
            {
                CLogHelper.Instance.LogErrorInfo(ex, "DMSBusiness.UploadBasedOnClientCode" + DateTime.Now);
                throw ex;
            }
            finally
            {
                    fileInformationListObject = null;
                    fileInformationDAOObejct = null;
                if (exceptionInfoObject != null)
                    exceptionInfoObject = null;
                if (exceptionInfoListObject != null)
                    exceptionInfoListObject = null;
            }
        }

        #region "Global Variables for Upload based on CSV option"

        List<CFileInfo> fileInformationListObject = new List<CFileInfo>();
        CFileInfo fileInformationDAOObejct = new CFileInfo();
        List<CCSVInfo> inActiveCSVInfoListObject;
        int totalNumberOfFiles = 0;
        int numberOfProcessedFiles = 0;
        int numberOfUnprocessedFiles = 0;
        #endregion

        /// <summary>
        /// Function to Upload the files under the passed directory
        /// </summary>
        /// <param name="sourceFolder"></param>
        /// <returns></returns>
        public List<CCSVInfo> UploadBasedOnFileName(string sourceFolder, ref System.Windows.Forms.ProgressBar progressBar1, ref System.Windows.Forms.Label folderProgressLabel, ref System.Windows.Forms.Label filesProgressLabel)
        {
            bool isInserted = false;
            string result = string.Empty;
            CExceptionFile exceptionFileObject;

            //CLearing the previous upload counts
            totalNumberOfFiles = 0;
            numberOfProcessedFiles = 0;
            numberOfUnprocessedFiles = 0;

            try
            {
                dmsDatabaseObject = new DMSDatabase();
                exceptionInfoObject = new CCSVInfo();
                exceptionInfoListObject = new List<CCSVInfo>();
                exceptionFileObject = new CExceptionFile();

                //Iterate the directory and upload the files to destination
                IterateDirectories(sourceFolder, ref progressBar1, ref folderProgressLabel, ref  filesProgressLabel);

                CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Total File : " + totalNumberOfFiles, "");
                CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Processed Count : " + numberOfProcessedFiles, "");
                CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Un processed Count : " + numberOfUnprocessedFiles, "");

                //Update in DB by bulk insertion
                //isInserted = dmsDatabaseObject.InsertFileInformationBulkly(fileInformationListObject);
                isInserted = dmsDatabaseObject.InsertFileInformationBulkly(fileInformationListObject,ref exceptionInfoListObject);


                if (exceptionInfoListObject.Count > 0)
                    exceptionFileObject.WriteExceptionInExcel(exceptionInfoListObject);

                return exceptionInfoListObject;
            }
            catch (Exception ex)
            {
                CLogHelper.Instance.LogErrorInfo(ex, "DMSBusiness.UploadBasedOnFileName" + DateTime.Now);
                throw ex;
            }
            finally
            {
                if (fileInformationDAOObejct  != null)
                    fileInformationDAOObejct = null;
                if (fileInformationListObject  != null)
                    fileInformationListObject = null;
                if (exceptionInfoObject != null)
                    exceptionInfoObject = null;
                if(exceptionInfoListObject != null)
                    exceptionInfoListObject = null;
            }
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceFolderPath"></param>
        /// <param name="csvFilePath"></param>
        /// <returns></returns>
        public List<CCSVInfo> UploadBasedOnCSV(string sourceFolderPath, string csvFilePath, ref System.Windows.Forms.ProgressBar progressBar1, ref System.Windows.Forms.Label filesProgressLabel)
        {
            CExceptionFile exceptionFile;
            exceptionInfoListObject = new List<CCSVInfo>();
            int totalFilesCount = 0;
            try
            {
                progressBar1.Step = 1;
                progressBar1.PerformStep();
                
                filesProgressLabel.Text = "Uploading Files";
                //Application.DoEvents();

                exceptionFile = new CExceptionFile();
                //Load the csv file and insert those information into the database
                LoadCSVFile(csvFilePath);

                progressBar1.Step = 1;
                progressBar1.PerformStep();

                //Load only the active file information and process those files repository
                List<CCSVInfo> activeCSVInfoListObject = new List<CCSVInfo>();
                
                //Fetch the active records
                activeCSVInfoListObject = CVSInfoList.Where(p => p.ClientCode != "" && p.FileName != "").ToList<CCSVInfo>();

                //Fetch inactive records
                inActiveCSVInfoListObject = new List<CCSVInfo>();
                inActiveCSVInfoListObject = CVSInfoList.Where(p => p.ClientCode == "" || p.FileName == "").ToList<CCSVInfo>();

                totalFilesCount = CVSInfoList.Count;

                progressBar1.PerformStep();

                CVSInfoList = activeCSVInfoListObject;

                CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Total File : " + totalFilesCount, "");

                LoadAndMoveScannedFiles(true, sourceFolderPath, ref progressBar1, ref filesProgressLabel, totalFilesCount);

                return inActiveCSVInfoListObject;
            }
            catch (Exception ex)
            {
                CLogHelper.Instance.LogErrorInfo(ex, "DMSBusiness.UploadBasedOnCSV" + DateTime.Now);
                throw ex;
            }
        }

        /// <summary>
        /// Method to move directory/files
        /// </summary>
        /// <param name="v_sourcePath"></param>
        /// <param name="v_ftpPath"></param>
        public void CopyFilesToFTP(string v_sourcePath, string v_ftpPath)
        {
            DirectoryInfo destinationDirectory = null;
            Microsoft.VisualBasic.Devices.Computer visualBasicObject = null;
            try
            {
                destinationDirectory = new DirectoryInfo(v_ftpPath + v_sourcePath.Substring(v_sourcePath.LastIndexOf("\\")+1));
                if (destinationDirectory.Exists)
                    destinationDirectory.Delete(true);

                //Moves the entire directory from specified source path to destination path
                visualBasicObject = new Microsoft.VisualBasic.Devices.Computer();
                visualBasicObject.FileSystem.MoveDirectory(v_sourcePath, v_ftpPath + v_sourcePath.Substring(v_sourcePath.LastIndexOf("\\")+1));
            }
            catch (Exception ex)
            {
                CLogHelper.Instance.LogErrorInfo(ex, "DMSBusiness.CopyFilesToFTP" + DateTime.Now);
                throw ex;
            }
            finally
            {
                if (visualBasicObject != null)
                    visualBasicObject = null;
                if (destinationDirectory != null)
                    destinationDirectory = null;
            }
        }

        /// <summary>
        /// Function to check whether sub folder existed under the passed path
        /// </summary>
        /// <param name="v_SourceFolderPath"></param>
        /// <returns></returns>
        public bool CheckForSubFolder(string v_SourceFolderPath)
        {
            DirectoryInfo sourceDirectoryInfoObject = null;
            bool hasSubFolders = false;
            try
            {
                sourceDirectoryInfoObject = new DirectoryInfo(v_SourceFolderPath);
                if (sourceDirectoryInfoObject.GetDirectories().Length > 0)
                    hasSubFolders = true;
                else
                    hasSubFolders = false;

                return hasSubFolders;
            }
            catch (Exception ex)
            {
                CLogHelper.Instance.LogErrorInfo(ex, "DMSBusiness.CheckForSubFolder" + DateTime.Now);
                throw ex;
            }
            finally
            {
                if (sourceDirectoryInfoObject != null)
                    sourceDirectoryInfoObject = null;
            }
        }

        /// <summary>
        /// Function to check whether atleast one file exists in the directory 
        /// </summary>
        /// <param name="v_SourceFolderPath"></param>
        /// <returns></returns>
        public bool CheckForFiles(string v_SourceFolderPath)
        {
            DirectoryInfo sourceDirectoryInfoObject = null;
            bool hasSubFolders = false;
            try
            {
                sourceDirectoryInfoObject = new DirectoryInfo(v_SourceFolderPath);
                if (sourceDirectoryInfoObject.GetDirectories().Length > 0 || sourceDirectoryInfoObject.GetDirectories().Length > 0)
                {
                    foreach (DirectoryInfo di in sourceDirectoryInfoObject.GetDirectories())
                    {
                        if (di.GetFiles().Length > 0)
                        {
                            hasSubFolders = true;
                            break;
                        }
                    }
                }
                if (sourceDirectoryInfoObject.GetFiles().Length > 0)
                {
                    hasSubFolders = true;
                }

                return hasSubFolders;
            }
            catch (Exception ex)
            {
                CLogHelper.Instance.LogErrorInfo(ex, "DMSBusiness.CheckForFiles" + DateTime.Now);
                throw ex;
            }
            finally
            {
            }
        }

        #endregion

        #region "Private Methods"

        /// <summary>
        /// Function to frame the destination path with the parameters supplied
        /// </summary>
        /// <param name="v_DocumentType"></param>
        /// <param name="v_SecurityCode"></param>
        /// <param name="v_Date"></param>
        /// <param name="v_FileName"></param>
        /// <returns></returns>
        private string FrameDestinationPath(string v_DocumentType, string v_SecurityCode, string v_Date, string v_FileName)
        {
            //Get the repository path
            string repositoryPath = ConfigurationManager.AppSettings.Get("FileUploadedPath");

            // A folder with CON cannot be created in windows OS so to overcome change it to CONT
            if (v_DocumentType == "CON") v_DocumentType = "CONT";
            if (v_SecurityCode == "CON") v_SecurityCode = "CONT";

            string destinationPath = repositoryPath + "\\" + v_DocumentType + "\\" + v_SecurityCode + "\\" + v_Date + "\\" + v_FileName;

            return destinationPath;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="v_ClientCode"></param>
        /// <param name="v_DocumentType"></param>
        /// <param name="v_SecurityCode"></param>
        /// <param name="v_dateTime"></param>
        /// <param name="v_FileExtension"></param>
        /// <returns></returns>
        private string FrameFileName(string v_ClientCode, string v_DocumentType, string v_SecurityCode, string v_dateTime, string v_FileExtension)
        {
            return v_ClientCode + "-" + v_DocumentType + "-" + v_SecurityCode + "-" + v_dateTime + "." + v_FileExtension;
        }

        /// <summary>
        /// Method to rename and uplaod the file specified in the source path to destination path
        /// </summary>
        /// <param name="v_SourceFilePath"></param>
        /// <param name="v_DestinationFilePath"></param>
        private void RenameAndUploadFile(string v_SourceFilePath, string v_DestinationFilePath)
        {
            //Rename and moving the file
            FileInfo fileInfo = new FileInfo(v_SourceFilePath); //Give the source path 
            {
                //Check for destination path exists, if not create it
                if (!File.Exists(v_DestinationFilePath.Substring(0, v_DestinationFilePath.LastIndexOf("\\") + 1)))
                    Directory.CreateDirectory(v_DestinationFilePath.Substring(0, v_DestinationFilePath.LastIndexOf("\\") + 1));

                //Check whether the file already exists in the destination path, if so delete the existing file
                if (File.Exists(v_DestinationFilePath))
                    File.Delete(v_DestinationFilePath);

                //Move and Rename the file from source to the destination path whereas destination path includes the File Name also 
                fileInfo.MoveTo(v_DestinationFilePath);
                fileSize = Convert.ToString(Math.Round(Convert.ToDouble(fileInfo.Length) / 1024, 0, MidpointRounding.AwayFromZero)) + "KB";
            }
        }

        /// <summary>
        /// Method to iterate the child directories for the passed directory
        /// </summary>
        /// <param name="directoryPath"></param>
        //private void IterateDirectories(string directoryPath)
        private void IterateDirectories(string directoryPath, ref System.Windows.Forms.ProgressBar progressBar1, ref System.Windows.Forms.Label folderProgressLabel, ref System.Windows.Forms.Label filesProgressLabel)
        {
            int directoryCount = 0;
            int totalDirectoryCount = 0;
            try
            {
                DirectoryInfo sourceFolderDirectoryInfo = new DirectoryInfo(directoryPath);
                if (sourceFolderDirectoryInfo.GetDirectories().Length > 0)
                {
                    totalDirectoryCount = sourceFolderDirectoryInfo.GetDirectories().Length;
                    IterateFilesAndAddFileInformationToList(sourceFolderDirectoryInfo, ref progressBar1, ref filesProgressLabel);
                    foreach (DirectoryInfo di in sourceFolderDirectoryInfo.GetDirectories())
                    {
                        directoryCount += 1;
                        progressBar1.PerformStep();
                        //folderProgressLabel.Text = "Folder " + directoryCount + "out of " + totalDirectoryCount;

                        IterateFilesAndAddFileInformationToList(di, ref progressBar1, ref filesProgressLabel);
                        IterateDirectories(di.FullName, ref progressBar1, ref folderProgressLabel, ref filesProgressLabel);
                        di.Delete();

                    }
                }
                else
                {
                    IterateFilesAndAddFileInformationToList(sourceFolderDirectoryInfo, ref progressBar1, ref filesProgressLabel);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Method to iterate the files for the passed directory
        /// </summary>
        /// <param name="di"></param>
        //private void IterateFilesAndAddFileInformationToList(DirectoryInfo di)
        private void IterateFilesAndAddFileInformationToList(DirectoryInfo di, ref System.Windows.Forms.ProgressBar progressBar1, ref System.Windows.Forms.Label filesProgressLabel)
        {
            int filesCount = 0;
            int totalFilesCount = 0;
            bool isValidFile = false;
            bool isValidDate = false;
            try
            {
                foreach (FileInfo fileInfo in di.GetFiles())
                {
                    isValidFile = false;
                    isValidDate = false;
                    //Total number of files count
                    totalNumberOfFiles += 1;

                    totalFilesCount = di.GetFiles().Length;

                    if (fileInfo.Name.Split('-').Length == 4)
                    {
                        isValidFile = true;
                        isValidDate = true;

                            try { Convert.ToDateTime(fileInfo.Name.Split('-')[3].Split('.')[0]); }
                            catch { isValidDate = false; }
                    }
                    if (isValidFile && isValidDate)
                    {
                        //Check the date format

                        //Processed file count
                        numberOfProcessedFiles += 1;

                        //Frame the destination path
                        string destinationPath = FrameDestinationPath(fileInfo.Name.Split('-')[1], fileInfo.Name.Split('-')[2], fileInfo.Name.Split('-')[3].Split('.')[0], fileInfo.Name);

                        filesCount += 1;
                        progressBar1.PerformStep();
                        Application.DoEvents();
                        filesProgressLabel.Text = "Files  Uploded : " + numberOfProcessedFiles + " out of " + totalNumberOfFiles;

                        //Move and rename the file to destination
                        RenameAndUploadFile(fileInfo.FullName, destinationPath);

                        //Add the moved file information to DAO list collection
                        fileInformationDAOObejct = new CFileInfo();
                        fileInformationDAOObejct.ClientCode = fileInfo.Name.Split('-')[0];
                        fileInformationDAOObejct.DocType = fileInfo.Name.Split('-')[1];
                        fileInformationDAOObejct.Institute = fileInfo.Name.Split('-')[2];
                        fileInformationDAOObejct.PaymentDate = fileInfo.Name.Split('-')[3].Split('.')[0];
                        fileInformationDAOObejct.FileName = fileInfo.Name;
                        if (fileInfo.Name.Split('-')[1] == "CON")
                            fileInformationDAOObejct.FilePath = "CONT";
                        else
                            fileInformationDAOObejct.FilePath = fileInfo.Name.Split('-')[1];

                        if (fileInfo.Name.Split('-')[2] == "CON")
                            fileInformationDAOObejct.FilePath = fileInformationDAOObejct.FilePath + "\\" + "CONT" + "\\";
                        else
                            fileInformationDAOObejct.FilePath = fileInformationDAOObejct.FilePath + "\\" + fileInfo.Name.Split('-')[2] + "\\";

                        fileInformationDAOObejct.FilePath = fileInformationDAOObejct.FilePath + fileInfo.Name.Split('-')[3].Split('.')[0] + "\\";
                        fileInformationDAOObejct.FileSize = fileSize;
                        fileInformationDAOObejct.UploadedDateTime = DateTime.Now;

                        //Add the DAO objec to List collection
                        fileInformationListObject.Add(fileInformationDAOObejct);
                        fileInformationDAOObejct = null;
                    }
                    else
                    {
                        //Unprocessed files count
                        numberOfUnprocessedFiles += 1;

                        //TODO : Write exception as FileName is not in proper format
                        exceptionInfoObject = new CCSVInfo();
                        //exceptionInfoObject.ParentFolderName = fileInfo.Name;
                        exceptionInfoObject.FileName = fileInfo.Name;
                        if (!isValidDate)
                            exceptionInfoObject.Reason = "Date is not in proper format";
                        else
                            exceptionInfoObject.Reason = "File Name is not in proper format";
                        exceptionInfoObject.ParentFolderName = di.Name;
                        exceptionInfoListObject.Add(exceptionInfoObject);
                        exceptionInfoObject = null;
                    }
                }
            }
            catch (Exception ex)
            {
                CLogHelper.Instance.LogErrorInfo(ex, "DMSBusiness.IterateFilesAndAddFileInformationToList" + DateTime.Now);
                throw ex;
            }
        }

        #endregion


        #region "Upload Based on CSV"

        #region " Global Variables "
        static String RepositoryPathString = ConfigurationManager.AppSettings.Get("FileUploadedPath");
        int ActiveFileCountInt = 0;
        int InActiveFileCountInt = 0;
        StringBuilder ErrorFileInfoStringBuilder = new StringBuilder();

        #endregion

        List<CCSVInfo> CVSInfoList = null;

        /// <summary>
        /// This Method will load the csv file and insert those information into the database
        /// </summary>
        public void LoadCSVFile(string v_strCSVFilePath)
        {
            try
            {
                    CVSInfoList = new List<CCSVInfo>();
                    CVSInfoList = (from line in File.ReadAllLines(v_strCSVFilePath)
                                   where
                                    line.Trim().Length > 0
                                   select new CCSVInfo
                                   {
                                       FileId = 0,
                                       FileName = (line.Split(Convert.ToChar(',')))[0],
                                       ClientCode = (line.Split(Convert.ToChar(',')))[1],
                                       ParentFolderName = (line.Split(Convert.ToChar(",")))[2],
                                       IsProcessFlag = 'N',
                                       IsMovedToManualProcess = 'N'
                                   }).ToList();
                    
                //Check whether the History Directory exists, if not create it
                    if (!Directory.Exists(ConfigurationManager.AppSettings.Get("CSVHistoryFolderPath")))
                        Directory.CreateDirectory(ConfigurationManager.AppSettings.Get("CSVHistoryFolderPath"));

                //Check whether the file exists, if exists delete the file and move 
                    if ((System.IO.File.Exists(ConfigurationManager.AppSettings.Get("CSVHistoryFolderPath") + v_strCSVFilePath.Substring(v_strCSVFilePath.LastIndexOf("\\")))))
                    {
                        System.IO.File.Delete(ConfigurationManager.AppSettings.Get("CSVHistoryFolderPath") + v_strCSVFilePath.Substring(v_strCSVFilePath.LastIndexOf("\\")));
                    }
                    File.Move(v_strCSVFilePath, ConfigurationManager.AppSettings.Get("CSVHistoryFolderPath") + "\\" + v_strCSVFilePath.Substring(v_strCSVFilePath.LastIndexOf("\\")));
            }
            catch (Exception ex)
            {
                CLogHelper.Instance.LogErrorInfo(ex, "DMSBusiness.LoadCSVFile" + DateTime.Now);
                throw (ex);
            }                
        }


        /// <summary>
        /// This method will move the files from scanned file path to the repository or Manual rename folder
        /// </summary>
        /// <param name="v_IsValidFilesBool">Flag if to process Valid or invalid files</param>
        public void LoadAndMoveScannedFiles(bool v_IsValidFilesBool, string v_strRootFilePath, ref System.Windows.Forms.ProgressBar progressBar1, ref System.Windows.Forms.Label filesProgressLabel, int totalFilesCount)
        {
            //Declaration
            //List<CCSVInfo> CSVInfoList = null;
            List<CFileInfo> CSVFileInfoList = new List<CFileInfo>();
            dmsDatabaseObject = new DMSDatabase();
            int filesCount = 0;
            try
            {
                //Loop through all the records which are loaded from CSV
                foreach (CCSVInfo objNewCCVInfo in CVSInfoList)
                {
                    filesCount += 1;

                    // Trace the file from the scanned root file path
                    CFileInfo objCFileInfo = TraceScannedFileAndMove(objNewCCVInfo, v_IsValidFilesBool, v_strRootFilePath);

                    progressBar1.Step = 1;
                    progressBar1.PerformStep();
                    Application.DoEvents();
                    filesProgressLabel.Text = "Files  Uploded : " + numberOfProcessedFiles + " out of " + totalFilesCount;
                    Application.DoEvents();
                    //folderProgressLabel.Text = "Files " + filesCount + " out of " + totalFilesCount;

                    if (objCFileInfo != null && objCFileInfo.ClientCode != null)
                    {
                        bool isValidDate = true;


                        if (objCFileInfo.PaymentDate != null)
                        {
                            try { Convert.ToDateTime(objCFileInfo.PaymentDate); }
                            catch { isValidDate = false; }
                        }

                        if (isValidDate == true)
                        {
                            // Add the objects into the list collection to update the status into the database
                            CSVFileInfoList.Add(objCFileInfo);
                        }
                        else
                        {
                            //Add the exception to the list 
                            objNewCCVInfo.Reason = "Date is not in proper format";
                            inActiveCSVInfoListObject.Add(objNewCCVInfo);
                        }
                    }
                    if (objCFileInfo != null)
                        objCFileInfo = null;
                }

                CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "Processed Count : " + numberOfProcessedFiles, "");
                CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "UnProcessed Count : " + inActiveCSVInfoListObject.Count.ToString(), "");

                // Update and insert the records in CSV file table and search table respectively
                dmsDatabaseObject.InsertFileInformationBulkly(CSVFileInfoList, ref inActiveCSVInfoListObject);
            }
            catch (Exception ex)
            {
                CLogHelper.Instance.LogErrorInfo(ex, "DMSBusiness.LoadAndMoveScannedFiles" + DateTime.Now);
                throw (ex);
            }
            finally
            {
                if ((CSVFileInfoList != null))
                {
                    CSVFileInfoList = null;
                }
            }
        }

        /// <summary>
        /// This function will trace the file which is available in the scanned file path and move them into repository or Rename Folder
        /// </summary>
        /// <param name="v_CCSVInfoObject">File Info Object</param>
        /// <param name="v_IsActiveFilesBool">Flag to check if its Active file or not</param>
        /// <returns>CFileInfo object</returns>
        private CFileInfo TraceScannedFileAndMove(CCSVInfo v_CCSVInfoObject, bool v_IsActiveFilesBool, string v_strRootFilePath)
        {
            DirectoryInfo RootDirectoryInfoObject = null;
            CFileInfo CFileInfoObject = null;
            try
            {
                RootDirectoryInfoObject = new DirectoryInfo(v_strRootFilePath);
                CFileInfoObject = GetFileInfoFromDirectory(RootDirectoryInfoObject, ref  v_CCSVInfoObject, v_IsActiveFilesBool);

                //Check if both Old and new Files path present if so move them
                if (CFileInfoObject != null && (!string.IsNullOrEmpty(CFileInfoObject.OldFilePath) & !string.IsNullOrEmpty(CFileInfoObject.FilePath)))
                {
                    MoveFileFromScannedPath(ref CFileInfoObject, ref v_CCSVInfoObject, v_IsActiveFilesBool);

                    //Increment the active and in active file count which is used for logging
                    if (v_IsActiveFilesBool)
                    {
                        numberOfProcessedFiles += 1;
                        ActiveFileCountInt = ActiveFileCountInt + 1;
                    }
                    else
                    {
                        numberOfUnprocessedFiles += 1;
                        InActiveFileCountInt = InActiveFileCountInt + 1;
                    }
                }
                else
                {
                    v_CCSVInfoObject.Reason = "File Not found";
                    inActiveCSVInfoListObject.Add(v_CCSVInfoObject);
                }

                return CFileInfoObject;
            }
            catch (Exception ex)
            {
                v_CCSVInfoObject.IsProcessFlag = 'N';
                CLogHelper.Instance.LogErrorInfo(ex, "DMSBusiness.TraceScannedFileAndMove" + DateTime.Now);
                throw (ex);
            }
            finally
            {
                if ((RootDirectoryInfoObject != null))
                {
                    RootDirectoryInfoObject = null;
                }
                if ((CFileInfoObject != null))
                {
                    CFileInfoObject = null;
                }
            }
        }


        /// <summary>
        /// This Recursive function will loop through the scanned root directory and will get the required file information
        /// </summary>
        /// <param name="v_SearchDirectoryInfoObject">Search DirectoryInfo object</param>
        /// <param name="v_CCSVInfoObject">CSV File Info</param>
        /// <param name="v_IsActiveRecordsBool">Flag for active record or not</param>
        /// <returns>CFileInfo object</returns>
        private CFileInfo GetFileInfoFromDirectory(DirectoryInfo v_SearchDirectoryInfoObject, ref CCSVInfo v_CCSVInfoObject, bool v_IsActiveRecordsBool)
        {
            CFileInfo CFileInfoObject = new CFileInfo();
            DirectoryInfo[] SubDirectoriesInfoObject = null;
            string strDocFldrName = "";
            string strInstFldrName = "";
            try
            {
                //Check if the currect directory is equal to the search directory
                if (v_SearchDirectoryInfoObject.Name != ConfigurationManager.AppSettings.Get("ContractNotesFolderName"))
                {
                    if (v_SearchDirectoryInfoObject.Name == v_CCSVInfoObject.ParentFolderName)
                    {
                        //Check if there are atleast one file available
                        if (v_SearchDirectoryInfoObject.GetFiles(v_CCSVInfoObject.FileName).Length > 0)
                        {
                            //Load inactive records information. Which is used to moved to rename folder
                            if (!v_IsActiveRecordsBool)
                            {
                                CFileInfoObject.OldFileName = v_CCSVInfoObject.FileName;
                                CFileInfoObject.OldFilePath = v_SearchDirectoryInfoObject.FullName;

                                CFileInfoObject.FileName = v_CCSVInfoObject.FileName;
                            }
                            //Load active records information. Which is used to moved to repository folder
                            else
                            {
                                CFileInfoObject.OldFileName = v_CCSVInfoObject.FileName;
                                CFileInfoObject.OldFilePath = v_SearchDirectoryInfoObject.FullName;

                                if (!string.IsNullOrEmpty(v_SearchDirectoryInfoObject.ToString()) && v_SearchDirectoryInfoObject.ToString().Split('-').Length == 3)
                                {
                                    CFileInfoObject.DocType = v_SearchDirectoryInfoObject.ToString().Split('-')[0];
                                    CFileInfoObject.Institute = v_SearchDirectoryInfoObject.ToString().Split('-')[1];
                                    CFileInfoObject.PaymentDate = v_SearchDirectoryInfoObject.ToString().Split('-')[2];

                                    strDocFldrName = CFileInfoObject.DocType;
                                    strInstFldrName = CFileInfoObject.Institute;

                                    CFileInfoObject.FileName = v_CCSVInfoObject.ClientCode + "-" + v_SearchDirectoryInfoObject.ToString() + v_SearchDirectoryInfoObject.GetFiles(v_CCSVInfoObject.FileName)[0].Extension;

                                    // A folder with CON cannot be created in windows OS so to overcome change it to CONT
                                    if (strDocFldrName == "CON") strDocFldrName = "CONT";
                                    if (strInstFldrName == "CON") strInstFldrName = "CONT";

                                    CFileInfoObject.FilePath = strDocFldrName + "\\" + strInstFldrName + "\\" + CFileInfoObject.PaymentDate + "\\";

                                    CFileInfoObject.FileSize = Convert.ToString(Math.Round(Convert.ToDouble(v_SearchDirectoryInfoObject.GetFiles(v_CCSVInfoObject.FileName)[0].Length) / 1024, 0, MidpointRounding.AwayFromZero)) + " KB";
                                    CFileInfoObject.ClientCode = v_CCSVInfoObject.ClientCode;

                                    CFileInfoObject.FileId = v_CCSVInfoObject.FileId;

                                }
                                else
                                {                                  
                                    //if the parent folder name is not in correct format
                                    exceptionInfoObject = new CCSVInfo();
                                    exceptionInfoObject.Reason = "Folder Name is not in proper format";
                                    exceptionInfoObject.ParentFolderName = v_CCSVInfoObject.ParentFolderName;
                                    exceptionInfoObject.ClientCode = v_CCSVInfoObject.ClientCode;
                                    exceptionInfoObject.FileName = v_CCSVInfoObject.FileName;

                                    //Add the exception to the list
                                    exceptionInfoListObject.Add(exceptionInfoObject);
                                    exceptionInfoObject= null;
                                }
                            }
                            return CFileInfoObject;
                        }
                    }
                }
                else
                {
                    //Check if there are atleast one file available
                    if (v_SearchDirectoryInfoObject.GetFiles(v_CCSVInfoObject.FileName).Length > 0)
                    {
                        //Load inactive records information. Which is used to moved to rename folder
                        if (!v_IsActiveRecordsBool)
                        {
                            CFileInfoObject.OldFileName = v_CCSVInfoObject.FileName;
                            CFileInfoObject.OldFilePath = v_SearchDirectoryInfoObject.FullName;

                            CFileInfoObject.FileName = v_CCSVInfoObject.FileName;
                        }
                        //Load active records information. Which is used to moved to repository folder
                        else
                        {
                            CFileInfoObject.OldFileName = v_CCSVInfoObject.FileName;
                            CFileInfoObject.OldFilePath = v_SearchDirectoryInfoObject.FullName;

                            if (!string.IsNullOrEmpty(v_SearchDirectoryInfoObject.ToString()) && v_CCSVInfoObject.FileName.ToString().Split('-').Length == 4)
                            {
                                CFileInfoObject.ClientCode = v_CCSVInfoObject.FileName.ToString().Split('-')[0];
                                CFileInfoObject.DocType = v_CCSVInfoObject.FileName.ToString().Split('-')[1];
                                CFileInfoObject.Institute = v_CCSVInfoObject.FileName.ToString().Split('-')[2];
                                CFileInfoObject.PaymentDate = v_CCSVInfoObject.FileName.ToString().Split('-')[3].Split('.')[0];
                                CFileInfoObject.FileName = v_CCSVInfoObject.FileName.ToString();

                                strDocFldrName = CFileInfoObject.DocType;
                                strInstFldrName = CFileInfoObject.Institute;

                                // A folder with CON cannot be created in windows OS so to overcome change it to CONT
                                if (strDocFldrName == "CON") strDocFldrName = "CONT";
                                if (strInstFldrName == "CON") strInstFldrName = "CONT";

                                CFileInfoObject.FilePath = strDocFldrName + "\\" + strInstFldrName + "\\" + CFileInfoObject.PaymentDate + "\\";

                                CFileInfoObject.FileSize = Convert.ToString(Math.Round(Convert.ToDouble(v_SearchDirectoryInfoObject.GetFiles(v_CCSVInfoObject.FileName)[0].Length) / 1024, 0, MidpointRounding.AwayFromZero)) + " KB";

                                CFileInfoObject.FileId = v_CCSVInfoObject.FileId;

                            }
                            else
                            {
                                //if the parent folder name is not in correct format
                                    exceptionInfoObject = new CCSVInfo();
                                    exceptionInfoObject.Reason = "Folder Name is not in proper format";
                                    exceptionInfoObject.ParentFolderName = v_CCSVInfoObject.ParentFolderName;
                                    exceptionInfoObject.ClientCode = v_CCSVInfoObject.ClientCode;
                                    exceptionInfoObject.FileName = v_CCSVInfoObject.FileName;

                                    //Add the exception to the list
                                    exceptionInfoListObject.Add(exceptionInfoObject);
                                    exceptionInfoObject= null;
                            }
                        }
                        return CFileInfoObject;
                    }
                }

                SubDirectoriesInfoObject = v_SearchDirectoryInfoObject.GetDirectories("*");
                //Loop through all the folders
                foreach (DirectoryInfo objNewDirectory in SubDirectoriesInfoObject)
                {
                    CFileInfoObject = GetFileInfoFromDirectory(objNewDirectory, ref v_CCSVInfoObject, v_IsActiveRecordsBool);
                    //Check if the File exist and if so return the parent directory
                    if (CFileInfoObject != null && !string.IsNullOrEmpty(CFileInfoObject.OldFilePath))
                    {
                        return CFileInfoObject;
                    }
                }
            }
            catch (Exception ex)
            {
                //CLogHelper.Instance.LogErrorInfo(ex, "DMSBusiness.GetFileInfoFromDirectory");
                throw (ex);
            }
            finally
            {
                if (CFileInfoObject != null)
                    CFileInfoObject = null;
                if (SubDirectoriesInfoObject != null)
                    SubDirectoriesInfoObject = null;
            }

            //CLogHelper.Instance.LogProcessInfo(System.Diagnostics.TraceEventType.Information, "DMSBusiness.GetFileInfoFromDirectory()", "... Completed With Active Flag as " + v_IsActiveRecordsBool.ToString());
            return CFileInfoObject;
        }


        /// <summary>
        /// This Method will move the files from Scanned path to Repository or Manual rename folder path
        /// </summary>
        /// <param name="v_CFileInfoObject">Reference CFileInfo object</param>
        /// <param name="v_CCSVInfoObject">Reference CCSVInfo object</param>
        /// <param name="v_IsMoveToRepositoryBool">Flag to chech if to move active or inactive files</param>
        private void MoveFileFromScannedPath(ref CFileInfo v_CFileInfoObject, ref CCSVInfo v_CCSVInfoObject, bool v_IsMoveToRepositoryBool)
        {
            string strNewFolderDirectory = string.Empty;
            string strNewFileFullPath = string.Empty;
            string strOldFileFullPath = string.Empty;

            try
            {
                if (!v_IsMoveToRepositoryBool)
                {
                    strNewFolderDirectory = v_CFileInfoObject.FilePath;
                    strNewFileFullPath = v_CFileInfoObject.FilePath + "\\" + v_CFileInfoObject.FileName;
                    strOldFileFullPath = v_CFileInfoObject.OldFilePath + "\\" + v_CFileInfoObject.OldFileName;
                }
                else
                {
                    strNewFolderDirectory = RepositoryPathString + v_CFileInfoObject.FilePath;
                    strNewFileFullPath = RepositoryPathString + v_CFileInfoObject.FilePath + v_CFileInfoObject.FileName;
                    strOldFileFullPath = v_CFileInfoObject.OldFilePath + "\\" + v_CFileInfoObject.OldFileName;
                }


                //Check if the directory exist if not create
                if (!System.IO.Directory.Exists(strNewFolderDirectory))
                    System.IO.Directory.CreateDirectory(strNewFolderDirectory);


                //Check if the file exist if so replace the file with the new one
                if (File.Exists(strNewFileFullPath))
                    System.IO.File.Delete(strNewFileFullPath);


                //Check and move the file from scanned to repository or Manual Rename folder
                if (File.Exists(strOldFileFullPath) & !File.Exists(strNewFileFullPath))
                {
                    //File.Copy(strOldFileFullPath, strNewFileFullPath);
                    File.Move(strOldFileFullPath, strNewFileFullPath);
                    v_CFileInfoObject.UploadedDateTime = DateTime.Now;
                    if (!v_IsMoveToRepositoryBool)
                    {
                        v_CCSVInfoObject.IsProcessFlag = 'N';
                        v_CCSVInfoObject.IsMovedToManualProcess = 'Y';
                    }
                    else
                    {
                        v_CCSVInfoObject.IsProcessFlag = 'Y';
                    }
                }
                else
                {

                   //if the parent folder name is not in correct format
                    exceptionInfoObject = new CCSVInfo();
                                    exceptionInfoObject.Reason = "File not found";
                                    exceptionInfoObject.ParentFolderName = v_CCSVInfoObject.ParentFolderName;
                                    exceptionInfoObject.ClientCode = v_CCSVInfoObject.ClientCode;
                                    exceptionInfoObject.FileName = v_CCSVInfoObject.FileName;

                                    //Add the exception to the list
                                    exceptionInfoListObject.Add(exceptionInfoObject);
                                    exceptionInfoObject= null;
                }
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        #endregion
    }
}
