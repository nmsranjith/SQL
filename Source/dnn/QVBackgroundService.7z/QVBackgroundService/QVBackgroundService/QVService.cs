﻿using System;
using log4net;

namespace QVBackgroundService
{
    public class QVService
    {
        private static ILog Log = null;

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            log4net.Config.XmlConfigurator.Configure();
            Log = LogManager.GetLogger("");

            Log.Info("QV Service Started");
            CheckInReminder reminder = new CheckInReminder();
            reminder.SendCheckInReminders();
            Log.Info("QV Service Ended");
        }
    }
}
