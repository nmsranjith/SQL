﻿
namespace QVBackgroundService
{
    class CheckInUser
    {
        private string _firstName;
        private string _lastName;
        private string _emailAddress;
        private string _managerEmailAddress;
        private int _statusID;

        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }

        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }

        public string UserName
        {
            get { return _firstName + ' ' + _lastName; }
        }

        public string EmailAddress
        {
            get { return _emailAddress; }
            set { _emailAddress = value; }
        }

        public string ManagerEmailAddress
        {
            get { return _managerEmailAddress; }
            set { _managerEmailAddress = value; }
        }

        public int StatusID
        {
            get { return _statusID; }
            set { _statusID = value; }
        }
    }



}
