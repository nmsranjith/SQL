﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using EmailService;
using System.Configuration;
using System.Collections;
using System.Net.Mail;
using log4net;
using QV3DBData;
using System.Threading;

namespace QVBackgroundService
{
    class CheckInReminder
    {

        public CheckInReminder()
        {

        }

        #region "Private Methods"

        //private DateTime GetCheckInByDateTime()
        //{
        //    DateTime checkInBy = DateTime.Today;
        //    string tmpTime = ConfigurationManager.AppSettings["checkInByTime"];
        //    TimeSpan checkInByTime;
        //    if (!TimeSpan.TryParse(tmpTime, out checkInByTime))
        //    {
        //        throw new ConfigurationErrorsException("AppSettings[checkInByTime] is not specified properly in configuration.");
        //    }

        //    checkInBy = checkInBy.Add(checkInByTime);

        //    return checkInBy;
        //}

        private IList<CheckInUser> GetPendingCheckInUsers()
        {
            IList<GetPendingCheckInUsersResult> qv = Queries.GetPendingCheckInUsers();
            List<CheckInUser> list = new List<CheckInUser>();
            foreach (GetPendingCheckInUsersResult res in qv)
            {
                CheckInUser user = new CheckInUser()
                {
                    EmailAddress = res.EmailAddress,
                    FirstName = res.FirstName,
                    LastName = res.LastName,
                    ManagerEmailAddress = res.ManagerEmailAddress,
                    StatusID = res.StatusID.HasValue ? (int)res.StatusID : 6
                };
                list.Add(user);
            }
            return list;

        }


        #endregion

        public void SendCheckInReminders()
        {
            try
            {
                //collect all email ids for logging
                StringBuilder emailIds = new StringBuilder();

                StringBuilder strUsersWithoutEmail = new StringBuilder();
                StringBuilder strUsersWithoutManagersEmail = new StringBuilder();
                int milliseconds = int.Parse(ConfigurationManager.AppSettings["maildeliveryinterval"].ToString());
                bool testMode = ConfigurationManager.AppSettings["TestMode"].ToString() == "YES" ? true : false;
                string testModeEmailID = ConfigurationManager.AppSettings["TestModeRecipient"].ToString();

                IList<CheckInUser> userList = GetPendingCheckInUsers();

                if (userList.Count == 0)
                {
                    LogHelper.Log.Info("All Users are checked in. No reminders were sent.");
                    return;
                }

                //string templateName = Path.Combine(System.Environment.CurrentDirectory, @"EmailTemplates\CheckInReminder.txt");
                string templateName = @"..\..\EmailTemplates\CheckInReminder.txt";
                IMailService smtpMailService = new SmtpMailService();
                smtpMailService.Server = ConfigurationManager.AppSettings["SMTP_IPAddress"];

                MailMessage mailMessage = new MailMessage();
                IMailTemplateHelper mailTemplateHelper = new MailTemplateHelper(templateName);
                mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["FromEmailAddress"],
                                                    ConfigurationManager.AppSettings["FromName"]);
                mailMessage.Subject = "QV";

                Hashtable htReplaceName = new Hashtable(2);
                htReplaceName.Add("{UserName}", "");
                htReplaceName.Add("{CheckInTime}", ConfigurationManager.AppSettings["checkInByTimeText"]);

                string[] strExceptionStatusIDs = ConfigurationManager.AppSettings["ExceptionStatusIDs"].Split(',');

                foreach (CheckInUser user in userList)
                {
                    bool blnExceptionStatusFound = false;
                    foreach (string strExceptionStatusID in strExceptionStatusIDs)
                    {
                        if (user.StatusID == ConvertToInt(strExceptionStatusID, 0))
                        {
                            blnExceptionStatusFound = true;
                            break;
                        }
                    }
                    if (blnExceptionStatusFound)
                        continue;

                    if (!string.IsNullOrEmpty(user.EmailAddress))
                    {
                        mailMessage.To.Clear();
                        mailMessage.Bcc.Clear();
                        if (!testMode)
                            mailMessage.To.Add(user.EmailAddress);
                        else
                            mailMessage.To.Add(testModeEmailID);

                        if (!string.IsNullOrEmpty(user.ManagerEmailAddress))
                        {
                            if (!testMode)
                                mailMessage.Bcc.Add(user.ManagerEmailAddress);
                            else
                                mailMessage.Bcc.Add(testModeEmailID);
                        }
                        else
                        {
                            strUsersWithoutManagersEmail.AppendLine(user.UserName);
                        }
                        htReplaceName["{UserName}"] = user.UserName;
                        mailMessage.Body = mailTemplateHelper.ReplaceKeyWithValue(htReplaceName);
                        if (LogHelper.Log.IsDebugEnabled)
                            LogHelper.Log.Debug(String.Format("An Email is ready to be sent for: {0}Name -- '{1}'{0}EmailAddress -- {2}",
                                Environment.NewLine, user.FirstName + " " + user.LastName, user.EmailAddress));

                        Thread.Sleep(milliseconds);
                        smtpMailService.Send(mailMessage);
                        emailIds.Append(user.EmailAddress);
                    }
                    else
                    {
                        strUsersWithoutEmail.AppendLine(user.UserName);
                    }
                }

                ///Site Administrator Email.
                if ((strUsersWithoutEmail.Length > 0) || (strUsersWithoutManagersEmail.Length > 0))
                {
                    if (LogHelper.Log.IsDebugEnabled)
                        LogHelper.Log.Debug("Sending site Admin email...");
                    Hashtable htReplaceKeyValue = new Hashtable(3);
                    htReplaceKeyValue.Add("{CheckInTime}", ConfigurationManager.AppSettings["checkInByTimeText"]);
                    htReplaceKeyValue.Add("{UsersWithoutEmail}", "");
                    htReplaceKeyValue.Add("{UsersWithoutManagersEmail}", "");
                    if (strUsersWithoutEmail.Length > 0)
                        htReplaceKeyValue["{UsersWithoutEmail}"] = strUsersWithoutEmail.ToString();
                    if (strUsersWithoutManagersEmail.Length > 0)
                        htReplaceKeyValue["{UsersWithoutManagersEmail}"] = strUsersWithoutManagersEmail.ToString();

                    mailMessage.To.Clear();
                    mailMessage.Bcc.Clear();
                    if (!testMode)
                        mailMessage.To.Add(ConfigurationManager.AppSettings["QvAdmin"]);
                    else
                        mailMessage.To.Add(testModeEmailID);
                    //string strAdminTemplateName = Path.Combine(System.Environment.CurrentDirectory, @"EmailTemplates\QvAdminEmailTemplate.txt");
                    string strAdminTemplateName = @"..\..\EmailTemplates\QvAdminEmailTemplate.txt";
                    mailMessage.Body = mailTemplateHelper.ReplaceKeyWithValue(htReplaceKeyValue, strAdminTemplateName);
                    Thread.Sleep(milliseconds);
                    smtpMailService.Send(mailMessage);
                    if (LogHelper.Log.IsDebugEnabled)
                        LogHelper.Log.Debug("Sent Admin email...");
                }
                LogHelper.Log.Info("Check in email reminders where successfully sent to " + emailIds.ToString());
            }
            catch (Exception ex)
            {
                LogHelper.Log.Error("Error occurred while emailing Check In Reminders", ex);
            }
        }

        /// <summary>
        /// Convert Object to Integer. Ignore exceptions and if object/string does not contain a valid int, return defaultValue.
        /// </summary>
        /// <param name="val">Value to be converted to int(Mostly string)</param>
        /// <param name="defaultValue">Value to be returned if there is a conversion error.</param>
        /// <returns></returns>
        public static int ConvertToInt(object val, int defaultValue)
        {
            try
            {
                if (val != null)
                    return int.Parse(val.ToString());
                else
                    return defaultValue;
            }
            catch (FormatException)
            {
                return defaultValue;
            }
            catch (InvalidCastException)
            {
                return defaultValue;
            }
        }

    }

    public class LogHelper
    {
        private static ILog _log = null;
        public static ILog Log
        {
            get
            {
                if (_log == null)
                    _log = LogManager.GetLogger("CheckInReminder");
                return _log;
            }
        }
    }
}
